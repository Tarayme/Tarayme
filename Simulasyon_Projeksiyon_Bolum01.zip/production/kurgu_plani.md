# Kurgu planı — Bölüm 01

## Görsel dil

- 16:9, 1920×1080.
- Ana palet: `#080C11` siyah, `#F4F1E8` kırık beyaz, `#00D8FF` camgöbeği, `#FF6B35` talihsizlik/turuncu.
- Fırsat: içi boş camgöbeği halka. Talihsizlik: içi boş turuncu halka.
- İnsan/ajan: küçük dolu nokta. Başlangıca yakın kırık beyaz; düşüş turuncuya, yükseliş camgöbeğine gider.
- Uzun açıklama yerine sayıyı ve değişimi göster. Aynı anda en fazla üç büyük bilgi.
- Her sonuç ekranında küçük “MODEL SONUCU — GERÇEK DÜNYA TAHMİNİ DEĞİL” ibaresi kullanılabilir.

## Zaman kodlu kurgu

| Süre | Anlatı | Görsel/varlık | Kurgu notu |
| --- | --- | --- | --- |
| 00:00–00:06 | Bin sanal insan | `simulation_preview_1080p.mp4` ilk kare, hızlı yakınlaşma | Müzik doğrudan başlasın; logo introsu yok |
| 00:06–00:14 | 2.560 ve 1,25 karşılaştırması | `04_dort_hayat.png` içinden iki çizgi + büyük sayılar | Sonucu göster, nedenini sakla |
| 00:14–00:25 | Bin evren sorusu | `05_coklu_evren_sonuclari.png`, histogram bulanık başlayıp netleşir | Ekran: “1.000 EVREN” |
| 00:25–01:05 | Temel soru ve sınır | Siyah fonda portal; “YETENEK / ŞANS / SONUÇ” üç düğüm | 3–4 saniyede bir ölçek değişimi |
| 01:05–01:25 | 1.000 ajan, 10 puan | Animasyon başlangıç karesi; herkes beyaz | Sayaç: `N=1.000`, `C₀=10` |
| 01:25–01:45 | Yetenek dağılımı | `03_yetenek_ve_basari.png` yalnız x ekseni veya yeniden çizilmiş çan eğrisi | “Yetenek = fırsatı değerlendirme olasılığı” |
| 01:45–02:15 | Fırsat/talihsizlik kuralları | Portal/halka animasyonu: fırsat `×2`, talihsizlik `÷2` | Her kural ayrı ses efekti |
| 02:15–03:05 | İlk 20–40 yıl | `simulation_preview_1080p.mp4` tam kullanım | Önizleme 20,25 sn; gerektiğinde %70–80 hız ve kesmelerle uzat |
| 03:05–04:30 | Dört kişi | `04_dort_hayat.png`; çizgileri ayrı ayrı maskeyle aç | İsimler: A0646, A0622, A0743, A0830 |
| 04:30–05:00 | Son dağılım | `02_40_yil_sonra_dagilim.png` | Önce başlangıç çizgisi, sonra tam eğri |
| 05:00–05:30 | Tipik evren seçimi | Bin küçük kutu; ortadaki kutu camgöbeği | Metin: “MEDYAN GINI'YE EN YAKIN” |
| 05:30–06:05 | En yetenekli 7/1.000 | `05_coklu_evren_sonuclari.png` sol panel | Büyük sayaç: `7 / 1.000` |
| 06:05–06:45 | 0,06 ve 0,92 ilişki | Aynı görselin sağ paneli | “Bu modelde” ibaresi ekranda kalsın |
| 06:45–07:15 | Dört kural | Dört portal kartı; bütçe her kartta `8.000` | Sonuçları henüz göstermeme |
| 07:15–08:15 | Kural sonuçları | `06_senaryo_karsilastirma.png` | Çubukları tek tek aç; önce Gini, sonra yüksek yetenekli başarı oranı |
| 08:15–08:45 | Model sınırları | Ekrana sırayla: eğitim, aile, ağlar, sağlık, davranış | Üzerlerinden ince çizgi değil; “MODELLENMEDİ” etiketi |
| 08:45–09:10 | Sonuç | Portal tek ışını üç olasılığa böler | Kanal sloganı ilk kez burada tam görünür |
| 09:10–09:35 | Sonraki deney | İki kart: “TEK BENCİL” / “TEK İŞBİRLİKÇİ” | Yorum çağrısı, ardından kısa logo sting |

## Varlık eşlemesi

- Konu seçimi: `outputs/charts/01_konu_puanlama.png`
- Son dağılım: `outputs/charts/02_40_yil_sonra_dagilim.png`
- Yetenek/başarı saçılımı: `outputs/charts/03_yetenek_ve_basari.png`
- Dört hayat: `outputs/charts/04_dort_hayat.png`
- Bin evren: `outputs/charts/05_coklu_evren_sonuclari.png`
- Dört kural: `outputs/charts/06_senaryo_karsilastirma.png`
- Hareketli dünya: `outputs/simulation_preview_1080p.mp4`
- Özel yeniden animasyon: `outputs/selected_seed_animation_data.csv`
- Olay noktaları: `outputs/selected_seed_event_positions.csv`

## Ses tasarımı

- Fırsat temasında kısa, temiz yüksek frekanslı klik.
- Talihsizlikte düşük, kuru vurgu; dramatik “felaket” efekti kullanma.
- Katlanma anlarında arpej veya yükselen ton; sayılar büyürken ses de çoğalsın.
- 05:30'daki “yedi” açıklamasından hemen önce 0,3–0,5 sn sessizlik.
- Sınırlar bölümünde müziği incelt; savunmacı değil, bilimsel ton.

## Veri kullanım notu

CSV'lerde ondalık ayırıcı nokta ve UTF-8 başlık kullanılır. After Effects/Blender/TouchDesigner içe aktarımında:

- Ajan rengi: `log2_growth_from_start`
- Ajan konumu: `x`, `y`
- Zaman: `step` veya `career_year`
- Fırsat/talihsizlik: `event_type`
- Öne çıkarılan kişiler: `featured_label_tr`

