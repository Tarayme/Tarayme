# Anlatım metni — Bölüm 01

Hedef süre: 9–10 dakika  
Ton: sakin, meraklı, kesin konuşurken sınırlarını belirten  
Okuma hızı: dakikada yaklaşık 145–155 kelime

## 00:00–00:25 — Soğuk açılış

Ekrandaki bin noktanın her biri, yirmi yaşında hayata başlayan sanal bir insan.

Hepsine aynı başlangıcı verdik: on puan. Fakat yetenekleri ve hayat boyunca karşılaşacakları olaylar farklı.

Kırk yılın sonunda içlerinden biri iki bin beş yüz altmış puana ulaştı. Grubun en yetenekli kişisi ise bir virgül yirmi beş puanda kaldı.

Peki bu yalnızca tek bir tuhaf tesadüf müydü?

Aynı deneyi bin ayrı evrende yeniden çalıştırdık.

## 00:25–01:05 — Soru

Sorumuz basit görünüyor: Başarı, yeteneğin sonucu mu; yoksa doğru zamanda doğru olayla karşılaşmanın mı?

Bunu gerçek insanları tek bir sayıya indirerek cevaplayamayız. Zaten bu videonun amacı da gerçek hayatı bütünüyle açıkladığını iddia etmek değil.

Yapabileceğimiz şey daha dar: kuralları görünür bir yapay dünya kurmak, o dünyayı tekrar tekrar çalıştırmak ve aynı kurallar altında hangi mekanizmanın ne ürettiğine bakmak.

Modelimiz, fizikçi Alessandro Pluchino ve çalışma arkadaşlarının “Yetenek ve Şans” adlı ajan tabanlı araştırmasından uyarlandı.

## 01:05–02:15 — Kurallar

Bin kişi var. Her biri on başarı puanıyla başlıyor.

Buradaki “yetenek” zekâ puanı değil. Bir insanın önüne çıkan fırsatı değerlendirebilme olasılığı. Çalışma, beceri, kararlılık ve risk alma gibi birçok özelliği tek bir basit sayıda topluyoruz.

Yeteneklerin çoğu ortalamaya yakın. Ortalama sıfır virgül altmış. Çok düşük ve çok yüksek değerler daha seyrek.

Dünyada ayrıca beş yüz hareketli olay var. Yarısı fırsat, yarısı talihsizlik. Her altı ayda rastgele bir yöne ilerliyorlar.

Bir fırsat bir kişiye değdiğinde, o kişi yeteneği oranında bu fırsatı değerlendirebiliyor. Başarırsa puanı ikiye katlanıyor.

Bir talihsizlik değdiğinde ise puanı yarıya iniyor. Model burada acımasız: yetenek, kazayı veya hastalığı otomatik olarak engellemiyor.

Kırk yıllık kariyer, seksen yarıyıl demek.

Kurallar bunlar. Gizli karar yok. Sonucu sonradan değiştiren anlatıcı yok.

## 02:15–03:05 — İlk yıllar

Başlangıçta herkes aynı görünüyor. İlk birkaç yılda küçük farklar oluşuyor; sonra bu farklar katlanmaya başlıyor.

Çünkü sistem toplama değil, çarpma sistemi. On puanlık bir insanın fırsatı yirmi puan yaratıyor. Yüz altmış puanlık aynı fırsat ise üç yüz yirmi yaratıyor.

Erken gelen bir avantaj, sonraki fırsatın büyüklüğünü de değiştiriyor. Erken gelen bir talihsizlik de aynı biçimde aşağı doğru katlanıyor.

Yirminci yılda eşitsizlik artık görünür. Otuzuncu yılda birkaç kişi kalabalıktan kopuyor. Kırkıncı yılda başlangıçtaki yatay çizginin yerini uzun bir kuyruk alıyor.

## 03:05–04:30 — Dört hayat

Bu tipik evrenden dört kişiyi izleyelim.

A sıfır altı dört altı. Yeteneği sıfır virgül altmış altı. Yani iyi ama olağanüstü değil; yetenek sıralamasında iki yüz altmış beşinci.

Hayatı boyunca sekiz fırsatla karşılaşıyor. Sekizini de değerlendiriyor ve hiç talihsizlik yaşamıyor. Son puanı: iki bin beş yüz altmış. Bu evrenin kazananı o.

A sıfır altı iki iki ise grubun en yetenekli kişisi. Yeteneği sıfır virgül seksen dokuz. Karşısına yalnız bir fırsat, dört talihsizlik çıkıyor. Kırk yılın sonunda ondan geriye bir virgül yirmi beş puan kalıyor.

A sıfır yedi dört üç, en yetenekli yüzde beşin içinde. Ama on ayrı talihsizlik yaşıyor ve tek bir fırsatla bile karşılaşmıyor. Sonucu başlangıcının binde birinden daha düşük.

Bir de A sıfır sekiz üç sıfır var. Yeteneği ortalamaya yakın: sıfır virgül altmış iki. On iki fırsat görüyor, yedisini kullanıyor, hiç talihsizlik yaşamıyor ve bin iki yüz seksen puana ulaşıyor.

Bu dört çizginin söylediği şey “yetenek gereksiz” değil. Fırsat geldiğinde onu değerlendirmek için yetenek gerekiyor. Fakat fırsat hiç gelmezse, en yüksek yetenek bile kullanılmadan kalıyor.

## 04:30–05:30 — Tek evrenin sonucu

Kırkıncı yılın sonunda en üst yüzde bir, toplam puanın yüzde otuz yedisini tutuyor. En üst yüzde yirmi ise yaklaşık yüzde yetmiş sekizini.

Kazananın yeteneği grubun yalnızca yüzde yetmiş dördüncü yüzdeliğinde. En yetenekli kişi başlangıç puanının sekizde birine düşmüş durumda.

Ama hâlâ önemli bir itiraz var: Belki özellikle dramatik bir dünya seçtik.

Seçmedik.

Ekranda izlediğiniz dünya, bin koşu içinde eşitsizlik değeri medyana en yakın olan dünya. Ne en adaletsiz, ne en dengeli. Ortadaki örnek.

Şimdi bütün evrenlere bakalım.

## 05:30–06:45 — Bin evren

Her evrende bin yeni hayat oluşturduk. Toplam bir milyon sanal kariyer.

En yetenekli kişi, bin evrenin yalnızca yedisinde birinci oldu. Yani yüzde sıfır virgül yedi.

Kazananın en yetenekli yüzde birin içinde olma oranı da yalnızca yüzde dört virgül beş.

Kazananların medyanı, yetenek sıralamasında yaklaşık yüzde yetmiş beşinci yüzdelikteydi. Başka bir deyişle, kazananlar genellikle yeteneksiz değildi; fakat neredeyse hiçbir zaman en yetenekli de değildi.

Bu modelde yetenek ile sonuç arasındaki sıra ilişkisi sıfır virgül sıfır altı. Karşılaşılan dışsal fırsat ve talihsizlik dengesiyle sonuç arasındaki ilişki ise sıfır virgül doksan iki.

Bu rakamlar gerçek dünyaya ait değil; kurduğumuz dünyanın matematiğine ait. Ama mekanizma net: çarpan etkisi bulunan bir sistemde küçük rastlantılar zamanla devasa sonuçlara dönüşebiliyor.

## 06:45–08:15 — Kuralı değiştirmek

Peki sonuç yalnızca teşhis mi? Aynı dünyaya, aynı toplam fırsat bütçesini farklı biçimlerde dağıtırsak ne olur?

Her beş yılda toplam bin ek puan veriyoruz.

Birinci kural: puanları o anda en başarılı yüzde ona ver.

İkinci kural: rastgele seçilen yüzde ona ver.

Üçüncü kural: herkese yalnız bir puan ver.

Toplam bütçe aynı. Yalnız dağıtım değişiyor.

Desteksiz dünyada yüksek yeteneklilerin yaklaşık yüzde otuz biri başlangıç puanını aşabiliyor.

Geçmiş kazananları desteklediğimizde bu oran yalnızca yüzde otuz dörde çıkıyor; eşitsizlik ise sıfır virgül seksen bire yükseliyor. Sistem, önceden şanslı olanların avantajını büyütüyor.

Rastgele yüzde ona destek verdiğimizde yüksek yeteneklilerin yüzde altmışı başlangıcı aşabiliyor.

Herkese küçük destek verdiğimizde oran yüzde yetmiş bire ulaşıyor ve eşitsizlik sıfır virgül altmış beşe düşüyor.

Bu da gerçek dünya için hazır bir politika reçetesi değil. Modelde motivasyon, vergi, rekabet, aile, eğitim ve davranış değişimi yok. Yalnızca şu mekanizmayı gösteriyor: kimin gerçekten yetenekli olduğunu sonuçtan sonra anlamaya çalışıyorsanız, geçmiş kazananlara daha fazla fırsat vermek ilk şansı başarıyla karıştırabilir.

## 08:15–09:10 — Sonuç ve sınır

Bu deneyden çıkarılabilecek en dürüst sonuç şu:

Başarı, yeteneğin kusursuz bir ölçüsü değildir.

Yetenek olasılığı değiştirir. Çaba, gelen fırsatı değerlendirmeyi kolaylaştırır. Fakat hangi fırsatın ne zaman geleceğini ve hangi talihsizliğin yolu keseceğini tamamen kontrol etmez.

Dolayısıyla başarılı birine bakıp her şeyi kişisel üstünlükle; başarısız birine bakıp her şeyi kişisel yetersizlikle açıklamak, sistemdeki rastlantıyı görünmez yapar.

Bu simülasyon hayatın cevabı değil. Bir düşünce laboratuvarı. Kurallarını biliyoruz, bin kez çalıştırabiliyoruz ve sonucuna itiraz edebiliyoruz.

Zaten bu kanalın işi de bu olacak.

Geleceği bilmiyoruz; ihtimalleri çalıştırıyoruz.

## 09:10–09:35 — Kapanış / sonraki deney

Bir sonraki deney için iki seçenek var:

Bin kişinin arasına tek bir sürekli işbirlikçi mi bırakalım, tek bir sürekli bencil mi?

Yorumlarda önce tahmininizi yazın. Sonra iki dünyayı da çalıştıracağız.

Bu, Simülasyon Projeksiyon.

## Okuma notları

- “Yetenek” kelimesini her ilk kullanımda “fırsatı değerlendirme olasılığı” diye aç.
- “Korelasyon” yerine seslendirmede “sıra ilişkisi” denebilir; ekranda Spearman yazabilir.
- Tüm genel sonuçlardan önce veya sonra “bu modelde” ifadesini koru.
- 1,25 Türkçe seslendirmede “bir virgül yirmi beş”; 0,0098 “yaklaşık yüzde birin binde biri” şeklinde sadeleştirilebilir.
- Politik kısımda kesin reçete dili kullanma; model sınırları ekranda en az dört saniye görünmeli.

