# Başlık, kapak ve yayın metni

## Önerilen ana paket

Başlık:

> **1.000 Kişi Aynı Parayla Başladı: En Yetenekli Kazandı mı?**

Kapak yazısı:

> **YETENEK YETMEDİ**

Kapak kompozisyonu:

- Siyah zemin ve kanalın camgöbeği çizgileri.
- Ortada olasılık portalı.
- Sol tarafta turuncu çerçeveli “EN YETENEKLİ”: `0,89 → 1,25`.
- Sağ tarafta camgöbeği çerçeveli “KAZANAN”: `0,66 → 2.560`.
- Küçük altta: `1.000 EVREN`.
- Başlık ve kapak aynı cümleyi tekrar etmesin; kapak sonuç, başlık soru taşısın.
- Kişi yüzü kullanma. İki büyük nokta/ajan ve aralarında portal, kanalın kimliğini daha iyi kurar.

## Başlık alternatifleri

1. **1.000 Hayatı 40 Yıl Simüle Ettik: Başarı Şans mı?**
2. **En Yetenekli Kişi Neden Kaybetti? — 1.000 Evrenlik Deney**
3. **1 Milyon Sanal Kariyer: Kazananlar Gerçekten En İyiler miydi?**
4. **Herkes 10 Puanla Başladı. 40 Yıl Sonra Eşitlik Kalmadı**
5. **Başarıyı 1.000 Kez Simüle Ettik — Sonuç Rahatsız Edici**

İlk yayın için 1 numaralı ana başlık en dengeli seçenektir: sayı, deney, eşit başlangıç ve açık soru aynı anda görünür; sonucu tamamen ele vermez.

## Kapak A/B varyantları

### A — Karşılaştırma

- Metin: **YETENEK YETMEDİ**
- Sol: “T: 0,89” ve aşağı yönlü turuncu çizgi
- Sağ: “T: 0,66” ve yukarı yönlü camgöbeği çizgi
- En anlaşılır ve önerilen sürüm

### B — Dağılım

- Metin: **HERKES EŞİTTİ**
- Başlangıçta tek yatay çizgi, sonda uçurum gibi dağılım
- Merakı artırır; “yetenek” temasını daha az anlatır

### C — Tek sayı

- Metin: **SADECE %0,7**
- Alt küçük satır: “EN YETENEKLİ KAZANDI”
- Güçlü ama ilk temas için bağlam gerektirir; ikinci A/B testi olarak uygundur

## Video açıklaması

Bin sanal insanı aynı başarı puanıyla başlattık. Yetenekleri farklıydı; karşılarına çıkan fırsat ve talihsizlikler rastgeleydi. Kırk yıllık kariyeri bin ayrı evrende yeniden çalıştırdık: toplam bir milyon sanal hayat.

En yetenekli kişi kaç kez kazandı? Küçük fırsatları herkese dağıtmakla yalnız geçmiş kazananlara vermek arasında ne değişti?

Bu video bir gerçek ekonomi tahmini veya kişisel başarı reçetesi değildir. Kuralları açık bir ajan tabanlı düşünce deneyidir. Kod, ham veriler ve kaynaklar kanal bağlantılarında paylaşılabilir.

Araştırma:

- Pluchino, Biondo & Rapisarda — Talent vs Luck: https://arxiv.org/abs/1802.07068
- Stanford/HAI — 1.000'den fazla kişilik üretken ajan araştırması: https://arxiv.org/abs/2411.10109

Geleceği bilmiyoruz; ihtimalleri çalıştırıyoruz.

## Sabit yorum

> Sonucu görmeden önce tahminin neydi: En yetenekli kişi 1.000 evrenin kaçında kazanmıştır? Gerçek sonuç **7**. Bir sonraki simülasyonda hangisini çalıştıralım: “tek bencil ajan” mı, “tek işbirlikçi ajan” mı?

## Bölümler

- 00:00 Aynı başlangıç, farklı sonuç
- 00:25 Soru
- 01:05 Simülasyonun kuralları
- 02:15 Kırk yıl başlıyor
- 03:05 Dört sanal hayat
- 04:30 Tek evrenin sonucu
- 05:30 Bin evren
- 06:45 Aynı bütçe, dört farklı kural
- 08:15 Ne öğrendik, ne öğrenmedik?
- 09:10 Sonraki simülasyon

## Arama/etiket çekirdeği

Etiket doldurmaktan çok başlık ve açıklamadaki doğal dil önemlidir. Kullanılabilecek çekirdek ifadeler:

`simülasyon`, `ajan tabanlı model`, `şans ve yetenek`, `başarı psikolojisi`, `eşitsizlik`, `olasılık`, `sanal insanlar`, `what if`, `talent vs luck`

