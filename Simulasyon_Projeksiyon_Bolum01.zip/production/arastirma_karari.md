# Araştırma kararı — neden ilk video bu?

Araştırma tarihi: 17 Ağustos 2026

## Kanal pozisyonu

“Simülasyon Projeksiyon”un farkı yalnız varsayımsal sorular sormak değil; soruyu görünür kurallara çevirmek, modeli tekrar çalıştırmak ve sonucun ne kadar değiştiğini göstermektir.

Önerilen temel format:

1. Tek cümlelik yüksek merak sorusu
2. Şeffaf model ve sınırlı iddia
3. Bir “tipik evren” üzerinden insan ölçeğinde hikâye
4. Yüzlerce/binlerce tekrar ile sağlamlık kontrolü
5. Bir kuralı değiştirip karşı-evren kurma
6. Modelin neyi söylemediğini açıkça belirtme

## Güncel içerik sinyalleri

- “100/1.000 kişi medeniyet simülasyonu” başlıkları YouTube'da güçlü ve uluslararası ölçekte yaygın. Türkçe izleyicide de 1.000 oyunculu Minecraft medeniyet videolarına tepki/analiz içerikleri bulunuyor. Bu, “çok sayıda kişi + tek dünya + ortaya çıkan hikâye” formatının anlaşılır olduğunu gösteriyor; aynı zamanda Minecraft alt türünün doygun olduğuna işaret ediyor.
- Stanford ve Google DeepMind araştırmacılarının 1.052 gerçek kişiden türetilen ajanları inceleyen çalışması 2024'te yayımlandı, 2026'da güncellendi. Stanford HAI özeti 2025'te bu alanı daha geniş kitleye taşıdı. “Bin sanal insan” fikri güncel, fakat LLM ajanlarının maliyeti ve belirsizliği ilk video için gereksiz.
- “Başarıda şans mı, yetenek mi?” sorusu Türkçe basında 2025 sonunda yeniden gündeme geldi. Buna karşılık güncel aramalarda Türkçe, kodu ve tekrarlı verisi açık bir görsel simülasyon örneği belirgin biçimde azdı.
- Trafik, mahkûm ikilemi ve zombi salgını çok görsel olsa da mevcut açıklama/simülasyon içeriği daha kalabalık. İlk videoda kanalın “araştırma + algoritma + veri” kimliğini daha az doygun bir konuda kurmak daha değerlidir.

## Adayların editoryal puanı

Puanlar ölçülmüş izlenme tahmini değildir. Merak %25, görsel güç %20, bilimsel dayanak %20, Türkçe içerik boşluğu %15, tekrar üretilebilirlik %10, düşük risk %10 ağırlıkla değerlendirilmiştir.

| Sıra | Konu | Puan / 100 | Karar |
| ---: | --- | ---: | --- |
| 1 | 1.000 kişi: yetenek mi şans mı? | 92 | İlk video |
| 2 | Bir bencil ajan işbirliğini bozar mı? | 86 | İkinci video adayı |
| 3 | Tek fren hareketi trafik yaratır mı? | 84 | Shorts + uzun video adayı |
| 4 | Bir yalancı bilgi toplumu ele geçirir mi? | 84 | Güçlü, fakat kutuplaşma riski daha yüksek |
| 5 | 100 kişi Mars'ta koloni kurabilir mi? | 79 | Görsel güçlü, varsayım yükü fazla |
| 6 | Zombi salgını hangi hızla yayılır? | 76 | Eğlenceli, doygun |
| 7 | Minecraft medeniyet simülasyonu | 73 | Talep var, farklılaşma zayıf |
| 8 | Herkes aynı maaşı alsaydı? | 72 | Merak yüksek, gerçekçi model çok geniş |

## Seçim gerekçesi

Yetenek–şans modeli ilk video için altı avantajı aynı anda taşıyor:

- Başlık tek bakışta anlaşılır.
- Bin kişilik nokta animasyonu kanal logosundaki olasılık portalıyla görsel olarak uyumlu.
- Kurallar dört maddede açıklanabilir.
- Bilimsel bir model ve yayımlanmış kaynak vardır.
- Tek koşu yerine bin tekrar yapılabilir.
- “Kuralı değiştir” bölümü doğal biçimde ikinci perde yaratır.

Zayıf yönü, modelin gerçek hayatı aşırı sadeleştirmesidir. Bu nedenle video baştan sona “bu modelde” dilini korumalı; başarıyı yalnız para olarak sunmamalı ve yeteneği IQ olarak adlandırmamalıdır.

## Neden ilk videoda LLM ajanı kullanılmıyor?

LLM ajanları karakterlere konuşma ve karar çeşitliliği katabilir; ancak ilk bölümde üç sorun doğurur:

- Aynı koşunun tam yeniden üretimi zorlaşır.
- Bir kararın model kuralından mı, dil modelinin gizli örüntüsünden mi çıktığı belirsizleşir.
- Binlerce ajan ve tekrar maliyeti, hikâyeye kattığı değerden daha yüksek olur.

İlk video şeffaf, deterministik tohumlu ajan modelini kanal standardı olarak kurmalı. LLM ajanları daha sonra “aynı kurallı dünyada farklı kişiliklerin pazarlık etmesi” gibi gerçekten gerekli oldukları bölümde kullanılabilir.

## İncelenen başlıca kaynaklar

- Pluchino, Biondo & Rapisarda — Talent vs Luck: https://arxiv.org/abs/1802.07068
- Aynı çalışmanın HTML tam metni: https://ar5iv.labs.arxiv.org/html/1802.07068
- Yazarın NetLogo model deposu: https://www.comses.net/codebases/199a298b-fe95-473e-ad39-0fd69b5ff61c/releases/1.0.0/
- Park ve diğerleri — LLM Agents Grounded in Self-Reports: https://arxiv.org/abs/2411.10109
- Stanford HAI — Simulating Human Behavior with AI Agents: https://hai.stanford.edu/policy/simulating-human-behavior-with-ai-agents
- Minecraft medeniyet formatına örnek: https://www.youtube.com/watch?v=6WXb4R4IF2A
- Türkçe 1.000 oyuncu formatı örneği: https://www.youtube.com/watch?v=RIcu589ZWto
- Trafik şok dalgası deneyi: https://www.youtube.com/watch?v=Suugn-p5C1M
- Türkçe güncel ilgi sinyali, Habertürk 2025: https://www.haberturk.com/ozel-icerikler/kadir-kaymakci/3839371-basari-icin-sans-mi-onemli-cok-calismak-mi-iste-butun-mesele-bu

## Sonraki iki bölüm için öneri

1. **1.000 işbirlikçinin arasına tek bencil ajan koyduk.** Tekrarlanan mahkûm ikilemi; güven ağının hangi eşikte çöktüğünü ölçer.
2. **Bir fren hareketi ne kadar trafik üretir?** Halka yol modeli; insan tepki süresi, takip mesafesi ve otonom araç oranını karşılaştırır.

