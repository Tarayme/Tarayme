#!/usr/bin/env python3
"""Episode 01 — Talent, luck and success.

This script implements a transparent agent-based model inspired by:
Pluchino, Biondo & Rapisarda (2018), "Talent vs Luck: the role of
randomness in success and failure".

It creates a reproducible data package for a Turkish YouTube video:
- hundreds of paired simulated worlds;
- a typical featured world selected by median baseline Gini;
- raw CSV files for editing/animation;
- editorial 16:9 charts;
- a 1080p simulation preview.

This is a toy model, not a forecast of any real person or economy.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import matplotlib

matplotlib.use("Agg")

import matplotlib.animation as mpl_animation
import matplotlib.colors as mpl_colors
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.stats import spearmanr


BG = "#080C11"
PANEL = "#101820"
WHITE = "#F4F1E8"
MUTED = "#9CA8B3"
CYAN = "#00D8FF"
ORANGE = "#FF6B35"
GRID = "#25313C"

SCENARIO_LABELS = {
    "baseline": "Desteksiz",
    "equal_support": "Herkese küçük destek",
    "past_winners": "Geçmiş kazananlara destek",
    "random_10pct": "Rastgele %10'a destek",
}


@dataclass(frozen=True)
class Config:
    n_agents: int = 1000
    n_events: int = 500
    lucky_fraction: float = 0.50
    world_size: float = 201.0
    event_step_distance: float = 2.0
    encounter_radius: float = 1.0
    career_years: int = 40
    steps_per_year: int = 2
    start_age: int = 20
    starting_capital: float = 10.0
    talent_mean: float = 0.60
    talent_sd: float = 0.10
    support_interval_years: int = 5
    equal_support_amount: float = 1.0
    selected_support_share: float = 0.10
    selected_support_amount: float = 10.0

    @property
    def n_steps(self) -> int:
        return self.career_years * self.steps_per_year

    @property
    def support_interval_steps(self) -> int:
        return self.support_interval_years * self.steps_per_year


@dataclass
class World:
    seed: int
    talent: np.ndarray
    agent_positions: np.ndarray
    event_is_lucky: np.ndarray
    event_positions_history: np.ndarray
    lucky_hits: np.ndarray
    lucky_exploited: np.ndarray
    unlucky_hits: np.ndarray
    step_lucky_exploited: list[np.ndarray]
    step_unlucky_hits: list[np.ndarray]


@dataclass
class ScenarioResult:
    scenario: str
    capital: np.ndarray
    capital_history: np.ndarray | None


def truncated_normal(
    rng: np.random.Generator,
    size: int,
    mean: float,
    sd: float,
    low: float = 0.0,
    high: float = 1.0,
) -> np.ndarray:
    values = rng.normal(mean, sd, size=size)
    invalid = (values < low) | (values > high)
    while invalid.any():
        values[invalid] = rng.normal(mean, sd, size=int(invalid.sum()))
        invalid = (values < low) | (values > high)
    return values


def make_world(seed: int, cfg: Config, keep_event_history: bool = False) -> World:
    setup_ss, movement_ss, outcome_ss = np.random.SeedSequence(seed).spawn(3)
    setup_rng = np.random.default_rng(setup_ss)
    movement_rng = np.random.default_rng(movement_ss)
    outcome_rng = np.random.default_rng(outcome_ss)

    talent = truncated_normal(
        setup_rng,
        cfg.n_agents,
        cfg.talent_mean,
        cfg.talent_sd,
    )
    agent_positions = setup_rng.uniform(0, cfg.world_size, size=(cfg.n_agents, 2))
    event_positions = setup_rng.uniform(0, cfg.world_size, size=(cfg.n_events, 2))

    n_lucky = int(round(cfg.n_events * cfg.lucky_fraction))
    event_is_lucky = np.zeros(cfg.n_events, dtype=bool)
    event_is_lucky[:n_lucky] = True
    setup_rng.shuffle(event_is_lucky)

    tree = cKDTree(agent_positions, boxsize=cfg.world_size)
    lucky_hits_total = np.zeros(cfg.n_agents, dtype=np.int16)
    lucky_exploited_total = np.zeros(cfg.n_agents, dtype=np.int16)
    unlucky_hits_total = np.zeros(cfg.n_agents, dtype=np.int16)
    step_lucky_exploited: list[np.ndarray] = []
    step_unlucky_hits: list[np.ndarray] = []
    event_history: list[np.ndarray] = []
    if keep_event_history:
        event_history.append(event_positions.copy())

    for _ in range(cfg.n_steps):
        angles = movement_rng.uniform(0.0, 2.0 * math.pi, size=cfg.n_events)
        displacement = cfg.event_step_distance * np.column_stack(
            (np.cos(angles), np.sin(angles))
        )
        event_positions = (event_positions + displacement) % cfg.world_size
        if keep_event_history:
            event_history.append(event_positions.copy())

        encounters = tree.query_ball_point(event_positions, r=cfg.encounter_radius)
        lucky_agent_ids: list[int] = []
        unlucky_agent_ids: list[int] = []
        for event_idx, agent_ids in enumerate(encounters):
            if not agent_ids:
                continue
            if event_is_lucky[event_idx]:
                lucky_agent_ids.extend(agent_ids)
            else:
                unlucky_agent_ids.extend(agent_ids)

        if lucky_agent_ids:
            lucky_ids = np.asarray(lucky_agent_ids, dtype=np.int32)
            lucky_hits_step = np.bincount(lucky_ids, minlength=cfg.n_agents)
            successful_mask = outcome_rng.random(lucky_ids.size) < talent[lucky_ids]
            successful_ids = lucky_ids[successful_mask]
            successful_step = np.bincount(successful_ids, minlength=cfg.n_agents)
        else:
            lucky_hits_step = np.zeros(cfg.n_agents, dtype=np.int64)
            successful_step = np.zeros(cfg.n_agents, dtype=np.int64)

        if unlucky_agent_ids:
            unlucky_ids = np.asarray(unlucky_agent_ids, dtype=np.int32)
            unlucky_step = np.bincount(unlucky_ids, minlength=cfg.n_agents)
        else:
            unlucky_step = np.zeros(cfg.n_agents, dtype=np.int64)

        lucky_hits_total += lucky_hits_step.astype(np.int16)
        lucky_exploited_total += successful_step.astype(np.int16)
        unlucky_hits_total += unlucky_step.astype(np.int16)
        step_lucky_exploited.append(successful_step.astype(np.int8))
        step_unlucky_hits.append(unlucky_step.astype(np.int8))

    if keep_event_history:
        event_positions_history = np.asarray(event_history, dtype=np.float32)
    else:
        event_positions_history = np.empty((0, 0, 2), dtype=np.float32)

    return World(
        seed=seed,
        talent=talent,
        agent_positions=agent_positions,
        event_is_lucky=event_is_lucky,
        event_positions_history=event_positions_history,
        lucky_hits=lucky_hits_total,
        lucky_exploited=lucky_exploited_total,
        unlucky_hits=unlucky_hits_total,
        step_lucky_exploited=step_lucky_exploited,
        step_unlucky_hits=step_unlucky_hits,
    )


def apply_scenarios(
    world: World,
    cfg: Config,
    scenarios: Iterable[str],
    keep_history: bool = False,
) -> dict[str, ScenarioResult]:
    results: dict[str, ScenarioResult] = {}
    for scenario_idx, scenario in enumerate(scenarios):
        capital = np.full(cfg.n_agents, cfg.starting_capital, dtype=np.float64)
        history = [capital.copy()] if keep_history else None
        policy_rng = np.random.default_rng(
            np.random.SeedSequence([world.seed, scenario_idx, 910_247])
        )

        for step_idx in range(cfg.n_steps):
            exponent = (
                world.step_lucky_exploited[step_idx].astype(np.int16)
                - world.step_unlucky_hits[step_idx].astype(np.int16)
            )
            capital *= np.exp2(exponent)

            if (step_idx + 1) % cfg.support_interval_steps == 0:
                if scenario == "equal_support":
                    capital += cfg.equal_support_amount
                elif scenario == "past_winners":
                    n_selected = max(1, int(round(cfg.n_agents * cfg.selected_support_share)))
                    selected = np.argpartition(capital, -n_selected)[-n_selected:]
                    capital[selected] += cfg.selected_support_amount
                elif scenario == "random_10pct":
                    n_selected = max(1, int(round(cfg.n_agents * cfg.selected_support_share)))
                    selected = policy_rng.choice(cfg.n_agents, size=n_selected, replace=False)
                    capital[selected] += cfg.selected_support_amount
                elif scenario != "baseline":
                    raise ValueError(f"Unknown scenario: {scenario}")

            if history is not None:
                history.append(capital.copy())

        results[scenario] = ScenarioResult(
            scenario=scenario,
            capital=capital,
            capital_history=np.asarray(history) if history is not None else None,
        )
    return results


def gini(values: np.ndarray) -> float:
    x = np.asarray(values, dtype=np.float64)
    if np.any(x < 0):
        x = x - x.min()
    total = x.sum()
    if total <= 0:
        return 0.0
    x = np.sort(x)
    n = x.size
    index = np.arange(1, n + 1)
    return float((2.0 * np.sum(index * x) / (n * total)) - ((n + 1.0) / n))


def top_share(values: np.ndarray, fraction: float) -> float:
    x = np.sort(np.asarray(values, dtype=np.float64))
    n_top = max(1, int(math.ceil(x.size * fraction)))
    return float(x[-n_top:].sum() / x.sum())


def safe_spearman(x: np.ndarray, y: np.ndarray) -> float:
    result = spearmanr(x, y)
    value = float(result.statistic)
    return value if np.isfinite(value) else 0.0


def metric_row(
    seed: int,
    scenario: str,
    world: World,
    capital: np.ndarray,
    cfg: Config,
) -> dict[str, float | int | str]:
    talent = world.talent
    log_capital = np.log2(np.maximum(capital, 1e-12))
    # External luck counts the events encountered, before talent determines whether
    # an opportunity can be exploited. This avoids defining "luck" from the final
    # capital formula itself.
    external_luck = world.lucky_hits.astype(np.int32) - world.unlucky_hits.astype(np.int32)
    winner_idx = int(np.argmax(capital))
    most_talented_idx = int(np.argmax(talent))
    winner_talent_percentile = 100.0 * (
        (np.count_nonzero(talent <= talent[winner_idx]) - 1) / (cfg.n_agents - 1)
    )
    high_talent = talent > (cfg.talent_mean + cfg.talent_sd)
    high_talent_success = float(np.mean(capital[high_talent] > cfg.starting_capital))
    most_talented_rank = int(1 + np.count_nonzero(capital > capital[most_talented_idx]))

    return {
        "seed": seed,
        "scenario": scenario,
        "scenario_label_tr": SCENARIO_LABELS[scenario],
        "gini": gini(capital),
        "top_1_share": top_share(capital, 0.01),
        "top_20_share": top_share(capital, 0.20),
        "below_start_share": float(np.mean(capital < cfg.starting_capital)),
        "high_talent_success_share": high_talent_success,
        "median_capital": float(np.median(capital)),
        "mean_capital": float(np.mean(capital)),
        "max_capital": float(np.max(capital)),
        "winner_agent_id": winner_idx + 1,
        "winner_talent": float(talent[winner_idx]),
        "winner_talent_percentile": float(winner_talent_percentile),
        "winner_is_most_talented": int(winner_idx == most_talented_idx),
        "winner_is_top_1pct_talent": int(winner_talent_percentile >= 99.0),
        "winner_lucky_hits": int(world.lucky_hits[winner_idx]),
        "winner_lucky_exploited": int(world.lucky_exploited[winner_idx]),
        "winner_unlucky_hits": int(world.unlucky_hits[winner_idx]),
        "most_talented_agent_id": most_talented_idx + 1,
        "most_talented_talent": float(talent[most_talented_idx]),
        "most_talented_capital": float(capital[most_talented_idx]),
        "most_talented_capital_rank": most_talented_rank,
        "talent_success_spearman": safe_spearman(talent, log_capital),
        "external_luck_success_spearman": safe_spearman(external_luck, log_capital),
    }


def run_many(
    cfg: Config,
    scenarios: list[str],
    n_runs: int,
    base_seed: int,
) -> pd.DataFrame:
    rows: list[dict[str, float | int | str]] = []
    for run_idx in range(n_runs):
        seed = base_seed + run_idx
        world = make_world(seed, cfg, keep_event_history=False)
        results = apply_scenarios(world, cfg, scenarios, keep_history=False)
        for scenario, result in results.items():
            rows.append(metric_row(seed, scenario, world, result.capital, cfg))
        if (run_idx + 1) % 25 == 0 or run_idx + 1 == n_runs:
            print(f"Completed {run_idx + 1}/{n_runs} paired worlds", flush=True)
    return pd.DataFrame(rows)


def quantile(series: pd.Series, q: float) -> float:
    return float(series.quantile(q))


def make_scenario_summary(metrics: pd.DataFrame) -> pd.DataFrame:
    records: list[dict[str, float | int | str]] = []
    for scenario, group in metrics.groupby("scenario", sort=False):
        records.append(
            {
                "scenario": scenario,
                "scenario_label_tr": SCENARIO_LABELS[scenario],
                "runs": int(group.shape[0]),
                "median_gini": float(group["gini"].median()),
                "gini_p10": quantile(group["gini"], 0.10),
                "gini_p90": quantile(group["gini"], 0.90),
                "median_top_1_share": float(group["top_1_share"].median()),
                "median_top_20_share": float(group["top_20_share"].median()),
                "median_below_start_share": float(group["below_start_share"].median()),
                "median_high_talent_success_share": float(
                    group["high_talent_success_share"].median()
                ),
                "winner_most_talented_frequency": float(
                    group["winner_is_most_talented"].mean()
                ),
                "winner_top_1pct_talent_frequency": float(
                    group["winner_is_top_1pct_talent"].mean()
                ),
                "median_winner_talent": float(group["winner_talent"].median()),
                "median_winner_talent_percentile": float(
                    group["winner_talent_percentile"].median()
                ),
                "median_talent_success_spearman": float(
                    group["talent_success_spearman"].median()
                ),
                "median_external_luck_success_spearman": float(
                    group["external_luck_success_spearman"].median()
                ),
            }
        )
    return pd.DataFrame(records)


def rank_desc(values: np.ndarray) -> np.ndarray:
    order = np.argsort(-values, kind="mergesort")
    ranks = np.empty(values.size, dtype=np.int32)
    ranks[order] = np.arange(1, values.size + 1)
    return ranks


def build_selected_seed_tables(
    world: World,
    results: dict[str, ScenarioResult],
    cfg: Config,
    output_dir: Path,
) -> dict[str, int | float | str | list[int]]:
    baseline = results["baseline"]
    assert baseline.capital_history is not None
    capital = baseline.capital
    talent = world.talent
    agent_ids = np.arange(1, cfg.n_agents + 1)
    capital_ranks = rank_desc(capital)
    talent_ranks = rank_desc(talent)
    external_luck = world.lucky_hits.astype(int) - world.unlucky_hits.astype(int)
    capital_event_balance = world.lucky_exploited.astype(int) - world.unlucky_hits.astype(int)

    winner_idx = int(np.argmax(capital))
    most_talented_idx = int(np.argmax(talent))
    top_talent_mask = talent_ranks <= max(10, int(cfg.n_agents * 0.10))
    used = {winner_idx, most_talented_idx}
    talented_candidates = [
        int(idx) for idx in np.where(top_talent_mask)[0] if int(idx) not in used
    ]
    talented_unlucky_idx = min(talented_candidates, key=lambda idx: capital[idx])
    used.add(talented_unlucky_idx)
    average_mask = (talent >= cfg.talent_mean - 0.03) & (talent <= cfg.talent_mean + 0.03)
    average_candidates = [
        int(idx) for idx in np.where(average_mask)[0] if int(idx) not in used
    ]
    average_lucky_idx = max(average_candidates, key=lambda idx: capital[idx])

    featured = {
        winner_idx: "Kazanan",
        most_talented_idx: "En yetenekli",
        talented_unlucky_idx: "Yetenekli ama şanssız",
        average_lucky_idx: "Ortalama yetenek, güçlü sonuç",
    }

    agents = pd.DataFrame(
        {
            "agent_id": [f"A{i:04d}" for i in agent_ids],
            "talent": talent,
            "talent_rank": talent_ranks,
            "final_capital": capital,
            "capital_rank": capital_ranks,
            "lucky_events_seen": world.lucky_hits,
            "lucky_events_exploited": world.lucky_exploited,
            "unlucky_events": world.unlucky_hits,
            "external_luck_balance": external_luck,
            "capital_event_balance": capital_event_balance,
            "featured_label_tr": [featured.get(i, "") for i in range(cfg.n_agents)],
            "x": world.agent_positions[:, 0],
            "y": world.agent_positions[:, 1],
        }
    )
    agents.to_csv(output_dir / "selected_seed_agents_baseline.csv", index=False)

    timeline_frames: list[pd.DataFrame] = []
    for step_idx, step_capital in enumerate(baseline.capital_history):
        year = step_idx / cfg.steps_per_year
        frame = pd.DataFrame(
            {
                "step": step_idx,
                "career_year": year,
                "age": cfg.start_age + year,
                "agent_id": agents["agent_id"],
                "talent": talent,
                "capital": step_capital,
                "log2_growth_from_start": np.log2(
                    np.maximum(step_capital, 1e-12) / cfg.starting_capital
                ),
            }
        )
        timeline_frames.append(frame)
    pd.concat(timeline_frames, ignore_index=True).to_csv(
        output_dir / "selected_seed_animation_data.csv", index=False
    )

    featured_rows: list[dict[str, float | int | str]] = []
    for idx, label in featured.items():
        for step_idx, step_capital in enumerate(baseline.capital_history):
            featured_rows.append(
                {
                    "step": step_idx,
                    "career_year": step_idx / cfg.steps_per_year,
                    "age": cfg.start_age + step_idx / cfg.steps_per_year,
                    "agent_id": f"A{idx + 1:04d}",
                    "label_tr": label,
                    "talent": float(talent[idx]),
                    "capital": float(step_capital[idx]),
                }
            )
    pd.DataFrame(featured_rows).to_csv(
        output_dir / "selected_seed_featured_agents_timeline.csv", index=False
    )

    event_rows: list[pd.DataFrame] = []
    for step_idx, positions in enumerate(world.event_positions_history):
        event_rows.append(
            pd.DataFrame(
                {
                    "step": step_idx,
                    "career_year": step_idx / cfg.steps_per_year,
                    "event_id": np.arange(1, cfg.n_events + 1),
                    "event_type": np.where(world.event_is_lucky, "lucky", "unlucky"),
                    "x": positions[:, 0],
                    "y": positions[:, 1],
                }
            )
        )
    pd.concat(event_rows, ignore_index=True).to_csv(
        output_dir / "selected_seed_event_positions.csv", index=False
    )

    scenario_rows: list[pd.DataFrame] = []
    for scenario, result in results.items():
        scenario_rows.append(
            pd.DataFrame(
                {
                    "scenario": scenario,
                    "scenario_label_tr": SCENARIO_LABELS[scenario],
                    "agent_id": agents["agent_id"],
                    "talent": talent,
                    "final_capital": result.capital,
                    "capital_rank": rank_desc(result.capital),
                }
            )
        )
    pd.concat(scenario_rows, ignore_index=True).to_csv(
        output_dir / "selected_seed_scenario_agents.csv", index=False
    )

    return {
        "selected_seed": world.seed,
        "winner_idx": winner_idx,
        "most_talented_idx": most_talented_idx,
        "talented_unlucky_idx": talented_unlucky_idx,
        "average_lucky_idx": average_lucky_idx,
        "featured_indices": list(featured.keys()),
    }


def save_topic_ranking(output_dir: Path) -> pd.DataFrame:
    # Editorial scores from the research phase; these are not measured audience data.
    rows = [
        ("1.000 kişi: yetenek mi şans mı?", 10, 9, 9, 9, 10, 8),
        ("Bir yalancı bilgi toplumu ele geçirir mi?", 9, 9, 8, 8, 9, 7),
        ("1 bencil ajan işbirliğini bozar mı?", 8, 9, 9, 8, 10, 8),
        ("Tek fren hareketi trafik yaratır mı?", 8, 10, 10, 5, 8, 9),
        ("100 kişi Mars'ta koloni kurabilir mi?", 9, 10, 6, 7, 8, 6),
        ("Herkes aynı maaşı alsaydı?", 9, 7, 6, 7, 8, 5),
        ("Zombi salgını hangi hızla yayılır?", 9, 10, 6, 4, 8, 8),
        ("Minecraft medeniyet simülasyonu", 10, 10, 4, 2, 9, 8),
    ]
    columns = [
        "topic_tr",
        "curiosity",
        "visual_strength",
        "scientific_rigor",
        "turkish_content_gap",
        "repeatability",
        "low_risk",
    ]
    df = pd.DataFrame(rows, columns=columns)
    weights = {
        "curiosity": 0.25,
        "visual_strength": 0.20,
        "scientific_rigor": 0.20,
        "turkish_content_gap": 0.15,
        "repeatability": 0.10,
        "low_risk": 0.10,
    }
    df["weighted_score_100"] = sum(df[key] * weight * 10 for key, weight in weights.items())
    df = df.sort_values("weighted_score_100", ascending=False).reset_index(drop=True)
    df["rank"] = np.arange(1, len(df) + 1)
    df["score_note"] = "Editoryal puan; ölçülmüş izlenme tahmini değildir."
    df.to_csv(output_dir / "topic_ranking.csv", index=False)
    return df


def style_axes(ax: plt.Axes) -> None:
    ax.set_facecolor(BG)
    ax.tick_params(colors=MUTED, labelsize=12)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.grid(True, color=GRID, alpha=0.5, linewidth=0.8)


def save_figure(fig: plt.Figure, path: Path) -> None:
    fig.savefig(path, dpi=120, facecolor=BG, bbox_inches="tight", pad_inches=0.25)
    plt.close(fig)


def chart_topic_ranking(topic_df: pd.DataFrame, charts_dir: Path) -> None:
    df = topic_df.sort_values("weighted_score_100", ascending=True)
    fig, ax = plt.subplots(figsize=(16, 9), facecolor=BG)
    style_axes(ax)
    colors = [CYAN if rank == 1 else "#31414F" for rank in df["rank"]]
    ax.barh(df["topic_tr"], df["weighted_score_100"], color=colors, height=0.68)
    ax.set_xlim(0, 100)
    ax.set_xlabel("Editoryal uygunluk puanı / 100", color=WHITE, fontsize=14)
    ax.set_title(
        "İlk video adayları — neden bu konu?",
        color=WHITE,
        fontsize=28,
        loc="left",
        pad=22,
        fontweight="bold",
    )
    ax.text(
        0,
        1.01,
        "Merak, görsel güç, bilimsel dayanak, Türkçe içerik boşluğu, tekrar üretilebilirlik ve risk.",
        color=MUTED,
        fontsize=13,
        transform=ax.transAxes,
    )
    for y, value in enumerate(df["weighted_score_100"]):
        ax.text(value + 1.0, y, f"{value:.0f}", va="center", color=WHITE, fontsize=13)
    save_figure(fig, charts_dir / "01_konu_puanlama.png")


def chart_final_distribution(
    capital: np.ndarray,
    cfg: Config,
    charts_dir: Path,
) -> None:
    sorted_capital = np.sort(capital)[::-1]
    ranks = np.arange(1, cfg.n_agents + 1)
    fig, ax = plt.subplots(figsize=(16, 9), facecolor=BG)
    style_axes(ax)
    ax.plot(ranks, sorted_capital, color=CYAN, linewidth=2.5)
    ax.fill_between(ranks[:10], sorted_capital[:10], color=ORANGE, alpha=0.65)
    ax.axhline(cfg.starting_capital, color=WHITE, linestyle="--", linewidth=1.3, alpha=0.8)
    ax.set_yscale("log", base=2)
    ax.set_xlabel("Başarı sırası", color=WHITE, fontsize=14)
    ax.set_ylabel("Sermaye / başarı puanı (log₂)", color=WHITE, fontsize=14)
    ax.set_title(
        "Herkes 10 puanla başladı — 40 yıl sonra",
        color=WHITE,
        fontsize=28,
        loc="left",
        pad=22,
        fontweight="bold",
    )
    ax.text(
        0,
        1.01,
        "Turuncu alan en yüksek sonuçlu %1'i, kesikli çizgi ortak başlangıcı gösteriyor.",
        color=MUTED,
        fontsize=13,
        transform=ax.transAxes,
    )
    save_figure(fig, charts_dir / "02_40_yil_sonra_dagilim.png")


def chart_talent_vs_success(
    world: World,
    capital: np.ndarray,
    charts_dir: Path,
) -> None:
    winner_idx = int(np.argmax(capital))
    talented_idx = int(np.argmax(world.talent))
    fig, ax = plt.subplots(figsize=(16, 9), facecolor=BG)
    style_axes(ax)
    scatter = ax.scatter(
        world.talent,
        capital,
        c=world.lucky_exploited - world.unlucky_hits,
        cmap=mpl_colors.LinearSegmentedColormap.from_list(
            "luck", [ORANGE, WHITE, CYAN]
        ),
        s=32,
        alpha=0.72,
        edgecolors="none",
    )
    ax.scatter(
        world.talent[winner_idx],
        capital[winner_idx],
        s=220,
        facecolors="none",
        edgecolors=CYAN,
        linewidths=3,
        label="Kazanan",
    )
    ax.scatter(
        world.talent[talented_idx],
        capital[talented_idx],
        s=220,
        marker="s",
        facecolors="none",
        edgecolors=ORANGE,
        linewidths=3,
        label="En yetenekli",
    )
    ax.set_yscale("log", base=2)
    ax.set_xlabel("Yetenek / fırsatı değerlendirme olasılığı", color=WHITE, fontsize=14)
    ax.set_ylabel("40. yıl sermayesi (log₂)", color=WHITE, fontsize=14)
    ax.set_title(
        "En başarılı kişi, en yetenekli kişi miydi?",
        color=WHITE,
        fontsize=28,
        loc="left",
        pad=22,
        fontweight="bold",
    )
    ax.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=WHITE, fontsize=13)
    cbar = fig.colorbar(scatter, ax=ax, pad=0.02)
    cbar.set_label("Değerlendirilen fırsat − talihsizlik", color=WHITE, fontsize=12)
    cbar.ax.tick_params(colors=MUTED)
    save_figure(fig, charts_dir / "03_yetenek_ve_basari.png")


def chart_featured_lives(
    world: World,
    baseline: ScenarioResult,
    featured_indices: list[int],
    cfg: Config,
    charts_dir: Path,
) -> None:
    assert baseline.capital_history is not None
    winner_idx, most_talented_idx, talented_unlucky_idx, average_lucky_idx = featured_indices
    series = [
        (winner_idx, "Kazanan", CYAN, 3.2),
        (most_talented_idx, "En yetenekli", ORANGE, 2.6),
        (talented_unlucky_idx, "Yetenekli ama şanssız", "#B790FF", 2.2),
        (average_lucky_idx, "Ortalama yetenek, güçlü sonuç", WHITE, 2.2),
    ]
    ages = cfg.start_age + np.arange(cfg.n_steps + 1) / cfg.steps_per_year
    fig, ax = plt.subplots(figsize=(16, 9), facecolor=BG)
    style_axes(ax)
    for idx, label, color, width in series:
        ax.plot(
            ages,
            baseline.capital_history[:, idx],
            color=color,
            linewidth=width,
            label=f"{label} · A{idx + 1:04d} · T={world.talent[idx]:.2f}",
        )
    ax.set_yscale("log", base=2)
    ax.set_xlabel("Yaş", color=WHITE, fontsize=14)
    ax.set_ylabel("Sermaye / başarı puanı (log₂)", color=WHITE, fontsize=14)
    ax.set_title(
        "Aynı başlangıç, dört farklı hayat",
        color=WHITE,
        fontsize=28,
        loc="left",
        pad=22,
        fontweight="bold",
    )
    ax.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=WHITE, fontsize=12)
    save_figure(fig, charts_dir / "04_dort_hayat.png")


def chart_many_worlds(metrics: pd.DataFrame, charts_dir: Path) -> None:
    baseline = metrics[metrics["scenario"] == "baseline"].copy()
    fig, axes = plt.subplots(1, 2, figsize=(16, 9), facecolor=BG)
    for ax in axes:
        style_axes(ax)
    axes[0].hist(
        baseline["winner_talent_percentile"],
        bins=np.linspace(0, 100, 21),
        color=CYAN,
        alpha=0.85,
        edgecolor=BG,
    )
    axes[0].axvspan(99, 100, color=ORANGE, alpha=0.75)
    axes[0].set_xlabel("Kazananın yetenek yüzdeliği", color=WHITE, fontsize=13)
    axes[0].set_ylabel("Evren sayısı", color=WHITE, fontsize=13)
    axes[0].set_title("Kazananlar ne kadar yetenekli?", color=WHITE, fontsize=19, loc="left")

    labels = ["Yetenek ↔ sonuç", "Şans ↔ sonuç"]
    values = [
        baseline["talent_success_spearman"].median(),
        baseline["external_luck_success_spearman"].median(),
    ]
    axes[1].bar(labels, values, color=[WHITE, CYAN], width=0.58)
    axes[1].set_ylim(0, 1)
    axes[1].set_ylabel("Medyan Spearman korelasyonu", color=WHITE, fontsize=13)
    axes[1].set_title("Sonuçla daha güçlü ilişki", color=WHITE, fontsize=19, loc="left")
    for idx, value in enumerate(values):
        axes[1].text(idx, value + 0.025, f"{value:.2f}", ha="center", color=WHITE, fontsize=16)

    fig.suptitle(
        f"{baseline.shape[0]} ayrı evren çalıştırıldığında",
        color=WHITE,
        fontsize=30,
        x=0.04,
        ha="left",
        fontweight="bold",
    )
    fig.subplots_adjust(top=0.84, wspace=0.22)
    save_figure(fig, charts_dir / "05_coklu_evren_sonuclari.png")


def chart_scenario_comparison(summary: pd.DataFrame, charts_dir: Path) -> None:
    order = ["baseline", "past_winners", "random_10pct", "equal_support"]
    df = summary.set_index("scenario").loc[order].reset_index()
    labels = ["Desteksiz", "Kazananlara", "Rastgele %10", "Herkese"]
    colors = ["#52616D", ORANGE, "#B790FF", CYAN]
    fig, axes = plt.subplots(1, 2, figsize=(16, 9), facecolor=BG)
    for ax in axes:
        style_axes(ax)

    gini_values = df["median_gini"].to_numpy()
    axes[0].barh(labels, gini_values, color=colors, height=0.62)
    axes[0].set_xlim(0, max(0.9, float(gini_values.max()) + 0.08))
    axes[0].invert_yaxis()
    axes[0].set_xlabel("Medyan Gini (düşük = daha eşit)", color=WHITE, fontsize=13)
    axes[0].set_title("Sonuç eşitsizliği", color=WHITE, fontsize=19, loc="left")
    for y, value in enumerate(gini_values):
        axes[0].text(value + 0.015, y, f"{value:.2f}", va="center", color=WHITE, fontsize=13)

    success_values = 100 * df["median_high_talent_success_share"].to_numpy()
    axes[1].barh(labels, success_values, color=colors, height=0.62)
    axes[1].set_xlim(0, 100)
    axes[1].invert_yaxis()
    axes[1].set_xlabel("Başlangıcı aşan yüksek yetenekliler (%)", color=WHITE, fontsize=13)
    axes[1].set_title("Yetenek için ikinci şans", color=WHITE, fontsize=19, loc="left")
    for y, value in enumerate(success_values):
        axes[1].text(value + 1.2, y, f"%{value:.0f}", va="center", color=WHITE, fontsize=13)

    fig.suptitle(
        "Aynı fırsat bütçesi, farklı dağıtım kuralı",
        color=WHITE,
        fontsize=30,
        x=0.04,
        ha="left",
        fontweight="bold",
    )
    fig.text(
        0.04,
        0.91,
        "Her 5 yılda toplam 1.000 puan: herkese 1; ya da seçilen %10'a 10.",
        color=MUTED,
        fontsize=13,
    )
    fig.subplots_adjust(top=0.82, wspace=0.33, left=0.20)
    save_figure(fig, charts_dir / "06_senaryo_karsilastirma.png")


def build_animation(
    world: World,
    baseline: ScenarioResult,
    cfg: Config,
    output_path: Path,
) -> None:
    assert baseline.capital_history is not None
    if world.event_positions_history.shape[0] != cfg.n_steps + 1:
        raise ValueError("Event history is required for animation")

    cmap = mpl_colors.LinearSegmentedColormap.from_list(
        "status", [ORANGE, WHITE, CYAN]
    )
    all_growth = np.log2(
        np.maximum(baseline.capital_history, 1e-12) / cfg.starting_capital
    )
    norm = mpl_colors.TwoSlopeNorm(
        vmin=min(-6.0, float(np.percentile(all_growth, 1))),
        vcenter=0.0,
        vmax=max(8.0, float(np.percentile(all_growth, 99.5))),
    )

    fig = plt.figure(figsize=(16, 9), facecolor=BG)
    ax = fig.add_axes([0.055, 0.10, 0.64, 0.80])
    ax.set_facecolor(PANEL)
    ax.set_xlim(0, cfg.world_size)
    ax.set_ylim(0, cfg.world_size)
    ax.set_aspect("equal")
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_color(GRID)

    agent_scatter = ax.scatter(
        world.agent_positions[:, 0],
        world.agent_positions[:, 1],
        c=all_growth[0],
        cmap=cmap,
        norm=norm,
        s=14,
        alpha=0.92,
        edgecolors="none",
    )
    lucky_pos = world.event_positions_history[0][world.event_is_lucky]
    unlucky_pos = world.event_positions_history[0][~world.event_is_lucky]
    lucky_scatter = ax.scatter(
        lucky_pos[:, 0],
        lucky_pos[:, 1],
        s=14,
        facecolors="none",
        edgecolors=CYAN,
        linewidths=0.6,
        alpha=0.55,
    )
    unlucky_scatter = ax.scatter(
        unlucky_pos[:, 0],
        unlucky_pos[:, 1],
        s=14,
        facecolors="none",
        edgecolors=ORANGE,
        linewidths=0.6,
        alpha=0.55,
    )

    fig.text(0.73, 0.88, "SİMÜLASYON / 01", color=CYAN, fontsize=14, fontweight="bold")
    year_text = fig.text(0.73, 0.78, "YIL 0", color=WHITE, fontsize=38, fontweight="bold")
    gini_text = fig.text(0.73, 0.67, "GINI 0.00", color=WHITE, fontsize=22)
    leader_text = fig.text(
        0.73,
        0.59,
        "",
        color=WHITE,
        fontsize=17,
        linespacing=1.6,
        verticalalignment="top",
    )
    talent_text = fig.text(0.73, 0.34, "", color=MUTED, fontsize=15, linespacing=1.6)
    fig.text(0.73, 0.14, "○ fırsat   ○ talihsizlik", color=MUTED, fontsize=14)
    fig.text(0.73, 0.09, "Turuncu ← başlangıç → camgöbeği", color=MUTED, fontsize=12)

    def update(frame_idx: int):
        capital = baseline.capital_history[frame_idx]
        agent_scatter.set_array(all_growth[frame_idx])
        positions = world.event_positions_history[frame_idx]
        lucky_scatter.set_offsets(positions[world.event_is_lucky])
        unlucky_scatter.set_offsets(positions[~world.event_is_lucky])

        year = frame_idx / cfg.steps_per_year
        year_text.set_text(f"YIL {year:04.1f}")
        gini_text.set_text(f"GINI {gini(capital):.2f}")
        top_ids = np.argsort(-capital)[:3]
        leader_text.set_text(
            "LİDERLER\n"
            + "\n".join(
                f"{rank}. A{idx + 1:04d}   {capital[idx]:,.1f}"
                for rank, idx in enumerate(top_ids, start=1)
            )
        )
        winner_idx = int(top_ids[0])
        talented_idx = int(np.argmax(world.talent))
        talent_text.set_text(
            f"Lider yeteneği      {world.talent[winner_idx]:.2f}\n"
            f"En yetenekli        {world.talent[talented_idx]:.2f}\n"
            f"En yetenekli sıra   {1 + np.count_nonzero(capital > capital[talented_idx])}"
        )
        return (
            agent_scatter,
            lucky_scatter,
            unlucky_scatter,
            year_text,
            gini_text,
            leader_text,
            talent_text,
        )

    animation = mpl_animation.FuncAnimation(
        fig,
        update,
        frames=cfg.n_steps + 1,
        interval=250,
        blit=False,
    )
    writer = mpl_animation.FFMpegWriter(
        fps=4,
        bitrate=5500,
        metadata={"title": "Simülasyon Projeksiyon — Episode 01 preview"},
    )
    animation.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=int, default=500, help="Paired worlds per scenario")
    parser.add_argument("--seed", type=int, default=20_260_817, help="First deterministic seed")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).resolve().parent / "outputs",
    )
    parser.add_argument("--skip-animation", action="store_true")
    args = parser.parse_args()

    cfg = Config()
    output_dir = args.output_dir.resolve()
    charts_dir = output_dir / "charts"
    output_dir.mkdir(parents=True, exist_ok=True)
    charts_dir.mkdir(parents=True, exist_ok=True)
    scenarios = ["baseline", "equal_support", "past_winners", "random_10pct"]

    write_json(output_dir / "model_config.json", asdict(cfg))
    topic_df = save_topic_ranking(output_dir)
    chart_topic_ranking(topic_df, charts_dir)

    metrics = run_many(cfg, scenarios, args.runs, args.seed)
    metrics.to_csv(output_dir / "all_run_metrics.csv", index=False)
    summary = make_scenario_summary(metrics)
    summary.to_csv(output_dir / "scenario_summary.csv", index=False)

    baseline_metrics = metrics[metrics["scenario"] == "baseline"].copy()
    target_gini = float(baseline_metrics["gini"].median())
    selected_row_idx = (baseline_metrics["gini"] - target_gini).abs().idxmin()
    selected_seed = int(baseline_metrics.loc[selected_row_idx, "seed"])
    print(f"Selected typical seed: {selected_seed} (median baseline Gini)", flush=True)

    selected_world = make_world(selected_seed, cfg, keep_event_history=True)
    selected_results = apply_scenarios(
        selected_world,
        cfg,
        scenarios,
        keep_history=True,
    )
    featured_info = build_selected_seed_tables(
        selected_world,
        selected_results,
        cfg,
        output_dir,
    )

    selected_metrics = {
        scenario: metric_row(
            selected_seed,
            scenario,
            selected_world,
            result.capital,
            cfg,
        )
        for scenario, result in selected_results.items()
    }
    write_json(
        output_dir / "selected_seed_metrics.json",
        {"selection": featured_info, "metrics": selected_metrics},
    )

    baseline = selected_results["baseline"]
    chart_final_distribution(baseline.capital, cfg, charts_dir)
    chart_talent_vs_success(selected_world, baseline.capital, charts_dir)
    chart_featured_lives(
        selected_world,
        baseline,
        featured_info["featured_indices"],
        cfg,
        charts_dir,
    )
    chart_many_worlds(metrics, charts_dir)
    chart_scenario_comparison(summary, charts_dir)

    if not args.skip_animation:
        print("Rendering 1080p simulation preview", flush=True)
        build_animation(
            selected_world,
            baseline,
            cfg,
            output_dir / "simulation_preview_1080p.mp4",
        )

    print(f"Outputs written to {output_dir}", flush=True)


if __name__ == "__main__":
    main()
