# Simülasyon Projeksiyon — Bölüm 01

## 1.000 kişi aynı parayla başladı: En yetenekli kazandı mı?

Bu paket kanalın ilk videosu için araştırmayı, çalıştırılabilir ajan tabanlı modeli, 1.000 tekrarlı deneyin ham verilerini, 16:9 grafikleri, 1080p simülasyon önizlemesini ve Türkçe anlatım/kurgu metinlerini içerir.

Ana iddia özellikle dar tutulmuştur:

> Bu basit modelin kuralları altında yetenek fırsatı değerlendirmeye yardım eder; fakat karşılaşılan fırsat ve talihsizliklerin dağılımı, en yüksek sonuca kimin ulaşacağını çok daha güçlü biçimde etkiler.

Bu bir gerçek ekonomi tahmini, insan kişiliği modeli veya “çalışmak önemsizdir” iddiası değildir.

## Neden ilk video bu?

Güncel taramada “çok sayıda kişi + tek anlaşılır kural + görünür sonuç” formatının güçlü olduğu, Minecraft/oyun tabanlı medeniyet simülasyonlarının ise kalabalıklaştığı görüldü. Türkçe içerikte şeffaf kurallı ve tekrarlanabilir sosyal simülasyonlar için daha açık bir alan var. Ayrıca 1.000'i aşkın kişiyi ajanlarla modelleyen güncel çalışmalar, “sanal toplum” fikrini anlaşılır ve güncel kılıyor.

Sekiz konu; merak, görsel güç, bilimsel dayanak, Türkçe içerik boşluğu, tekrar üretilebilirlik ve risk açısından puanlandı. Editoryal tablo `outputs/topic_ranking.csv`, görseli `outputs/charts/01_konu_puanlama.png` dosyasındadır.

## Model

Model, Pluchino, Biondo ve Rapisarda'nın “Talent vs Luck” çalışmasından uyarlanmıştır:

- 1.000 ajan, 10 başarı/sermaye puanıyla başlar.
- “Yetenek”, IQ değildir; bir fırsatı değerlendirme olasılığıdır.
- Yetenekler 0–1 aralığında, ortalaması 0,60 ve standart sapması 0,10 olan kesilmiş normal dağılımdan gelir.
- 500 olayın yarısı fırsat, yarısı talihsizliktir.
- Olaylar 201×201 toroidal dünyada her altı ayda iki hücrelik rastgele yürüyüş yapar.
- Bir fırsat ajana değerse, ajan yeteneği oranında onu değerlendirir ve puanı ikiye katlanır.
- Bir talihsizlik değerse puanı yarıya iner.
- Kariyer 40 yıl, yani 80 yarıyıl sürer.
- Deney 1.000 bağımsız evrende tekrarlanır.

Politika karşılaştırmaları aynı olay akışını ve aynı toplam fırsat bütçesini kullanır. Her beş yılda toplam 1.000 puan ya herkese birer puan, geçmişte en başarılı %10'a onar puan veya rastgele %10'a onar puan olarak dağıtılır.

## Nihai bulgular

1.000 desteksiz evrenin medyanı:

- Gini: **0,749**
- En üst %1'in toplam puan payı: **%34,3**
- En üst %20'nin payı: **%77,8**
- Başlangıç puanını aşan yüksek yetenekliler: **%31,3**
- En yetenekli kişinin kazanma sıklığı: **%0,7** — 1.000 evrende 7 kez
- Kazananın en yetenekli %1 içinde olma sıklığı: **%4,5**
- Kazananın medyan yetenek yüzdeliği: **%75,2**
- Yetenek ile sonuç arasındaki medyan sıra korelasyonu: **0,062**
- Dışsal olay dengesi ile sonuç arasındaki medyan sıra korelasyonu: **0,923**

Medyan Gini'ye en yakın “tipik” evren otomatik seçildi; tohum **20260926**:

- Kazanan A0646: yetenek 0,665; 8 fırsatın 8'ini değerlendirdi, talihsizlik yaşamadı; **2.560** puan.
- En yetenekli A0622: yetenek 0,888; 1 fırsat, 4 talihsizlik; **1,25** puan.
- Yetenekli ama şanssız A0743: yetenek 0,767; 10 talihsizlik; **0,0098** puan.
- Ortalama yetenekli A0830: yetenek 0,618; 12 fırsatın 7'sini değerlendirdi, talihsizlik yaşamadı; **1.280** puan.

Eşit fırsat bütçeli karşılaştırmanın medyan sonuçları:

| Kural | Gini | Başlangıcı aşan yüksek yetenekliler |
| --- | ---: | ---: |
| Desteksiz | 0,749 | %31,3 |
| Geçmiş kazananlara | 0,813 | %34,1 |
| Rastgele %10'a | 0,691 | %60,4 |
| Herkese küçük destek | 0,653 | %70,7 |

Bu sonuç yalnızca bu modelin mekanizması içinde geçerlidir. İnsan motivasyonu, eğitim, aile, ağlar, miras, ayrımcılık, sağlık, rekabet, işbirliği ve davranış değişimi modellenmemiştir. Bu nedenle grafikler politika reçetesi değil, mekanizma gösterimidir.

## Dosya haritası

- `simulation.py`: model, 1.000 tekrarlı deney, CSV/grafik/animasyon üretimi
- `test_simulation.py`: yeniden üretilebilirlik ve bütçe eşitliği testleri
- `outputs/all_run_metrics.csv`: 1.000 evren × 4 kural için özet metrikler
- `outputs/scenario_summary.csv`: kural bazında medyan ve yüzdelikler
- `outputs/selected_seed_agents_baseline.csv`: seçilen evrendeki 1.000 kişinin son verisi
- `outputs/selected_seed_animation_data.csv`: 81 kare × 1.000 ajan zaman serisi
- `outputs/selected_seed_event_positions.csv`: hareketli fırsat/talihsizlik noktaları
- `outputs/selected_seed_featured_agents_timeline.csv`: anlatıda izlenen dört kişinin zaman serisi
- `outputs/selected_seed_scenario_agents.csv`: dört kural altında seçilen evren
- `outputs/charts/*.png`: altı adet 16:9 editoryal grafik
- `outputs/simulation_preview_1080p.mp4`: 20,25 saniyelik 1080p önizleme
- `production/anlatim_metni.md`: yaklaşık 9–10 dakikalık anlatım
- `production/kurgu_plani.md`: zaman kodlu kurgu ve varlık eşlemesi
- `production/baslik_thumbnail.md`: başlık, kapak, açıklama ve sabit yorum
- `production/arastirma_karari.md`: konu seçiminin araştırma özeti

## Çalıştırma

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
MPLCONFIGDIR=.mplconfig python3 simulation.py --runs 1000 --seed 20260817
python3 -m unittest -v
```

`--skip-animation` parametresi yalnız CSV ve grafikleri üretir. Aynı tohum aynı dünyayı üretir.

## Kaynaklar

- Pluchino, Biondo & Rapisarda (2018), “Talent vs Luck: the role of randomness in success and failure”: https://arxiv.org/abs/1802.07068
- Makalenin okunabilir HTML sürümü: https://ar5iv.labs.arxiv.org/html/1802.07068
- Modelin yazar tarafından yayımlanan NetLogo kodu: https://www.comses.net/codebases/199a298b-fe95-473e-ad39-0fd69b5ff61c/releases/1.0.0/
- Park ve diğerleri, 1.052 kişilik üretken ajan çalışması: https://arxiv.org/abs/2411.10109
- Stanford HAI politika özeti: https://hai.stanford.edu/policy/simulating-human-behavior-with-ai-agents

