import unittest
from dataclasses import replace

import numpy as np

from simulation import Config, apply_scenarios, gini, make_world, metric_row


class SimulationTests(unittest.TestCase):
    def test_same_seed_reproduces_same_world(self):
        cfg = replace(Config(), n_agents=120, n_events=60, career_years=3)
        first = make_world(1234, cfg)
        second = make_world(1234, cfg)
        np.testing.assert_allclose(first.talent, second.talent)
        np.testing.assert_allclose(first.agent_positions, second.agent_positions)
        np.testing.assert_array_equal(first.lucky_hits, second.lucky_hits)
        np.testing.assert_array_equal(first.unlucky_hits, second.unlucky_hits)

    def test_baseline_capital_matches_event_exponents(self):
        cfg = replace(Config(), n_agents=150, n_events=75, career_years=5)
        world = make_world(5678, cfg)
        result = apply_scenarios(world, cfg, ["baseline"])["baseline"]
        expected = cfg.starting_capital * np.exp2(
            world.lucky_exploited.astype(int) - world.unlucky_hits.astype(int)
        )
        np.testing.assert_allclose(result.capital, expected)

    def test_support_scenarios_use_equal_total_budget_without_events(self):
        cfg = replace(
            Config(),
            n_agents=100,
            n_events=0,
            career_years=10,
            support_interval_years=5,
        )
        world = make_world(9012, cfg)
        results = apply_scenarios(
            world,
            cfg,
            ["equal_support", "past_winners", "random_10pct"],
        )
        totals = [result.capital.sum() for result in results.values()]
        np.testing.assert_allclose(totals, totals[0])
        expected = cfg.n_agents * cfg.starting_capital + 2 * cfg.n_agents
        self.assertAlmostEqual(totals[0], expected)

    def test_metrics_remain_in_valid_ranges(self):
        cfg = replace(Config(), n_agents=200, n_events=100, career_years=5)
        world = make_world(3456, cfg)
        capital = apply_scenarios(world, cfg, ["baseline"])["baseline"].capital
        row = metric_row(3456, "baseline", world, capital, cfg)
        self.assertGreaterEqual(gini(capital), 0.0)
        self.assertLessEqual(gini(capital), 1.0)
        self.assertGreaterEqual(row["top_1_share"], 0.0)
        self.assertLessEqual(row["top_1_share"], 1.0)
        self.assertGreaterEqual(row["winner_talent_percentile"], 0.0)
        self.assertLessEqual(row["winner_talent_percentile"], 100.0)


if __name__ == "__main__":
    unittest.main()
