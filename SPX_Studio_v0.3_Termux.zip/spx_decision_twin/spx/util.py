from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Iterable, Sequence


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def sigmoid(value: float) -> float:
    if value >= 0:
        z = math.exp(-value)
        return 1.0 / (1.0 + z)
    z = math.exp(value)
    return z / (1.0 + z)


def stable_seed(*parts: Any) -> int:
    """Platformdan bağımsız, sıralı ve tekrar üretilebilir 64-bit tohum."""
    payload = "\x1f".join(str(part) for part in parts).encode("utf-8")
    return int.from_bytes(hashlib.blake2b(payload, digest_size=8).digest(), "big")


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def object_hash(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else math.nan


def variance(values: Sequence[float], *, sample: bool = False) -> float:
    if not values:
        return math.nan
    if sample and len(values) < 2:
        return 0.0
    center = mean(values)
    denom = len(values) - 1 if sample else len(values)
    return sum((x - center) ** 2 for x in values) / denom


def stdev(values: Sequence[float], *, sample: bool = False) -> float:
    return math.sqrt(max(0.0, variance(values, sample=sample)))


def quantile(values: Sequence[float], q: float) -> float:
    if not values:
        return math.nan
    ordered = sorted(values)
    q = clamp(q, 0.0, 1.0)
    position = (len(ordered) - 1) * q
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    if lower == upper:
        return ordered[lower]
    weight = position - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


def cvar(values: Sequence[float], alpha: float = 0.1, *, lower_tail: bool = True) -> float:
    if not values:
        return math.nan
    count = max(1, math.ceil(len(values) * clamp(alpha, 1e-9, 1.0)))
    ordered = sorted(values)
    tail = ordered[:count] if lower_tail else ordered[-count:]
    return mean(tail)


def rankdata(values: Sequence[float]) -> list[float]:
    indexed = sorted(enumerate(values), key=lambda pair: pair[1])
    ranks = [0.0] * len(values)
    i = 0
    while i < len(indexed):
        j = i + 1
        while j < len(indexed) and indexed[j][1] == indexed[i][1]:
            j += 1
        average_rank = (i + j - 1) / 2.0 + 1.0
        for k in range(i, j):
            ranks[indexed[k][0]] = average_rank
        i = j
    return ranks


def pearson(x: Sequence[float], y: Sequence[float]) -> float:
    if len(x) != len(y) or len(x) < 2:
        return 0.0
    mx, my = mean(x), mean(y)
    sx = math.sqrt(sum((v - mx) ** 2 for v in x))
    sy = math.sqrt(sum((v - my) ** 2 for v in y))
    if sx <= 1e-15 or sy <= 1e-15:
        return 0.0
    return sum((a - mx) * (b - my) for a, b in zip(x, y)) / (sx * sy)


def spearman(x: Sequence[float], y: Sequence[float]) -> float:
    return pearson(rankdata(x), rankdata(y))


def weighted_choice(values: Sequence[Any], weights: Sequence[float], draw: float) -> Any:
    if len(values) != len(weights) or not values:
        raise ValueError("values ve weights aynı, sıfırdan büyük uzunlukta olmalı")
    total = sum(max(0.0, w) for w in weights)
    if total <= 0:
        return values[-1]
    threshold = clamp(draw, 0.0, 1.0 - 1e-16) * total
    cumulative = 0.0
    for value, weight in zip(values, weights):
        cumulative += max(0.0, weight)
        if threshold < cumulative:
            return value
    return values[-1]


def safe_slug(value: str) -> str:
    normalized = []
    replacements = str.maketrans("çğıöşüÇĞİÖŞÜ", "cgiosuCGIOSU")
    for char in value.translate(replacements).lower():
        normalized.append(char if char.isalnum() else "-")
    return "-".join(part for part in "".join(normalized).split("-") if part)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def finite_or(value: float, fallback: float = 0.0) -> float:
    return value if math.isfinite(value) else fallback


def chunks(values: Sequence[Any], size: int) -> Iterable[Sequence[Any]]:
    for index in range(0, len(values), size):
        yield values[index : index + size]

