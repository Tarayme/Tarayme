from __future__ import annotations

import itertools
import math
from collections import defaultdict
from typing import Any, Mapping, Sequence

from .safeexpr import compile_expression
from .util import clamp, cvar, mean, quantile, spearman, stdev


def summarize_run(
    outcomes: list[dict[str, Any]],
    strategies: list[dict[str, Any]],
    objectives: list[dict[str, Any]],
    constraints: list[dict[str, Any]],
    decision_policy: Mapping[str, Any],
) -> dict[str, Any]:
    by_strategy: dict[str, list[dict[str, Any]]] = defaultdict(list)
    by_world: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for outcome in outcomes:
        by_strategy[outcome["strategy_id"]].append(outcome)
        by_world[int(outcome["world_id"])].append(outcome)

    regret: dict[tuple[int, str], float] = {}
    for world_id, world_outcomes in by_world.items():
        best = max(item["utility"] for item in world_outcomes)
        for item in world_outcomes:
            regret[(world_id, item["strategy_id"])] = best - item["utility"]

    acceptance = float(decision_policy.get("acceptance_utility", 0.58))
    tail_alpha = float(decision_policy.get("tail_alpha", 0.10))
    weights = {
        "expected": float(decision_policy.get("expected_weight", 0.28)),
        "tail": float(decision_policy.get("tail_weight", 0.22)),
        "robustness": float(decision_policy.get("robustness_weight", 0.20)),
        "success": float(decision_policy.get("success_weight", 0.15)),
        "regret": float(decision_policy.get("regret_weight", 0.15)),
    }
    weight_total = sum(weights.values()) or 1.0
    strategy_summaries: list[dict[str, Any]] = []
    for strategy in strategies:
        strategy_id = str(strategy["id"])
        rows = by_strategy[strategy_id]
        utilities = [float(row["utility"]) for row in rows]
        constraint_ids = [str(item.get("id", item.get("name", "constraint"))) for item in constraints]
        violation_probabilities = {
            constraint_id: mean([
                1.0 if row["constraint_violations"].get(constraint_id, False) else 0.0
                for row in rows
            ])
            for constraint_id in constraint_ids
        }
        constraint_pass = [not any(row["constraint_violations"].values()) for row in rows]
        robustness = mean([
            1.0 if utility >= acceptance and passed else 0.0
            for utility, passed in zip(utilities, constraint_pass)
        ])
        regrets = [regret[(int(row["world_id"]), strategy_id)] for row in rows]
        eligible = True
        breaches: list[str] = []
        for constraint in constraints:
            constraint_id = str(constraint.get("id", constraint.get("name", "constraint")))
            allowed = float(constraint.get("max_violation_probability", 1.0))
            if constraint.get("hard", True) and violation_probabilities[constraint_id] > allowed:
                eligible = False
                breaches.append(constraint_id)
        ruin_ids = {
            str(item.get("id", item.get("name", "constraint")))
            for item in constraints
            if item.get("ruin", False)
        }
        ruin_probability = mean([
            1.0 if any(row["constraint_violations"].get(item, False) for item in ruin_ids) else 0.0
            for row in rows
        ]) if ruin_ids else 0.0
        metric_stats: dict[str, Any] = {}
        metric_names = sorted({name for row in rows for name in row["metrics"]})
        for metric_name in metric_names:
            values = [float(row["metrics"][metric_name]) for row in rows]
            metric_stats[metric_name] = _stats(values, tail_alpha)
        expected_utility = mean(utilities)
        tail_utility = cvar(utilities, tail_alpha, lower_tail=True)
        success_probability = mean([1.0 if row["success"] else 0.0 for row in rows])
        mean_regret = mean(regrets)
        score = (
            weights["expected"] * expected_utility
            + weights["tail"] * tail_utility
            + weights["robustness"] * robustness
            + weights["success"] * success_probability
            + weights["regret"] * (1.0 - mean_regret)
        ) / weight_total
        if not eligible:
            score -= 1.0
        strategy_summaries.append(
            {
                "strategy_id": strategy_id,
                "label": str(strategy.get("label", strategy_id)),
                "eligible": eligible,
                "hard_constraint_breaches": breaches,
                "decision_score": score,
                "expected_utility": expected_utility,
                "utility_p05": quantile(utilities, 0.05),
                "utility_p50": quantile(utilities, 0.50),
                "utility_p95": quantile(utilities, 0.95),
                "utility_cvar": tail_utility,
                "success_probability": success_probability,
                "robustness": robustness,
                "mean_regret": mean_regret,
                "max_regret": max(regrets) if regrets else 0.0,
                "ruin_probability": ruin_probability,
                "constraint_violation_probability": violation_probabilities,
                "metrics": metric_stats,
            }
        )
    strategy_summaries.sort(key=lambda row: (row["eligible"], row["decision_score"]), reverse=True)
    pareto_ids = pareto_frontier(strategy_summaries, objectives)
    for summary in strategy_summaries:
        summary["pareto"] = summary["strategy_id"] in pareto_ids
        summary["rank"] = strategy_summaries.index(summary) + 1
    return {
        "ranking": strategy_summaries,
        "recommended_strategy_id": strategy_summaries[0]["strategy_id"],
        "pareto_strategy_ids": sorted(pareto_ids),
        "world_count": len(by_world),
        "acceptance_utility": acceptance,
        "tail_alpha": tail_alpha,
    }


def _stats(values: Sequence[float], tail_alpha: float) -> dict[str, float]:
    return {
        "mean": mean(values),
        "sd": stdev(values),
        "p05": quantile(values, 0.05),
        "p50": quantile(values, 0.50),
        "p95": quantile(values, 0.95),
        "cvar_low": cvar(values, tail_alpha, lower_tail=True),
    }


def pareto_frontier(
    summaries: Sequence[Mapping[str, Any]], objectives: Sequence[Mapping[str, Any]]
) -> set[str]:
    objective_specs = [item for item in objectives if item.get("metric")]
    if not objective_specs:
        return {str(item["strategy_id"]) for item in summaries}
    frontier: set[str] = set()
    for candidate in summaries:
        dominated = False
        for challenger in summaries:
            if challenger is candidate:
                continue
            weakly_better = True
            strictly_better = False
            for objective in objective_specs:
                metric = str(objective["metric"])
                a = float(candidate["metrics"][metric]["mean"])
                b = float(challenger["metrics"][metric]["mean"])
                direction = str(objective.get("direction", "max"))
                if direction == "min":
                    a, b = -a, -b
                if b < a - 1e-12:
                    weakly_better = False
                    break
                if b > a + 1e-12:
                    strictly_better = True
            if weakly_better and strictly_better:
                dominated = True
                break
        if not dominated:
            frontier.add(str(candidate["strategy_id"]))
    return frontier


def pairwise_comparisons(
    outcomes: Sequence[Mapping[str, Any]], strategies: Sequence[Mapping[str, Any]]
) -> list[dict[str, Any]]:
    by_strategy_world = {
        (str(row["strategy_id"]), int(row["world_id"])): row for row in outcomes
    }
    world_ids = sorted({int(row["world_id"]) for row in outcomes})
    results: list[dict[str, Any]] = []
    for left, right in itertools.combinations(strategies, 2):
        left_id, right_id = str(left["id"]), str(right["id"])
        deltas = [
            float(by_strategy_world[(left_id, world_id)]["utility"])
            - float(by_strategy_world[(right_id, world_id)]["utility"])
            for world_id in world_ids
        ]
        results.append(
            {
                "left": left_id,
                "right": right_id,
                "p_left_better": mean([1.0 if delta > 0 else 0.0 for delta in deltas]),
                "p_tie": mean([1.0 if abs(delta) <= 1e-12 else 0.0 for delta in deltas]),
                "mean_utility_delta": mean(deltas),
                "p05_delta": quantile(deltas, 0.05),
                "p50_delta": quantile(deltas, 0.50),
                "p95_delta": quantile(deltas, 0.95),
            }
        )
    return results


def sensitivity_analysis(
    outcomes: Sequence[Mapping[str, Any]], strategies: Sequence[Mapping[str, Any]], limit: int = 12
) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = {}
    for strategy in strategies:
        strategy_id = str(strategy["id"])
        rows = [row for row in outcomes if row["strategy_id"] == strategy_id]
        utilities = [float(row["utility"]) for row in rows]
        feature_names = sorted({name for row in rows for name in row.get("features", {})})
        effects: list[dict[str, Any]] = []
        for feature in feature_names:
            values = [float(row["features"].get(feature, 0.0)) for row in rows]
            rho = spearman(values, utilities)
            effects.append({"driver": feature, "spearman": rho, "absolute_effect": abs(rho), "kind": "main"})
        effects.sort(key=lambda row: row["absolute_effect"], reverse=True)
        top_main = effects[:limit]
        interaction_candidates = top_main[: min(6, len(top_main))]
        interactions: list[dict[str, Any]] = []
        for left, right in itertools.combinations(interaction_candidates, 2):
            left_values = [float(row["features"].get(left["driver"], 0.0)) for row in rows]
            right_values = [float(row["features"].get(right["driver"], 0.0)) for row in rows]
            left_center, right_center = mean(left_values), mean(right_values)
            left_sd, right_sd = stdev(left_values), stdev(right_values)
            if left_sd <= 1e-12 or right_sd <= 1e-12:
                continue
            products = [
                ((a - left_center) / left_sd) * ((b - right_center) / right_sd)
                for a, b in zip(left_values, right_values)
            ]
            rho = spearman(products, utilities)
            interactions.append(
                {
                    "driver": f"{left['driver']} × {right['driver']}",
                    "spearman": rho,
                    "absolute_effect": abs(rho),
                    "kind": "interaction",
                }
            )
        interactions.sort(key=lambda row: row["absolute_effect"], reverse=True)
        result[strategy_id] = top_main + interactions[:4]
    return result


def cluster_futures(
    outcomes: Sequence[Mapping[str, Any]],
    strategies: Sequence[Mapping[str, Any]],
    cluster_count: int,
    max_iterations: int = 60,
) -> list[dict[str, Any]]:
    if not outcomes:
        return []
    first_strategy = str(strategies[0]["id"])
    base_rows = sorted(
        (row for row in outcomes if row["strategy_id"] == first_strategy),
        key=lambda row: int(row["world_id"]),
    )
    feature_names = sorted(
        name
        for name in base_rows[0].get("features", {})
        if name.startswith("driver_") and name.endswith("_mean")
    )
    if not feature_names:
        feature_names = sorted(base_rows[0].get("features", {}))
    raw = [[float(row["features"].get(name, 0.0)) for name in feature_names] for row in base_rows]
    centers = [mean([row[index] for row in raw]) for index in range(len(feature_names))]
    scales = [stdev([row[index] for row in raw]) or 1.0 for index in range(len(feature_names))]
    points = [[(value - centers[index]) / scales[index] for index, value in enumerate(row)] for row in raw]
    k = max(1, min(cluster_count, len(points)))
    centroid_indices = [_nearest_to_origin(points)]
    while len(centroid_indices) < k:
        next_index = max(
            (index for index in range(len(points)) if index not in centroid_indices),
            key=lambda index: min(_distance2(points[index], points[c]) for c in centroid_indices),
        )
        centroid_indices.append(next_index)
    centroids = [list(points[index]) for index in centroid_indices]
    assignments = [0] * len(points)
    for _ in range(max_iterations):
        new_assignments = [
            min(range(k), key=lambda cluster: _distance2(point, centroids[cluster]))
            for point in points
        ]
        if new_assignments == assignments and _ > 0:
            break
        assignments = new_assignments
        for cluster in range(k):
            members = [points[index] for index, assigned in enumerate(assignments) if assigned == cluster]
            if members:
                centroids[cluster] = [mean([row[index] for row in members]) for index in range(len(feature_names))]
    by_key = {(int(row["world_id"]), str(row["strategy_id"])): row for row in outcomes}
    clusters: list[dict[str, Any]] = []
    for cluster in range(k):
        member_indices = [index for index, assigned in enumerate(assignments) if assigned == cluster]
        world_ids = [int(base_rows[index]["world_id"]) for index in member_indices]
        if not world_ids:
            continue
        centroid = centroids[cluster]
        top_dimensions = sorted(range(len(feature_names)), key=lambda index: abs(centroid[index]), reverse=True)[:2]
        label_parts = [
            f"{'yüksek' if centroid[index] >= 0 else 'düşük'} {_display_driver(feature_names[index])}"
            for index in top_dimensions
            if abs(centroid[index]) >= 0.18
        ]
        label = " + ".join(label_parts) if label_parts else "merkez senaryolar"
        strategy_results: list[dict[str, Any]] = []
        for strategy in strategies:
            strategy_id = str(strategy["id"])
            rows = [by_key[(world_id, strategy_id)] for world_id in world_ids]
            strategy_results.append(
                {
                    "strategy_id": strategy_id,
                    "mean_utility": mean([float(row["utility"]) for row in rows]),
                    "success_probability": mean([1.0 if row["success"] else 0.0 for row in rows]),
                }
            )
        strategy_results.sort(key=lambda row: row["mean_utility"], reverse=True)
        clusters.append(
            {
                "cluster_id": cluster + 1,
                "label": label,
                "worlds": len(world_ids),
                "probability": len(world_ids) / len(base_rows),
                "best_strategy_id": strategy_results[0]["strategy_id"],
                "strategies": strategy_results,
                "driver_z": {feature_names[index]: centroid[index] for index in range(len(feature_names))},
            }
        )
    clusters.sort(key=lambda row: row["probability"], reverse=True)
    return clusters


def decision_boundaries(
    outcomes: Sequence[Mapping[str, Any]], strategies: Sequence[Mapping[str, Any]], limit: int = 12
) -> list[dict[str, Any]]:
    by_key = {(int(row["world_id"]), str(row["strategy_id"])): row for row in outcomes}
    first_strategy = str(strategies[0]["id"])
    base_rows = [row for row in outcomes if row["strategy_id"] == first_strategy]
    world_ids = sorted(int(row["world_id"]) for row in base_rows)
    features = sorted(
        name for name in base_rows[0].get("features", {}) if name.startswith("driver_")
    )
    boundaries: list[dict[str, Any]] = []
    for left, right in itertools.combinations(strategies, 2):
        left_id, right_id = str(left["id"]), str(right["id"])
        for feature in features:
            pairs = sorted(
                (
                    float(by_key[(world_id, first_strategy)]["features"][feature]),
                    float(by_key[(world_id, left_id)]["utility"]) - float(by_key[(world_id, right_id)]["utility"]),
                )
                for world_id in world_ids
            )
            best: dict[str, Any] | None = None
            prefix: list[float] = []
            running = 0.0
            for _, delta in pairs:
                running += delta
                prefix.append(running)
            lower_split = max(2, int(len(pairs) * 0.20))
            upper_split = min(len(pairs) - 2, int(len(pairs) * 0.80))
            for split in range(lower_split, upper_split + 1):
                if pairs[split - 1][0] >= pairs[split][0]:
                    continue
                below = prefix[split - 1] / split
                above = (prefix[-1] - prefix[split - 1]) / (len(pairs) - split)
                if below == 0 or above == 0 or below * above >= 0:
                    continue
                balance = min(split, len(pairs) - split) / (len(pairs) / 2.0)
                score = abs(below - above) * balance
                candidate = {
                    "driver": feature,
                    "threshold": (pairs[split - 1][0] + pairs[split][0]) / 2.0,
                    "below_best": left_id if below > 0 else right_id,
                    "above_best": left_id if above > 0 else right_id,
                    "below_utility_delta": below,
                    "above_utility_delta": above,
                    "strength": score,
                }
                if best is None or candidate["strength"] > best["strength"]:
                    best = candidate
            if best is not None and best["strength"] >= 0.015:
                boundaries.append(best)
    boundaries.sort(key=lambda row: row["strength"], reverse=True)
    return boundaries[:limit]


def stress_profiles(
    outcomes: Sequence[Mapping[str, Any]],
    strategies: Sequence[Mapping[str, Any]],
    stress_tests: Sequence[Mapping[str, Any]],
    tail_alpha: float,
) -> list[dict[str, Any]]:
    profiles: list[dict[str, Any]] = []
    for stress in stress_tests:
        expression = compile_expression(stress["condition"])
        strategy_results: list[dict[str, Any]] = []
        for strategy in strategies:
            strategy_id = str(strategy["id"])
            rows = []
            for outcome in outcomes:
                if outcome["strategy_id"] != strategy_id:
                    continue
                context = dict(outcome.get("features", {}))
                context.update(outcome.get("metrics", {}))
                if bool(expression.evaluate(context)):
                    rows.append(outcome)
            utilities = [float(row["utility"]) for row in rows]
            strategy_results.append(
                {
                    "strategy_id": strategy_id,
                    "worlds": len(rows),
                    "probability": len(rows) / max(1, len([row for row in outcomes if row["strategy_id"] == strategy_id])),
                    "expected_utility": mean(utilities) if utilities else math.nan,
                    "utility_cvar": cvar(utilities, tail_alpha) if utilities else math.nan,
                    "success_probability": mean([1.0 if row["success"] else 0.0 for row in rows]) if rows else math.nan,
                }
            )
        valid = [row for row in strategy_results if math.isfinite(row["expected_utility"])]
        valid.sort(key=lambda row: row["expected_utility"], reverse=True)
        profiles.append(
            {
                "id": str(stress.get("id", f"stress-{len(profiles)+1}")),
                "label": str(stress.get("label", stress.get("id", "Stress"))),
                "condition": str(stress["condition"]),
                "best_strategy_id": valid[0]["strategy_id"] if valid else None,
                "strategies": strategy_results,
            }
        )
    return profiles


def _nearest_to_origin(points: Sequence[Sequence[float]]) -> int:
    return min(range(len(points)), key=lambda index: sum(value * value for value in points[index]))


def _distance2(left: Sequence[float], right: Sequence[float]) -> float:
    return sum((a - b) ** 2 for a, b in zip(left, right))


def _display_driver(name: str) -> str:
    value = name.removeprefix("driver_")
    for suffix in ("_mean", "_min", "_max", "_final"):
        value = value.removesuffix(suffix)
    return value.replace("_", " ")
