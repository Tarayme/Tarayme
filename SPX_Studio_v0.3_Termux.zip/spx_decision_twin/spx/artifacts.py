from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from .engine import RunResult
from .registry import record_run
from .report import build_html_report
from .schema import Scenario
from .util import write_json


def write_run(output_directory: str | Path, result: RunResult, scenario: Scenario) -> dict[str, Path]:
    output = Path(output_directory).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    paths = {
        "report": output / "report.html",
        "summary": output / "summary.json",
        "worlds": output / "worlds.csv",
        "traces": output / "traces.json",
        "audit": output / "audit.json",
        "ledger": output / "spx_ledger.sqlite3",
        "scenario": output / "scenario.snapshot.json",
    }
    paths["report"].write_text(build_html_report(result, scenario), encoding="utf-8")
    write_json(paths["summary"], result.compact())
    write_json(paths["traces"], result.traces)
    write_json(paths["audit"], result.audit)
    write_json(paths["scenario"], scenario.raw)
    _write_worlds(paths["worlds"], result)
    record_run(paths["ledger"], result)
    return paths


def _write_worlds(path: Path, result: RunResult) -> None:
    if not result.outcomes:
        path.write_text("", encoding="utf-8")
        return
    metric_names = sorted({name for row in result.outcomes for name in row["metrics"]})
    feature_names = sorted({name for row in result.outcomes for name in row.get("features", {})})
    constraint_names = sorted({name for row in result.outcomes for name in row.get("constraint_violations", {})})
    fieldnames = ["world_id", "strategy_id", "utility", "success"]
    fieldnames += [f"metric__{name}" for name in metric_names]
    fieldnames += [f"feature__{name}" for name in feature_names]
    fieldnames += [f"violation__{name}" for name in constraint_names]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for outcome in result.outcomes:
            row: dict[str, Any] = {
                "world_id": outcome["world_id"],
                "strategy_id": outcome["strategy_id"],
                "utility": outcome["utility"],
                "success": int(bool(outcome["success"])),
            }
            row.update({f"metric__{name}": outcome["metrics"].get(name) for name in metric_names})
            row.update({f"feature__{name}": outcome.get("features", {}).get(name) for name in feature_names})
            row.update({f"violation__{name}": int(bool(outcome.get("constraint_violations", {}).get(name))) for name in constraint_names})
            writer.writerow(row)

