from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Any, Mapping

from .safeexpr import CompiledExpression, compile_expression
from .util import clamp


@dataclass
class ActorStep:
    actor_id: str
    shares: dict[str, float]
    effects: dict[str, float]


class ActorRuntime:
    """Temsili kişi/kurum segmentini stokastik softmax politika ile simüle eder."""

    def __init__(self, spec: Mapping[str, Any]):
        self.spec = dict(spec)
        self.actor_id = str(spec["id"])
        self.population = int(spec.get("population", 1))
        self.temperature = max(1e-6, float(spec.get("temperature", 0.35)))
        self.inertia = clamp(float(spec.get("inertia", 0.0)), 0.0, 0.999)
        self.concentration = max(2.0, float(spec.get("response_concentration", min(250, max(20, self.population ** 0.5)))))
        self.enabled_when = compile_expression(spec.get("enabled_when", "true"))
        self.actions: list[dict[str, Any]] = []
        for action in spec.get("actions", []):
            action_id = str(action["id"])
            self.actions.append(
                {
                    "id": action_id,
                    "utility": compile_expression(action.get("utility", 0.0)),
                    "effects": {
                        str(key): compile_expression(value)
                        for key, value in action.get("effects", {}).items()
                    },
                }
            )
        if not self.actions:
            raise ValueError(f"Aktörün en az bir eylemi olmalı: {self.actor_id}")
        equal = 1.0 / len(self.actions)
        self.previous = {action["id"]: equal for action in self.actions}

    def step(self, context: Mapping[str, Any], rng: random.Random) -> ActorStep:
        if not bool(self.enabled_when.evaluate(context)):
            return ActorStep(self.actor_id, dict(self.previous), {})
        utilities = [float(action["utility"].evaluate(context)) for action in self.actions]
        peak = max(utilities)
        raw = [math.exp(clamp((utility - peak) / self.temperature, -60.0, 0.0)) for utility in utilities]
        total = sum(raw) or 1.0
        probabilities = [value / total for value in raw]
        probabilities = [
            (1.0 - self.inertia) * probability + self.inertia * self.previous[action["id"]]
            for probability, action in zip(probabilities, self.actions)
        ]
        draws = [rng.gammavariate(max(1e-6, probability * self.concentration), 1.0) for probability in probabilities]
        draw_total = sum(draws) or 1.0
        shares = {action["id"]: draw / draw_total for action, draw in zip(self.actions, draws)}
        effects: dict[str, float] = {}
        local_context = dict(context)
        for action_id, share in shares.items():
            local_context[f"actor_{self.actor_id}_{action_id}_share"] = share
        for action in self.actions:
            share = shares[action["id"]]
            for effect_id, expression in action["effects"].items():
                effects[effect_id] = effects.get(effect_id, 0.0) + share * float(expression.evaluate(local_context))
        self.previous = shares
        return ActorStep(self.actor_id, shares, effects)


def run_actors(
    runtimes: list[ActorRuntime], context: dict[str, Any], rng_factory
) -> tuple[dict[str, float], dict[str, dict[str, float]]]:
    total_effects: dict[str, float] = {}
    shares: dict[str, dict[str, float]] = {}
    for runtime in runtimes:
        result = runtime.step(context, rng_factory(runtime.actor_id))
        shares[runtime.actor_id] = result.shares
        for action_id, share in result.shares.items():
            context[f"actor_{runtime.actor_id}_{action_id}_share"] = share
        for key, value in result.effects.items():
            total_effects[key] = total_effects.get(key, 0.0) + value
            context[key] = total_effects[key]
    return total_effects, shares

