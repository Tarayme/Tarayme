from __future__ import annotations

import ast
import math
from dataclasses import dataclass
from typing import Any, Mapping

from .util import clamp, sigmoid


class ExpressionError(ValueError):
    pass


def _step(value: float, threshold: float = 0.0) -> float:
    return 1.0 if value >= threshold else 0.0


def _lerp(a: float, b: float, weight: float) -> float:
    return a + (b - a) * clamp(weight, 0.0, 1.0)


def _safe_div(a: float, b: float, fallback: float = 0.0) -> float:
    return fallback if abs(b) < 1e-15 else a / b


FUNCTIONS: dict[str, Any] = {
    "abs": abs,
    "min": min,
    "max": max,
    "round": round,
    "sqrt": math.sqrt,
    "log": math.log,
    "log1p": math.log1p,
    "exp": math.exp,
    "sin": math.sin,
    "cos": math.cos,
    "tanh": math.tanh,
    "floor": math.floor,
    "ceil": math.ceil,
    "clamp": clamp,
    "sigmoid": sigmoid,
    "step": _step,
    "lerp": _lerp,
    "safe_div": _safe_div,
}

CONSTANTS = {"pi": math.pi, "e": math.e, "true": True, "false": False}

ALLOWED_NODES = (
    ast.Expression,
    ast.Constant,
    ast.Name,
    ast.Load,
    ast.BinOp,
    ast.UnaryOp,
    ast.BoolOp,
    ast.Compare,
    ast.IfExp,
    ast.Call,
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Div,
    ast.FloorDiv,
    ast.Mod,
    ast.Pow,
    ast.USub,
    ast.UAdd,
    ast.Not,
    ast.And,
    ast.Or,
    ast.Eq,
    ast.NotEq,
    ast.Lt,
    ast.LtE,
    ast.Gt,
    ast.GtE,
)


@dataclass(frozen=True)
class CompiledExpression:
    source: str
    code: Any
    names: frozenset[str]

    def evaluate(self, context: Mapping[str, Any]) -> Any:
        namespace = dict(FUNCTIONS)
        namespace.update(CONSTANTS)
        namespace.update(context)
        try:
            result = eval(self.code, {"__builtins__": {}}, namespace)
        except Exception as exc:  # Kullanıcı modeli için zengin bağlam ekliyoruz.
            raise ExpressionError(f"İfade çalıştırılamadı: {self.source!r}: {exc}") from exc
        if isinstance(result, complex):
            raise ExpressionError(f"İfade karmaşık sayı üretti: {self.source!r}")
        return result


def compile_expression(source: str | int | float | bool) -> CompiledExpression:
    if isinstance(source, (int, float, bool)):
        source = repr(source)
    if not isinstance(source, str) or not source.strip():
        raise ExpressionError("İfade boş olamaz")
    try:
        tree = ast.parse(source, mode="eval")
    except SyntaxError as exc:
        raise ExpressionError(f"Geçersiz ifade: {source!r}: {exc.msg}") from exc
    for node in ast.walk(tree):
        if not isinstance(node, ALLOWED_NODES):
            raise ExpressionError(
                f"İfadede izin verilmeyen yapı: {type(node).__name__} ({source!r})"
            )
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name) or node.func.id not in FUNCTIONS:
                raise ExpressionError(f"İzin verilmeyen fonksiyon çağrısı: {source!r}")
            if node.keywords:
                raise ExpressionError("Fonksiyonlarda keyword argüman desteklenmiyor")
        if isinstance(node, ast.Name) and node.id.startswith("__"):
            raise ExpressionError("Çift alt çizgili adlar yasaktır")
        if isinstance(node, ast.Pow) and isinstance(getattr(node, "right", None), ast.Constant):
            if abs(float(node.right.value)) > 12:
                raise ExpressionError("Sabit üs mutlak değerce 12'yi aşamaz")
    names = {
        node.id
        for node in ast.walk(tree)
        if isinstance(node, ast.Name)
        and node.id not in FUNCTIONS
        and node.id not in CONSTANTS
    }
    return CompiledExpression(source, compile(tree, "<spx-expression>", "eval"), frozenset(names))

