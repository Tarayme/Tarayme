from __future__ import annotations

import csv
import json
import math
import sqlite3
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping

from .engine import RunResult
from .util import clamp, mean


SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS runs (
    run_id TEXT PRIMARY KEY,
    scenario_id TEXT NOT NULL,
    scenario_hash TEXT NOT NULL,
    engine_version TEXT NOT NULL,
    seed INTEGER NOT NULL,
    worlds INTEGER NOT NULL,
    horizon INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    metadata_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS strategy_summaries (
    run_id TEXT NOT NULL,
    strategy_id TEXT NOT NULL,
    rank INTEGER NOT NULL,
    decision_score REAL NOT NULL,
    expected_utility REAL NOT NULL,
    utility_cvar REAL NOT NULL,
    success_probability REAL NOT NULL,
    robustness REAL NOT NULL,
    summary_json TEXT NOT NULL,
    PRIMARY KEY (run_id, strategy_id),
    FOREIGN KEY (run_id) REFERENCES runs(run_id)
);
CREATE TABLE IF NOT EXISTS forecast_outcomes (
    prediction_id TEXT PRIMARY KEY,
    model_id TEXT NOT NULL,
    horizon TEXT,
    regime TEXT,
    probability REAL NOT NULL,
    outcome INTEGER NOT NULL,
    timestamp TEXT,
    metadata_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_forecast_model ON forecast_outcomes(model_id, horizon, regime);
"""


def connect(path: str | Path) -> sqlite3.Connection:
    db_path = Path(path).expanduser().resolve()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(db_path)
    connection.executescript(SCHEMA)
    return connection


def record_run(path: str | Path, result: RunResult) -> None:
    with connect(path) as connection:
        metadata = result.metadata
        connection.execute(
            """
            INSERT OR REPLACE INTO runs
            (run_id, scenario_id, scenario_hash, engine_version, seed, worlds, horizon, created_at, metadata_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                metadata["run_id"],
                metadata["scenario_id"],
                metadata["scenario_hash"],
                metadata["engine_version"],
                int(metadata["seed"]),
                int(metadata["worlds"]),
                int(metadata["horizon"]),
                metadata["started_at"],
                json.dumps(metadata, ensure_ascii=False, sort_keys=True),
            ),
        )
        for summary in result.summary["ranking"]:
            connection.execute(
                """
                INSERT OR REPLACE INTO strategy_summaries
                (run_id, strategy_id, rank, decision_score, expected_utility, utility_cvar,
                 success_probability, robustness, summary_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    metadata["run_id"],
                    summary["strategy_id"],
                    int(summary["rank"]),
                    float(summary["decision_score"]),
                    float(summary["expected_utility"]),
                    float(summary["utility_cvar"]),
                    float(summary["success_probability"]),
                    float(summary["robustness"]),
                    json.dumps(summary, ensure_ascii=False, sort_keys=True),
                ),
            )


def import_forecasts(path: str | Path, csv_path: str | Path) -> int:
    rows = list(csv.DictReader(Path(csv_path).read_text(encoding="utf-8").splitlines()))
    required = {"prediction_id", "model_id", "probability", "outcome"}
    if not rows or not required <= set(rows[0]):
        raise ValueError("Kalibrasyon CSV'si prediction_id, model_id, probability, outcome sütunlarını taşımalı")
    with connect(path) as connection:
        for row in rows:
            probability = clamp(float(row["probability"]), 1e-12, 1.0 - 1e-12)
            outcome = int(row["outcome"])
            if outcome not in {0, 1}:
                raise ValueError("outcome yalnızca 0 veya 1 olabilir")
            metadata = {key: value for key, value in row.items() if key not in required}
            connection.execute(
                """
                INSERT OR REPLACE INTO forecast_outcomes
                (prediction_id, model_id, horizon, regime, probability, outcome, timestamp, metadata_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    row["prediction_id"],
                    row["model_id"],
                    row.get("horizon"),
                    row.get("regime"),
                    probability,
                    outcome,
                    row.get("timestamp"),
                    json.dumps(metadata, ensure_ascii=False, sort_keys=True),
                ),
            )
    return len(rows)


def calibration_report(path: str | Path) -> dict[str, Any]:
    with connect(path) as connection:
        rows = connection.execute(
            "SELECT model_id, horizon, regime, probability, outcome FROM forecast_outcomes ORDER BY model_id"
        ).fetchall()
    groups: dict[tuple[str, str, str], list[tuple[float, int]]] = defaultdict(list)
    for model_id, horizon, regime, probability, outcome in rows:
        groups[(model_id, horizon or "*", regime or "*")].append((float(probability), int(outcome)))
    reports = []
    for (model_id, horizon, regime), values in sorted(groups.items()):
        probabilities = [value[0] for value in values]
        outcomes = [value[1] for value in values]
        brier = mean([(probability - outcome) ** 2 for probability, outcome in values])
        log_loss = -mean([
            outcome * math.log(probability) + (1 - outcome) * math.log(1.0 - probability)
            for probability, outcome in values
        ])
        bins = _calibration_bins(values)
        expected_calibration_error = sum(
            item["count"] / len(values) * abs(item["mean_probability"] - item["observed_frequency"])
            for item in bins
        )
        reports.append(
            {
                "model_id": model_id,
                "horizon": horizon,
                "regime": regime,
                "n": len(values),
                "brier": brier,
                "log_loss": log_loss,
                "base_rate": mean(outcomes),
                "mean_probability": mean(probabilities),
                "expected_calibration_error": expected_calibration_error,
                "bins": bins,
            }
        )
    return {"groups": reports, "records": len(rows)}


def list_runs(path: str | Path, limit: int = 20) -> list[dict[str, Any]]:
    with connect(path) as connection:
        rows = connection.execute(
            """
            SELECT run_id, scenario_id, worlds, horizon, created_at
            FROM runs ORDER BY created_at DESC LIMIT ?
            """,
            (limit,),
        ).fetchall()
    return [
        {
            "run_id": row[0],
            "scenario_id": row[1],
            "worlds": row[2],
            "horizon": row[3],
            "created_at": row[4],
        }
        for row in rows
    ]


def _calibration_bins(values: Iterable[tuple[float, int]], count: int = 10) -> list[dict[str, Any]]:
    buckets: list[list[tuple[float, int]]] = [[] for _ in range(count)]
    for probability, outcome in values:
        index = min(count - 1, int(probability * count))
        buckets[index].append((probability, outcome))
    result = []
    for index, bucket in enumerate(buckets):
        if not bucket:
            continue
        result.append(
            {
                "low": index / count,
                "high": (index + 1) / count,
                "count": len(bucket),
                "mean_probability": mean([value[0] for value in bucket]),
                "observed_frequency": mean([value[1] for value in bucket]),
            }
        )
    return result

