from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .util import object_hash


class ScenarioError(ValueError):
    pass


@dataclass(frozen=True)
class Scenario:
    raw: dict[str, Any]
    source_path: Path | None = None

    @property
    def meta(self) -> dict[str, Any]:
        return dict(self.raw.get("meta", {}))

    @property
    def scenario_id(self) -> str:
        return str(self.meta.get("id", "unnamed-scenario"))

    @property
    def name(self) -> str:
        return str(self.meta.get("name", self.scenario_id))

    @property
    def horizon(self) -> int:
        return int(self.raw.get("horizon", self.raw.get("simulation", {}).get("horizon", 1)))

    @property
    def step(self) -> str:
        return str(self.raw.get("step", "period"))

    @property
    def simulation(self) -> dict[str, Any]:
        return dict(self.raw.get("simulation", {}))

    @property
    def drivers(self) -> dict[str, Any]:
        return dict(self.raw.get("drivers", {}))

    @property
    def states(self) -> dict[str, Any]:
        return dict(self.raw.get("states", {}))

    @property
    def equations(self) -> dict[str, Any]:
        return dict(self.raw.get("equations", {}))

    @property
    def strategies(self) -> list[dict[str, Any]]:
        return [dict(item) for item in self.raw.get("strategies", [])]

    @property
    def actors(self) -> list[dict[str, Any]]:
        return [dict(item) for item in self.raw.get("actors", [])]

    @property
    def shocks(self) -> list[dict[str, Any]]:
        return [dict(item) for item in self.raw.get("shocks", [])]

    @property
    def metrics(self) -> dict[str, Any]:
        return dict(self.raw.get("metrics", {}))

    @property
    def objectives(self) -> list[dict[str, Any]]:
        return [dict(item) for item in self.raw.get("objectives", [])]

    @property
    def constraints(self) -> list[dict[str, Any]]:
        return [dict(item) for item in self.raw.get("constraints", [])]

    @property
    def evidence(self) -> list[dict[str, Any]]:
        return [dict(item) for item in self.raw.get("evidence", [])]

    @property
    def success_expression(self) -> str:
        return str(self.raw.get("success", "true"))

    @property
    def correlations(self) -> list[dict[str, Any]]:
        return [dict(item) for item in self.raw.get("correlations", [])]

    @property
    def stress_tests(self) -> list[dict[str, Any]]:
        return [dict(item) for item in self.raw.get("stress_tests", [])]

    @property
    def hash(self) -> str:
        return object_hash(self.raw)

    def with_overrides(self, overrides: Mapping[str, Any]) -> "Scenario":
        merged = json.loads(json.dumps(self.raw))
        _deep_merge(merged, overrides)
        return Scenario(merged, self.source_path)


def _deep_merge(target: dict[str, Any], update: Mapping[str, Any]) -> None:
    for key, value in update.items():
        if isinstance(value, Mapping) and isinstance(target.get(key), dict):
            _deep_merge(target[key], value)
        else:
            target[key] = value


def load_scenario(path: str | Path) -> Scenario:
    source = Path(path).expanduser().resolve()
    try:
        raw = json.loads(source.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ScenarioError(f"Senaryo bulunamadı: {source}") from exc
    except json.JSONDecodeError as exc:
        raise ScenarioError(f"Geçersiz JSON ({source}:{exc.lineno}:{exc.colno}): {exc.msg}") from exc
    if not isinstance(raw, dict):
        raise ScenarioError("Senaryo kökü JSON nesnesi olmalı")
    return Scenario(raw, source)

