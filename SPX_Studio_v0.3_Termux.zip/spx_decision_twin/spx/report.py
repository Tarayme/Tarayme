from __future__ import annotations

import html
import math
from typing import Any, Mapping

from .engine import RunResult
from .schema import Scenario


COLORS = ["#6ee7ff", "#a78bfa", "#f59e0b", "#34d399", "#fb7185", "#60a5fa"]


def build_html_report(result: RunResult, scenario: Scenario) -> str:
    metadata = result.metadata
    ranking = result.summary["ranking"]
    strategy_labels = {str(item["id"]): str(item.get("label", item["id"])) for item in scenario.strategies}
    recommended = ranking[0]
    status = str(metadata.get("data_status", "UNSPECIFIED"))
    warning_text = {
        "ILLUSTRATIVE": "Bu koşu temsili varsayımlarla üretilmiş bir yöntem demonstrasyonudur; gerçek platform tahmini değildir.",
        "SYNTHETIC": "Bu koşunun verileri sentetiktir; gerçek dünya tahmini olarak yorumlanmamalıdır.",
        "MIXED": "Bu model gözlenen ve varsayımsal girdileri birlikte kullanır; lineage bölümünü kontrol edin.",
        "OBSERVED": "Girdiler gözlenen verilere dayanır; yine de sonuçlar model belirsizliği taşır.",
    }.get(status, "Veri statüsü belirtilmemiş; sonuçları karar kanıtı olarak kullanmayın.")
    sections = [
        _hero(metadata, recommended, warning_text),
        _ranking_cards(ranking),
        _utility_svg(ranking),
        _metric_table(ranking, scenario),
        _future_families(result.clusters, strategy_labels),
        _stress_table(result.stress, strategy_labels),
        _sensitivity(result.sensitivity, recommended["strategy_id"]),
        _boundaries(result.boundaries, strategy_labels),
        _pairwise(result.pairwise, strategy_labels),
        _audit(result),
    ]
    return f"""<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(scenario.name)} — SPX Karar Raporu</title>
<style>
:root{{--bg:#070a13;--panel:#111827;--panel2:#0c1323;--line:#26344c;--text:#eef5ff;--muted:#93a4bd;--cyan:#6ee7ff;--violet:#a78bfa;--amber:#f59e0b;--green:#34d399;--red:#fb7185}}
*{{box-sizing:border-box}} body{{margin:0;background:radial-gradient(circle at 15% 0,#16213a 0,#070a13 42%);color:var(--text);font:15px/1.55 ui-sans-serif,system-ui,-apple-system,Segoe UI,sans-serif}}
main{{max-width:1180px;margin:auto;padding:28px 20px 70px}} h1,h2,h3{{line-height:1.15}} h1{{font-size:clamp(30px,6vw,64px);margin:.15em 0}} h2{{margin:44px 0 16px;font-size:25px}} h3{{margin:0 0 8px}} .eyebrow{{color:var(--cyan);letter-spacing:.18em;text-transform:uppercase;font-weight:800;font-size:12px}}
.hero{{padding:34px;border:1px solid #334568;border-radius:24px;background:linear-gradient(135deg,rgba(17,24,39,.92),rgba(10,18,34,.72));box-shadow:0 20px 70px #0008}}
.subtitle{{font-size:18px;color:#cbd8eb;max-width:800px}} .notice{{margin-top:22px;padding:13px 15px;border-left:3px solid var(--amber);background:#f59e0b12;color:#fcdba4;border-radius:8px}}
.meta{{display:flex;flex-wrap:wrap;gap:8px;margin-top:24px}} .pill{{border:1px solid var(--line);border-radius:999px;padding:6px 11px;background:#0b1220;color:#b9c8dd;font-size:12px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:14px}} .card{{border:1px solid var(--line);border-radius:16px;background:linear-gradient(180deg,var(--panel),var(--panel2));padding:18px}}
.card.best{{border-color:#4dbbd5;box-shadow:0 0 0 1px #6ee7ff22 inset}} .rank{{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em}} .score{{font-size:34px;font-weight:850;margin:6px 0}} .metricline{{display:flex;justify-content:space-between;gap:12px;color:#c9d5e8;border-top:1px solid #1e2a3e;padding-top:7px;margin-top:7px}}
.bar{{height:8px;border-radius:9px;background:#1d2a40;overflow:hidden;margin-top:7px}} .bar>i{{display:block;height:100%;background:linear-gradient(90deg,var(--violet),var(--cyan));border-radius:inherit}}
.panel{{border:1px solid var(--line);border-radius:18px;background:#0c1323cc;padding:16px;overflow:auto}} table{{border-collapse:collapse;width:100%;min-width:650px}} th,td{{padding:10px 11px;border-bottom:1px solid #1d2a40;text-align:right;white-space:nowrap}} th:first-child,td:first-child{{text-align:left}} th{{color:#9fb0c9;font-size:12px;text-transform:uppercase;letter-spacing:.06em}} td strong{{color:#fff}}
.family{{display:grid;grid-template-columns:minmax(160px,1.3fr) 80px minmax(180px,2fr) 150px;gap:12px;align-items:center;border-bottom:1px solid #1d2a40;padding:12px 0}} .family:last-child{{border:0}} .family small{{color:var(--muted)}}
.driver{{display:grid;grid-template-columns:minmax(220px,1fr) 3fr 65px;gap:10px;align-items:center;margin:9px 0}} .driver .track{{height:12px;background:#1d2a40;border-radius:10px;position:relative}} .driver .track i{{position:absolute;top:0;height:100%;border-radius:10px;background:var(--cyan)}} .driver.neg .track i{{background:var(--red)}}
.good{{color:var(--green)}} .bad{{color:var(--red)}} .muted{{color:var(--muted)}} code{{color:#b9ebff;background:#101a2c;padding:2px 5px;border-radius:5px}} details{{margin-top:16px}} summary{{cursor:pointer;color:#b8c8df}} footer{{color:var(--muted);margin-top:42px;border-top:1px solid var(--line);padding-top:20px}}
@media(max-width:700px){{.hero{{padding:22px}}.family{{grid-template-columns:1fr 65px}}.family>:nth-child(n+3){{grid-column:1/-1}}}}
</style>
</head>
<body><main>{''.join(sections)}<footer>SPX v{html.escape(str(metadata['engine_version']))} • Dağılım-öncelikli karar desteği • İnsan onayı gerektirir.</footer></main></body>
</html>"""


def _hero(metadata: Mapping[str, Any], recommended: Mapping[str, Any], warning: str) -> str:
    return f"""<section class="hero">
<div class="eyebrow">SPX • Simüle / Stratejik Projeksiyon</div>
<h1>{html.escape(str(metadata['scenario_name']))}</h1>
<p class="subtitle">Tek gelecek tahmini değil; ortak rassal dünyalarda strateji karşılaştırması, kuyruk riski, sağlamlık, pişmanlık, gelecek aileleri ve karar sınırları.</p>
<p><span class="muted">Mevcut risk tercihlerinde öne çıkan strateji:</span><br><strong style="font-size:25px;color:var(--cyan)">{html.escape(str(recommended['label']))}</strong></p>
<div class="notice"><strong>{html.escape(str(metadata.get('data_status')))}</strong> — {html.escape(warning)}</div>
<div class="meta"><span class="pill">{int(metadata['worlds']):,} dünya</span><span class="pill">{int(metadata['horizon'])} {html.escape(str(metadata['step']))}</span><span class="pill">tohum {int(metadata['seed'])}</span><span class="pill">ortak rassal sayılar</span><span class="pill">{float(metadata['runtime_seconds']):.2f} sn</span><span class="pill">model {html.escape(str(metadata['scenario_hash'])[:10])}</span></div>
</section>"""


def _ranking_cards(ranking: list[Mapping[str, Any]]) -> str:
    cards = []
    for index, row in enumerate(ranking):
        cards.append(f"""<article class="card {'best' if index == 0 else ''}">
<div class="rank">#{row['rank']} karar skoru</div><h3>{html.escape(str(row['label']))}</h3><div class="score">{_pct(row['decision_score'])}</div>
<div class="metricline"><span>Beklenen fayda</span><strong>{_pct(row['expected_utility'])}</strong></div>
<div class="metricline"><span>En kötü %10 / CVaR</span><strong>{_pct(row['utility_cvar'])}</strong></div>
<div class="metricline"><span>Sağlamlık</span><strong>{_pct(row['robustness'])}</strong></div>
<div class="metricline"><span>Başarı</span><strong>{_pct(row['success_probability'])}</strong></div>
<div class="metricline"><span>Ruin riski</span><strong class="{'bad' if row['ruin_probability'] > .1 else 'good'}">{_pct(row['ruin_probability'])}</strong></div>
<div class="bar"><i style="width:{clamp01(row['decision_score'])*100:.1f}%"></i></div>
<p class="muted">{'Pareto sınırında' if row['pareto'] else 'Pareto-dominant değil'} • {'Kısıtları geçti' if row['eligible'] else 'Hard constraint ihlali'}</p>
</article>""")
    return '<h2>Karar sıralaması</h2><section class="grid">' + "".join(cards) + "</section>"


def _utility_svg(ranking: list[Mapping[str, Any]]) -> str:
    width, left, plot = 900, 190, 650
    height = 70 + 58 * len(ranking)
    lines = []
    for tick in range(0, 11, 2):
        x = left + plot * tick / 10
        lines.append(f'<line x1="{x}" y1="30" x2="{x}" y2="{height-25}" stroke="#26344c"/><text x="{x}" y="{height-7}" fill="#93a4bd" text-anchor="middle" font-size="11">{tick*10}%</text>')
    for index, row in enumerate(ranking):
        y = 58 + index * 58
        color = COLORS[index % len(COLORS)]
        p05, p50, p95, avg = (float(row[key]) for key in ("utility_p05", "utility_p50", "utility_p95", "expected_utility"))
        lines.append(f'<text x="8" y="{y+5}" fill="#eef5ff" font-size="13">{html.escape(str(row["label"]))}</text>')
        lines.append(f'<line x1="{left+plot*p05}" y1="{y}" x2="{left+plot*p95}" y2="{y}" stroke="{color}" stroke-width="8" stroke-linecap="round" opacity=".58"/>')
        lines.append(f'<circle cx="{left+plot*p50}" cy="{y}" r="7" fill="{color}"/><path d="M {left+plot*avg-6} {y-12} L {left+plot*avg+6} {y-12} L {left+plot*avg} {y-3} Z" fill="#fff"/>')
    return f'<h2>Dağılım: ortalama tek başına yeterli değil</h2><div class="panel"><svg viewBox="0 0 {width} {height}" style="width:100%;min-width:720px" role="img" aria-label="Strateji fayda dağılımları">{"".join(lines)}</svg><p class="muted">Kalın çizgi P5–P95, daire medyan, beyaz işaret ortalamadır.</p></div>'


def _metric_table(ranking: list[Mapping[str, Any]], scenario: Scenario) -> str:
    metric_ids = [str(item["metric"]) for item in scenario.objectives]
    labels = {
        metric_id: str(scenario.metrics[metric_id].get("label", metric_id))
        for metric_id in metric_ids
    }
    units = {
        metric_id: str(scenario.metrics[metric_id].get("unit", ""))
        for metric_id in metric_ids
    }
    header = "<tr><th>Strateji</th>" + "".join(f"<th>{html.escape(labels[m])}</th>" for m in metric_ids) + "</tr>"
    rows = []
    for strategy in ranking:
        cells = []
        for metric_id in metric_ids:
            stats = strategy["metrics"][metric_id]
            cells.append(f'<td><strong>{_num(stats["mean"])}</strong> {html.escape(units[metric_id])}<br><small class="muted">P5 {_num(stats["p05"])} · P95 {_num(stats["p95"])}</small></td>')
        rows.append(f"<tr><td>{html.escape(str(strategy['label']))}</td>{''.join(cells)}</tr>")
    return f'<h2>Çok amaçlı sonuçlar</h2><div class="panel"><table>{header}{"".join(rows)}</table></div>'


def _future_families(clusters: list[Mapping[str, Any]], labels: Mapping[str, str]) -> str:
    rows = []
    for cluster in clusters:
        probability = float(cluster["probability"])
        rows.append(f"""<div class="family"><div><strong>{html.escape(str(cluster['label']))}</strong><br><small>Gelecek ailesi {cluster['cluster_id']}</small></div><div><strong>{_pct(probability)}</strong></div><div><div class="bar"><i style="width:{probability*100:.1f}%"></i></div></div><div><small>Öne çıkan</small><br><strong>{html.escape(labels.get(str(cluster['best_strategy_id']), str(cluster['best_strategy_id'])))}</strong></div></div>""")
    return '<h2>Gelecek aileleri: yüzdeyi aç</h2><div class="panel">' + "".join(rows) + "</div>"


def _stress_table(stress: list[Mapping[str, Any]], labels: Mapping[str, str]) -> str:
    if not stress:
        return ""
    rows = []
    for profile in stress:
        for index, strategy in enumerate(profile["strategies"]):
            rows.append(f"<tr><td>{html.escape(str(profile['label'])) if index == 0 else ''}</td><td>{html.escape(labels.get(str(strategy['strategy_id']), str(strategy['strategy_id'])))}</td><td>{_pct(strategy['probability'])}</td><td>{_pct(strategy['expected_utility'])}</td><td>{_pct(strategy['utility_cvar'])}</td><td>{_pct(strategy['success_probability'])}</td></tr>")
    return '<h2>Stress-world kitabı</h2><div class="panel"><table><tr><th>Koşul ailesi</th><th>Strateji</th><th>Dünya payı</th><th>Fayda</th><th>CVaR</th><th>Başarı</th></tr>' + "".join(rows) + "</table></div>"


def _sensitivity(sensitivity: Mapping[str, list[Mapping[str, Any]]], strategy_id: str) -> str:
    rows = []
    for item in sensitivity.get(strategy_id, [])[:12]:
        effect = float(item["spearman"])
        width = min(100.0, abs(effect) * 100.0)
        left = 50.0 if effect >= 0 else 50.0 - width / 2.0
        rows.append(f"""<div class="driver {'neg' if effect < 0 else ''}"><code>{html.escape(str(item['driver']))}</code><div class="track"><i style="left:{left:.1f}%;width:{max(2,width/2):.1f}%"></i></div><strong>{effect:+.2f}</strong></div>""")
    return '<h2>Sonucu taşıyan sürücüler ve etkileşimler</h2><div class="panel">' + "".join(rows) + '<p class="muted">Spearman sıralama ilişkisi; nedensel etki iddiası değildir. × işaretli satırlar iki sürücünün ortak etkisini tarar.</p></div>'


def _boundaries(boundaries: list[Mapping[str, Any]], labels: Mapping[str, str]) -> str:
    if not boundaries:
        return '<h2>Karar sınırları</h2><div class="panel"><p class="muted">Örneklem içinde güvenilir bir tek-değişken strateji dönüş eşiği bulunmadı.</p></div>'
    rows = []
    for boundary in boundaries:
        rows.append(f"<tr><td><code>{html.escape(str(boundary['driver']))}</code></td><td>{_num(boundary['threshold'])}</td><td>{html.escape(labels.get(str(boundary['below_best']), str(boundary['below_best'])))}</td><td>{html.escape(labels.get(str(boundary['above_best']), str(boundary['above_best'])))}</td><td>{float(boundary['strength']):.3f}</td></tr>")
    return '<h2>Hangi eşikte strateji değişiyor?</h2><div class="panel"><table><tr><th>Gözlenebilir sürücü</th><th>Eşik</th><th>Eşik altı</th><th>Eşik üstü</th><th>Güç</th></tr>' + "".join(rows) + '</table><p class="muted">Eşikler eşlenmiş dünyalarda koşullu fayda farkının işaret değiştirdiği tarama noktalarıdır; yeni veriyle yeniden hesaplanmalıdır.</p></div>'


def _pairwise(pairwise: list[Mapping[str, Any]], labels: Mapping[str, str]) -> str:
    rows = []
    for row in pairwise:
        rows.append(f"<tr><td>{html.escape(labels.get(str(row['left']), str(row['left'])))}</td><td>{html.escape(labels.get(str(row['right']), str(row['right'])))}</td><td>{_pct(row['p_left_better'])}</td><td>{float(row['mean_utility_delta']):+.3f}</td><td>[{float(row['p05_delta']):+.3f}, {float(row['p95_delta']):+.3f}]</td></tr>")
    return '<h2>Aynı dünyada counterfactual karşılaştırma</h2><div class="panel"><table><tr><th>A</th><th>B</th><th>P(A &gt; B)</th><th>Ort. fark</th><th>P5–P95 fark</th></tr>' + "".join(rows) + "</table></div>"


def _audit(result: RunResult) -> str:
    errors = [item for item in result.validation if item.get("level") == "error"]
    warnings = [item for item in result.validation if item.get("level") == "warning"]
    model_count = len(result.audit.get("model_registry", []))
    evidence_count = len(result.audit.get("evidence_registry", []))
    issue_rows = "".join(f"<li><code>{html.escape(str(item.get('code')))}</code> {html.escape(str(item.get('message')))}</li>" for item in warnings)
    return f"""<h2>Model riski ve lineage</h2><div class="panel"><div class="grid"><div><span class="muted">Model düğümü</span><div class="score">{model_count}</div></div><div><span class="muted">Evidence kaydı</span><div class="score">{evidence_count}</div></div><div><span class="muted">Doğrulama hatası</span><div class="score {'bad' if errors else 'good'}">{len(errors)}</div></div><div><span class="muted">Uyarı</span><div class="score">{len(warnings)}</div></div></div><details><summary>Uyarıları aç</summary><ul>{issue_rows or '<li>Uyarı yok.</li>'}</ul></details><p class="muted">Bu çıktı karar desteğidir. Korelasyon, model formu, aktör politikaları ve kanıt kalitesi ayrıca gözden geçirilmeden yüksek etkili karar otomatikleştirilmemelidir.</p></div>"""


def _pct(value: Any) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "—"
    if not math.isfinite(number):
        return "—"
    return f"%{number*100:.1f}"


def _num(value: Any) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "—"
    if not math.isfinite(number):
        return "—"
    magnitude = abs(number)
    if magnitude >= 1_000_000:
        return f"{number/1_000_000:.2f}M"
    if magnitude >= 1_000:
        return f"{number/1_000:.1f}K"
    if magnitude >= 100:
        return f"{number:.0f}"
    if magnitude >= 10:
        return f"{number:.1f}"
    return f"{number:.2f}"


def clamp01(value: Any) -> float:
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return 0.0
