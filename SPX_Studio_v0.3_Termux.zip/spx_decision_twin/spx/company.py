from __future__ import annotations

import json
import re
from typing import Any, Mapping

from .schema import Scenario
from .validation import raise_for_errors, validate_scenario


BUILDER_VERSION = "0.3.0"

SECTORS: dict[str, dict[str, Any]] = {
    "generic": {
        "label": "Genel işletme",
        "description": "Satış, kapasite, çalışan, tedarik ve nakit birlikte modellenir.",
        "equipment_dependency": 0.45,
        "supplier_dependency": 0.50,
        "workforce_dependency": 0.60,
    },
    "manufacturing": {
        "label": "Üretim / fabrika",
        "description": "Makine sağlığı, kapasite, arıza, kalite ve tedarik daha güçlüdür.",
        "equipment_dependency": 0.88,
        "supplier_dependency": 0.78,
        "workforce_dependency": 0.62,
    },
    "service": {
        "label": "Hizmet şirketi",
        "description": "Çalışan kapasitesi, müşteri deneyimi ve itibar daha güçlüdür.",
        "equipment_dependency": 0.18,
        "supplier_dependency": 0.20,
        "workforce_dependency": 0.90,
    },
    "retail": {
        "label": "Mağaza / perakende",
        "description": "Talep, fiyat, stok ve tedarik dengesi öne çıkar.",
        "equipment_dependency": 0.28,
        "supplier_dependency": 0.82,
        "workforce_dependency": 0.58,
    },
    "food": {
        "label": "Restoran / gıda",
        "description": "Günlük talep, çalışan, malzeme, kapasite ve kalite birlikte işler.",
        "equipment_dependency": 0.48,
        "supplier_dependency": 0.68,
        "workforce_dependency": 0.82,
    },
    "ecommerce": {
        "label": "E-ticaret",
        "description": "Reklam, dönüşüm, fiyat, stok ve lojistik belirsizliği öne çıkar.",
        "equipment_dependency": 0.12,
        "supplier_dependency": 0.76,
        "workforce_dependency": 0.42,
    },
}


DEFAULT_PROFILE: dict[str, Any] = {
    "company_name": "Örnek Şirketim",
    "sector": "generic",
    "decision_question": "Önümüzdeki 12 ayda hangi politika büyüme ile dayanıklılığı daha iyi dengeler?",
    "horizon": 12,
    "step": "ay",
    "monthly_revenue": 500_000.0,
    "monthly_cost": 390_000.0,
    "cash": 600_000.0,
    "employees": 20,
    "monthly_units": 5_000.0,
    "max_capacity": 6_200.0,
    "variable_cost_share": 0.42,
    "demand_uncertainty": 0.16,
    "annual_cost_inflation": 0.24,
    "absence_rate": 0.06,
    "failure_risk": 0.045,
    "supplier_delay_risk": 0.09,
    "data_quality": "MIXED",
}


DEFAULT_STRATEGIES: list[dict[str, Any]] = [
    {
        "id": "current_course",
        "label": "Mevcut Düzen",
        "description": "Büyük yatırım yapmadan mevcut işleyişi sürdürür.",
        "marketing_rate": 0.020,
        "hiring_rate": 0.000,
        "capacity_investment": 0.015,
        "maintenance_intensity": 0.055,
        "buffer_stock": 0.045,
        "training_rate": 0.025,
        "price_change": 0.000,
    },
    {
        "id": "growth_push",
        "label": "Büyüme Hamlesi",
        "description": "Pazarlama, çalışan ve kapasite yatırımıyla satış potansiyelini zorlar.",
        "marketing_rate": 0.095,
        "hiring_rate": 0.140,
        "capacity_investment": 0.100,
        "maintenance_intensity": 0.080,
        "buffer_stock": 0.060,
        "training_rate": 0.055,
        "price_change": -0.015,
    },
    {
        "id": "resilient_balance",
        "label": "Dayanıklı Denge",
        "description": "Nakit, bakım, çalışan gücü ve stok tamponunu dengeler.",
        "marketing_rate": 0.040,
        "hiring_rate": 0.055,
        "capacity_investment": 0.060,
        "maintenance_intensity": 0.175,
        "buffer_stock": 0.170,
        "training_rate": 0.130,
        "price_change": 0.018,
    },
]


CONTROL_FIELDS = (
    "marketing_rate",
    "hiring_rate",
    "capacity_investment",
    "maintenance_intensity",
    "buffer_stock",
    "training_rate",
    "price_change",
)


def company_builder_catalog() -> dict[str, Any]:
    return {
        "version": BUILDER_VERSION,
        "sectors": [
            {
                "id": sector_id,
                "label": spec["label"],
                "description": spec["description"],
            }
            for sector_id, spec in SECTORS.items()
        ],
        "default_profile": json.loads(json.dumps(DEFAULT_PROFILE)),
        "default_strategies": json.loads(json.dumps(DEFAULT_STRATEGIES)),
    }


def normalize_company_profile(raw: Mapping[str, Any] | None) -> dict[str, Any]:
    incoming = dict(raw or {})
    profile = json.loads(json.dumps(DEFAULT_PROFILE))
    profile.update(incoming)
    profile["company_name"] = str(profile.get("company_name", "Şirketim")).strip()[:100] or "Şirketim"
    profile["sector"] = str(profile.get("sector", "generic"))
    if profile["sector"] not in SECTORS:
        profile["sector"] = "generic"
    profile["decision_question"] = str(profile.get("decision_question", "")).strip()[:500]
    profile["horizon"] = int(_bound(profile.get("horizon"), 3, 60, 12))
    profile["step"] = "ay"
    profile["monthly_revenue"] = _bound(profile.get("monthly_revenue"), 1_000, 1e12, 500_000)
    profile["monthly_cost"] = _bound(profile.get("monthly_cost"), 0, 1e12, 390_000)
    profile["cash"] = _bound(profile.get("cash"), 0, 1e13, 600_000)
    profile["employees"] = int(_bound(profile.get("employees"), 1, 1_000_000, 20))
    profile["monthly_units"] = _bound(profile.get("monthly_units"), 1, 1e10, 5_000)
    profile["max_capacity"] = _bound(profile.get("max_capacity"), 1, 1e10, profile["monthly_units"] * 1.2)
    profile["max_capacity"] = max(profile["max_capacity"], profile["monthly_units"] * 0.3)
    profile["variable_cost_share"] = _bound(profile.get("variable_cost_share"), 0.02, 0.95, 0.42)
    profile["demand_uncertainty"] = _bound(profile.get("demand_uncertainty"), 0.01, 0.55, 0.16)
    profile["annual_cost_inflation"] = _bound(profile.get("annual_cost_inflation"), -0.20, 3.0, 0.24)
    profile["absence_rate"] = _bound(profile.get("absence_rate"), 0.0, 0.50, 0.06)
    profile["failure_risk"] = _bound(profile.get("failure_risk"), 0.0, 0.55, 0.045)
    profile["supplier_delay_risk"] = _bound(profile.get("supplier_delay_risk"), 0.0, 0.70, 0.09)
    quality = str(profile.get("data_quality", "MIXED")).upper()
    profile["data_quality"] = quality if quality in {"OBSERVED", "MIXED", "ILLUSTRATIVE"} else "MIXED"
    return profile


def normalize_strategies(raw: Any) -> list[dict[str, Any]]:
    provided = raw if isinstance(raw, list) else []
    strategies: list[dict[str, Any]] = []
    for index, base in enumerate(DEFAULT_STRATEGIES):
        incoming = dict(provided[index]) if index < len(provided) and isinstance(provided[index], Mapping) else {}
        strategy = dict(base)
        strategy.update(incoming)
        strategy["id"] = _identifier(strategy.get("id"), base["id"])
        strategy["label"] = str(strategy.get("label", base["label"])).strip()[:80] or base["label"]
        strategy["description"] = str(strategy.get("description", base["description"])).strip()[:240]
        for field in CONTROL_FIELDS:
            low = -0.25 if field == "price_change" else 0.0
            high = 0.35 if field == "price_change" else 0.80
            strategy[field] = _bound(strategy.get(field), low, high, base[field])
        strategies.append(strategy)
    ids: set[str] = set()
    for index, strategy in enumerate(strategies):
        original = strategy["id"]
        candidate = original
        suffix = 2
        while candidate in ids:
            candidate = f"{original}_{suffix}"
            suffix += 1
        strategy["id"] = candidate
        ids.add(candidate)
    return strategies


def build_company_scenario(
    raw_profile: Mapping[str, Any] | None,
    raw_strategies: Any = None,
) -> dict[str, Any]:
    p = normalize_company_profile(raw_profile)
    controls = normalize_strategies(raw_strategies)
    sector = SECTORS[p["sector"]]
    equipment_dependency = float(sector["equipment_dependency"])
    supplier_dependency = float(sector["supplier_dependency"])
    workforce_dependency = float(sector["workforce_dependency"])

    revenue = p["monthly_revenue"]
    cost = p["monthly_cost"]
    units = p["monthly_units"]
    capacity = p["max_capacity"]
    price = revenue / max(1.0, units)
    variable_cost_total = cost * p["variable_cost_share"]
    fixed_cost = max(0.0, cost - variable_cost_total)
    variable_cost_per_unit = variable_cost_total / max(1.0, units)
    initial_margin = (revenue - cost) / max(1.0, revenue)
    cash_floor = -max(revenue * 0.75, p["cash"] * 0.5)
    horizon = p["horizon"]
    quality_grade = {"OBSERVED": "A", "MIXED": "B", "ILLUSTRATIVE": "C"}[p["data_quality"]]
    scenario_id = f"company_{_identifier(p['company_name'], 'my_company')}_{horizon}m"

    strategies = []
    for control in controls:
        strategies.append(
            {
                "id": control["id"],
                "label": control["label"],
                "description": control["description"],
                "parameters": {field: float(control[field]) for field in CONTROL_FIELDS},
                "rules": _company_policy_rules(control["id"]),
            }
        )

    scenario: dict[str, Any] = {
        "meta": {
            "id": scenario_id,
            "name": f"{p['company_name']} — {horizon} Aylık Karar Simülasyonu",
            "version": BUILDER_VERSION,
            "builder_version": BUILDER_VERSION,
            "data_status": p["data_quality"],
            "human_approval_required": True,
            "decision_question": p["decision_question"],
            "description": (
                f"{sector['label']} için satış, kapasite, çalışan, tedarik, şok, "
                "nakit ve itibar geri beslemelerini birlikte çalıştıran şirket karar ikizi."
            ),
            "company_profile": p,
        },
        "horizon": horizon,
        "step": "ay",
        "simulation": {
            "worlds": 1000,
            "seed": 20260817,
            "clusters": 6,
            "trace_worlds": 3,
            "sensitivity_limit": 14,
            "boundary_limit": 10,
            "trace_nodes": [
                "cash",
                "backlog",
                "reputation",
                "employee_energy",
                "operational_health",
                "customer_base",
                "inventory_buffer",
            ],
        },
        "decision_policy": {
            "acceptance_utility": 0.45,
            "tail_alpha": 0.10,
            "expected_weight": 0.25,
            "tail_weight": 0.25,
            "robustness_weight": 0.20,
            "success_weight": 0.15,
            "regret_weight": 0.15,
        },
        "evidence": [
            {
                "id": "E-COMPANY-INPUT",
                "type": "user_input",
                "source": "studio-wizard:company-profile",
                "fingerprint": f"company-profile:{scenario_id}",
                "quality": quality_grade,
                "validity": "until-user-update",
                "note": "Ciro, gider, nakit, çalışan, satış ve kapasite değerleri kullanıcı girişidir.",
            },
            {
                "id": "E-COMPANY-RISK",
                "type": "user_estimate",
                "source": "studio-wizard:risk-profile",
                "fingerprint": f"company-risk:{scenario_id}",
                "quality": quality_grade,
                "validity": "until-user-update",
                "note": "Talep, maliyet, devamsızlık, arıza ve tedarik belirsizlikleri kullanıcı tahmini veya verisidir.",
            },
            {
                "id": "E-COMPANY-STRUCTURE",
                "type": "structural_hypothesis",
                "source": f"spx-company-builder:{BUILDER_VERSION}",
                "fingerprint": f"spx-company-structure:{BUILDER_VERSION}:{p['sector']}",
                "quality": "C",
                "validity": "requires-calibration",
                "note": "Satış, kapasite, maliyet ve geri besleme denklemleri kalibrasyon öncesi genel şirket yapısıdır.",
            },
            {
                "id": "E-COMPANY-PREFERENCE",
                "type": "decision_preference",
                "source": "studio-wizard:balanced-objectives",
                "fingerprint": f"company-preference:{scenario_id}",
                "quality": "B",
                "validity": "until-owner-review",
                "note": "Kârlılık, nakit, büyüme, hizmet ve dayanıklılık ağırlıkları karar sahibince değiştirilebilir.",
            },
        ],
        "drivers": {
            "demand_index": {
                "process": "ar1",
                "initial": {"dist": "normal", "mean": 1.0, "sd": p["demand_uncertainty"] * 0.45, "min": 0.45, "max": 1.65},
                "mean": 1.0,
                "phi": 0.68,
                "sigma": p["demand_uncertainty"],
                "min": 0.30,
                "max": 2.0,
            },
            "cost_index": {
                "process": "random_walk",
                "initial": {"dist": "normal", "mean": 1.0, "sd": 0.025, "min": 0.86, "max": 1.18},
                "drift": (1.0 + p["annual_cost_inflation"]) ** (1.0 / 12.0) - 1.0,
                "sigma": 0.025 + abs(p["annual_cost_inflation"]) * 0.035,
                "min": 0.55,
                "max": 3.5,
            },
            "price_sensitivity": {
                "process": "ar1",
                "initial": {"dist": "normal", "mean": 0.70, "sd": 0.08, "min": 0.35, "max": 1.05},
                "mean": 0.72,
                "phi": 0.60,
                "sigma": 0.10,
                "min": 0.20,
                "max": 1.35,
            },
            "absence_pressure": {
                "process": "ar1",
                "initial": {"dist": "normal", "mean": p["absence_rate"], "sd": 0.015, "min": 0, "max": 0.35},
                "mean": p["absence_rate"],
                "phi": 0.55,
                "sigma": 0.018 + p["absence_rate"] * 0.25,
                "min": 0,
                "max": 0.50,
                "seasonality": [1.28, 1.20, 1.08, 0.96, 0.88, 0.80, 0.76, 0.78, 0.88, 1.0, 1.12, 1.25],
            },
            "supplier_reliability": {
                "process": "ar1",
                "initial": {"dist": "normal", "mean": 1.0 - p["supplier_delay_risk"] * 0.55, "sd": 0.025, "min": 0.50, "max": 1.0},
                "mean": 1.0 - p["supplier_delay_risk"] * 0.55,
                "phi": 0.72,
                "sigma": 0.025 + p["supplier_delay_risk"] * 0.18,
                "min": 0.35,
                "max": 1.0,
            },
            "economy_regime": {
                "process": "markov",
                "states": [0.84, 1.0, 1.14],
                "initial_probabilities": [0.22, 0.60, 0.18],
                "transition": [[0.72, 0.24, 0.04], [0.12, 0.76, 0.12], [0.05, 0.28, 0.67]],
            },
        },
        "correlations": [
            {"drivers": ["demand_index", "cost_index", "price_sensitivity"], "matrix": [[1.0, 0.18, -0.12], [0.18, 1.0, 0.08], [-0.12, 0.08, 1.0]]},
            {"drivers": ["absence_pressure", "supplier_reliability"], "matrix": [[1.0, -0.16], [-0.16, 1.0]]},
        ],
        "strategies": strategies,
        "actors": [
            {
                "id": "customers",
                "population": max(50, min(1_000_000, int(units))),
                "temperature": 0.40,
                "inertia": 0.18,
                "response_concentration": 160,
                "actions": [
                    {"id": "wait", "utility": "0.25 + 1.9*price_change*price_sensitivity + 0.7*(1-prev_reputation)", "effects": {"customer_purchase_factor": "0.42", "reputation_feedback": "-0.008"}},
                    {"id": "buy", "utility": "0.65 + 0.9*prev_reputation + 0.35*demand_index - 1.6*price_change*price_sensitivity", "effects": {"customer_purchase_factor": "0.92", "reputation_feedback": "0.003"}},
                    {"id": "recommend", "utility": "-0.25 + 1.55*prev_reputation + 1.2*marketing_rate - 0.7*price_change", "effects": {"customer_purchase_factor": "1.16", "reputation_feedback": "0.016"}},
                ],
            },
            {
                "id": "employees",
                "population": p["employees"],
                "temperature": 0.34,
                "inertia": 0.22,
                "response_concentration": max(30, min(220, p["employees"] * 3)),
                "actions": [
                    {"id": "absent", "utility": "-1.15 + 5.0*absence_pressure + 1.7*(1-prev_employee_energy) - 0.8*training_rate", "effects": {"labor_factor": "0.0", "fatigue_effect": "0.015"}},
                    {"id": "normal", "utility": "1.0 + 1.0*prev_employee_energy + 0.65*prev_skill - 3.2*absence_pressure", "effects": {"labor_factor": "1.0", "fatigue_effect": "0.0"}},
                    {"id": "extra_effort", "utility": "-0.1 + 0.55*demand_index + 0.4*prev_employee_energy + 0.75*hiring_rate", "effects": {"labor_factor": "1.12", "fatigue_effect": "0.065"}},
                ],
            },
            {
                "id": "suppliers",
                "population": 20,
                "temperature": 0.38,
                "inertia": 0.16,
                "response_concentration": 120,
                "actions": [
                    {"id": "on_time", "utility": "2.3*supplier_reliability + 1.0*buffer_stock", "effects": {"supplier_factor": "1.0", "supply_premium": "0.0"}},
                    {"id": "late", "utility": "1.5*(1-supplier_reliability) + 0.35*demand_index", "effects": {"supplier_factor": "0.74", "supply_premium": "0.10"}},
                    {"id": "disrupted", "utility": "-1.3 + 2.6*(1-supplier_reliability)", "effects": {"supplier_factor": "0.30", "supply_premium": "0.28"}},
                ],
            },
        ],
        "shocks": [
            {
                "id": "equipment_failure",
                "hazard": f"clamp({_n(p['failure_risk'] * equipment_dependency)} + 0.13*(1-prev_operational_health) - 0.10*maintenance_intensity, 0.001, 0.45)",
                "duration": {"dist": "discrete_uniform", "low": 1, "high": 2},
                "effects": {"capacity_shock": _n(-0.55 * equipment_dependency), "repair_cost": _n(revenue * 0.10 * equipment_dependency), "health_shock": _n(-0.18 * equipment_dependency)},
            },
            {
                "id": "supplier_disruption",
                "hazard": f"clamp({_n(p['supplier_delay_risk'] * supplier_dependency * 0.45)} + 0.12*(1-supplier_reliability) - 0.08*buffer_stock, 0.001, 0.35)",
                "duration": {"dist": "discrete_uniform", "low": 1, "high": 3},
                "effects": {"supplier_shock": _n(-0.36 * supplier_dependency), "supply_shock_cost": _n(revenue * 0.045 * supplier_dependency)},
            },
            {
                "id": "staffing_wave",
                "hazard": f"clamp({_n(p['absence_rate'] * workforce_dependency * 0.55)} + 0.20*absence_pressure - 0.05*training_rate, 0.001, 0.28)",
                "duration": {"dist": "discrete_uniform", "low": 1, "high": 2},
                "effects": {"labor_shock": _n(-0.24 * workforce_dependency)},
            },
            {
                "id": "demand_upside",
                "hazard": "clamp(0.018 + 0.025*demand_index + 0.06*marketing_rate, 0.005, 0.14)",
                "duration": {"dist": "discrete_uniform", "low": 1, "high": 3},
                "effects": {"demand_shock": "0.34"},
            },
            {
                "id": "demand_slump",
                "hazard": "clamp(0.012 + 0.04*(1-economy_regime) + 0.025*price_sensitivity, 0.004, 0.12)",
                "duration": {"dist": "discrete_uniform", "low": 2, "high": 4},
                "effects": {"demand_down_shock": "-0.26"},
            },
        ],
        "equations": {
            "market_demand": {"expression": f"{_n(units)}*demand_index*economy_regime*(1+1.8*marketing_rate)*exp(-2.2*price_sensitivity*price_change)*(0.55+0.45*customer_purchase_factor)*(0.82+0.18*prev_customer_base)*(1+demand_shock+demand_down_shock)", "unit": "sale/month", "min": 0, "max": units * 8, "model_id": "COMPANY-DEMAND-v1", "evidence_ids": ["E-COMPANY-INPUT", "E-COMPANY-RISK", "E-COMPANY-STRUCTURE"]},
            "planned_capacity": {"expression": f"{_n(capacity)}*(1+1.45*capacity_investment+0.70*hiring_rate+0.24*training_rate)*(0.82+0.18*prev_skill)", "unit": "sale/month", "min": 1, "max": capacity * 4, "model_id": "COMPANY-PLANNED-CAPACITY-v1", "evidence_ids": ["E-COMPANY-INPUT", "E-COMPANY-STRUCTURE"]},
            "effective_capacity": {"expression": f"planned_capacity*clamp(labor_factor+{_n(0.40*(1-workforce_dependency))}+labor_shock,0.18,1.28)*clamp((1-{_n(supplier_dependency)})+{_n(supplier_dependency)}*supplier_factor+0.65*prev_inventory_buffer+supplier_shock,0.18,1.22)*(0.45+0.55*prev_operational_health)*(1+capacity_shock)", "unit": "sale/month", "min": 0, "max": capacity * 5, "model_id": "COMPANY-EFFECTIVE-CAPACITY-v1", "evidence_ids": ["E-COMPANY-RISK", "E-COMPANY-STRUCTURE"]},
            "sales_units": {"expression": "min(effective_capacity, market_demand + 0.32*prev_backlog)", "unit": "sale/month", "min": 0, "max": units * 8, "model_id": "COMPANY-SALES-v1", "evidence_ids": ["E-COMPANY-STRUCTURE"]},
            "selling_price": {"expression": f"{_n(price)}*(1+price_change)", "unit": "TRY/sale", "min": price * 0.45, "max": price * 2.5, "model_id": "COMPANY-PRICE-v1", "evidence_ids": ["E-COMPANY-INPUT", "E-COMPANY-STRUCTURE"]},
            "monthly_revenue": {"expression": "sales_units*selling_price", "unit": "TRY/month", "min": 0, "max": revenue * 10, "model_id": "COMPANY-REVENUE-v1", "evidence_ids": ["E-COMPANY-INPUT", "E-COMPANY-STRUCTURE"]},
            "variable_cost": {"expression": f"sales_units*{_n(variable_cost_per_unit)}*cost_index*(1+{_n(supplier_dependency)}*supply_premium)", "unit": "TRY/month", "min": 0, "max": cost * 8, "model_id": "COMPANY-VARIABLE-COST-v1", "evidence_ids": ["E-COMPANY-INPUT", "E-COMPANY-RISK", "E-COMPANY-STRUCTURE"]},
            "base_operating_cost": {"expression": f"{_n(fixed_cost)}*cost_index*(1+0.62*hiring_rate)", "unit": "TRY/month", "min": 0, "max": cost * 6, "model_id": "COMPANY-FIXED-COST-v1", "evidence_ids": ["E-COMPANY-INPUT", "E-COMPANY-RISK", "E-COMPANY-STRUCTURE"]},
            "strategy_spend": {"expression": f"{_n(revenue)}*(marketing_rate+0.30*capacity_investment+0.08*maintenance_intensity+0.10*buffer_stock+0.10*training_rate)", "unit": "TRY/month", "min": 0, "max": revenue * 3, "model_id": "COMPANY-STRATEGY-SPEND-v1", "evidence_ids": ["E-COMPANY-PREFERENCE", "E-COMPANY-STRUCTURE"]},
            "monthly_profit": {"expression": "monthly_revenue-variable_cost-base_operating_cost-strategy_spend-repair_cost-supply_shock_cost", "unit": "TRY/month", "min": -revenue * 6, "max": revenue * 6, "model_id": "COMPANY-PROFIT-v1", "evidence_ids": ["E-COMPANY-INPUT", "E-COMPANY-STRUCTURE"]},
            "service_level": {"expression": "clamp(sales_units/max(1,market_demand+0.18*prev_backlog),0,1)", "unit": "ratio", "min": 0, "max": 1, "model_id": "COMPANY-SERVICE-v1", "evidence_ids": ["E-COMPANY-STRUCTURE"]},
            "utilization": {"expression": "clamp((market_demand+0.20*prev_backlog)/max(1,effective_capacity),0,1.45)", "unit": "ratio", "min": 0, "max": 1.45, "model_id": "COMPANY-UTILIZATION-v1", "evidence_ids": ["E-COMPANY-STRUCTURE"]},
            "margin_rate": {"expression": "clamp(monthly_profit/max(1,monthly_revenue),-2,1)", "unit": "ratio", "min": -2, "max": 1, "model_id": "COMPANY-MARGIN-v1", "evidence_ids": ["E-COMPANY-STRUCTURE"]},
            "customer_experience": {"expression": "clamp(0.22+0.50*service_level+0.26*prev_reputation-0.08*max(0,price_change)+reputation_feedback,0.05,1)", "unit": "index", "min": 0.05, "max": 1, "model_id": "COMPANY-EXPERIENCE-v1", "evidence_ids": ["E-COMPANY-STRUCTURE"]},
            "backlog_change": {"expression": "market_demand-sales_units-0.04*prev_backlog", "unit": "sale/month", "model_id": "COMPANY-BACKLOG-v1", "evidence_ids": ["E-COMPANY-STRUCTURE"]},
        },
        "states": {
            "cash": {"initial": {"dist": "normal", "mean": p["cash"], "sd": max(1.0, p["cash"] * 0.035), "min": p["cash"] * 0.75, "max": p["cash"] * 1.25 + 1}, "transition": "prev_cash+monthly_profit", "unit": "TRY", "min": -revenue * horizon * 3, "max": p["cash"] + revenue * horizon * 8, "model_id": "STATE-CASH-v1", "evidence_ids": ["E-COMPANY-INPUT", "E-COMPANY-STRUCTURE"]},
            "backlog": {"initial": {"dist": "normal", "mean": units * 0.06, "sd": units * 0.025, "min": 0, "max": units * 0.25}, "transition": f"clamp(prev_backlog+backlog_change,0,{_n(units*horizon*3)})", "unit": "sale", "min": 0, "max": units * horizon * 3, "model_id": "STATE-BACKLOG-v1", "evidence_ids": ["E-COMPANY-INPUT", "E-COMPANY-STRUCTURE"]},
            "reputation": {"initial": {"dist": "beta", "alpha": 9, "beta": 4, "low": 0.40, "high": 0.84}, "transition": "clamp(0.86*prev_reputation+0.14*customer_experience+reputation_feedback,0.08,1)", "unit": "index", "min": 0.08, "max": 1, "model_id": "STATE-REPUTATION-v1", "evidence_ids": ["E-COMPANY-STRUCTURE"]},
            "employee_energy": {"initial": {"dist": "beta", "alpha": 9, "beta": 3, "low": 0.48, "high": 0.94}, "transition": "clamp(prev_employee_energy+0.08*(0.80-prev_employee_energy)+0.09*training_rate-0.055*max(0,utilization-0.88)-fatigue_effect,0.04,1)", "unit": "index", "min": 0.04, "max": 1, "model_id": "STATE-EMPLOYEE-ENERGY-v1", "evidence_ids": ["E-COMPANY-RISK", "E-COMPANY-STRUCTURE"]},
            "operational_health": {"initial": {"dist": "beta", "alpha": 11, "beta": 3, "low": 0.52, "high": 0.96}, "transition": f"clamp(prev_operational_health+{_n(0.12*equipment_dependency)}*maintenance_intensity-0.035*utilization+health_shock,0.04,1)", "unit": "index", "min": 0.04, "max": 1, "model_id": "STATE-OPERATIONAL-HEALTH-v1", "evidence_ids": ["E-COMPANY-RISK", "E-COMPANY-STRUCTURE"]},
            "skill": {"initial": {"dist": "beta", "alpha": 8, "beta": 4, "low": 0.38, "high": 0.86}, "transition": "clamp(prev_skill+0.07*training_rate*(1-prev_skill)+0.015*hiring_rate-0.01*fatigue_effect,0.20,1)", "unit": "index", "min": 0.20, "max": 1, "model_id": "STATE-SKILL-v1", "evidence_ids": ["E-COMPANY-STRUCTURE"]},
            "customer_base": {"initial": {"dist": "normal", "mean": 1.0, "sd": 0.035, "min": 0.82, "max": 1.18}, "transition": "clamp(prev_customer_base+0.035*(customer_experience-0.60)+0.05*marketing_rate-0.025*max(0,price_change),0.45,2.2)", "unit": "index", "min": 0.45, "max": 2.2, "model_id": "STATE-CUSTOMER-BASE-v1", "evidence_ids": ["E-COMPANY-STRUCTURE"]},
            "inventory_buffer": {"initial": {"dist": "normal", "mean": 0.10, "sd": 0.025, "min": 0.01, "max": 0.22}, "transition": "clamp(0.68*prev_inventory_buffer+0.32*buffer_stock+0.06*(supplier_reliability-0.82)-0.05*max(0,demand_index-1),0,0.48)", "unit": "ratio", "min": 0, "max": 0.48, "model_id": "STATE-INVENTORY-BUFFER-v1", "evidence_ids": ["E-COMPANY-RISK", "E-COMPANY-STRUCTURE"]},
        },
        "metrics": {
            "final_cash": {"expression": "cash", "aggregation": "final", "label": "Dönem sonu nakit", "unit": "TRY"},
            "minimum_cash": {"expression": "cash", "aggregation": "min", "label": "Görülen en düşük nakit", "unit": "TRY"},
            "cumulative_profit": {"expression": "monthly_profit", "aggregation": "sum", "label": "Toplam kâr", "unit": "TRY"},
            "total_revenue": {"expression": "monthly_revenue", "aggregation": "sum", "label": "Toplam ciro", "unit": "TRY"},
            "average_margin": {"expression": "margin_rate", "aggregation": "mean", "label": "Ortalama kâr marjı", "unit": "ratio"},
            "average_service_level": {"expression": "service_level", "aggregation": "mean", "label": "Talebi karşılama oranı", "unit": "ratio"},
            "final_reputation": {"expression": "reputation", "aggregation": "final", "label": "Dönem sonu itibar", "unit": "index"},
            "minimum_employee_energy": {"expression": "employee_energy", "aggregation": "min", "label": "En düşük çalışan gücü", "unit": "index"},
            "minimum_operational_health": {"expression": "operational_health", "aggregation": "min", "label": "En düşük operasyon sağlığı", "unit": "index"},
            "final_backlog": {"expression": "backlog", "aggregation": "final", "label": "Dönem sonu karşılanmayan talep", "unit": "sale"},
            "failure_months": {"expression": "shock_equipment_failure", "aggregation": "sum", "label": "Arıza yaşanan ay", "unit": "month"},
        },
        "objectives": [
            {"id": "profitability", "metric": "cumulative_profit", "direction": "max", "worst": -revenue * 0.65 * horizon, "best": revenue * 0.38 * horizon, "weight": 0.22},
            {"id": "liquidity", "metric": "final_cash", "direction": "max", "worst": cash_floor, "best": p["cash"] + revenue * 0.42 * horizon, "weight": 0.20},
            {"id": "growth", "metric": "total_revenue", "direction": "max", "worst": revenue * 0.55 * horizon, "best": revenue * 1.65 * horizon, "weight": 0.17},
            {"id": "service", "metric": "average_service_level", "direction": "max", "worst": 0.45, "best": 0.98, "weight": 0.15},
            {"id": "reputation", "metric": "final_reputation", "direction": "max", "worst": 0.28, "best": 0.90, "weight": 0.10},
            {"id": "workforce_resilience", "metric": "minimum_employee_energy", "direction": "max", "worst": 0.10, "best": 0.75, "weight": 0.08 + 0.04 * workforce_dependency},
            {"id": "operational_resilience", "metric": "minimum_operational_health", "direction": "max", "worst": 0.08, "best": 0.75, "weight": 0.08 + 0.04 * equipment_dependency},
        ],
        "constraints": [
            {"id": "cash_survival", "metric": "minimum_cash", "op": ">=", "value": cash_floor, "hard": True, "ruin": True, "max_violation_probability": 0.12, "penalty": 0.58},
            {"id": "service_floor", "metric": "average_service_level", "op": ">=", "value": 0.56, "hard": True, "ruin": False, "max_violation_probability": 0.22, "penalty": 0.36},
            {"id": "employee_floor", "metric": "minimum_employee_energy", "op": ">=", "value": 0.11, "hard": True, "ruin": True, "max_violation_probability": 0.18, "penalty": 0.42},
            {"id": "operation_floor", "metric": "minimum_operational_health", "op": ">=", "value": 0.09, "hard": True, "ruin": True, "max_violation_probability": 0.18, "penalty": 0.44},
        ],
        "success": f"cumulative_profit > 0 and average_service_level >= 0.72 and minimum_cash >= {_n(cash_floor)}",
        "stress_tests": [
            {"id": "demand_drop", "label": "Talep düşüşü", "condition": "driver_demand_index_mean < 0.86"},
            {"id": "demand_surge", "label": "Talep sıçraması", "condition": "driver_demand_index_mean > 1.14"},
            {"id": "cost_squeeze", "label": "Maliyet sıkışması", "condition": "driver_cost_index_mean > 1.16"},
            {"id": "staffing_pressure", "label": "Çalışan devamsızlığı", "condition": "driver_absence_pressure_mean > 0.12"},
            {"id": "supplier_pressure", "label": "Tedarik gecikmesi", "condition": "driver_supplier_reliability_mean < 0.82"},
            {"id": "compound_storm", "label": "Bileşik kötü dönem", "condition": "driver_demand_index_mean < 0.92 and driver_cost_index_mean > 1.10 and driver_supplier_reliability_mean < 0.88"},
        ],
    }

    built = Scenario(scenario)
    raise_for_errors(validate_scenario(built))
    return scenario


def company_scenario_explanation(scenario: Mapping[str, Any]) -> dict[str, Any]:
    profile = dict(scenario.get("meta", {}).get("company_profile", {}))
    sector = SECTORS.get(str(profile.get("sector", "generic")), SECTORS["generic"])
    return {
        "headline": f"{profile.get('company_name', 'Şirket')} için karar modeli hazır",
        "plain_model": [
            "Talep ve maliyet her olası dünyada farklı bir yol izler.",
            "Müşteriler, çalışanlar ve tedarikçiler koşullara tepki verir.",
            "Arıza, personel ve tedarik şokları süreleriyle birlikte çalışır.",
            "Her strateji aynı dünyalarda denenir; böylece adil karşılaştırılır.",
            "Kârın yanında nakit, hizmet, itibar ve dayanıklılık da ölçülür.",
        ],
        "sector_label": sector["label"],
        "data_status": profile.get("data_quality", "MIXED"),
        "model_counts": {
            "drivers": len(scenario.get("drivers", {})),
            "actors": len(scenario.get("actors", [])),
            "shocks": len(scenario.get("shocks", [])),
            "nodes": len(scenario.get("equations", {})) + len(scenario.get("states", {})),
            "metrics": len(scenario.get("metrics", {})),
        },
    }


def _company_policy_rules(strategy_id: str) -> list[dict[str, Any]]:
    if strategy_id == "growth_push":
        return [
            {"id": "growth_cash_brake", "when": "period >= 3 and prev_cash < 0", "set": {"marketing_rate": "0.035", "capacity_investment": "0.025", "hiring_rate": "0.02"}, "once": True},
            {"id": "growth_demand_response", "when": "period >= 3 and demand_index > 1.16 and prev_cash > 0", "set": {"marketing_rate": "0.12", "capacity_investment": "0.13"}, "once": False},
        ]
    if strategy_id == "resilient_balance":
        return [
            {"id": "resilience_supply_response", "when": "supplier_reliability < 0.80", "set": {"buffer_stock": "0.24", "maintenance_intensity": "0.20"}, "once": False},
            {"id": "resilience_workforce_response", "when": "prev_employee_energy < 0.42", "set": {"training_rate": "0.18", "hiring_rate": "0.09"}, "once": False},
        ]
    return [
        {"id": "current_cash_defense", "when": "period >= 3 and prev_cash < 0", "set": {"marketing_rate": "0.01", "capacity_investment": "0.0", "buffer_stock": "0.025"}, "once": True}
    ]


def _identifier(value: Any, fallback: str) -> str:
    text = str(value or "").strip().lower()
    text = text.translate(str.maketrans("çğıöşü", "cgiosu"))
    text = re.sub(r"[^a-z0-9_]+", "_", text)
    text = re.sub(r"^\d+", "", text).strip("_")
    return text or fallback


def _bound(value: Any, low: float, high: float, fallback: float) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        number = float(fallback)
    return max(low, min(high, number))


def _n(value: float) -> str:
    return format(float(value), ".12g")
