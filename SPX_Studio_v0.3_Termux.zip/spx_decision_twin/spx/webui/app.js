"use strict";

const state = {
  profile: null,
  strategies: [],
  catalog: null,
  scenario: null,
  modelExplanation: null,
  templates: [],
  projects: [],
  wizardStep: 0,
  activeTab: "setup",
  selectedWorlds: 500,
  selectedNode: null,
  expertView: "drivers",
  valid: null,
  dirty: false,
  wizardDirty: false,
  jobId: null,
  result: null,
  narrative: null,
  activeFuture: 0,
  tourIndex: 0,
};

const WIZARD_LABELS = ["Şirket", "Para", "Kapasite", "Riskler", "Seçenekler", "Kontrol"];
const DATA_QUALITY = {
  OBSERVED: "Gerçek kayıtlardan",
  MIXED: "Kayıt + tahmin karışık",
  ILLUSTRATIVE: "Yaklaşık / örnek değerler",
};
const CONTROL_LABELS = {
  marketing_rate: "Pazarlama bütçesi",
  hiring_rate: "Yeni çalışan / kapasite",
  capacity_investment: "Kapasite yatırımı",
  maintenance_intensity: "Bakım / operasyon güvencesi",
  buffer_stock: "Stok / nakit tamponu",
  training_rate: "Eğitim ve süreç geliştirme",
  price_change: "Fiyat değişimi",
};
const CONTROL_RANGES = {
  marketing_rate: [0, 30, 1],
  hiring_rate: [0, 40, 1],
  capacity_investment: [0, 40, 1],
  maintenance_intensity: [0, 40, 1],
  buffer_stock: [0, 40, 1],
  training_rate: [0, 30, 1],
  price_change: [-25, 35, 1],
};

const LABELS = {
  demand_index: "Pazar talebi",
  cost_index: "Maliyet seviyesi",
  price_sensitivity: "Fiyat hassasiyeti",
  absence_pressure: "Çalışan devamsızlığı",
  supplier_reliability: "Tedarik güvenilirliği",
  economy_regime: "Ekonomik ortam",
  market_demand: "Oluşan talep",
  planned_capacity: "Planlanan kapasite",
  effective_capacity: "Gerçek kullanılabilir kapasite",
  sales_units: "Gerçekleşen satış",
  backlog_change: "Bekleyen iş değişimi",
  backlog: "Bekleyen işler",
  selling_price: "Satış fiyatı",
  monthly_revenue: "Aylık ciro",
  service_level: "Hizmet seviyesi",
  customer_experience: "Müşteri deneyimi",
  customer_base: "Müşteri tabanı",
  reputation: "İtibar",
  skill: "Ekip becerisi",
  strategy_spend: "Strateji harcaması",
  utilization: "Kapasite kullanımı",
  employee_energy: "Çalışan enerjisi",
  operational_health: "Operasyon sağlığı",
  variable_cost: "Değişken gider",
  base_operating_cost: "Sabit işletme gideri",
  monthly_profit: "Aylık kâr",
  cash: "Nakit",
  margin_rate: "Kâr marjı",
  final_cash: "Dönem sonu nakit",
  minimum_cash: "Görülen en düşük nakit",
  cumulative_profit: "Toplam kâr",
  total_revenue: "Toplam ciro",
  average_margin: "Ortalama kâr marjı",
  average_service_level: "Ortalama hizmet seviyesi",
  final_reputation: "Dönem sonu itibar",
  minimum_employee_energy: "En düşük çalışan enerjisi",
  minimum_operational_health: "En düşük operasyon sağlığı",
  final_backlog: "Dönem sonu bekleyen iş",
  failure_months: "Kesinti yaşanan ay",
  customers: "Müşteriler",
  employees: "Çalışanlar",
  suppliers: "Tedarikçiler",
  equipment_failure: "Ekipman / sistem arızası",
  supplier_disruption: "Tedarik kesintisi",
  staffing_wave: "Personel eksikliği dalgası",
  demand_upside: "Talep sıçraması",
  demand_slump: "Talep düşüşü",
  profitability: "Kârlılık",
  liquidity: "Likidite / nakit",
  growth: "Büyüme",
  service: "Hizmet seviyesi",
  workforce_resilience: "Çalışan dayanıklılığı",
  operational_resilience: "Operasyon dayanıklılığı",
};

const NODE_HELP = {
  demand_index: "Pazarın normal bir aya göre ne kadar güçlü veya zayıf olduğunu temsil eder.",
  cost_index: "Malzeme, kira, ücret ve enerji gibi giderlerdeki ortak değişimi taşır.",
  price_sensitivity: "Müşterilerin fiyat değişimine ne kadar tepki verdiğini temsil eder.",
  absence_pressure: "Bir dönemde eksik çalışma ve devamsızlığın ne kadar baskı yarattığını gösterir.",
  supplier_reliability: "Tedarikçilerin zamanında ve eksiksiz teslim etme gücünü temsil eder.",
  economy_regime: "Ekonominin daralma, normal veya genişleme koşulunda olmasını temsil eder.",
  market_demand: "Ekonomi, fiyat, pazarlama, müşteri davranışı ve itibar birleşince oluşan iş talebidir.",
  effective_capacity: "Çalışan, tedarik, bakım, yatırım ve şoklardan sonra gerçekten kullanılabilen kapasitedir.",
  sales_units: "Talep ile kapasitenin izin verdiği ölçüde tamamlanan satış veya iştir.",
  monthly_profit: "Cirodan sabit, değişken ve strateji giderleri çıkarıldıktan sonra kalan aylık sonuçtur.",
  cash: "Aylık kâr veya zararın birikmesiyle şirketin kullanılabilir nakdinin nasıl değiştiğini gösterir.",
  service_level: "Gelen talebin ne kadarının zamanında karşılanabildiğini gösterir.",
  employee_energy: "Yoğunluk, devamsızlık ve eğitim etkileri altında ekibin çalışma gücünü temsil eder.",
  operational_health: "Bakım, kullanım yoğunluğu ve arızalar altında operasyon sisteminin sağlığını temsil eder.",
  reputation: "Müşteri deneyiminin zaman içinde şirket itibarına dönüşen birikimli etkisidir.",
};

const TOUR_STEPS = [
  { screen: "setup", title: "Şirketini normal dille tanıt", body: "İlk ekranda kod veya formül yok. Şirket türünü, bugünkü sayılarını, riskleri ve karşılaştırmak istediğin üç yolu altı kısa adımda yazarsın." },
  { screen: "setup", title: "Her alanın altında ne istediği yazıyor", body: "Kesin verin yoksa yaklaşık değer kullanabilirsin. Veri kalitesini işaretlediğin için rapor bunun tahmin olduğunu unutmaz." },
  { screen: "model", title: "Sistem kurduğu modeli açıklar", body: "Şirket modelini oluşturduğunda talep, müşteri, çalışan, tedarik, kapasite, maliyet ve nakit bağlantılarını sade bir haritada görürsün." },
  { screen: "simulate", title: "Tek gelecek yerine olası dünyalar", body: "100 dünya hızlı kontroldür. 500 dengeli inceleme, 1.000 dünya ise daha kararlı bir karar koşusudur. Her strateji aynı dünyalarda denenir." },
  { screen: "results", title: "Önce karar, sonra risk ve neden", body: "Sonuç ekranı dört soruya ayrılır: hangi strateji önde, risk ne kadar, hangi geleceklerde değişiyor ve sonucu hangi veri sürüklüyor?" },
  { screen: "guide", title: "Takıldığında Öğren merkezine dön", body: "Veri hazırlama tablosu, Monte Carlo anlatımı, sonuç okuma rehberi ve terimler sözlüğü her zaman burada durur." },
];

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

document.addEventListener("DOMContentLoaded", boot);

async function boot() {
  bindStaticEvents();
  try {
    const data = await api("/api/bootstrap");
    state.catalog = data.company_builder || {};
    state.profile = clone(state.catalog.default_profile || {});
    state.strategies = clone(state.catalog.default_strategies || []);
    state.templates = data.templates || [];
    state.projects = data.projects || [];
    populateWizard();
    renderExampleTemplates();
    renderProjects();
    renderWizard();
    renderSimulationRecap();
    $("#runSeed").value = 20260817;
    $("#loadingPanel").hidden = true;
    showScreen("setup", { quiet: true });
    setServerState("online", "Yerel motor hazır");
    if (!storageGet("spx-welcome-v03")) openDialog("welcomeDialog");
  } catch (error) {
    setServerState("error", "Motor bağlantısı yok");
    $("#loadingPanel h1").textContent = "SPX motoruna bağlanamadık";
    $("#loadingPanel p").textContent = `${error.message} · Termux penceresindeki sunucunun açık kaldığını kontrol et.`;
    toast(error.message, true);
  }
}

function bindStaticEvents() {
  $$('[data-tab]').forEach((button) => button.addEventListener("click", () => showScreen(button.dataset.tab)));
  $$('[data-go]').forEach((button) => button.addEventListener("click", (event) => {
    event.preventDefault();
    showScreen(button.dataset.go);
  }));
  $$('[data-close-dialog]').forEach((button) => button.addEventListener("click", () => closeDialog(button.dataset.closeDialog)));
  $$('[data-worlds]').forEach((button) => button.addEventListener("click", () => selectWorlds(Number(button.dataset.worlds))));
  $$('[data-result-view]').forEach((button) => button.addEventListener("click", () => showResultView(button.dataset.resultView)));
  $$('[data-guide]').forEach((button) => button.addEventListener("click", () => showGuide(button.dataset.guide)));
  $$('[data-guide-topic]').forEach((button) => button.addEventListener("click", () => openGuideTopic(button.dataset.guideTopic)));
  $$('[data-expert]').forEach((button) => button.addEventListener("click", () => {
    state.expertView = button.dataset.expert;
    renderExpert();
  }));

  $("#wizardBackButton").addEventListener("click", () => moveWizard(-1));
  $("#wizardNextButton").addEventListener("click", () => moveWizard(1));
  $("#buildCompanyButton").addEventListener("click", buildCompanyModel);
  $("#modelToSimulationButton").addEventListener("click", modelToSimulation);
  $("#runButton").addEventListener("click", runSimulation);
  $("#viewLastResultButton").addEventListener("click", () => showScreen("results"));
  $("#downloadReportButton").addEventListener("click", () => openDownload("report.html", true));
  $("#downloadCsvButton").addEventListener("click", () => openDownload("worlds.csv"));
  $("#tourButton").addEventListener("click", startTour);
  $("#guideStartTourButton").addEventListener("click", startTour);
  $("#skipWelcomeButton").addEventListener("click", dismissWelcome);
  $("#welcomeTourButton").addEventListener("click", () => { dismissWelcome(); startTour(); });
  $("#tourExitButton").addEventListener("click", endTour);
  $("#tourNextButton").addEventListener("click", nextTourStep);
  $("#projectsButton").addEventListener("click", openProjects);
  $("#saveProjectButton").addEventListener("click", openSaveDialog);
  $("#confirmSaveButton").addEventListener("click", saveProject);
}

function populateWizard() {
  const p = state.profile;
  const binds = [
    ["companyName", "company_name", "text"],
    ["decisionQuestion", "decision_question", "text"],
    ["companyHorizon", "horizon", "number"],
    ["dataQuality", "data_quality", "text"],
    ["monthlyRevenue", "monthly_revenue", "number"],
    ["monthlyCost", "monthly_cost", "number"],
    ["companyCash", "cash", "number"],
    ["employees", "employees", "number"],
    ["monthlyUnits", "monthly_units", "number"],
    ["maxCapacity", "max_capacity", "number"],
  ];
  binds.forEach(([id, key, kind]) => {
    const node = $(`#${id}`);
    node.value = p[key] ?? "";
    node.oninput = () => {
      state.profile[key] = kind === "number" ? numeric(node.value, 0) : node.value;
      invalidateBuiltModel();
      updateDerivedWizardValues();
    };
  });

  bindPercentInput("variableCostShare", "variable_cost_share", "variableCostShareValue", (value) => `%${Math.round(value)}`);
  bindRiskInput("demandUncertainty", "demand_uncertainty", "demandUncertaintyValue", [12, 25]);
  bindRiskInput("costInflation", "annual_cost_inflation", "costInflationValue", [20, 50]);
  bindRiskInput("absenceRate", "absence_rate", "absenceRateValue", [5, 12]);
  bindRiskInput("failureRisk", "failure_risk", "failureRiskValue", [4, 10]);
  bindRiskInput("supplierRisk", "supplier_delay_risk", "supplierRiskValue", [7, 18]);
  renderSectors();
  renderStrategyBuilder();
  updateDerivedWizardValues();
}

function bindPercentInput(inputId, key, outputId, formatter) {
  const input = $(`#${inputId}`);
  input.value = Math.round(numeric(state.profile[key], 0) * 100);
  input.oninput = () => {
    state.profile[key] = numeric(input.value, 0) / 100;
    $(`#${outputId}`).textContent = formatter(numeric(input.value, 0));
    invalidateBuiltModel();
    updateDerivedWizardValues();
  };
  $(`#${outputId}`).textContent = formatter(numeric(input.value, 0));
}

function bindRiskInput(inputId, key, outputId, thresholds) {
  bindPercentInput(inputId, key, outputId, (value) => `%${Math.round(value)} · ${riskLevel(value, thresholds)}`);
}

function riskLevel(value, thresholds = [10, 25]) {
  if (value <= thresholds[0]) return "Düşük";
  if (value <= thresholds[1]) return "Orta";
  return "Yüksek";
}

function renderSectors() {
  const sectors = state.catalog?.sectors || [];
  $("#sectorGrid").innerHTML = sectors.map((sector) => `<button class="sector-card ${state.profile.sector === sector.id ? "active" : ""}" type="button" data-sector="${esc(sector.id)}"><b>${esc(sector.label)}</b><small>${esc(sector.description)}</small></button>`).join("");
  $$('[data-sector]', $("#sectorGrid")).forEach((button) => button.addEventListener("click", () => {
    state.profile.sector = button.dataset.sector;
    invalidateBuiltModel();
    renderSectors();
  }));
}

function renderStrategyBuilder() {
  $("#strategyBuilder").innerHTML = state.strategies.map((strategy, index) => {
    const controls = Object.keys(CONTROL_LABELS).map((key) => {
      const [min, max, step] = CONTROL_RANGES[key];
      const value = Math.round(numeric(strategy[key], 0) * 100);
      return `<label class="mini-range"><span>${esc(CONTROL_LABELS[key])}<output data-control-output="${index}:${key}">${signedPercent(value)}</output></span><input type="range" min="${min}" max="${max}" step="${step}" value="${value}" data-strategy-control="${index}:${key}"></label>`;
    }).join("");
    return `<article class="strategy-build-card" data-strategy-index="${index}">
      <div class="strategy-index"><span>SEÇENEK ${index + 1}</span><span>${index === 0 ? "REFERANS" : "ALTERNATİF"}</span></div>
      <label class="field"><span>Seçeneğin adı</span><input data-strategy-label="${index}" value="${esc(strategy.label)}" maxlength="80"></label>
      <label class="field"><span>Ne yapılıyor?</span><textarea data-strategy-description="${index}" rows="3" maxlength="240">${esc(strategy.description || "")}</textarea></label>
      <div class="strategy-summary">${strategySummaryChips(strategy)}</div>
      <details><summary>Ayrıntılı oranları aç</summary><div class="control-list">${controls}</div></details>
    </article>`;
  }).join("");

  $$('[data-strategy-label]').forEach((input) => input.addEventListener("input", () => {
    state.strategies[Number(input.dataset.strategyLabel)].label = input.value;
    invalidateBuiltModel();
  }));
  $$('[data-strategy-description]').forEach((input) => input.addEventListener("input", () => {
    state.strategies[Number(input.dataset.strategyDescription)].description = input.value;
    invalidateBuiltModel();
  }));
  $$('[data-strategy-control]').forEach((input) => input.addEventListener("input", () => {
    const [rawIndex, key] = input.dataset.strategyControl.split(":");
    const index = Number(rawIndex);
    state.strategies[index][key] = numeric(input.value, 0) / 100;
    const output = $(`[data-control-output="${index}:${key}"]`);
    if (output) output.textContent = signedPercent(numeric(input.value, 0));
    const card = input.closest(".strategy-build-card");
    const summary = $(".strategy-summary", card);
    if (summary) summary.innerHTML = strategySummaryChips(state.strategies[index]);
    invalidateBuiltModel();
  }));
}

function strategySummaryChips(strategy) {
  const rows = [
    ["marketing_rate", "Pazarlama"], ["capacity_investment", "Kapasite"],
    ["maintenance_intensity", "Bakım"], ["buffer_stock", "Tampon"],
  ].sort((a, b) => numeric(strategy[b[0]], 0) - numeric(strategy[a[0]], 0)).slice(0, 3);
  return rows.map(([key, label]) => `<span>${label} ${signedPercent(numeric(strategy[key], 0) * 100)}</span>`).join("");
}

function updateDerivedWizardValues() {
  if (!state.profile) return;
  const p = state.profile;
  const use = p.max_capacity > 0 ? p.monthly_units / p.max_capacity : 0;
  const margin = p.monthly_revenue > 0 ? (p.monthly_revenue - p.monthly_cost) / p.monthly_revenue : 0;
  const runway = p.monthly_cost > p.monthly_revenue ? p.cash / Math.max(1, p.monthly_cost - p.monthly_revenue) : null;
  const capacityText = use > 1
    ? `Gerçekleşen iş kapasite tahminini <b>%${Math.round((use - 1) * 100)}</b> aşıyor. Kapasite değerini kontrol et veya bunun fazla mesai olduğunu kabul et.`
    : `Bugünkü yaklaşık kapasite kullanımı <b>%${Math.round(use * 100)}</b>. ${use > .88 ? "Sistem yoğun; talep artışında kuyruk oluşabilir." : use < .55 ? "Belirgin boş kapasite var; talep tarafı kritik olabilir." : "Talep artışı için sınırlı bir hareket alanı var."}`;
  $("#capacityPreview").innerHTML = `${capacityText}<br>Bugünkü kaba faaliyet marjı <b>${pct(margin)}</b>${runway === null ? "; işletme bugünkü ortalamada nakit yakmıyor." : `; aynı açık sürerse nakit yaklaşık <b>${num(runway)} ay</b> dayanır.`}`;
  if (state.wizardStep === 5) renderReview();
}

function renderWizard() {
  $("#wizardProgress").innerHTML = WIZARD_LABELS.map((label, index) => `<button type="button" data-wizard-jump="${index}" class="${index === state.wizardStep ? "active" : ""} ${index < state.wizardStep ? "done" : ""}"><span>${index < state.wizardStep ? "✓" : index + 1}</span><b>${label}</b></button>`).join("");
  $$('[data-wizard-jump]').forEach((button) => button.addEventListener("click", () => {
    const target = Number(button.dataset.wizardJump);
    if (target <= state.wizardStep || validateWizardStep(state.wizardStep, true)) {
      state.wizardStep = target;
      renderWizard();
    }
  }));
  $$('[data-wizard-step]').forEach((section) => {
    const active = Number(section.dataset.wizardStep) === state.wizardStep;
    section.hidden = !active;
    section.classList.toggle("active", active);
  });
  $("#wizardBackButton").disabled = state.wizardStep === 0;
  $("#wizardNextButton").hidden = state.wizardStep === 5;
  $("#wizardNextButton").textContent = state.wizardStep === 4 ? "Kontrole geç →" : "Devam →";
  if (state.wizardStep === 5) renderReview();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function moveWizard(direction) {
  if (direction > 0 && !validateWizardStep(state.wizardStep)) return;
  state.wizardStep = clamp(state.wizardStep + direction, 0, 5);
  renderWizard();
}

function validateWizardStep(step, quiet = false) {
  const problems = [];
  if (step === 0) {
    if (!String(state.profile.company_name || "").trim()) problems.push(["companyName", "Şirketin adını yaz."]);
    if (!String(state.profile.decision_question || "").trim()) problems.push(["decisionQuestion", "Karşılaştırmak istediğin karar sorusunu yaz."]);
  }
  if (step === 1) {
    if (numeric(state.profile.monthly_revenue, 0) <= 0) problems.push(["monthlyRevenue", "Aylık ciro sıfırdan büyük olmalı."]);
    if (numeric(state.profile.monthly_cost, -1) < 0) problems.push(["monthlyCost", "Aylık gider negatif olamaz."]);
    if (numeric(state.profile.employees, 0) < 1) problems.push(["employees", "En az bir çalışan gir."]);
  }
  if (step === 2) {
    if (numeric(state.profile.monthly_units, 0) <= 0) problems.push(["monthlyUnits", "Aylık satış / iş miktarını gir."]);
    if (numeric(state.profile.max_capacity, 0) <= 0) problems.push(["maxCapacity", "Aylık azami kapasiteyi gir."]);
  }
  if (step === 4) {
    const names = state.strategies.map((item) => String(item.label || "").trim().toLocaleLowerCase("tr"));
    if (names.some((name) => !name)) problems.push([null, "Üç seçeneğin de adını yaz."]);
    if (new Set(names).size !== names.length) problems.push([null, "Seçenek adları birbirinden farklı olmalı."]);
  }
  if (problems.length && !quiet) {
    toast(problems[0][1], true);
    if (problems[0][0]) $(`#${problems[0][0]}`)?.focus();
  }
  return problems.length === 0;
}

function renderReview() {
  const p = state.profile;
  const sector = (state.catalog?.sectors || []).find((item) => item.id === p.sector);
  const utilization = p.max_capacity > 0 ? p.monthly_units / p.max_capacity : 0;
  $("#reviewSummary").innerHTML = `<h3>Kurulacak şirket modeli</h3>
    ${reviewRow("Şirket", p.company_name)}
    ${reviewRow("Tür", sector?.label || humanize(p.sector))}
    ${reviewRow("Zaman", `${p.horizon} ay`)}
    ${reviewRow("Aylık ciro / gider", `${money(p.monthly_revenue)} / ${money(p.monthly_cost)}`)}
    ${reviewRow("Kullanılabilir nakit", money(p.cash))}
    ${reviewRow("Çalışan / kapasite", `${num(p.employees)} kişi · %${Math.round(utilization * 100)} kullanım`)}
    ${reviewRow("Veri durumu", DATA_QUALITY[p.data_quality] || p.data_quality)}
    ${reviewRow("Karşılaştırma", state.strategies.map((item) => item.label).join(" · "))}`;
  const allSteps = [0, 1, 2, 4].every((step) => validateWizardStep(step, true));
  const riskCount = [p.demand_uncertainty, p.annual_cost_inflation, p.absence_rate, p.failure_risk, p.supplier_delay_risk].filter((x) => Number.isFinite(Number(x))).length;
  const score = Math.round((allSteps ? 65 : 35) + (riskCount / 5) * 20 + (p.data_quality === "OBSERVED" ? 15 : p.data_quality === "MIXED" ? 10 : 3));
  $("#readinessCard").innerHTML = `<h3>İlk koşu hazırlığı</h3><div class="readiness-score">%${clamp(score, 0, 100)}</div><p>${p.data_quality === "ILLUSTRATIVE" ? "Bu bir keşif modeli olacak. Sonucu karar vermek için değil, hangi verinin önemli olduğunu görmek için kullan." : "İlk karşılaştırma için yeterli. Sonuçtan sonra hassas verileri gerçek kayıtlarla güncelle."}</p><div class="readiness-list"><span>Üç karar yolu tanımlı</span><span>Beş belirsizlik tanımlı</span><span>Nakit ve kapasite sınırları kurulacak</span><span>İnsan onayı zorunlu kalacak</span></div>`;
  $("#buildCompanyButton").disabled = !allSteps;
}

function reviewRow(label, value) {
  return `<div class="review-row"><span>${esc(label)}</span><b>${esc(value)}</b></div>`;
}

function invalidateBuiltModel() {
  if (!state.scenario) return;
  state.dirty = true;
  state.wizardDirty = true;
  state.valid = null;
  state.result = null;
  state.narrative = null;
  state.jobId = null;
  $("#saveProjectButton").disabled = true;
  $("#viewLastResultButton").disabled = true;
  renderResults();
  $("#wizardSaveHint").textContent = "Değişiklikleri modele aktarmak için son adımda yeniden oluştur.";
}

async function buildCompanyModel() {
  if (![0, 1, 2, 4].every((step) => validateWizardStep(step))) return;
  const button = $("#buildCompanyButton");
  button.disabled = true;
  button.querySelector("span").textContent = "Şirket modeli kuruluyor…";
  try {
    const payload = await api("/api/company/build", { method: "POST", body: { profile: state.profile, strategies: state.strategies } });
    state.scenario = normalizeScenario(payload.scenario);
    state.modelExplanation = payload.explanation || deriveExplanation(state.scenario);
    state.valid = true;
    state.dirty = false;
    state.wizardDirty = false;
    state.selectedNode = null;
    state.result = null;
    state.narrative = null;
    state.jobId = null;
    $("#runSeed").value = state.scenario.simulation?.seed || 20260817;
    $("#saveProjectButton").disabled = false;
    $("#wizardSaveHint").textContent = "Model oluşturuldu; istersen proje olarak kaydet.";
    renderModel();
    renderSimulationRecap();
    renderResults();
    toast("Şirket modeli hazır: belirsizlikler, aktörler, şoklar ve karar ölçütleri kuruldu.");
    showScreen("model", { quiet: true });
  } catch (error) {
    toast(`Model kurulamadı: ${error.message}`, true);
  } finally {
    button.disabled = false;
    button.querySelector("span").textContent = "Şirket modelini oluştur";
  }
}

function normalizeScenario(raw) {
  const s = clone(raw || {});
  s.meta ||= {};
  s.meta.id ||= "my_projection_model";
  s.meta.name ||= "Yeni projeksiyon modeli";
  s.meta.data_status ||= "ILLUSTRATIVE";
  s.simulation ||= { worlds: 1000, seed: 20260817 };
  s.drivers ||= {};
  s.correlations ||= [];
  s.strategies ||= [];
  s.actors ||= [];
  s.shocks ||= [];
  s.states ||= {};
  s.equations ||= {};
  s.metrics ||= {};
  s.objectives ||= [];
  s.constraints ||= [];
  s.evidence ||= [];
  s.stress_tests ||= [];
  return s;
}

function deriveExplanation(scenario) {
  return {
    headline: `${scenario.meta.name || "Model"} hazır`,
    plain_model: [
      "Belirsiz girdiler farklı olası gelecekler üretir.",
      "Sanal aktörler ve olaylar bu koşullara tepki verir.",
      "Her strateji aynı dünyalarda çalıştırılarak adil karşılaştırılır.",
      "Sonuçlar ortalama, kötü kuyruk, başarı ve dayanıklılık açısından sıralanır.",
    ],
    sector_label: "Hazır deneysel model",
    data_status: scenario.meta.data_status,
    model_counts: modelCounts(scenario),
  };
}

function renderExampleTemplates() {
  $("#exampleTemplateCards").innerHTML = state.templates.map((template) => `<button class="example-card" type="button" data-template="${esc(template.id)}"><div><h3>${esc(template.name)}</h3><p>${esc(template.description || "Hazır olasılık simülasyonunu aç, model yapısını incele ve çalıştır.")}</p></div><span>→</span></button>`).join("");
  $$('[data-template]').forEach((button) => button.addEventListener("click", () => loadTemplate(button.dataset.template)));
}

async function loadTemplate(templateId) {
  if (state.dirty && !window.confirm("Kurulumda modele aktarılmamış değişiklikler var. Hazır örneği yine de açalım mı?")) return;
  try {
    state.scenario = normalizeScenario(await api(`/api/templates/${encodeURIComponent(templateId)}`));
    state.modelExplanation = deriveExplanation(state.scenario);
    state.valid = null;
    state.dirty = false;
    state.wizardDirty = false;
    state.selectedNode = null;
    state.result = null;
    state.jobId = null;
    $("#runSeed").value = state.scenario.simulation.seed || 20260817;
    $("#saveProjectButton").disabled = false;
    renderModel();
    renderSimulationRecap();
    renderResults();
    await validateModel({ silent: true });
    showScreen("model", { quiet: true });
    toast("Hazır örnek model açıldı.");
  } catch (error) { toast(error.message, true); }
}

function showScreen(name, options = {}) {
  if ((name === "model" || name === "simulate") && state.wizardDirty) {
    if (!options.quiet) toast("Şirket bilgileri değişti. Son adıma gidip modeli yeniden oluştur.");
    state.wizardStep = 5;
    renderWizard();
    name = "setup";
  }
  if ((name === "model" || name === "simulate") && !state.scenario) {
    if (!options.quiet) toast("Önce şirket bilgilerini tamamlayıp modeli oluştur.");
    name = "setup";
  }
  state.activeTab = name;
  $$(".workspace-screen").forEach((screen) => { screen.hidden = screen.id !== `screen-${name}`; });
  $$('[data-tab]').forEach((button) => {
    const active = button.dataset.tab === name;
    button.classList.toggle("active", active);
    button.setAttribute("aria-selected", String(active));
  });
  if (state.scenario) updateContextBar();
  if (name === "model" && state.scenario) renderModel();
  if (name === "simulate") renderSimulationRecap();
  if (name === "results") renderResults();
  window.scrollTo({ top: 0, behavior: options.quiet ? "auto" : "smooth" });
}

function updateContextBar() {
  $("#contextbar").hidden = false;
  $("#activeModelName").textContent = state.scenario.meta.name || "Aktif model";
  const counts = modelCounts(state.scenario);
  $("#activeModelMeta").textContent = `${state.scenario.horizon} ${state.scenario.step || "dönem"} · ${counts.strategies} strateji · ${counts.drivers} belirsizlik · ${state.valid === true ? "doğrulandı" : state.dirty ? "yeniden doğrulanmalı" : "kontrol bekliyor"}`;
}

function renderModel() {
  if (!state.scenario) return;
  const s = state.scenario;
  const explanation = state.modelExplanation || deriveExplanation(s);
  $("#modelSummaryCard").innerHTML = `<span class="eyebrow">${esc(explanation.sector_label || "OLASILIK MODELİ")}</span><h2>${esc(explanation.headline || `${s.meta.name} hazır`)}</h2><p>${esc((explanation.plain_model || []).join(" "))}</p>`;
  renderPlainData();
  renderModelCounts();
  renderGraph();
  renderPreflight();
  renderExpert();
  renderHealth();
  updateContextBar();
}

function modelCounts(s) {
  return {
    drivers: Object.keys(s.drivers || {}).length,
    strategies: (s.strategies || []).length,
    actors: (s.actors || []).length,
    shocks: (s.shocks || []).length,
    nodes: Object.keys(s.states || {}).length + Object.keys(s.equations || {}).length,
    metrics: Object.keys(s.metrics || {}).length,
  };
}

function renderPlainData() {
  const p = state.scenario.meta?.company_profile;
  let rows;
  if (p) {
    const sector = (state.catalog?.sectors || []).find((item) => item.id === p.sector);
    rows = [
      ["Şirket türü", sector?.label || humanize(p.sector)], ["Karar süresi", `${p.horizon} ay`],
      ["Aylık ciro", money(p.monthly_revenue)], ["Aylık gider", money(p.monthly_cost)],
      ["Kullanılabilir nakit", money(p.cash)], ["Çalışan", `${num(p.employees)} kişi`],
      ["Aylık iş / kapasite", `${num(p.monthly_units)} / ${num(p.max_capacity)}`], ["Talep oynaklığı", pct(p.demand_uncertainty)],
      ["Maliyet artışı", `yıllık ${pct(p.annual_cost_inflation)}`], ["Veri durumu", DATA_QUALITY[p.data_quality] || p.data_quality],
    ];
  } else {
    rows = [
      ["Model", state.scenario.meta.name], ["Karar sorusu", state.scenario.meta.decision_question || "—"],
      ["Süre", `${state.scenario.horizon} ${state.scenario.step || "dönem"}`], ["Veri durumu", DATA_QUALITY[state.scenario.meta.data_status] || state.scenario.meta.data_status],
      ["Stratejiler", state.scenario.strategies.map((item) => item.label || item.id).join(" · ")], ["Tohum", state.scenario.simulation.seed],
    ];
  }
  $("#plainDataList").innerHTML = rows.map(([label, value]) => `<div class="plain-data-row"><span>${esc(label)}</span><b>${esc(value)}</b></div>`).join("");
}

function renderModelCounts() {
  const c = modelCounts(state.scenario);
  const rows = [[c.drivers, "belirsizlik sürücüsü"], [c.actors, "sanal aktör grubu"], [c.shocks, "beklenmeyen olay"], [c.nodes, "neden-sonuç düğümü"], [c.metrics, "sonuç ölçüsü"], [c.strategies, "karar stratejisi"]];
  $("#modelCounts").innerHTML = rows.map(([value, label]) => `<div class="model-count"><b>${value}</b><span>${label}</span></div>`).join("");
}

function graphNodes() {
  const s = state.scenario;
  return [
    ...Object.entries(s.drivers).map(([id, spec]) => ({ id, kind: "driver", spec })),
    ...Object.entries(s.equations).map(([id, spec]) => ({ id, kind: "equation", spec })),
    ...Object.entries(s.states).map(([id, spec]) => ({ id, kind: "state", spec })),
    ...Object.entries(s.metrics).map(([id, spec]) => ({ id, kind: "metric", spec })),
  ];
}

function renderGraph() {
  if (!state.scenario) return;
  const svg = $("#nodeGraph");
  const nodes = graphNodes();
  const groups = ["driver", "equation", "state", "metric"].map((kind) => nodes.filter((node) => node.kind === kind));
  const xByKind = { driver: 18, equation: 260, state: 502, metric: 744 };
  const width = 952;
  const nodeWidth = 190;
  const nodeHeight = 42;
  const gap = 14;
  const header = 42;
  const height = Math.max(470, header + Math.max(...groups.map((group) => group.length)) * (nodeHeight + gap) + 22);
  const positions = {};
  groups.forEach((group) => group.forEach((node, index) => {
    positions[node.id] = { x: xByKind[node.kind], y: header + index * (nodeHeight + gap), node };
  }));
  const allIds = new Set(nodes.map((node) => node.id));
  const edges = [];
  nodes.filter((node) => node.kind !== "driver").forEach((node) => {
    const expression = String(node.spec.expression || node.spec.transition || "");
    allIds.forEach((source) => {
      const pattern = new RegExp(`(?:^|[^A-Za-z0-9_])(?:prev_)?${escapeRegExp(source)}(?:$|[^A-Za-z0-9_])`);
      if (source !== node.id && pattern.test(expression)) edges.push([source, node.id]);
    });
  });
  const active = state.selectedNode;
  const edgeMarkup = edges.map(([source, target]) => {
    const a = positions[source], b = positions[target];
    if (!a || !b) return "";
    const x1 = a.x + nodeWidth, y1 = a.y + nodeHeight / 2, x2 = b.x, y2 = b.y + nodeHeight / 2;
    const mid = (x1 + x2) / 2;
    const isActive = active === source || active === target;
    return `<path class="edge ${isActive ? "active" : ""}" d="M${x1},${y1} C${mid},${y1} ${mid},${y2} ${x2},${y2}"></path>`;
  }).join("");
  const headers = [["driver", "DIŞ DÜNYA"], ["equation", "HESAPLAMALAR"], ["state", "BİRİKEN DURUM"], ["metric", "ÖLÇÜLEN SONUÇ"]].map(([kind, label]) => `<text x="${xByKind[kind]}" y="20" class="node-kind">${label}</text>`).join("");
  const nodeMarkup = nodes.map((node) => {
    const p = positions[node.id];
    const label = truncate(humanize(node.id), 27);
    return `<g class="graph-node ${node.kind} ${active === node.id ? "selected" : ""}" data-node="${esc(node.id)}" transform="translate(${p.x},${p.y})"><rect width="${nodeWidth}" height="${nodeHeight}"></rect><text x="11" y="17">${esc(label)}</text><text class="node-kind" x="11" y="31">${esc(kindLabel(node.kind))}</text></g>`;
  }).join("");
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  svg.innerHTML = `${headers}${edgeMarkup}${nodeMarkup}`;
  $$('[data-node]', svg).forEach((group) => group.addEventListener("click", () => {
    state.selectedNode = group.dataset.node;
    renderGraph();
    renderNodeInspector();
  }));
  renderNodeInspector();
}

function renderNodeInspector() {
  const container = $("#nodeInspector");
  if (!state.selectedNode) {
    container.innerHTML = `<span class="eyebrow">SEÇİLEN PARÇA</span><h3>Bir kutuya dokun</h3><p>Görevi burada sade dille açıklanacak. Haritayı anlamadan da simülasyonu çalıştırabilirsin.</p>`;
    return;
  }
  const node = graphNodes().find((item) => item.id === state.selectedNode);
  if (!node) return;
  const expression = node.spec.expression || node.spec.transition || `${node.spec.process || "tanımlı"} belirsizlik süreci`;
  const evidence = (node.spec.evidence_ids || []).join(" · ") || "Üst model / kullanıcı girişi";
  container.innerHTML = `<span class="eyebrow">${esc(kindLabel(node.kind).toLocaleUpperCase("tr"))}</span><h3>${esc(humanize(node.id))}</h3><p>${esc(NODE_HELP[node.id] || genericNodeHelp(node))}</p><div class="node-meta"><div><span>Teknik kimlik</span><code>${esc(node.id)}</code></div><div><span>Model / süreç</span><code>${esc(node.spec.model_id || node.spec.process || "Model tanımı")}</code></div><div><span>Formül / geçiş</span><code>${esc(expression)}</code></div><div><span>Kaynak izi</span><code>${esc(evidence)}</code></div></div>`;
}

function genericNodeHelp(node) {
  if (node.kind === "driver") return "Farklı olası dünyalarda değişen ve şirketin doğrudan kontrol edemediği bir koşuldur.";
  if (node.kind === "state") return "Bir aydan sonraki aya taşınan, geçmiş sonuçları içinde biriktiren şirket durumudur.";
  if (node.kind === "metric") return "Stratejilerin sonuçlarını karşılaştırmak için koşu sonunda özetlenen ölçüdür.";
  return "Diğer şirket parçalarını bir formülle birleştirerek her dönem yeniden hesaplanan ara sonuçtur.";
}

function renderPreflight() {
  const s = state.scenario;
  const checks = [
    [Boolean(s.meta?.data_status), "Veri durumu işaretli", DATA_QUALITY[s.meta?.data_status] || "Kaynak sınıfı modelde tutuluyor."],
    [s.strategies.length >= 2, "Karşılaştırma mümkün", `${s.strategies.length} farklı strateji aynı dünyalarda denenecek.`],
    [Object.keys(s.drivers).length > 0 && Object.keys(s.metrics).length > 0, "Belirsizlik ve sonuç bağlı", `${Object.keys(s.drivers).length} belirsizlikten ${Object.keys(s.metrics).length} ölçü üretilecek.`],
    [(s.constraints || []).length > 0, "Kritik sınırlar tanımlı", `${(s.constraints || []).length} nakit / hizmet / operasyon sınırı izlenecek.`],
    [(s.evidence || []).length > 0, "Kaynak izi var", `${(s.evidence || []).length} veri, varsayım veya tercih kaydı tutuluyor.`],
    [s.meta?.human_approval_required !== false, "Kararı insan onaylayacak", "Motor seçenekleri karşılaştırır; kararı otomatik uygulamaz."],
  ];
  $("#preflightChecklist").innerHTML = checks.map(([ok, title, copy]) => `<div class="check-item"><i>${ok ? "✓" : "!"}</i><div><b>${esc(title)}</b><small>${esc(copy)}</small></div></div>`).join("");
}

function renderHealth() {
  const node = $("#modelHealth");
  if (state.valid === true) {
    node.className = "model-health valid";
    node.textContent = "Model çalışmaya hazır";
  } else if (state.valid === false) {
    node.className = "model-health invalid";
    node.textContent = "Düzeltilmesi gereken hata var";
  } else {
    node.className = "model-health";
    node.textContent = state.dirty ? "Değişiklikler kontrol bekliyor" : "Otomatik kontrol bekliyor";
  }
}

async function validateModel({ silent = false } = {}) {
  if (!state.scenario) return false;
  try {
    const payload = await api("/api/validate", { method: "POST", body: { scenario: state.scenario } });
    state.valid = Boolean(payload.valid);
    renderHealth();
    updateContextBar();
    const box = $("#validationBox");
    box.hidden = false;
    box.className = `validation-box ${payload.valid ? "valid" : "invalid"}`;
    const issues = payload.issues || [];
    box.innerHTML = payload.valid
      ? `<h3>✓ Teknik kontrol tamam</h3><p class="section-copy">Model çalıştırılabilir.${issues.length ? ` ${issues.length} uyarı var; sonuç raporunda korunacak.` : " Hata veya uyarı bulunmadı."}</p>${issues.map(issueMarkup).join("")}`
      : `<h3>Model henüz çalıştırılamaz</h3>${issues.map(issueMarkup).join("")}`;
    if (!silent) toast(payload.valid ? "Model teknik kontrolden geçti." : "Modelde düzeltilmesi gereken hata var.", !payload.valid);
    return payload.valid;
  } catch (error) {
    state.valid = false;
    renderHealth();
    if (!silent) toast(error.message, true);
    return false;
  }
}

function issueMarkup(issue) {
  return `<div class="issue"><b>${issue.level === "error" ? "HATA" : "UYARI"}</b><span>${esc(issue.message || issue.code || "Model sorunu")}</span></div>`;
}

async function modelToSimulation() {
  if (await validateModel()) showScreen("simulate", { quiet: true });
}

function renderExpert() {
  if (!state.scenario) return;
  $$('[data-expert]').forEach((button) => button.classList.toggle("active", button.dataset.expert === state.expertView));
  const panel = $("#expertPanel");
  if (state.expertView === "drivers") renderExpertDrivers(panel);
  else if (state.expertView === "strategies") renderExpertStrategies(panel);
  else if (state.expertView === "actors") renderExpertActors(panel);
  else if (state.expertView === "objectives") renderExpertObjectives(panel);
  else renderExpertJson(panel);
}

function renderExpertDrivers(panel) {
  panel.innerHTML = `<div class="expert-list">${Object.entries(state.scenario.drivers).map(([id, spec]) => `<div class="expert-row" data-driver-row="${esc(id)}"><label class="field"><span>Belirsizlik</span><input value="${esc(humanize(id))}" disabled></label><label class="field"><span>Süreç</span><select data-driver-field="process"><option value="ar1" ${selected(spec.process, "ar1")}>AR(1)</option><option value="iid" ${selected(spec.process, "iid")}>Bağımsız</option><option value="random_walk" ${selected(spec.process, "random_walk")}>Rastgele yürüyüş</option><option value="constant" ${selected(spec.process, "constant")}>Sabit</option><option value="markov" ${selected(spec.process, "markov")}>Markov</option></select></label><label class="field"><span>Ortalama</span><input type="number" step="any" data-driver-field="mean" value="${esc(spec.mean ?? "")}"></label><label class="field"><span>Oynaklık σ</span><input type="number" step="any" min="0" data-driver-field="sigma" value="${esc(spec.sigma ?? "")}"></label><label class="field"><span>Hafıza φ</span><input type="number" step="0.01" min="-0.99" max="0.99" data-driver-field="phi" value="${esc(spec.phi ?? "")}"></label></div>`).join("")}</div>`;
  $$('[data-driver-field]', panel).forEach((input) => input.addEventListener("change", () => {
    const id = input.closest("[data-driver-row]").dataset.driverRow;
    const key = input.dataset.driverField;
    state.scenario.drivers[id][key] = key === "process" ? input.value : numeric(input.value, 0);
    markScenarioDirty();
  }));
}

function renderExpertStrategies(panel) {
  panel.innerHTML = `<div class="expert-card-grid">${state.scenario.strategies.map((strategy, index) => `<article class="expert-card" data-expert-strategy="${index}"><h3>${esc(strategy.label || strategy.id)}</h3><p>${esc(strategy.description || "Tanımlı politika")}</p>${Object.entries(strategy.parameters || {}).map(([key, value]) => `<label class="field"><span>${esc(CONTROL_LABELS[key] || humanize(key))}</span><input type="number" step="0.001" data-parameter="${esc(key)}" value="${esc(value)}"></label>`).join("")}</article>`).join("")}</div>`;
  $$('[data-parameter]', panel).forEach((input) => input.addEventListener("change", () => {
    const index = Number(input.closest("[data-expert-strategy]").dataset.expertStrategy);
    state.scenario.strategies[index].parameters[input.dataset.parameter] = numeric(input.value, 0);
    markScenarioDirty();
  }));
}

function renderExpertActors(panel) {
  const actorCards = state.scenario.actors.map((actor) => `<article class="expert-card"><h3>${esc(humanize(actor.id))}</h3><p><b>${num(actor.population)}</b> sanal temsilci · ${(actor.actions || []).length} davranış seçeneği</p><p>${esc((actor.actions || []).map((item) => humanize(item.id)).join(" · "))}</p></article>`).join("");
  const shockCards = state.scenario.shocks.map((shock) => `<article class="expert-card"><h3>${esc(humanize(shock.id))}</h3><p>Olasılık: <code>${esc(shock.hazard)}</code></p><p>Etkiler: ${esc(Object.keys(shock.effects || {}).map(humanize).join(" · "))}</p></article>`).join("");
  panel.innerHTML = `<h3>Sanal aktörler</h3><div class="expert-card-grid">${actorCards || "<p>Aktör yok.</p>"}</div><h3>Beklenmeyen olaylar</h3><div class="expert-card-grid">${shockCards || "<p>Şok yok.</p>"}</div>`;
}

function renderExpertObjectives(panel) {
  panel.innerHTML = `<div class="expert-list">${state.scenario.objectives.map((objective, index) => `<div class="expert-row" data-objective="${index}"><label class="field"><span>Amaç</span><input value="${esc(humanize(objective.id || objective.metric))}" disabled></label><label class="field"><span>Ölçü</span><input value="${esc(humanize(objective.metric))}" disabled></label><label class="field"><span>Ağırlık</span><input type="number" step="0.01" min="0" data-objective-field="weight" value="${esc(objective.weight)}"></label><label class="field"><span>Kötü sınır</span><input type="number" step="any" data-objective-field="worst" value="${esc(objective.worst)}"></label><label class="field"><span>İyi sınır</span><input type="number" step="any" data-objective-field="best" value="${esc(objective.best)}"></label></div>`).join("")}</div>`;
  $$('[data-objective-field]', panel).forEach((input) => input.addEventListener("change", () => {
    const index = Number(input.closest("[data-objective]").dataset.objective);
    state.scenario.objectives[index][input.dataset.objectiveField] = numeric(input.value, 0);
    markScenarioDirty();
  }));
}

function renderExpertJson(panel) {
  panel.innerHTML = `<div class="expert-json-actions"><button class="button small secondary" id="applyExpertJson" type="button">JSON değişikliklerini uygula</button><button class="button small ghost" id="downloadExpertJson" type="button">JSON indir</button><label class="button small ghost" for="importExpertJson">JSON yükle</label><input id="importExpertJson" type="file" accept="application/json,.json" hidden></div><textarea class="code-editor" id="expertJsonEditor" spellcheck="false">${esc(JSON.stringify(state.scenario, null, 2))}</textarea>`;
  $("#applyExpertJson").addEventListener("click", () => {
    try {
      state.scenario = normalizeScenario(JSON.parse($("#expertJsonEditor").value));
      state.modelExplanation = deriveExplanation(state.scenario);
      markScenarioDirty();
      renderModel();
      renderSimulationRecap();
      toast("JSON modele uygulandı; çalıştırmadan önce doğrula.");
    } catch (error) { toast(`JSON okunamadı: ${error.message}`, true); }
  });
  $("#downloadExpertJson").addEventListener("click", () => downloadBlob(JSON.stringify(state.scenario, null, 2), `${safeFilename(state.scenario.meta.name)}.json`, "application/json"));
  $("#importExpertJson").addEventListener("change", importExpertJson);
}

async function importExpertJson(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    state.scenario = normalizeScenario(JSON.parse(await file.text()));
    state.modelExplanation = deriveExplanation(state.scenario);
    markScenarioDirty();
    renderModel();
    renderSimulationRecap();
    toast("JSON dosyası yüklendi; modeli doğrula.");
  } catch (error) { toast(`Dosya okunamadı: ${error.message}`, true); }
}

function markScenarioDirty() {
  state.dirty = true;
  state.valid = null;
  renderHealth();
  updateContextBar();
}

function selectWorlds(worlds) {
  state.selectedWorlds = worlds;
  $$('[data-worlds]').forEach((button) => button.classList.toggle("active", Number(button.dataset.worlds) === worlds));
  renderSimulationRecap();
}

function renderSimulationRecap() {
  $("#runButtonSub").textContent = `${num(state.selectedWorlds)} dünya`;
  if (!state.scenario) {
    $("#runRecapTitle").textContent = "Önce şirket modelini oluştur";
    $("#runEstimate").textContent = "Kurulum tamamlandığında burada koşu özeti görünecek.";
    $("#strategyRecap").innerHTML = "";
    $("#runButton").disabled = true;
    return;
  }
  const operations = state.selectedWorlds * state.scenario.strategies.length * state.scenario.horizon;
  $("#runRecapTitle").textContent = `${state.scenario.meta.name} · ${num(state.selectedWorlds)} olası dünya`;
  $("#runEstimate").textContent = `${state.scenario.strategies.length} strateji × ${num(state.selectedWorlds)} dünya × ${state.scenario.horizon} ${state.scenario.step || "dönem"} = yaklaşık ${num(operations)} dönem hesabı. Süre telefonun hızına göre değişir.`;
  $("#strategyRecap").innerHTML = state.scenario.strategies.map((strategy, index) => `<div><span>SEÇENEK ${index + 1}</span><b>${esc(strategy.label || strategy.id)}</b></div>`).join("");
  $("#runButton").disabled = false;
}

async function runSimulation() {
  if (!state.scenario) return toast("Önce şirket modelini oluştur.", true);
  if (!(await validateModel({ silent: true }))) {
    showScreen("model", { quiet: true });
    toast("Model doğrulanamadı. Kontrol ekranındaki hataları düzelt.", true);
    return;
  }
  const seed = Math.trunc(numeric($("#runSeed").value, 20260817));
  $("#runReady").hidden = true;
  $("#runProgress").hidden = false;
  $("#runButton").disabled = true;
  updateProgress({ progress: 0, completed: 0, total: state.selectedWorlds * state.scenario.strategies.length, message: "Model hazırlanıyor" });
  try {
    const job = await api("/api/run", { method: "POST", body: { scenario: state.scenario, worlds: state.selectedWorlds, seed } });
    state.jobId = job.job_id;
    await pollJob();
  } catch (error) {
    finishRunUi();
    toast(`Simülasyon başlatılamadı: ${error.message}`, true);
  }
}

async function pollJob() {
  try {
    const job = await api(`/api/jobs/${encodeURIComponent(state.jobId)}`);
    updateProgress(job);
    if (job.status === "completed") {
      state.result = job.result;
      state.narrative = job.narrative || {};
      state.activeFuture = 0;
      finishRunUi();
      $("#viewLastResultButton").disabled = false;
      renderResults();
      toast("Simülasyon tamamlandı. Sonuçlar sade anlatıma çevrildi.");
      showScreen("results", { quiet: true });
      return;
    }
    if (job.status === "failed") throw new Error(job.error || "Simülasyon başarısız oldu");
    window.setTimeout(pollJob, 450);
  } catch (error) {
    finishRunUi();
    toast(`Koşu durdu: ${error.message}`, true);
  }
}

function updateProgress(job) {
  const progress = clamp(numeric(job.progress, 0), 0, 1);
  let phase = "DÜNYALAR ÜRETİLİYOR";
  let message = "Talep, maliyet ve dış koşullar örnekleniyor";
  if (progress >= .15) { phase = "STRATEJİLER ÇALIŞIYOR"; message = "Her seçenek aynı olası dünyalarda deneniyor"; }
  if (progress >= .62) { phase = "SANAL AKTÖRLER VE ŞOKLAR"; message = "Müşteri, çalışan, tedarik ve beklenmeyen olaylar işliyor"; }
  if (progress >= .90) { phase = "SONUÇLAR TOPLANIYOR"; message = "Risk kuyrukları, gelecek aileleri ve sıralama hesaplanıyor"; }
  $("#progressPhase").textContent = phase;
  $("#progressMessage").textContent = message;
  $("#progressBar").style.width = `${progress * 100}%`;
  $("#progressPercent").textContent = `${Math.round(progress * 100)}%`;
  $("#progressDetail").textContent = job.message || `${num(job.completed || 0)} / ${num(job.total || 0)} strateji-dünya`;
}

function finishRunUi() {
  $("#runReady").hidden = false;
  $("#runProgress").hidden = true;
  $("#runButton").disabled = false;
}

function renderResults() {
  const hasResult = Boolean(state.result?.summary?.ranking?.length);
  $("#emptyResults").hidden = hasResult;
  $("#resultsWorkspace").hidden = !hasResult;
  if (!hasResult) return;
  const metadata = state.result.metadata || {};
  $("#resultMeta").textContent = `${metadata.scenario_name || state.scenario?.meta?.name || "Model"} · ${num(metadata.worlds)} dünya · ${metadata.horizon} ${metadata.step || "dönem"} · ${num(metadata.runtime_seconds)} sn · tohum ${metadata.seed}`;
  renderVerdict();
  renderRanking();
  renderIntervals();
  renderPairwise();
  renderStress();
  renderFutures();
  renderSensitivity();
  showResultView("decision");
}

function renderVerdict() {
  const winner = state.result.summary.ranking[0];
  const contender = state.result.summary.ranking[1];
  const gap = contender ? winner.decision_score - contender.decision_score : 0;
  const closeness = gap < .025 ? "Sonuç çok yakın; tek kazanan varmış gibi davranma." : gap < .07 ? "Önde, fakat yeni veri sıralamayı değiştirebilir." : "Bu modelde belirgin biçimde önde.";
  $("#verdictCard").innerHTML = `<span class="eyebrow">ÖNE ÇIKAN KARAR YOLU</span><h2>${esc(winner.label)}</h2><p>${esc(state.narrative?.why || `${winner.label}, ortalama sonuç ve kötü dünya dayanıklılığı birlikte değerlendirildiğinde ilk sırada.`)} ${esc(closeness)}</p>${state.narrative?.comparison ? `<p>${esc(state.narrative.comparison)}</p>` : ""}<div class="verdict-metrics"><div><b>${pct(winner.decision_score)}</b><span>birleşik karar skoru</span></div><div><b>${pct(winner.success_probability)}</b><span>başarı şartlarını karşılama</span></div><div><b>${pct(winner.ruin_probability)}</b><span>kritik sınır / çöküş riski</span></div></div><span class="confidence-note">${esc(state.narrative?.confidence_note || "Model girdileri ve varsayımları doğrulanmadan yüksek etkili karar verilmemelidir.")}</span>`;
}

function renderRanking() {
  $("#rankingGrid").innerHTML = state.result.summary.ranking.map((row, index) => `<article class="rank-card ${index === 0 ? "winner" : ""}"><header><span class="rank-number">#${index + 1} KARAR SKORU</span><span class="eligibility ${row.eligible ? "" : "fail"}">${row.eligible ? "Kritik sınırları geçti" : "Sınır ihlali var"}</span></header><h3>${esc(row.label)}</h3><div class="decision-score">${pct(row.decision_score)}</div><p class="rank-explanation">${row.pareto ? "En az bir önemli ölçüde güçlü; Pareto sınırında." : "Başka bir seçenek temel ölçülerde daha iyi sonuç üretiyor."}</p><div class="rank-metrics"><div><span>Beklenen genel fayda</span><b>${pct(row.expected_utility)}</b></div><div><span>En kötü %10 ortalaması</span><b>${pct(row.utility_cvar)}</b></div><div><span>Sağlam dünya oranı</span><b>${pct(row.robustness)}</b></div><div><span>Başarı ihtimali</span><b>${pct(row.success_probability)}</b></div><div><span>Çöküş riski</span><b>${pct(row.ruin_probability)}</b></div></div></article>`).join("");
  const actions = state.narrative?.recommended_actions || ["En hassas girdiyi gerçek veriyle güncelle.", "Öne çıkan stratejiyi en zayıf stres koşulunda yedek planla birlikte değerlendir.", "Gerçek aylık sonuçları kaydedip modeli yeniden çalıştır."];
  $("#recommendedActions").innerHTML = actions.map((action) => `<li>${esc(translateTechnicalSentence(action))}</li>`).join("");
}

function renderIntervals() {
  const rows = state.result.summary.ranking;
  $("#intervalChart").innerHTML = rows.map((row) => {
    const left = clamp(numeric(row.utility_p05, 0), 0, 1) * 100;
    const right = clamp(numeric(row.utility_p95, 0), 0, 1) * 100;
    const mid = clamp(numeric(row.utility_p50, 0), 0, 1) * 100;
    return `<div class="interval-row"><div class="interval-label"><b>${esc(row.label)}</b><small>genel fayda dağılımı</small></div><div class="interval-axis"><i class="interval-line" style="left:${left}%;width:${Math.max(1, right - left)}%"></i><i class="interval-mid" style="left:${mid}%"></i></div><div class="interval-values">Kötü P5 ${pct(row.utility_p05)} · Tipik ${pct(row.utility_p50)} · İyi P95 ${pct(row.utility_p95)}</div></div>`;
  }).join("");
}

function renderPairwise() {
  const labels = strategyLabels();
  $("#pairwisePanel").innerHTML = (state.result.pairwise || []).map((row) => {
    const left = labels[row.left] || humanize(row.left), right = labels[row.right] || humanize(row.right);
    const p = numeric(row.p_left_better, 0);
    const statement = p > .58 ? `${left}, aynı koşullar altında daha sık üstün geliyor.` : p < .42 ? `${right}, aynı koşullar altında daha sık üstün geliyor.` : "İki seçenek sık sık yer değiştiriyor; fark kararlı değil.";
    return `<article class="pair-card"><header><b>${esc(left)} ↔ ${esc(right)}</b><strong>${pct(p)} ${esc(left)} üstün</strong></header><p>${esc(statement)} Ortalama fayda farkı ${signedNumber(row.mean_utility_delta)}.</p></article>`;
  }).join("") || `<p class="section-copy">İkili karşılaştırma bulunamadı.</p>`;
}

function renderStress() {
  const labels = strategyLabels();
  $("#stressTable").innerHTML = (state.result.stress_profiles || []).map((profile) => {
    const best = (profile.strategies || []).find((row) => row.strategy_id === profile.best_strategy_id);
    const probability = numeric(best?.probability ?? profile.strategies?.[0]?.probability, 0);
    return `<tr><td>${esc(profile.label || humanize(profile.id))}</td><td>${pct(probability)}<br><small>${best ? `${num(best.worlds)} dünya` : "örneklenmedi"}</small></td><td>${esc(profile.best_strategy_id ? labels[profile.best_strategy_id] || humanize(profile.best_strategy_id) : "Bu koşuda dünya yok")}</td><td>${best ? pct(best.success_probability) : "—"}</td></tr>`;
  }).join("") || `<tr><td colspan="4">Stres profili tanımlı değil.</td></tr>`;
}

function renderFutures() {
  const families = state.result.future_families || [];
  if (!families.length) {
    $("#futureList").innerHTML = `<p class="section-copy">Gelecek ailesi oluşmadı.</p>`;
    $("#futureDetail").innerHTML = "";
    return;
  }
  state.activeFuture = clamp(state.activeFuture, 0, families.length - 1);
  $("#futureList").innerHTML = families.map((family, index) => `<button class="future-button ${index === state.activeFuture ? "active" : ""}" type="button" data-future="${index}"><span><b>Aile ${family.cluster_id}</b><strong>${pct(family.probability)}</strong></span><small>${esc(translateFamilyLabel(family.label))}</small></button>`).join("");
  $$('[data-future]').forEach((button) => button.addEventListener("click", () => { state.activeFuture = Number(button.dataset.future); renderFutures(); }));
  renderFutureDetail(families[state.activeFuture]);
}

function renderFutureDetail(family) {
  const labels = strategyLabels();
  const conditions = Object.entries(family.driver_z || {}).sort((a, b) => Math.abs(b[1]) - Math.abs(a[1])).slice(0, 6);
  $("#futureDetail").innerHTML = `<span class="eyebrow">GELECEK AİLESİ ${family.cluster_id}</span><div class="future-probability">${pct(family.probability)}</div><h3>${esc(translateFamilyLabel(family.label))}</h3><p class="section-copy">${num(family.worlds)} olası dünya bu koşullara benziyor. Z-skoru + ise normalden yüksek, − ise normalden düşüktür.</p><div class="driver-z-list">${conditions.map(([id, value]) => `<div>${esc(featureLabel(id))}<b>${signedNumber(value)}</b></div>`).join("")}</div><h3>Bu koşulda stratejiler</h3>${(family.strategies || []).map((row, index) => `<div class="family-strategy"><b>${index === 0 ? "★ " : ""}${esc(labels[row.strategy_id] || humanize(row.strategy_id))}</b><span>Genel fayda ${pct(row.mean_utility)}</span><span>Başarı ${pct(row.success_probability)}</span></div>`).join("")}`;
}

function renderSensitivity() {
  const strategyId = state.result.summary.recommended_strategy_id || state.result.summary.ranking[0].strategy_id;
  const rows = (state.result.sensitivity?.[strategyId] || []).filter((row) => row.kind === "main").slice(0, 10);
  $("#sensitivityPanel").innerHTML = `<span class="eyebrow">ÖNE ÇIKAN STRATEJİNİN SÜRÜCÜLERİ</span><h2>${esc(strategyLabels()[strategyId] || humanize(strategyId))}</h2><p class="section-copy">Çubuğun büyüklüğü birlikte değişimin gücünü, renk ise yönünü gösterir. Bir satıra dokunarak model ve kaynak izini aç.</p>${rows.map((row, index) => `<button class="sensitivity-row ${numeric(row.spearman, 0) < 0 ? "negative" : ""}" type="button" data-sensitive="${index}"><span>${esc(featureLabel(row.driver))}</span><i class="sensitivity-track"><i style="width:${clamp(numeric(row.absolute_effect, 0), 0, 1) * 100}%"></i></i><b>${signedNumber(row.spearman)}</b></button>`).join("")}`;
  $$('[data-sensitive]').forEach((button) => button.addEventListener("click", () => renderTrace(rows[Number(button.dataset.sensitive)])));
  if (rows[0]) renderTrace(rows[0]);
}

function renderTrace(row) {
  const trace = traceFeature(row.driver);
  const direction = numeric(row.spearman, 0) >= 0 ? "aynı yönde" : "ters yönde";
  const models = trace.models.length ? trace.models : [{ node_id: "utility", model_id: "Karar puanlama modeli", evidence_ids: [] }];
  const evidenceIds = new Set(models.flatMap((model) => model.evidence_ids || []));
  const evidence = (state.result.audit?.evidence_registry || []).filter((item) => evidenceIds.has(item.id));
  $("#tracePanel").innerHTML = `<span class="eyebrow">DENETİM İZİ</span><h2>${esc(featureLabel(row.driver))}</h2><p>Bu özellik ile öne çıkan stratejinin sonucu <b>${signedNumber(row.spearman)}</b> düzeyinde ${direction} değişti. Bu ilişki nedensellik kanıtı değildir.</p><div class="trace-chain"><div class="trace-step"><span>1 · SONUÇ</span><b>Genel karar faydası</b><code>Spearman ${signedNumber(row.spearman)}</code></div><div class="trace-step"><span>2 · GÖZLENEN ÖZELLİK</span><b>${esc(featureLabel(row.driver))}</b><code>${esc(row.driver)}</code></div>${models.slice(0, 3).map((model) => `<div class="trace-step"><span>3 · MODEL DÜĞÜMÜ</span><b>${esc(humanize(model.node_id))}</b><code>${esc(model.model_id || "Model tanımı")}</code></div>`).join("")}${evidence.length ? evidence.map((item) => `<div class="trace-step"><span>4 · VERİ / VARSAYIM</span><b>${esc(item.note || item.type || item.id)}</b><code>${esc(item.source || item.id)} · kalite ${esc(item.quality || "—")}</code></div>`).join("") : `<div class="trace-step"><span>4 · KAYNAK</span><b>${esc(trace.source)}</b><code>Bu kayıt modelin iç tanımından türetildi.</code></div>`}</div>`;
}

function traceFeature(feature) {
  const audit = state.result.audit?.model_registry || [];
  const scenario = state.scenario || {};
  const first = String(feature).split(" × ")[0];
  let base = first.replace(/^driver_/, "").replace(/_(mean|min|max|final)$/, "");
  let effectKeys = [];
  let source = "Olasılık sürücüsü";
  if (first.startsWith("event_")) {
    base = first.replace(/^event_/, "").replace(/_count$/, "");
    effectKeys = Object.keys((scenario.shocks || []).find((item) => item.id === base)?.effects || {});
    source = "Beklenmeyen olay modeli";
  } else if (first.startsWith("actor_")) {
    const remainder = first.replace(/^actor_/, "");
    const actor = (scenario.actors || []).find((item) => remainder.startsWith(`${item.id}_`));
    base = actor?.id || remainder.split("_")[0];
    effectKeys = (actor?.actions || []).flatMap((action) => Object.keys(action.effects || {}));
    source = "Sanal aktör davranış modeli";
  } else if (first.startsWith("policy_")) {
    base = first.replace(/^policy_/, "").replace(/_fires$/, "");
    source = "Stratejinin koşullu karar kuralı";
  }
  const candidates = new Set([base, ...effectKeys]);
  const models = audit.filter((model) => {
    const spec = scenario.equations?.[model.node_id] || scenario.states?.[model.node_id] || {};
    const expr = String(spec.expression || spec.transition || "");
    return candidates.has(model.node_id) || [...candidates].some((token) => token && new RegExp(`(?:^|[^A-Za-z0-9_])(?:prev_)?${escapeRegExp(token)}(?:$|[^A-Za-z0-9_])`).test(expr));
  });
  return { models, source };
}

function showResultView(name) {
  $$('[data-result-view]').forEach((button) => button.classList.toggle("active", button.dataset.resultView === name));
  $$('[data-result-panel]').forEach((panel) => {
    const active = panel.dataset.resultPanel === name;
    panel.hidden = !active;
    panel.classList.toggle("active", active);
  });
}

function showGuide(name) {
  $$('[data-guide]').forEach((button) => button.classList.toggle("active", button.dataset.guide === name));
  $$('[data-guide-panel]').forEach((panel) => {
    const active = panel.dataset.guidePanel === name;
    panel.hidden = !active;
    panel.classList.toggle("active", active);
  });
}

function openGuideTopic(topic) {
  const target = topic === "monte-carlo" ? "montecarlo" : topic === "risk-terms" ? "glossary" : "quickstart";
  showScreen("guide", { quiet: true });
  showGuide(target);
  if (topic === "nodes") toast("Neden-sonuç haritası, dış koşuldan ölçülen sonuca giden bağlantıları gösterir; kullanmak için ezberlemen gerekmez.");
}

function startTour() {
  state.tourIndex = 0;
  renderTour();
  openDialog("tourDialog");
}

function renderTour() {
  const step = TOUR_STEPS[state.tourIndex];
  const canOpen = step.screen === "setup" || step.screen === "guide" || step.screen === "results" || Boolean(state.scenario);
  showScreen(canOpen ? step.screen : "setup", { quiet: true });
  $("#tourStepLabel").textContent = `ADIM ${state.tourIndex + 1} / ${TOUR_STEPS.length}`;
  $("#tourTitle").textContent = step.title;
  $("#tourBody").textContent = step.body;
  $("#tourProgressBar").style.width = `${((state.tourIndex + 1) / TOUR_STEPS.length) * 100}%`;
  $("#tourNextButton").textContent = state.tourIndex === TOUR_STEPS.length - 1 ? "Turu bitir ✓" : "İleri →";
}

function nextTourStep() {
  if (state.tourIndex >= TOUR_STEPS.length - 1) return endTour();
  state.tourIndex += 1;
  renderTour();
}

function endTour() {
  closeDialog("tourDialog");
  storageSet("spx-welcome-v03", "1");
}

function dismissWelcome() {
  closeDialog("welcomeDialog");
  storageSet("spx-welcome-v03", "1");
}

function openProjects() {
  renderProjects();
  openDialog("projectsDialog");
}

function renderProjects() {
  const container = $("#projectList");
  if (!container) return;
  container.innerHTML = state.projects.length ? state.projects.map((project) => `<button class="project-item" type="button" data-project="${esc(project.id)}"><b>${esc(project.name)}</b><small>${esc(formatDate(project.modified_at))} · ${esc(project.scenario_id || "model")}</small></button>`).join("") : `<div class="empty-state" style="min-height:180px"><p>Henüz kayıtlı proje yok.</p></div>`;
  $$('[data-project]', container).forEach((button) => button.addEventListener("click", () => loadProject(button.dataset.project)));
}

async function loadProject(projectId) {
  try {
    const scenario = normalizeScenario(await api(`/api/projects/${encodeURIComponent(projectId)}`));
    state.scenario = scenario;
    state.modelExplanation = deriveExplanation(scenario);
    state.valid = null;
    state.dirty = false;
    state.wizardDirty = false;
    state.selectedNode = null;
    state.result = null;
    state.jobId = null;
    if (scenario.meta?.company_profile) hydrateWizardFromScenario(scenario);
    $("#runSeed").value = scenario.simulation.seed || 20260817;
    $("#saveProjectButton").disabled = false;
    closeDialog("projectsDialog");
    renderModel();
    renderSimulationRecap();
    renderResults();
    await validateModel({ silent: true });
    showScreen("model", { quiet: true });
    toast("Kayıtlı proje açıldı.");
  } catch (error) { toast(error.message, true); }
}

function hydrateWizardFromScenario(scenario) {
  state.profile = clone(scenario.meta.company_profile);
  state.strategies = scenario.strategies.map((item, index) => ({
    ...(state.catalog.default_strategies?.[index] || {}),
    id: item.id,
    label: item.label,
    description: item.description,
    ...(item.parameters || {}),
  }));
  populateWizard();
  renderWizard();
}

function openSaveDialog() {
  if (!state.scenario) return toast("Kaydetmek için önce bir model oluştur.");
  $("#projectName").value = (state.scenario.meta.name || "SPX projem").replace(/\s+—.*$/, "");
  openDialog("saveDialog");
  $("#projectName").focus();
}

async function saveProject() {
  const name = $("#projectName").value.trim();
  if (!name) return toast("Projeye bir ad ver.", true);
  try {
    await api("/api/projects", { method: "POST", body: { name, scenario: state.scenario } });
    state.projects = (await api("/api/projects")).projects || [];
    state.dirty = false;
    closeDialog("saveDialog");
    renderProjects();
    updateContextBar();
    toast("Proje telefona kaydedildi.");
  } catch (error) { toast(`Kaydedilemedi: ${error.message}`, true); }
}

function openDownload(filename, newTab = false) {
  if (!state.jobId) return toast("Önce bir simülasyon çalıştır.");
  const url = `/api/jobs/${encodeURIComponent(state.jobId)}/download/${encodeURIComponent(filename)}`;
  if (newTab) window.open(url, "_blank", "noopener");
  else {
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }
}

function strategyLabels() {
  return Object.fromEntries((state.scenario?.strategies || []).map((item) => [item.id, item.label || item.id]));
}

function featureLabel(raw) {
  const value = String(raw || "");
  if (value.includes(" × ")) return value.split(" × ").map(featureLabel).join(" + ");
  if (value.startsWith("driver_")) {
    const base = value.replace(/^driver_/, "").replace(/_(mean|min|max|final)$/, "");
    const suffix = value.match(/_(mean|min|max|final)$/)?.[1];
    const suffixLabel = { mean: "ortalaması", min: "en düşük değeri", max: "en yüksek değeri", final: "son değeri" }[suffix] || "";
    return `${humanize(base)} ${suffixLabel}`.trim();
  }
  if (value.startsWith("event_")) return `${humanize(value.replace(/^event_/, "").replace(/_count$/, ""))} sayısı`;
  if (value.startsWith("actor_")) {
    const clean = value.replace(/^actor_/, "").replace(/_mean$/, "");
    return humanize(clean);
  }
  if (value.startsWith("policy_")) return `Strateji kuralı: ${humanize(value.replace(/^policy_/, "").replace(/_fires$/, ""))}`;
  return humanize(value);
}

function translateFamilyLabel(label) {
  return String(label || "Benzer koşullar").replace(/demand index/gi, "talep").replace(/cost index/gi, "maliyet").replace(/price sensitivity/gi, "fiyat hassasiyeti").replace(/absence pressure/gi, "devamsızlık").replace(/supplier reliability/gi, "tedarik güvenilirliği").replace(/economy regime/gi, "ekonomik ortam");
}

function translateTechnicalSentence(text) {
  let result = String(text || "");
  const tokens = result.match(/'([^']+)'/g) || [];
  tokens.forEach((token) => { result = result.replace(token, `'${featureLabel(token.slice(1, -1))}'`); });
  return result;
}

function humanize(value) {
  const id = String(value ?? "");
  if (LABELS[id]) return LABELS[id];
  return id.replace(/_/g, " ").replace(/\b\w/g, (letter) => letter.toLocaleUpperCase("tr"));
}

function kindLabel(kind) {
  return { driver: "Belirsiz dış koşul", equation: "Her ay hesaplanan", state: "Aydan aya biriken", metric: "Sonuç ölçüsü" }[kind] || kind;
}

function setServerState(kind, label) {
  const node = $("#serverState");
  node.className = `server-state ${kind}`;
  $("span", node).textContent = label;
}

async function api(path, options = {}) {
  const config = { ...options, headers: { ...(options.headers || {}) } };
  if (options.body && typeof options.body !== "string") {
    config.body = JSON.stringify(options.body);
    config.headers["Content-Type"] = "application/json";
  }
  const response = await fetch(path, config);
  let payload = null;
  try { payload = await response.json(); } catch { /* boş yanıt */ }
  if (!response.ok) throw new Error(payload?.error || `Sunucu hatası: ${response.status}`);
  return payload;
}

function openDialog(id) {
  const dialog = $(`#${id}`);
  if (!dialog || dialog.open) return;
  if (typeof dialog.showModal === "function") dialog.showModal();
  else dialog.setAttribute("open", "");
}

function closeDialog(id) {
  const dialog = $(`#${id}`);
  if (!dialog || !dialog.open) return;
  if (typeof dialog.close === "function") dialog.close();
  else dialog.removeAttribute("open");
}

function toast(message, error = false) {
  const node = document.createElement("div");
  node.className = `toast ${error ? "error" : ""}`;
  node.textContent = message;
  $("#toastRegion").appendChild(node);
  window.setTimeout(() => node.remove(), 4500);
}

function downloadBlob(content, filename, type) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function storageGet(key) {
  try { return window.localStorage.getItem(key); } catch { return null; }
}

function storageSet(key, value) {
  try { window.localStorage.setItem(key, value); } catch { /* özel mod */ }
}

function clone(value) {
  if (typeof structuredClone === "function") return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

function numeric(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function pct(value, digits = 1) {
  const number = Number(value);
  return Number.isFinite(number) ? `%${(number * 100).toFixed(digits)}` : "—";
}

function money(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "—";
  return `${new Intl.NumberFormat("tr-TR", { maximumFractionDigits: 0 }).format(number)} ₺`;
}

function num(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "—";
  const magnitude = Math.abs(number);
  if (magnitude >= 1e9) return `${(number / 1e9).toFixed(2)} Mr`;
  if (magnitude >= 1e6) return `${(number / 1e6).toFixed(2)} Mn`;
  if (magnitude >= 1e3) return `${(number / 1e3).toFixed(1)} Bin`;
  return new Intl.NumberFormat("tr-TR", { maximumFractionDigits: 2 }).format(number);
}

function signedPercent(value) {
  const number = numeric(value, 0);
  return `${number > 0 ? "+" : ""}%${Math.round(number)}`;
}

function signedNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? `${number >= 0 ? "+" : ""}${number.toFixed(2)}` : "—";
}

function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
function truncate(value, max) { return value.length > max ? `${value.slice(0, max - 1)}…` : value; }
function selected(value, expected) { return value === expected ? "selected" : ""; }
function escapeRegExp(value) { return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
function safeFilename(value) { return String(value || "spx-model").toLocaleLowerCase("tr").replace(/[^a-z0-9ğüşöçıİĞÜŞÖÇ]+/gi, "-").replace(/^-|-$/g, "") || "spx-model"; }
function formatDate(value) { try { return new Intl.DateTimeFormat("tr-TR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value)); } catch { return value || "—"; } }
function esc(value) { return String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char])); }
