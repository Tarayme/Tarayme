from __future__ import annotations

import re
import random
from dataclasses import asdict, dataclass
from typing import Any, Mapping

from .distributions import cholesky, sample_distribution
from .graph import EquationGraph, GraphError
from .safeexpr import ExpressionError, compile_expression
from .schema import Scenario


IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


@dataclass(frozen=True)
class ValidationIssue:
    level: str
    code: str
    path: str
    message: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


class ScenarioValidationError(ValueError):
    def __init__(self, issues: list[ValidationIssue]):
        self.issues = issues
        super().__init__("Senaryo doğrulaması başarısız: " + "; ".join(issue.message for issue in issues if issue.level == "error"))


def validate_scenario(scenario: Scenario) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []

    def add(level: str, code: str, path: str, message: str) -> None:
        issues.append(ValidationIssue(level, code, path, message))

    if not scenario.meta.get("id"):
        add("error", "meta.id", "meta.id", "Senaryo kimliği eksik")
    if scenario.horizon < 1:
        add("error", "horizon", "horizon", "Zaman ufku en az 1 olmalı")
    if len(scenario.strategies) < 2:
        add("error", "strategies.count", "strategies", "Karar karşılaştırması için en az iki strateji gerekli")
    if not scenario.states:
        add("error", "states.empty", "states", "En az bir dinamik state gerekli")
    if not scenario.metrics:
        add("error", "metrics.empty", "metrics", "En az bir sonuç metriği gerekli")
    if not scenario.objectives:
        add("error", "objectives.empty", "objectives", "En az bir karar amacı gerekli")

    identifier_groups = {
        "drivers": scenario.drivers,
        "states": scenario.states,
        "equations": scenario.equations,
        "metrics": scenario.metrics,
    }
    for group_name, values in identifier_groups.items():
        for key in values:
            if not IDENTIFIER.match(str(key)):
                add("error", "identifier", f"{group_name}.{key}", f"İfade içinde kullanılacak kimlik geçersiz: {key}")
    graph_driver_overlap = set(scenario.drivers) & (set(scenario.states) | set(scenario.equations))
    if graph_driver_overlap:
        add("error", "identifier.collision", "drivers/states/equations", "Driver ve grafik düğümü adları çakışıyor: " + ", ".join(sorted(graph_driver_overlap)))

    for driver_id, spec in scenario.drivers.items():
        process = str(spec.get("process", "iid"))
        if process not in {"constant", "iid", "ar1", "random_walk", "markov"}:
            add("error", "driver.process", f"drivers.{driver_id}.process", f"Bilinmeyen süreç: {process}")
        try:
            if process == "markov":
                states = spec["states"]
                transition = spec["transition"]
                if len(states) == 0 or len(transition) != len(states) or any(len(row) != len(states) for row in transition):
                    raise ValueError("Markov state ve transition boyutları uyuşmuyor")
                if any(sum(float(value) for value in row) <= 0 for row in transition):
                    raise ValueError("Markov transition satırlarının toplamı pozitif olmalı")
            elif process != "constant":
                sample_distribution(spec.get("initial", spec.get("distribution", 0.0)), random.Random(0))
        except (KeyError, TypeError, ValueError) as exc:
            add("error", "driver.invalid", f"drivers.{driver_id}", str(exc))

    strategy_ids: set[str] = set()
    parameter_sets: list[set[str]] = []
    for index, strategy in enumerate(scenario.strategies):
        strategy_id = str(strategy.get("id", ""))
        if not strategy_id:
            add("error", "strategy.id", f"strategies[{index}].id", "Strateji kimliği eksik")
        elif strategy_id in strategy_ids:
            add("error", "strategy.duplicate", f"strategies[{index}].id", f"Tekrarlanan strateji: {strategy_id}")
        strategy_ids.add(strategy_id)
        parameters = {str(key) for key in strategy.get("parameters", {})}
        parameter_sets.append(parameters)
        for key, value in strategy.get("parameters", {}).items():
            if not IDENTIFIER.match(str(key)):
                add("error", "parameter.identifier", f"strategies[{index}].parameters.{key}", f"Geçersiz parametre kimliği: {key}")
            if not isinstance(value, (int, float)):
                add("error", "parameter.numeric", f"strategies[{index}].parameters.{key}", "Strateji parametresi sayısal olmalı")
        for rule_index, rule in enumerate(strategy.get("rules", [])):
            _check_expression(rule.get("when", "true"), f"strategies[{index}].rules[{rule_index}].when", add)
            for key, expression in rule.get("set", {}).items():
                if key not in parameters:
                    add("error", "rule.unknown_parameter", f"strategies[{index}].rules[{rule_index}].set.{key}", f"Kural tanımsız parametreyi değiştiriyor: {key}")
                _check_expression(expression, f"strategies[{index}].rules[{rule_index}].set.{key}", add)

    common_params = set.intersection(*parameter_sets) if parameter_sets else set()
    union_params = set.union(*parameter_sets) if parameter_sets else set()
    if common_params != union_params:
        for parameter in sorted(union_params - common_params):
            missing = [str(strategy.get("id")) for strategy, params in zip(scenario.strategies, parameter_sets) if parameter not in params]
            add("error", "parameter.inconsistent", "strategies", f"Parametre bütün stratejilerde tanımlı değil: {parameter}; eksik: {', '.join(missing)}")

    graph: EquationGraph | None = None
    try:
        graph = EquationGraph(scenario.equations, scenario.states)
    except (GraphError, ExpressionError, KeyError, TypeError, ValueError) as exc:
        add("error", "graph.invalid", "states/equations", str(exc))

    actor_effects: set[str] = set()
    actor_share_names: set[str] = set()
    actor_ids: set[str] = set()
    for actor_index, actor in enumerate(scenario.actors):
        actor_id = str(actor.get("id", ""))
        if not actor_id or actor_id in actor_ids:
            add("error", "actor.id", f"actors[{actor_index}].id", "Aktör kimliği eksik veya tekrarlanmış")
        actor_ids.add(actor_id)
        actions = actor.get("actions", [])
        if not actions:
            add("error", "actor.actions", f"actors[{actor_index}].actions", "Aktör en az bir eylem taşımalı")
        _check_expression(actor.get("enabled_when", "true"), f"actors[{actor_index}].enabled_when", add)
        for action_index, action in enumerate(actions):
            action_id = str(action.get("id", ""))
            actor_share_names.add(f"actor_{actor_id}_{action_id}_share")
            _check_expression(action.get("utility", 0.0), f"actors[{actor_index}].actions[{action_index}].utility", add)
            for effect, expression in action.get("effects", {}).items():
                actor_effects.add(str(effect))
                _check_expression(expression, f"actors[{actor_index}].actions[{action_index}].effects.{effect}", add)

    shock_effects: set[str] = set()
    shock_names: set[str] = set()
    for shock_index, shock in enumerate(scenario.shocks):
        shock_id = str(shock.get("id", ""))
        shock_names.add(f"shock_{shock_id}")
        _check_expression(shock.get("hazard", 0.0), f"shocks[{shock_index}].hazard", add)
        for effect, expression in shock.get("effects", {}).items():
            shock_effects.add(str(effect))
            _check_expression(expression, f"shocks[{shock_index}].effects.{effect}", add)

    builtins = {"t", "period", "horizon"}
    known_period_names = (
        builtins
        | set(scenario.drivers)
        | set(scenario.states)
        | {f"prev_{name}" for name in scenario.states}
        | common_params
        | actor_effects
        | actor_share_names
        | shock_effects
        | shock_names
    )
    protected_names = builtins | set(scenario.drivers) | set(scenario.states) | set(scenario.equations) | common_params
    effect_collisions = (actor_effects | shock_effects) & protected_names
    if effect_collisions:
        add("error", "effect.collision", "actors/shocks", "Etki değişkeni korunan bir model adıyla çakışıyor: " + ", ".join(sorted(effect_collisions)))

    rule_names = builtins | set(scenario.drivers) | set(scenario.states) | {f"prev_{name}" for name in scenario.states} | common_params
    for strategy_index, strategy in enumerate(scenario.strategies):
        for state_id, expression in strategy.get("initial_state", {}).items():
            compiled = _check_expression(expression, f"strategies[{strategy_index}].initial_state.{state_id}", add)
            if compiled:
                for name in sorted(compiled.names - rule_names):
                    add("error", "strategy.initial_unknown", f"strategies[{strategy_index}].initial_state.{state_id}", f"Başlangıç müdahalesinde tanımsız ad: {name}")
        for rule_index, rule in enumerate(strategy.get("rules", [])):
            expressions = [("when", rule.get("when", "true"))] + [(f"set.{key}", value) for key, value in rule.get("set", {}).items()]
            for suffix, expression in expressions:
                compiled = _check_expression(expression, f"strategies[{strategy_index}].rules[{rule_index}].{suffix}", add)
                if compiled:
                    for name in sorted(compiled.names - rule_names):
                        add("error", "strategy.rule_unknown", f"strategies[{strategy_index}].rules[{rule_index}].{suffix}", f"Strateji kuralında tanımsız ad: {name}")

    for actor_index, actor in enumerate(scenario.actors):
        actor_expressions = [("enabled_when", actor.get("enabled_when", "true"))]
        for action_index, action in enumerate(actor.get("actions", [])):
            actor_expressions.append((f"actions[{action_index}].utility", action.get("utility", 0.0)))
            actor_expressions.extend((f"actions[{action_index}].effects.{key}", value) for key, value in action.get("effects", {}).items())
        for suffix, expression in actor_expressions:
            compiled = _check_expression(expression, f"actors[{actor_index}].{suffix}", add)
            if compiled:
                for name in sorted(compiled.names - known_period_names):
                    add("error", "actor.unknown_name", f"actors[{actor_index}].{suffix}", f"Aktör ifadesinde tanımsız ad: {name}")

    for shock_index, shock in enumerate(scenario.shocks):
        shock_expressions = [("hazard", shock.get("hazard", 0.0))]
        shock_expressions.extend((f"effects.{key}", value) for key, value in shock.get("effects", {}).items())
        for suffix, expression in shock_expressions:
            compiled = _check_expression(expression, f"shocks[{shock_index}].{suffix}", add)
            if compiled:
                for name in sorted(compiled.names - known_period_names):
                    add("error", "shock.unknown_name", f"shocks[{shock_index}].{suffix}", f"Şok ifadesinde tanımsız ad: {name}")
        try:
            sample_distribution(shock.get("duration", 1), random.Random(0))
        except (TypeError, ValueError) as exc:
            add("error", "shock.duration", f"shocks[{shock_index}].duration", str(exc))
    if graph is not None:
        unknown = graph.external_names() - known_period_names
        for name in sorted(unknown):
            add("error", "graph.unknown_name", "states/equations", f"Grafik ifadesinde tanımsız ad: {name}")

    metric_names = set(scenario.metrics)
    for metric_id, spec in scenario.metrics.items():
        expression = spec.get("expression", metric_id) if isinstance(spec, Mapping) else spec
        compiled = _check_expression(expression, f"metrics.{metric_id}.expression", add)
        if compiled:
            unknown = compiled.names - known_period_names - set(scenario.equations)
            for name in sorted(unknown):
                add("error", "metric.unknown_name", f"metrics.{metric_id}", f"Metrik ifadesinde tanımsız ad: {name}")
        aggregation = spec.get("aggregation", "final") if isinstance(spec, Mapping) else "final"
        if aggregation not in {"final", "sum", "mean", "min", "max", "discounted_sum"}:
            add("error", "metric.aggregation", f"metrics.{metric_id}.aggregation", f"Bilinmeyen aggregation: {aggregation}")

    evidence_ids = {str(item.get("id")) for item in scenario.evidence}
    if not evidence_ids:
        add("warning", "evidence.empty", "evidence", "Evidence Registry boş; bütün girdiler varsayım olarak bile kayıtlı değil")
    fingerprints: dict[str, list[str]] = {}
    for index, evidence in enumerate(scenario.evidence):
        evidence_id = str(evidence.get("id", ""))
        if not evidence_id:
            add("error", "evidence.id", f"evidence[{index}].id", "Kanıt kimliği eksik")
        if not evidence.get("quality"):
            add("warning", "evidence.quality", f"evidence[{index}].quality", f"Kanıt kalite sınıfı eksik: {evidence_id}")
        fingerprint = str(evidence.get("fingerprint", evidence.get("source", evidence_id)))
        fingerprints.setdefault(fingerprint, []).append(evidence_id)
    for fingerprint, ids in fingerprints.items():
        if len(ids) > 1:
            add("warning", "evidence.overlap", "evidence", f"Aynı semantik kaynak izi birden fazla kanıtta var: {fingerprint}: {', '.join(ids)}")
    if graph is not None:
        for node in graph.nodes.values():
            missing = set(node.evidence_ids) - evidence_ids
            if missing:
                add("error", "model.evidence_missing", f"nodes.{node.node_id}.evidence_ids", f"Model tanımsız evidence referansı taşıyor: {', '.join(sorted(missing))}")
            if not node.evidence_ids:
                add("warning", "model.no_evidence", f"nodes.{node.node_id}.evidence_ids", f"Düğüm evidence referansı taşımıyor: {node.node_id}")

    for index, objective in enumerate(scenario.objectives):
        metric = str(objective.get("metric", ""))
        if metric not in metric_names:
            add("error", "objective.metric", f"objectives[{index}].metric", f"Amaç tanımsız metriğe bağlı: {metric}")
        if "worst" not in objective or "best" not in objective:
            add("error", "objective.scale", f"objectives[{index}]", "Amaç worst ve best ölçeği taşımalı")
        elif objective.get("direction", "max") == "max" and float(objective["best"]) <= float(objective["worst"]):
            add("error", "objective.order", f"objectives[{index}]", "Max amacı için best > worst olmalı")
        elif objective.get("direction") == "min" and float(objective["best"]) >= float(objective["worst"]):
            add("error", "objective.order", f"objectives[{index}]", "Min amacı için best < worst olmalı")

    for index, constraint in enumerate(scenario.constraints):
        if "expression" in constraint:
            compiled = _check_expression(constraint["expression"], f"constraints[{index}].expression", add)
            if compiled:
                unknown = compiled.names - metric_names
                for name in sorted(unknown):
                    add("error", "constraint.unknown_name", f"constraints[{index}]", f"Kısıt ifadesinde tanımsız metrik: {name}")
        elif str(constraint.get("metric", "")) not in metric_names:
            add("error", "constraint.metric", f"constraints[{index}].metric", "Kısıt tanımsız metriğe bağlı")

    success = _check_expression(scenario.success_expression, "success", add)
    if success:
        constraint_ok_names = {
            f"constraint_{str(item.get('id', item.get('name', f'constraint-{index+1}')))}_ok"
            for index, item in enumerate(scenario.constraints)
        }
        for name in sorted(success.names - metric_names - constraint_ok_names):
            add("error", "success.unknown_name", "success", f"Başarı ifadesinde tanımsız metrik: {name}")

    for index, group in enumerate(scenario.correlations):
        try:
            cholesky(group["matrix"])
        except (KeyError, TypeError, ValueError) as exc:
            add("error", "correlation.invalid", f"correlations[{index}]", str(exc))
        if len(group.get("drivers", [])) != len(group.get("matrix", [])):
            add("error", "correlation.dimension", f"correlations[{index}]", "Driver listesi ile matris boyutu uyuşmuyor")

    worlds = int(scenario.simulation.get("worlds", 0))
    if worlds < 1000:
        add("warning", "simulation.low_worlds", "simulation.worlds", "Karar yüzdeleri için 1.000'den az dünya kararsız olabilir")
    if scenario.meta.get("data_status") not in {"ILLUSTRATIVE", "OBSERVED", "MIXED", "SYNTHETIC"}:
        add("warning", "meta.data_status", "meta.data_status", "Veri statüsü ILLUSTRATIVE/OBSERVED/MIXED/SYNTHETIC olarak açık etiketlenmeli")
    if not scenario.stress_tests:
        add("warning", "stress.empty", "stress_tests", "Tanımlı stress-world yok")
    return issues


def raise_for_errors(issues: list[ValidationIssue]) -> None:
    errors = [issue for issue in issues if issue.level == "error"]
    if errors:
        raise ScenarioValidationError(issues)


def _check_expression(value: Any, path: str, add) -> Any | None:
    try:
        return compile_expression(value)
    except (ExpressionError, TypeError, ValueError) as exc:
        add("error", "expression.invalid", path, str(exc))
        return None
