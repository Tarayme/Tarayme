from __future__ import annotations

import math
import random
from statistics import NormalDist
from typing import Any, Mapping, Sequence

from .util import clamp, weighted_choice


class DistributionError(ValueError):
    pass


def _bounded(value: float, spec: Mapping[str, Any]) -> float:
    low = float(spec.get("min", -math.inf))
    high = float(spec.get("max", math.inf))
    if low > high:
        raise DistributionError("Dağılım min değeri max değerinden büyük")
    return clamp(value, low, high)


def sample_distribution(spec: Any, rng: random.Random) -> float:
    if isinstance(spec, bool):
        return float(spec)
    if isinstance(spec, (int, float)):
        return float(spec)
    if not isinstance(spec, Mapping):
        raise DistributionError(f"Dağılım sayısal değer veya nesne olmalı: {spec!r}")
    kind = str(spec.get("dist", "constant")).lower()
    if kind == "constant":
        value = float(spec.get("value", 0.0))
    elif kind == "uniform":
        value = rng.uniform(float(spec["low"]), float(spec["high"]))
    elif kind == "triangular":
        value = rng.triangular(float(spec["low"]), float(spec["high"]), float(spec["mode"]))
    elif kind == "normal":
        value = rng.gauss(float(spec.get("mean", 0.0)), float(spec.get("sd", spec.get("sigma", 1.0))))
    elif kind == "lognormal":
        sigma = float(spec.get("sigma", 1.0))
        if "median" in spec:
            mu = math.log(max(float(spec["median"]), 1e-15))
        else:
            mu = float(spec.get("mu", 0.0))
        value = rng.lognormvariate(mu, sigma)
    elif kind == "beta":
        raw = rng.betavariate(float(spec["alpha"]), float(spec["beta"]))
        low, high = float(spec.get("low", 0.0)), float(spec.get("high", 1.0))
        value = low + raw * (high - low)
    elif kind == "pert":
        low, mode, high = float(spec["low"]), float(spec["mode"]), float(spec["high"])
        if not low <= mode <= high or low == high:
            raise DistributionError("PERT için low <= mode <= high ve low < high olmalı")
        shape = float(spec.get("shape", 4.0))
        alpha = 1.0 + shape * (mode - low) / (high - low)
        beta = 1.0 + shape * (high - mode) / (high - low)
        value = low + rng.betavariate(alpha, beta) * (high - low)
    elif kind == "bernoulli":
        value = 1.0 if rng.random() < clamp(float(spec["p"]), 0.0, 1.0) else 0.0
    elif kind == "discrete_uniform":
        value = float(rng.randint(int(spec["low"]), int(spec["high"])))
    elif kind in {"categorical", "empirical"}:
        values = list(spec["values"])
        weights = list(spec.get("weights", [1.0] * len(values)))
        chosen = weighted_choice(values, weights, rng.random())
        if not isinstance(chosen, (int, float, bool)):
            raise DistributionError("Çekirdekte kategorik değerler sayısal olmalı")
        value = float(chosen)
    else:
        raise DistributionError(f"Bilinmeyen dağılım: {kind}")
    return _bounded(value, spec)


def cholesky(matrix: Sequence[Sequence[float]], *, jitter: float = 1e-10) -> list[list[float]]:
    size = len(matrix)
    if size == 0 or any(len(row) != size for row in matrix):
        raise DistributionError("Korelasyon matrisi kare ve boş olmayan bir matris olmalı")
    for i in range(size):
        if abs(float(matrix[i][i]) - 1.0) > 1e-6:
            raise DistributionError("Korelasyon matrisinin köşegeni 1 olmalı")
        for j in range(size):
            if abs(float(matrix[i][j]) - float(matrix[j][i])) > 1e-8:
                raise DistributionError("Korelasyon matrisi simetrik olmalı")
            if not -1.0 <= float(matrix[i][j]) <= 1.0:
                raise DistributionError("Korelasyon katsayıları [-1, 1] aralığında olmalı")
    lower = [[0.0] * size for _ in range(size)]
    for i in range(size):
        for j in range(i + 1):
            subtotal = sum(lower[i][k] * lower[j][k] for k in range(j))
            if i == j:
                diagonal = float(matrix[i][i]) - subtotal
                if diagonal < -1e-8:
                    raise DistributionError("Korelasyon matrisi pozitif yarı tanımlı değil")
                lower[i][j] = math.sqrt(max(diagonal, jitter))
            else:
                if abs(lower[j][j]) < 1e-15:
                    lower[i][j] = 0.0
                else:
                    lower[i][j] = (float(matrix[i][j]) - subtotal) / lower[j][j]
    return lower


def correlated_normals(lower: Sequence[Sequence[float]], rng: random.Random) -> list[float]:
    independent = [rng.gauss(0.0, 1.0) for _ in range(len(lower))]
    return [sum(row[j] * independent[j] for j in range(i + 1)) for i, row in enumerate(lower)]


def gaussian_to_uniform(value: float) -> float:
    return clamp(NormalDist().cdf(value), 1e-12, 1.0 - 1e-12)

