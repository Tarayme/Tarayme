"""SPX — Simüle / Stratejik Projeksiyon karar ikizi motoru."""

from .engine import Engine, RunResult
from .schema import Scenario, load_scenario

__all__ = ["Engine", "RunResult", "Scenario", "load_scenario"]
__version__ = "0.3.0"
