from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any, Mapping

from .distributions import cholesky, correlated_normals, sample_distribution
from .util import clamp, stable_seed, weighted_choice


@dataclass(frozen=True)
class DriverPath:
    values: dict[str, list[float]]

    def period(self, t: int) -> dict[str, float]:
        return {name: path[t] for name, path in self.values.items()}

    def summaries(self) -> dict[str, float]:
        result: dict[str, float] = {}
        for name, path in self.values.items():
            result[f"driver_{name}_mean"] = sum(path) / len(path)
            result[f"driver_{name}_min"] = min(path)
            result[f"driver_{name}_max"] = max(path)
            result[f"driver_{name}_final"] = path[-1]
        return result


class DriverGenerator:
    def __init__(
        self,
        drivers: Mapping[str, Any],
        correlations: list[Mapping[str, Any]],
        horizon: int,
        seed: int,
    ):
        self.drivers = {str(key): dict(value) for key, value in drivers.items()}
        self.horizon = horizon
        self.seed = seed
        self.groups: list[tuple[list[str], list[list[float]]]] = []
        assigned: set[str] = set()
        for group in correlations:
            names = [str(name) for name in group["drivers"]]
            if assigned & set(names):
                raise ValueError("Bir driver birden fazla korelasyon grubunda olamaz")
            missing = set(names) - set(self.drivers)
            if missing:
                raise ValueError("Korelasyon grubunda tanımsız driver: " + ", ".join(sorted(missing)))
            self.groups.append((names, cholesky(group["matrix"])))
            assigned.update(names)

    def generate(self, world_id: int) -> DriverPath:
        innovations: dict[tuple[str, int], float] = {}
        for group_index, (names, lower) in enumerate(self.groups):
            for t in range(self.horizon):
                rng = random.Random(stable_seed(self.seed, world_id, "corr", group_index, t))
                values = correlated_normals(lower, rng)
                innovations.update({(name, t): value for name, value in zip(names, values)})
        paths: dict[str, list[float]] = {}
        for name, spec in self.drivers.items():
            process = str(spec.get("process", "iid")).lower()
            initial_rng = random.Random(stable_seed(self.seed, world_id, "driver", name, "initial"))
            if process == "constant":
                value = float(spec.get("value", spec.get("initial", 0.0)))
                paths[name] = [value] * self.horizon
                continue
            if process == "markov":
                paths[name] = self._markov_path(name, spec, world_id)
                continue
            previous = sample_distribution(spec.get("initial", spec.get("distribution", 0.0)), initial_rng)
            path: list[float] = []
            for t in range(self.horizon):
                rng = random.Random(stable_seed(self.seed, world_id, "driver", name, t))
                innovation = innovations.get((name, t), rng.gauss(0.0, 1.0))
                if process == "iid":
                    value = sample_distribution(spec.get("distribution", spec.get("initial", 0.0)), rng)
                elif process == "ar1":
                    target = float(spec.get("mean", previous))
                    seasonal = spec.get("seasonality", [])
                    if seasonal:
                        seasonal_value = float(seasonal[t % len(seasonal)])
                        if spec.get("seasonality_mode", "multiply") == "add":
                            target += seasonal_value
                        else:
                            target *= seasonal_value
                    value = target + float(spec.get("phi", 0.7)) * (previous - target) + float(spec.get("sigma", 0.1)) * innovation
                elif process == "random_walk":
                    value = previous + float(spec.get("drift", 0.0)) + float(spec.get("sigma", 0.1)) * innovation
                else:
                    raise ValueError(f"Bilinmeyen driver process: {name}: {process}")
                value = clamp(float(value), float(spec.get("min", -1e300)), float(spec.get("max", 1e300)))
                path.append(value)
                previous = value
            paths[name] = path
        return DriverPath(paths)

    def _markov_path(self, name: str, spec: Mapping[str, Any], world_id: int) -> list[float]:
        values = [float(value) for value in spec["states"]]
        transition = spec["transition"]
        initial = list(spec.get("initial_probabilities", [1.0 / len(values)] * len(values)))
        rng = random.Random(stable_seed(self.seed, world_id, "driver", name, "markov-initial"))
        state_index = weighted_choice(list(range(len(values))), initial, rng.random())
        path: list[float] = []
        for t in range(self.horizon):
            path.append(values[state_index])
            rng = random.Random(stable_seed(self.seed, world_id, "driver", name, "markov", t))
            state_index = weighted_choice(list(range(len(values))), transition[state_index], rng.random())
        return path

