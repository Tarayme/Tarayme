from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from .safeexpr import CompiledExpression, compile_expression
from .util import clamp


class GraphError(ValueError):
    pass


@dataclass(frozen=True)
class GraphNode:
    node_id: str
    expression: CompiledExpression
    kind: str
    unit: str
    evidence_ids: tuple[str, ...]
    model_id: str
    lower: float
    upper: float


class EquationGraph:
    """Aynı dönem içindeki nedensel/hesapsal düğümleri DAG olarak çalıştırır."""

    def __init__(self, equations: Mapping[str, Any], states: Mapping[str, Any]):
        self.nodes: dict[str, GraphNode] = {}
        for node_id, spec in equations.items():
            self.nodes[node_id] = self._node_from_spec(node_id, spec, "equation")
        for node_id, spec in states.items():
            if node_id in self.nodes:
                raise GraphError(f"Düğüm hem state hem equation olarak tanımlı: {node_id}")
            transition = spec.get("transition") if isinstance(spec, Mapping) else None
            if transition is None:
                raise GraphError(f"State transition eksik: {node_id}")
            self.nodes[node_id] = self._node_from_spec(node_id, spec, "state", transition)
        self.dependencies: dict[str, set[str]] = {
            node_id: {name for name in node.expression.names if name in self.nodes}
            for node_id, node in self.nodes.items()
        }
        self.order = self._topological_order()

    def _node_from_spec(
        self, node_id: str, spec: Any, kind: str, expression: Any | None = None
    ) -> GraphNode:
        if isinstance(spec, Mapping):
            source = expression if expression is not None else spec.get("expression")
            if source is None:
                raise GraphError(f"Düğüm expression eksik: {node_id}")
            unit = str(spec.get("unit", "1"))
            evidence_ids = tuple(str(v) for v in spec.get("evidence_ids", []))
            model_id = str(spec.get("model_id", f"{kind}:{node_id}"))
            lower = float(spec.get("min", -1e300))
            upper = float(spec.get("max", 1e300))
        else:
            source, unit, evidence_ids, model_id = spec, "1", (), f"{kind}:{node_id}"
            lower, upper = -1e300, 1e300
        if lower > upper:
            raise GraphError(f"Düğüm min değeri max değerinden büyük: {node_id}")
        return GraphNode(node_id, compile_expression(source), kind, unit, evidence_ids, model_id, lower, upper)

    def _topological_order(self) -> list[str]:
        remaining = {key: set(value) for key, value in self.dependencies.items()}
        order: list[str] = []
        ready = sorted(key for key, deps in remaining.items() if not deps)
        while ready:
            node_id = ready.pop(0)
            order.append(node_id)
            for other in sorted(remaining):
                if node_id in remaining[other]:
                    remaining[other].remove(node_id)
                    if not remaining[other] and other not in order and other not in ready:
                        ready.append(other)
                        ready.sort()
        if len(order) != len(remaining):
            cycle_nodes = sorted(set(remaining) - set(order))
            raise GraphError("Dönem içi nedensel grafikte döngü var: " + ", ".join(cycle_nodes))
        return order

    def evaluate(self, context: dict[str, Any]) -> dict[str, float]:
        produced: dict[str, float] = {}
        for node_id in self.order:
            value = self.nodes[node_id].expression.evaluate(context)
            if isinstance(value, bool):
                value = float(value)
            if not isinstance(value, (int, float)):
                raise GraphError(f"Düğüm sayısal değer üretmedi: {node_id} -> {value!r}")
            value = clamp(float(value), self.nodes[node_id].lower, self.nodes[node_id].upper)
            produced[node_id] = value
            context[node_id] = value
        return produced

    def external_names(self) -> set[str]:
        return {
            name
            for node in self.nodes.values()
            for name in node.expression.names
            if name not in self.nodes
        }

    def downstream(self, changed: Iterable[str]) -> set[str]:
        dirty = set(changed)
        expanded = True
        while expanded:
            expanded = False
            for node_id, deps in self.dependencies.items():
                if node_id not in dirty and deps & dirty:
                    dirty.add(node_id)
                    expanded = True
        return dirty & set(self.nodes)
