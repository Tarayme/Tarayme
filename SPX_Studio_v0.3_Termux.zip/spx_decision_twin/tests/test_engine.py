import tempfile
import unittest
from pathlib import Path

from spx.artifacts import write_run
from spx.engine import Engine
from spx.schema import Scenario, load_scenario
from spx.validation import raise_for_errors, validate_scenario


def mini_scenario() -> Scenario:
    return Scenario(
        {
            "meta": {"id": "mini", "name": "Mini", "version": "1", "data_status": "ILLUSTRATIVE"},
            "horizon": 5,
            "step": "period",
            "simulation": {"worlds": 80, "seed": 44, "clusters": 3, "trace_worlds": 1},
            "decision_policy": {"acceptance_utility": 0.4},
            "evidence": [{"id": "E", "source": "assumption", "quality": "C", "fingerprint": "E"}],
            "drivers": {
                "market": {
                    "process": "ar1",
                    "initial": {"dist": "normal", "mean": 1, "sd": 0.1},
                    "mean": 1,
                    "phi": 0.4,
                    "sigma": 0.2,
                    "min": 0.2,
                    "max": 1.8,
                }
            },
            "strategies": [
                {"id": "safe", "label": "Safe", "parameters": {"risk": 0.4}},
                {"id": "bold", "label": "Bold", "parameters": {"risk": 1.1}},
            ],
            "equations": {
                "gain": {
                    "expression": "100*risk*market - 25*risk*risk",
                    "unit": "money",
                    "evidence_ids": ["E"],
                }
            },
            "states": {
                "wealth": {
                    "initial": {"dist": "normal", "mean": 100, "sd": 5},
                    "transition": "prev_wealth+gain",
                    "unit": "money",
                    "evidence_ids": ["E"],
                }
            },
            "metrics": {
                "final_wealth": {"expression": "wealth", "aggregation": "final", "unit": "money"},
                "min_wealth": {"expression": "wealth", "aggregation": "min", "unit": "money"},
            },
            "objectives": [
                {"metric": "final_wealth", "direction": "max", "worst": 150, "best": 700, "weight": 1}
            ],
            "constraints": [
                {"id": "solvent", "metric": "min_wealth", "op": ">=", "value": 0, "max_violation_probability": 0.1, "hard": True}
            ],
            "success": "final_wealth >= 300",
            "stress_tests": [
                {"id": "weak", "label": "Weak", "condition": "driver_market_mean < 0.9"}
            ],
        }
    )


class EngineTests(unittest.TestCase):
    def test_run_is_repeatable_and_paired(self):
        scenario = mini_scenario()
        issues = validate_scenario(scenario)
        raise_for_errors(issues)
        first = Engine(scenario).run(worlds=80, seed=9)
        second = Engine(scenario).run(worlds=80, seed=9)
        compact_first = [(row["world_id"], row["strategy_id"], row["utility"], row["metrics"]) for row in first.outcomes]
        compact_second = [(row["world_id"], row["strategy_id"], row["utility"], row["metrics"]) for row in second.outcomes]
        self.assertEqual(compact_first, compact_second)
        self.assertEqual(len(first.pairwise), 1)
        self.assertEqual(first.summary["world_count"], 80)
        self.assertEqual(len(first.clusters), 3)

    def test_writes_all_artifacts(self):
        scenario = mini_scenario()
        result = Engine(scenario).run(worlds=20, seed=3)
        with tempfile.TemporaryDirectory() as directory:
            paths = write_run(directory, result, scenario)
            for path in paths.values():
                self.assertTrue(path.exists(), path)
            self.assertIn("SPX", paths["report"].read_text(encoding="utf-8"))

    def test_full_reference_scenario_smoke(self):
        root = Path(__file__).resolve().parents[1]
        scenario = load_scenario(root / "examples" / "channel_24m.json")
        issues = validate_scenario(scenario)
        raise_for_errors(issues)
        result = Engine(scenario).run(worlds=12, seed=1)
        self.assertEqual(len(result.outcomes), 36)
        self.assertEqual(len(result.summary["ranking"]), 3)
        self.assertTrue(result.sensitivity)


if __name__ == "__main__":
    unittest.main()

