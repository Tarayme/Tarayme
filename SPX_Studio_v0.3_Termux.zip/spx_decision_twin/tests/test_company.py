from __future__ import annotations

import unittest

from spx.company import (
    build_company_scenario,
    company_builder_catalog,
    normalize_company_profile,
)
from spx.engine import Engine
from spx.schema import Scenario
from spx.validation import validate_scenario


class CompanyBuilderTests(unittest.TestCase):
    def test_catalog_has_beginner_defaults_and_sectors(self) -> None:
        catalog = company_builder_catalog()
        self.assertEqual(catalog["version"], "0.3.0")
        self.assertGreaterEqual(len(catalog["sectors"]), 5)
        self.assertEqual(len(catalog["default_strategies"]), 3)
        self.assertIn("monthly_revenue", catalog["default_profile"])

    def test_profile_is_bounded_and_normalized(self) -> None:
        profile = normalize_company_profile(
            {
                "company_name": "  Test A.Ş.  ",
                "sector": "unknown",
                "horizon": 999,
                "employees": 0,
                "demand_uncertainty": 9,
            }
        )
        self.assertEqual(profile["company_name"], "Test A.Ş.")
        self.assertEqual(profile["sector"], "generic")
        self.assertEqual(profile["horizon"], 60)
        self.assertEqual(profile["employees"], 1)
        self.assertEqual(profile["demand_uncertainty"], 0.55)

    def test_builds_valid_food_company_and_runs(self) -> None:
        raw = build_company_scenario(
            {
                "company_name": "Mehmet Döner",
                "sector": "food",
                "monthly_revenue": 900_000,
                "monthly_cost": 680_000,
                "cash": 350_000,
                "employees": 12,
                "monthly_units": 14_000,
                "max_capacity": 17_500,
            }
        )
        scenario = Scenario(raw)
        issues = validate_scenario(scenario)
        self.assertFalse([issue for issue in issues if issue.level == "error"])
        self.assertEqual(len(scenario.strategies), 3)
        self.assertEqual(len(scenario.actors), 3)
        self.assertEqual(len(scenario.shocks), 5)

        result = Engine(scenario).run(worlds=5, seed=19)
        self.assertEqual(len(result.outcomes), 15)
        self.assertEqual(len(result.summary["ranking"]), 3)
        self.assertTrue(result.clusters)


if __name__ == "__main__":
    unittest.main()
