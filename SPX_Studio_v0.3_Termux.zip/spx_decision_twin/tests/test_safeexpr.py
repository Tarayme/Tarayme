import unittest

from spx.safeexpr import ExpressionError, compile_expression


class SafeExpressionTests(unittest.TestCase):
    def test_expression_and_dependencies(self):
        expression = compile_expression("clamp(a*2 + max(b, 1), 0, 10)")
        self.assertEqual(expression.names, frozenset({"a", "b"}))
        self.assertEqual(expression.evaluate({"a": 2, "b": 3}), 7)

    def test_boolean_expression(self):
        expression = compile_expression("x > 3 and y <= 2")
        self.assertTrue(expression.evaluate({"x": 4, "y": 2}))

    def test_attribute_access_is_blocked(self):
        with self.assertRaises(ExpressionError):
            compile_expression("x.__class__")

    def test_unknown_function_is_blocked(self):
        with self.assertRaises(ExpressionError):
            compile_expression("open('x')")


if __name__ == "__main__":
    unittest.main()

