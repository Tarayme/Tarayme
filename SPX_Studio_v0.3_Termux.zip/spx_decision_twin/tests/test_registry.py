import csv
import tempfile
import unittest
from pathlib import Path

from spx.registry import calibration_report, import_forecasts


class RegistryTests(unittest.TestCase):
    def test_calibration_memory(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            csv_path = root / "predictions.csv"
            with csv_path.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=["prediction_id", "model_id", "probability", "outcome", "horizon", "regime"])
                writer.writeheader()
                writer.writerows(
                    [
                        {"prediction_id": "p1", "model_id": "m", "probability": 0.8, "outcome": 1, "horizon": "1m", "regime": "base"},
                        {"prediction_id": "p2", "model_id": "m", "probability": 0.2, "outcome": 0, "horizon": "1m", "regime": "base"},
                    ]
                )
            db = root / "ledger.sqlite3"
            self.assertEqual(import_forecasts(db, csv_path), 2)
            report = calibration_report(db)
            self.assertEqual(report["records"], 2)
            self.assertAlmostEqual(report["groups"][0]["brier"], 0.04)


if __name__ == "__main__":
    unittest.main()

