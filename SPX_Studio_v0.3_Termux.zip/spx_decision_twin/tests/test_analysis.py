import unittest

from spx.analysis import cluster_futures, decision_boundaries


class AnalysisTests(unittest.TestCase):
    def test_decision_boundary_detects_real_switch(self):
        strategies = [{"id": "a"}, {"id": "b"}]
        outcomes = []
        for world_id in range(100):
            driver = world_id / 99
            outcomes.extend(
                [
                    {
                        "world_id": world_id,
                        "strategy_id": "a",
                        "utility": 0.8 - 0.6 * driver,
                        "features": {"driver_demand_mean": driver},
                    },
                    {
                        "world_id": world_id,
                        "strategy_id": "b",
                        "utility": 0.2 + 0.6 * driver,
                        "features": {"driver_demand_mean": driver},
                    },
                ]
            )
        boundaries = decision_boundaries(outcomes, strategies)
        self.assertTrue(boundaries)
        self.assertAlmostEqual(boundaries[0]["threshold"], 0.5, delta=0.08)
        self.assertEqual(boundaries[0]["below_best"], "a")
        self.assertEqual(boundaries[0]["above_best"], "b")

    def test_future_clusters_use_exogenous_drivers_only(self):
        strategies = [{"id": "a"}, {"id": "b"}]
        outcomes = []
        for world_id in range(30):
            for strategy in strategies:
                outcomes.append(
                    {
                        "world_id": world_id,
                        "strategy_id": strategy["id"],
                        "utility": 0.5,
                        "success": True,
                        "features": {
                            "driver_demand_mean": 0.7 if world_id < 15 else 1.3,
                            "actor_viewer_share_mean": world_id / 30,
                        },
                    }
                )
        clusters = cluster_futures(outcomes, strategies, 2)
        labels = " ".join(cluster["label"] for cluster in clusters)
        self.assertIn("demand", labels)
        self.assertNotIn("actor", labels)


if __name__ == "__main__":
    unittest.main()

