import unittest

from spx.graph import EquationGraph, GraphError


class GraphTests(unittest.TestCase):
    def test_topological_evaluation(self):
        graph = EquationGraph(
            {
                "b": {"expression": "a*2", "evidence_ids": ["E"]},
                "a": {"expression": "x+1", "evidence_ids": ["E"]},
            },
            {
                "state": {
                    "initial": 0,
                    "transition": "prev_state+b",
                    "evidence_ids": ["E"],
                }
            },
        )
        context = {"x": 2, "prev_state": 4}
        result = graph.evaluate(context)
        self.assertEqual(result["a"], 3)
        self.assertEqual(result["b"], 6)
        self.assertEqual(result["state"], 10)

    def test_cycle_is_rejected(self):
        with self.assertRaises(GraphError):
            EquationGraph({"a": "b+1", "b": "a+1"}, {})


if __name__ == "__main__":
    unittest.main()

