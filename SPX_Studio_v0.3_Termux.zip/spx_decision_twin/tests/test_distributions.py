import random
import unittest

from spx.distributions import DistributionError, cholesky, correlated_normals, sample_distribution
from spx.util import pearson


class DistributionTests(unittest.TestCase):
    def test_sampling_is_repeatable(self):
        spec = {"dist": "pert", "low": 1, "mode": 3, "high": 8}
        first = sample_distribution(spec, random.Random(42))
        second = sample_distribution(spec, random.Random(42))
        self.assertEqual(first, second)
        self.assertGreaterEqual(first, 1)
        self.assertLessEqual(first, 8)

    def test_correlated_normals(self):
        lower = cholesky([[1.0, 0.65], [0.65, 1.0]])
        rng = random.Random(7)
        samples = [correlated_normals(lower, rng) for _ in range(4000)]
        observed = pearson([row[0] for row in samples], [row[1] for row in samples])
        self.assertAlmostEqual(observed, 0.65, delta=0.04)

    def test_invalid_correlation_fails(self):
        with self.assertRaises(DistributionError):
            cholesky([[1.0, 1.2], [1.2, 1.0]])


if __name__ == "__main__":
    unittest.main()

