# SPX algoritması

## 1. Ana ayrım

SPX ajan yanıtlarını oylamaz. Akış şöyledir:

```text
evidence → dağılım/model parçaları → ortak dünya grafiği
         → eşlenmiş simülasyon → çok amaçlı karar motoru
         → gelecek aileleri / sürücüler / eşikler / lineage
```

Bir stratejinin puanı bir dil modelinin kanaati değil, açık model sözleşmesinin çalıştırılmış sonucudur.

## 2. Eşlenmiş dünyalar ve tekrar üretilebilirlik

Her rastgele kaynak için anahtar tabanlı tohum üretilir:

\[
s_{w,c,t}=\operatorname{BLAKE2b}(s_0, w, c, t)
\]

Burada `w` dünya, `c` driver/aktör/şok bileşeni, `t` dönemdir. Strateji kimliği dış dünya rassallığının tohumuna girmez. Böylece A ve B stratejileri aynı talep, platform, başlangıç state’i ve temel şok çekilişleri altında karşılaştırılır. Strateji farkının dış dünya gürültüsüyle karışması azaltılır.

## 3. Dış süreçler ve ortak dağılım

AR(1) driver için:

\[
x_t=\mu_t+\phi(x_{t-1}-\mu_t)+\sigma z_t
\]

Korelasyon grubundaki `z` vektörü, kullanıcı korelasyon matrisinin Cholesky ayrışımıyla üretilir:

\[
\mathbf{z}=L\boldsymbol{\epsilon}, \qquad LL^\top=R
\]

Motor ayrıca IID, bounded random walk ve ayrık Markov rejimlerini destekler. Korelasyon matrisi simetri, köşegen ve pozitif yarı tanımlılık açısından doğrulanır.

## 4. Strateji politikası

Her strateji aynı parametre sözleşmesini taşır. Dönem başında kurallar mevcut state ve gözlenen driver’ları okuyup parametreyi değiştirebilir:

\[
\pi_t = f_\pi(s_{t-1}, x_t)
\]

Bu, “başta bir karar ver ve 24 ay hiç değiştirme” yaklaşımıyla adaptif stratejiyi aynı motor içinde karşılaştırır. Kural `once=true` ise ilk tetiklemeden sonra kalıcı müdahale olur.

## 5. Sanal aktör segmentleri

Bir aktörün her eylem için utility değeri model ifadesinden gelir. Olası eylem payları softmax ile hesaplanır:

\[
p(a_i)=\frac{\exp((u_i-u_{max})/\tau)}{\sum_j \exp((u_j-u_{max})/\tau)}
\]

Davranış ataleti önceki eylem payıyla karıştırılır. Son olarak Dirichlet benzeri Gamma örneklemesi, aynı koşullardaki nüfus kompozisyonunun her dünyada birebir aynı olmamasını sağlar. Eylem etkileri, eylem paylarıyla ağırlıklandırılarak ortak state bağlamına bırakılır.

Aktör sayısı, her gerçek kişiyi tek tek kopyalamak anlamına gelmez. Karar açısından anlamlı heterojenlik segment düzeyindedir; gerekirse bir segment daha küçük alt segmentlere ayrılır.

## 6. Şok motoru

Her şok için dönemsel hazard:

\[
h_t=\operatorname{clamp}(f_h(s_{t-1},x_t,\pi_t),0,1)
\]

Aynı uniform çekiliş, farklı stratejilerin koşullu hazard’ına uygulanır. Şok tetiklenince süre dağılımından örnek alınır; aktif olduğu her dönemde etki değişkenlerini grafiğe bırakır. Bu yapı tek dönemli viral sıçramayı da üç dönemlik tükenmişlik olayını da temsil eder.

## 7. Dönem içi nedensel grafik

`equations + states`, topolojik sıralanan bir DAG oluşturur. `prev_*` isimleri gecikmeli state’i, düz düğüm isimleri aynı dönem bağımlılığını gösterir. Döngü bulunursa senaryo koşmaz. Bir state geçişi genel biçimde:

\[
s_t=g(s_{t-1},x_t,a_t,e_t,\pi_t)
\]

Her düğüm birim, model kimliği, evidence kimliği ve isteğe bağlı min/max sınırı taşır. Audit çıktısı expression hash’ini ve dependency listesini kaydeder.

## 8. Çok amaçlı utility ve hard constraint

Her objective önce `[0,1]` aralığında desirability’ye dönüşür. Maksimizasyon için:

\[
d_i(y)=\operatorname{clamp}\left(\frac{y-w_i}{b_i-w_i},0,1\right)^{q_i}
\]

Minimizasyonda ölçek ters çevrilir. Dünya utility’si:

\[
U_w=\frac{\sum_i \omega_i d_i(y_w)}{\sum_i\omega_i}-\sum_k \lambda_k I[\text{kısıt}_k\text{ ihlal}]
\]

`worst`, `best`, ağırlık ve ceza karar sahibinin tercihidir; veri gerçeği gibi sunulmaz. Bir strateji hard constraint’in izin verilen ihlal olasılığını aşarsa karar sıralamasında uygun değildir.

## 9. Kuyruk riski, sağlamlık ve pişmanlık

Alt-kuyruk CVaR:

\[
\operatorname{CVaR}_{\alpha}(U)=E[U\mid U\le Q_\alpha(U)]
\]

Sağlamlık, utility kabul eşiğini geçen ve hiçbir hard constraint ihlal etmeyen dünya payıdır. Dünya bazlı pişmanlık:

\[
R_{w,s}=\max_j U_{w,j}-U_{w,s}
\]

Karar skoru beklenen utility, CVaR, sağlamlık, başarı olasılığı ve `1-ortalama pişmanlık` bileşimidir. Ham bileşenler daima ayrıca raporlanır; tek skorun trade-off’ları gizlemesine izin verilmez.

## 10. Counterfactual fark

Ortak rassal sayılar sayesinde iki strateji için:

\[
\Delta_w=U_{w,A}-U_{w,B}
\]

doğrudan hesaplanır. Rapor `P(A>B)`, ortalama fark ve P5/P50/P95 farkını verir. Bu, ayrı ayrı iki Monte Carlo ortalamasını kıyaslamaktan daha düşük varyanslıdır.

## 11. Gelecek aileleri

Her dünyanın driver özetleri standardize edilir. Deterministik uzak-başlangıçlı k-means, dünyaları `k` aileye ayırır. Aile etiketi centroid’in mutlak z skoru en yüksek iki boyutundan üretilir. Her aile için olasılık kütlesi, strateji utility’si ve başarılı strateji raporlanır.

Küme etiketi açıklama kolaylığıdır; ontolojik bir “gerçek rejim” iddiası değildir.

## 12. Sürücü ve etkileşim taraması

Her driver özeti ile utility arasında Spearman sıralama ilişkisi hesaplanır. En güçlü ana etkilerin standardize edilmiş ikili çarpımları da taranır. Bu sonuçlar sensitivity’dir, causal effect değildir.

## 13. Karar sınırı

Her strateji çifti ve gözlenebilir driver için dünyalar sıralanır. %20–%80 aday eşiklerinde eşik altı/üstü ortalama eşlenmiş utility farkı hesaplanır. Fark işaret değiştiriyorsa ve ayrım yeterince güçlüyse “strateji dönüş eşiği” adayı oluşur. Eşikler model ve veri güncellendiğinde yeniden hesaplanmalıdır.

## 14. Kalibrasyon hafızası

Gerçekleşmiş binary tahminler SQLite ledger’a alınır. Model × horizon × regime için:

- Brier skoru;
- log loss;
- base rate ve ortalama tahmin;
- 10 kutulu calibration curve;
- expected calibration error

üretilir. Bu, gelecekte model/ajan ağırlığının self-reported confidence yerine gerçek geçmiş performansa bağlanması için ilk hafıza katmanıdır.

## 15. Bilinçli sınırlar

- Otomatik causal discovery yoktur.
- Büyük ölçek DES kuyruk kaynağı henüz ayrı bir event scheduler servisi değildir; dönemsel DAG içine bağlanır.
- K-means ve ikili etkileşim taraması açıklanabilir, hafif yöntemlerdir; ileri sürümde scenario discovery/surrogate model eklenebilir.
- Model stacking için kayıt sözleşmesi vardır; v0.1 aynı node’daki challenger posterior’larını otomatik birleştirmez.
- Incremental recompute için dependency traversal hazırdır; v0.1 CLI tam koşu çalıştırır.

