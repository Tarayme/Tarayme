# Mimari karar kayıtları

## ADR-001 — Termux çekirdeğinde standart kütüphane

**Karar:** V0.1 çekirdeği yalnız Python standart kütüphanesini kullanır.

**Neden:** Telefon üzerinde kurulum sürtünmesini ve native paket hatalarını azaltır; aynı seed’in farklı ortamlarda yeniden üretimini kolaylaştırır.

**Bedel:** PyMC posterior inference, SimPy DES ve SALib Sobol analizi çekirdeğe gömülü değildir. Model federation interface’i sonraki sürümde bu motorları adapter olarak bağlamak üzere ayrıdır.

## ADR-002 — “Ajan oyu” yok

**Karar:** Aktör/ajan sayısı sonucu oylayarak üretmez. Ajanlar evidence, dağılım, tepki veya model parçası bırakır; sonuç ortak world graph içinde hesaplanır.

**Neden:** Korele kanıtı iki kez saymayı ve farklı fiziksel niceliklerin anlamsız ortalamasını önler.

## ADR-003 — Dağılım-öncelikli arayüz

**Karar:** Belirsiz girişler tek sayı değil dağılım ve süreçtir; strateji özeti en az P5/P50/P95 ve CVaR taşır.

**Neden:** Ortalama aynıyken kuyruk riski farklı stratejileri ayırabilmek.

## ADR-004 — Ortak rassal sayılar

**Karar:** Dünya kaynaklı seed’lere strateji kimliği eklenmez.

**Neden:** Counterfactual farkın varyansını azaltmak ve “A şanslı dünyalarda, B kötü dünyalarda koştu” hatasını engellemek.

## ADR-005 — Human approval gate

**Karar:** Rapor bir öneri ve tetikleyici üretir, kararı otomatik uygulamaz.

**Neden:** Utility ağırlıkları, causal graph ve calibration belirsizliği yönetim tercihinden bağımsız gerçekler değildir.

## ADR-006 — Model/evidence lineage matematiğin parçası

**Karar:** Her graph düğümü model kimliği, expression hash’i, evidence referansı ve dependency listesi taşır.

**Neden:** Kaynak kökeni yalnız audit değil; duplicate evidence ve model conflict kontrolü için fusion girdisidir.

## ADR-007 — Tam gelecek ağacı yerine sampled worlds

**Karar:** Kombinasyonlar explicit dallara açılmaz; joint processes örneklenir ve sonuçlar gelecek ailelerine kümelenir.

**Neden:** Dallar üstel büyür. Düşük olasılık × yüksek etki dünyaları, stress conditions ve kuyruk ölçüleriyle korunur.

## ADR-008 — Senaryo kod değildir

**Karar:** Model JSON ve güvenli expression alt diliyle tanımlanır.

**Neden:** Model sahibinin denklemi görebilmesi, sürümleyebilmesi ve Termux’ta güvenli biçimde çalıştırabilmesi.

