# SPX senaryo sözleşmesi

Senaryo UTF-8 JSON dosyasıdır. Kimlikler güvenli ifade dilinde değişken olarak kullanıldığı için `A-Z`, `a-z`, `0-9`, `_` ile ve sayı olmayan karakterle başlamalıdır.

## Üst seviye alanlar

| Alan | Amaç |
| --- | --- |
| `meta` | Kimlik, sürüm, veri statüsü, insan onayı |
| `horizon`, `step` | Dönem sayısı ve okunabilir zaman birimi |
| `simulation` | Dünya, seed, küme ve trace ayarları |
| `evidence` | Kaynak/varsayım kökeni ve kalite sınıfı |
| `drivers` | Dış stokastik süreçler |
| `correlations` | Driver inovasyon ortak dağılımı |
| `strategies` | Parametreler ve adaptif politika kuralları |
| `actors` | Tepki veren sanal kişi/kurum segmentleri |
| `shocks` | Hazard, süre ve etkiler |
| `equations` | Aynı dönem hesap düğümleri |
| `states` | Başlangıç dağılımı ve geçiş denklemi |
| `metrics` | Final/sum/mean/min/max/discounted sonuç |
| `objectives` | Çok amaçlı desirability ve ağırlıklar |
| `constraints` | Hard/soft eşikler ve ruin etiketi |
| `success` | Metriklerden boolean başarı tanımı |
| `stress_tests` | Koşullu zor dünya aileleri |

## Dağılımlar

Sabit sayı doğrudan yazılabilir. Desteklenen nesneler:

```json
{"dist":"constant","value":3}
{"dist":"uniform","low":1,"high":5}
{"dist":"triangular","low":1,"mode":2,"high":8}
{"dist":"normal","mean":0,"sd":1,"min":-3,"max":3}
{"dist":"lognormal","median":100,"sigma":0.4}
{"dist":"beta","alpha":3,"beta":7,"low":0,"high":1}
{"dist":"pert","low":1,"mode":3,"high":10,"shape":4}
{"dist":"bernoulli","p":0.2}
{"dist":"discrete_uniform","low":1,"high":4}
{"dist":"categorical","values":[0.8,1,1.3],"weights":[1,6,2]}
```

`min`/`max`, örnek sonrasında fiziksel sınır uygular.

## Driver süreçleri

```json
"demand": {
  "process": "ar1",
  "initial": {"dist":"normal","mean":1,"sd":0.1},
  "mean": 1,
  "phi": 0.75,
  "sigma": 0.12,
  "min": 0.4,
  "max": 1.8,
  "seasonality": [1.0,0.9,1.1]
}
```

Destek: `constant`, `iid`, `ar1`, `random_walk`, `markov`. Markov örneği hazır kanal senaryosundaki `trend_regime` alanındadır.

Korelasyon:

```json
{
  "drivers": ["demand","price"],
  "matrix": [[1,-0.4],[-0.4,1]]
}
```

Bir driver yalnız bir korelasyon grubunda olabilir.

## Strateji

Bütün stratejiler aynı parametre anahtarlarını taşımalıdır:

```json
{
  "id": "adaptive",
  "label": "Adaptif",
  "parameters": {"capacity": 10, "reserve": 0.2},
  "initial_state": {"cash": "prev_cash-5000"},
  "rules": [
    {
      "id": "reserve_trigger",
      "when": "period>=4 and demand<0.8",
      "set": {"capacity":"capacity*0.8","reserve":"0.35"},
      "once": true
    }
  ]
}
```

Kurallar aktörlerden ve aynı dönem equations’dan önce çalışır; `t`, `period`, driver, state, `prev_state` ve strateji parametrelerini okuyabilir.

## Aktör

```json
{
  "id": "customers",
  "population": 100000,
  "temperature": 0.35,
  "inertia": 0.3,
  "response_concentration": 150,
  "actions": [
    {"id":"buy","utility":"1.2-price","effects":{"demand_signal":"0.8"}},
    {"id":"wait","utility":"price-0.4","effects":{"demand_signal":"0.1"}}
  ]
}
```

`temperature` düşerse aktör utility’si yüksek eyleme daha kesin yönelir. `inertia` önceki eylem kompozisyonunu korur. `response_concentration` büyürse nüfus payı çekilişinin varyansı azalır.

## Şok

```json
{
  "id":"supply_break",
  "hazard":"clamp(0.02+0.1*fragility,0,1)",
  "duration":{"dist":"discrete_uniform","low":1,"high":4},
  "effects":{"supply_shock":"-0.35"},
  "once":false
}
```

Grafik içinde aktiflik `shock_supply_break` değişkeniyle okunabilir.

## Equation ve state

```json
"equations": {
  "sales": {
    "expression":"max(0,demand*capacity*(1+supply_shock))",
    "unit":"unit/month",
    "min":0,
    "model_id":"SALES-v2",
    "evidence_ids":["E-12"]
  }
},
"states": {
  "cash": {
    "initial":{"dist":"pert","low":10000,"mode":15000,"high":25000},
    "transition":"prev_cash + sales*margin - fixed_cost",
    "unit":"TRY",
    "model_id":"CASH-v1",
    "evidence_ids":["E-12","E-18"]
  }
}
```

`prev_cash` önceki dönemi, `cash` aynı dönemde hesaplanan state’i ifade eder. Dönem içi graph döngüsüz olmalıdır.

## Metric, objective, constraint

```json
"metrics": {
  "final_cash":{"expression":"cash","aggregation":"final","unit":"TRY"},
  "min_cash":{"expression":"cash","aggregation":"min","unit":"TRY"},
  "total_sales":{"expression":"sales","aggregation":"sum","unit":"unit"}
},
"objectives": [
  {"metric":"final_cash","direction":"max","worst":0,"best":500000,"weight":0.7},
  {"metric":"risk","direction":"min","worst":1,"best":0,"weight":0.3}
],
"constraints": [
  {"id":"solvency","metric":"min_cash","op":">=","value":0,
   "hard":true,"ruin":true,"max_violation_probability":0.05,"penalty":0.6}
],
"success":"final_cash>100000 and total_sales>5000"
```

Objective yönleri `max`, `min`, `target`; aggregation türleri `final`, `sum`, `mean`, `min`, `max`, `discounted_sum`; constraint işlemleri `>=`, `>`, `<=`, `<`, `==`, `between` olabilir.

## Evidence Registry

Her kayıt asgari olarak kimlik, kaynak veya varsayım kökeni ve kalite taşımalıdır:

```json
{
  "id":"E-12",
  "type":"observed_data",
  "source":"internal:sales-ledger-2026Q2",
  "fingerprint":"sales-ledger-v4",
  "quality":"A",
  "validity":"2026-12-31",
  "note":"Net satış; KDV hariç"
}
```

Aynı fingerprint birden fazla kayıtta bulunursa double-counting uyarısı üretilir.

## Güvenli ifade dili

Desteklenen yapılar: sayılar, boolean, `+ - * / // % **`, karşılaştırma, `and/or/not`, ternary expression ve izinli fonksiyonlar. Attribute, subscript, comprehension, import, lambda, dosya veya sistem erişimi yasaktır.

