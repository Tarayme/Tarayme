# SPX Studio — Olasılık Simülasyonu ve Stratejik Projeksiyon

SPX Studio, bir kararın alternatiflerini tek bir gelecek tahminine göre değil, binlerce eşlenmiş olası dünyada sınayan çevrimdışı bir **karar ikizi aracı**dır. Termux dâhil Python 3.10+ çalışan her yerde ek bağımlılık olmadan çalışır.

Sürüm 0.3 başlangıç seviyesinden uzman kullanıma uzanan beş bağlı alan sunar:

1. **Şirketini kur:** şirket türü, para, kapasite, riskler ve üç karar yolunu 6 adımda gir.
2. **Modeli kontrol et:** motorun kurduğu neden-sonuç sistemini sade açıklamalarla incele.
3. **Simülasyonu çalıştır:** 100–3.000 eşlenmiş olası dünyada Monte Carlo + politika simülasyonu yap.
4. **Sonuçları oku:** karar, risk, gelecek aileleri ve sonuçtan kaynağa denetim izini aç.
5. **Öğren:** ekran turu, veri hazırlama tablosu, Monte Carlo anlatımı, sonuç okuma rehberi ve sözlükten yararlan.

Teknik dağılımlar, aktörler, amaç ağırlıkları ve tam JSON ana akışı kalabalıklaştırmamak için **Uzman Modu** altında korunur.

Bu sürüm bir “rastgele sayı üret, ortalamasını al” demonstrasyonu değildir. Aynı model içinde şunları birleştirir:

- koşullu ve korelasyonlu dış dünya süreçleri;
- zaman içinde stok biriktiren nedensel karar grafiği;
- amaçları ve tepki politikaları farklı sanal aktör segmentleri;
- hazard ve süre taşıyan bileşik şoklar;
- koşula göre parametre değiştiren adaptif stratejiler;
- aynı rassal dünyalarda counterfactual strateji karşılaştırması;
- expected utility, P5/P50/P95, alt-kuyruk CVaR, ruin riski, sağlamlık ve pişmanlık;
- gelecek aileleri, sürücü/etkileşim taraması ve karar dönüş eşikleri;
- evidence/model lineage, senaryo hash’i, seed ve SQLite kalibrasyon hafızası;
- telefonda çalışan etkileşimli Studio arayüzü;
- çevrimdışı, tek dosyalık HTML karar raporu.

## Hızlı başlangıç — Termux

```bash
pkg install python
cd /storage/emulated/0/Download
unzip -o SPX_Studio_v0.3_Termux.zip
cd spx_decision_twin
chmod +x install-termux.sh START-STUDIO.sh spx-run
./install-termux.sh

spx studio
```

Tarayıcı otomatik açılır. Açılmazsa Termux'ta yazan `http://127.0.0.1:8765/` adresini Chrome'a gir. Sunucuyu kapatmak için Termux ekranında `CTRL+C` kullan.

Kurulum yapmadan da proje klasöründe doğrudan açılabilir:

```bash
./START-STUDIO.sh
```

Kurulum betiği `spx-run` yerel başlatıcısını Termux'un `$PREFIX/bin` dizinine sembolik bağlar. `pip`, sanal ortam, ağ servisi, API anahtarı veya ücretli model gerekmez. Proje klasörünü daha sonra taşırsan kurucuyu yeni konumdan tekrar çalıştır.

Android ortak depolamasında çalıştırma izni sorun çıkarırsa projeyi Termux ana dizinine kopyala:

```bash
cp -r /storage/emulated/0/simulatörrr/spx_decision_twin "$HOME/"
cd "$HOME/spx_decision_twin"
chmod +x install-termux.sh START-STUDIO.sh spx-run
./install-termux.sh
spx studio
```

Komut satırı motoru da çalışmaya devam eder:

```bash
python -m spx validate examples/channel_24m.json
python -m spx run examples/channel_24m.json --worlds 1000 --output runs/test
```

## Kendi şirketimi nasıl simüle ederim?

Tarayıcıdaki **Şirketini kur** ekranı şu girdileri tam bir karar modeline dönüştürür:

1. Şirket adı, sektör, karar sorusu ve 6–36 aylık ufuk.
2. Aylık ciro, toplam gider, kullanılabilir nakit ve çalışan sayısı.
3. Aylık gerçekleşen iş, azami kapasite ve satışa bağlı gider payı.
4. Talep oynaklığı, maliyet artışı, devamsızlık, arıza ve tedarik gecikmesi.
5. Karşılaştırılacak üç yol ve her yolun pazarlama, çalışan, kapasite, bakım, tampon, eğitim ve fiyat ayarları.

Kurucu bu bilgilerden otomatik olarak altı dış dünya süreci, müşteri/çalışan/tedarikçi aktörleri, beş şok türü, 23 neden-sonuç düğümü, 11 sonuç metriği, sert hayatta kalma sınırları ve stres testleri üretir. İlk koşuda 100 dünya ile formu kontrol et; sonra 500 veya 1.000 dünyaya geç. Sonuç ekranında yalnızca ilk sıraya değil, kötü yüzde 10 ortalamasına, çöküş riskine, gelecek ailelerine ve sonucu taşıyan girdinin kaynak izine de bak.

İlk model kalibrasyon öncesidir. Gerçek aylık sonuçları biriktirdikçe ciro, gider, kapasite ve risk oranlarını güncelleyip aynı karar sorusunu yeniden çalıştır.

## Hazır referans modeli

`examples/channel_24m.json`, “Simülasyon Projeksiyon” kanalının ilk 24 ayını üç politika altında sınar:

1. **Hacim Motoru:** daha fazla uzun video ve kısa içerikle keşif olasılığını artırır; kalite, güven ve enerji kuyruğu riski taşır.
2. **Amiral İçerik / Derinlik:** araştırma ve paketlemeye daha fazla kaynak ayırır; daha yavaş fakat güven/enerji yönünden güçlü bir politika izler.
3. **Adaptif Portföy:** talep, enerji, platform uyumu ve sponsor pencerelerine göre üretim karmasını değiştirir.

Modelde meraklı izleyici, çekirdek izleyici, rakip üretici ve sponsor segmentleri tepki verir. Platform rejimi, konu talebi, izleyici dikkati, rekabet, sponsor pazarı ve üretim sürtünmesi zamana bağlıdır. Algoritma değişimi, tükenmişlik, viral sıçrama ve sponsor uyumsuzluğu ayrı şok süreçleridir.

**Önemli:** Referans modelin bütün sayıları `ILLUSTRATIVE` olarak etiketlidir. Bu bir YouTube büyüme tahmini değildir; ciddi motorun nasıl model kurulacağını gösteren kalibrasyon öncesi çalışma senaryosudur. Gerçek kullanımda ilk iş, varsayımları kanal verisi ve dış kaynaklarla değiştirmektir.

İkinci şablon `examples/operations_12m.json`, talep, makine arızası, bakım politikası, çalışan devamsızlığı, fazla mesai, tedarik gecikmesi, kapasite, kalite, nakit ve backlog geri beslemelerini birlikte simüle eder. Reaktif kontrol, önleyici bakım ve adaptif dayanıklılık politikalarını aynı dünyalarda karşılaştırır. Bu şablonun sayıları da kalibrasyon öncesi temsili varsayımlardır.

## Üretilen dosyalar

Her `spx run` koşusu aşağıdakileri yazar:

| Dosya | İçerik |
| --- | --- |
| `report.html` | Telefonda/masaüstünde açılan çevrimdışı yönetici raporu |
| `summary.json` | Sıralama, riskler, kümeler, eşikler, sensitivity ve stress sonuçları |
| `worlds.csv` | Her dünya × strateji için metrik, utility, kısıt ve sürücü verisi |
| `traces.json` | Örnek dünyaların dönemsel state yolları |
| `audit.json` | Evidence Registry, Model Registry, hash ve dependency lineage |
| `scenario.snapshot.json` | Koşuda kullanılan senaryonun tam kopyası |
| `spx_ledger.sqlite3` | Koşu ve strateji özetlerinin kalıcı kayıt defteri |

## Komutlar

```bash
# Etkileşimli Studio'yu aç
spx studio

# Belirli bir senaryoyla Studio'yu aç
spx studio examples/operations_12m.json

# Şema, güvenli ifadeler, korelasyon matrisi, DAG ve evidence referansları
spx validate examples/channel_24m.json

# Model boyutları ve scenario hash
spx inspect examples/channel_24m.json

# Tohum ve dünya sayısı kontrollü koşu
spx run examples/channel_24m.json --worlds 5000 --seed 42 --output runs/run_42

# Önceki koşuları listele
spx ledger --db runs/run_42/spx_ledger.sqlite3

# Gerçekleşmiş tahminleri kalibrasyon hafızasına al
spx calibrate --db runs/run_42/spx_ledger.sqlite3 \
  --import-csv examples/calibration_sample.csv \
  --output runs/run_42/calibration.json
```

Kalibrasyon CSV sözleşmesi: `prediction_id,model_id,probability,outcome`; isteğe bağlı `horizon,regime,timestamp`.

## Modeli değiştirme

En hızlı başlangıç, `examples/channel_24m.json` dosyasını kopyalayıp şu bölümleri düzenlemektir:

- `drivers`: AR(1), random walk, IID, Markov rejimi veya sabit dış süreçler;
- `correlations`: aynı dönemdeki driver inovasyonlarının korelasyonu;
- `strategies`: ortak parametre sözleşmesi ve koşullu politika kuralları;
- `actors`: softmax eylem seçen kişi/kurum segmentleri ve etkileri;
- `shocks`: hazard, duration ve aktifken bıraktığı etkiler;
- `equations`: dönem içi DAG düğümleri;
- `states`: başlangıç dağılımı ve bir sonraki dönem denklemi;
- `metrics`, `objectives`, `constraints`, `success`: karar ölçümü;
- `stress_tests`: koşullu zor dünya aileleri.

İfade dili güvenli bir matematik alt kümesidir. `min`, `max`, `abs`, `sqrt`, `log`, `log1p`, `exp`, `tanh`, `clamp`, `sigmoid`, `step`, `lerp`, `safe_div` ve temel karşılaştırmalar desteklenir. Python kodu, attribute erişimi, dosya/işletim sistemi çağrısı çalıştırılamaz.

Ayrıntılı sözleşme için [docs/MODEL_SPEC.md](docs/MODEL_SPEC.md), algoritma için [docs/ALGORITHM.md](docs/ALGORITHM.md), mimari kararlar için [docs/ADR.md](docs/ADR.md) dosyasına bakın.

## Test

```bash
python -m unittest discover -s tests -v
```

Test paketi güvenli ifade sandbox’ını, korelasyon üretimini, DAG sıralamasını/döngü reddini, aynı seed ile birebir tekrar üretilebilirliği, eşlenmiş strateji karşılaştırmasını, çıktı üretimini, kalibrasyon hafızasını ve tam kanal senaryosunu kapsar.

## Kapsam ve sınırlar

- SPX nedenselliği kendi kendine keşfetmez; yazılan yapısal varsayımları çalıştırır ve görünür kılar.
- Sensitivity ilişkisi nedensel etki değildir.
- Kümeler, milyonlarca olası yolu yönetici için birkaç aileye sıkıştırır; gerçekliğin doğal sınıfları olduğu iddia edilmez.
- Model kalibre edilmeden yüzdeler yalnızca “bu varsayımlar altında” geçerlidir.
- Yüksek etkili kararlar için insan onayı, challenger model ve historical replay gerekir.

## Lisans

MIT. Ticari veya deneysel kullanım serbesttir; sonuçların doğruluğu ve karar sorumluluğu kullanıcıya aittir.
