#!/data/data/com.termux/files/usr/bin/bash
set -eu

spx_studio_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
chmod +x "$spx_studio_dir/spx-run"
exec "$spx_studio_dir/spx-run" studio
