"use strict";

const state = {
  scenario: null,
  templates: [],
  projects: [],
  selectedStrategy: null,
  selectedNode: null,
  activeTab: "model",
  dirty: false,
  valid: null,
  jobId: null,
  job: null,
  result: null,
  narrative: null,
  activeFuture: 0,
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

document.addEventListener("DOMContentLoaded", boot);

async function boot() {
  bindStaticEvents();
  try {
    const data = await api("/api/bootstrap");
    state.templates = data.templates || [];
    state.projects = data.projects || [];
    state.scenario = normalizeScenario(data.default_scenario);
    state.selectedStrategy = state.scenario.strategies[0]?.id || null;
    $("#runSeed").value = state.scenario.simulation.seed || 20260817;
    populateTemplateSelect();
    renderAll();
    $("#loadingPanel").hidden = true;
    showScreen("model");
    setServerState("online", "Yerel motor hazır");
  } catch (error) {
    setServerState("error", "Motor bağlantısı yok");
    $("#loadingPanel h1").textContent = "SPX motoruna bağlanamadık";
    $("#loadingPanel p").textContent = error.message;
    toast(error.message, true);
  }
}

function bindStaticEvents() {
  $$("[data-tab]").forEach((button) => button.addEventListener("click", () => showScreen(button.dataset.tab)));
  $$("[data-go]").forEach((button) => button.addEventListener("click", () => showScreen(button.dataset.go)));
  $("#templateSelect").addEventListener("change", loadTemplate);
  $("#saveProjectButton").addEventListener("click", saveProject);
  $("#loadProjectButton").addEventListener("click", openProjects);
  $("#addDriverButton").addEventListener("click", addDriver);
  $("#addStrategyButton").addEventListener("click", addStrategy);
  $("#refreshJsonButton").addEventListener("click", refreshJson);
  $("#applyJsonButton").addEventListener("click", applyJson);
  $("#exportJsonButton").addEventListener("click", exportScenario);
  $("#importJsonInput").addEventListener("change", importScenario);
  $("#validateButton").addEventListener("click", validateModel);
  $("#runButton").addEventListener("click", runSimulation);
  $("#viewLastResultButton").addEventListener("click", () => showScreen("insights"));
  $("#runWorlds").addEventListener("change", updateRunEstimate);
  $("#downloadReportButton").addEventListener("click", () => openDownload("report.html", true));
  $("#downloadCsvButton").addEventListener("click", () => openDownload("worlds.csv"));
}

function normalizeScenario(raw) {
  const scenario = typeof structuredClone === "function" ? structuredClone(raw) : JSON.parse(JSON.stringify(raw));
  scenario.meta ||= {};
  scenario.meta.id ||= "my_projection_model";
  scenario.meta.name ||= "Yeni projeksiyon modeli";
  scenario.meta.data_status ||= "ILLUSTRATIVE";
  scenario.simulation ||= { worlds: 1000, seed: 20260817 };
  scenario.drivers ||= {};
  scenario.correlations ||= [];
  scenario.strategies ||= [];
  scenario.actors ||= [];
  scenario.shocks ||= [];
  scenario.states ||= {};
  scenario.equations ||= {};
  scenario.metrics ||= {};
  scenario.objectives ||= [];
  scenario.constraints ||= [];
  scenario.evidence ||= [];
  scenario.stress_tests ||= [];
  return scenario;
}

function setServerState(kind, label) {
  const node = $("#serverState");
  node.className = `server-state ${kind}`;
  $("span", node).textContent = label;
}

async function api(path, options = {}) {
  const config = { ...options, headers: { ...(options.headers || {}) } };
  if (options.body && typeof options.body !== "string") {
    config.body = JSON.stringify(options.body);
    config.headers["Content-Type"] = "application/json";
  }
  const response = await fetch(path, config);
  let payload;
  try { payload = await response.json(); } catch { payload = null; }
  if (!response.ok) throw new Error(payload?.error || `Sunucu hatası: ${response.status}`);
  return payload;
}

function populateTemplateSelect() {
  $("#templateSelect").innerHTML = state.templates.map((template) =>
    `<option value="${esc(template.id)}">${esc(template.name)}</option>`
  ).join("");
  if (state.scenario) $("#templateSelect").value = state.scenario.meta.id;
}

async function loadTemplate(event) {
  if (state.dirty && !confirm("Kaydedilmemiş değişiklikler var. Şablonu yine de değiştirilsin mi?")) {
    event.target.value = state.scenario.meta.id;
    return;
  }
  try {
    state.scenario = normalizeScenario(await api(`/api/templates/${encodeURIComponent(event.target.value)}`));
    state.selectedStrategy = state.scenario.strategies[0]?.id || null;
    state.selectedNode = null;
    state.dirty = false;
    state.valid = null;
    $("#projectName").value = `${state.scenario.meta.name} — çalışma`;
    $("#runSeed").value = state.scenario.simulation.seed || 20260817;
    renderAll();
    toast("Şablon yüklendi");
  } catch (error) { toast(error.message, true); }
}

function renderAll() {
  renderModel();
  renderGraph();
  updateRunEstimate();
  if (state.result) renderResults();
}

function renderModel() {
  const s = state.scenario;
  if (!s) return;
  $("#scenarioName").value = s.meta.name || "";
  $("#decisionQuestion").value = s.meta.decision_question || s.meta.description || "";
  $("#horizon").value = s.horizon || 1;
  $("#step").value = s.step || "dönem";
  $("#scenarioWorlds").value = s.simulation.worlds || 1000;
  $("#scenarioSeed").value = s.simulation.seed || 20260817;
  bindIdentityInputs();
  renderOverview();
  renderDrivers();
  renderStrategies();
  renderActorsAndShocks();
  renderPreferences();
  renderInventory();
  refreshJson();
  renderHealth();
}

function bindIdentityInputs() {
  const binds = [
    ["#scenarioName", (v) => state.scenario.meta.name = v],
    ["#decisionQuestion", (v) => state.scenario.meta.decision_question = v],
    ["#horizon", (v) => state.scenario.horizon = numeric(v, 1)],
    ["#step", (v) => state.scenario.step = v],
    ["#scenarioWorlds", (v) => state.scenario.simulation.worlds = numeric(v, 1000)],
    ["#scenarioSeed", (v) => state.scenario.simulation.seed = numeric(v, 20260817)],
  ];
  binds.forEach(([selector, setter]) => {
    const node = $(selector);
    node.oninput = () => { setter(node.value); markDirty(); renderOverview(); updateRunEstimate(); };
  });
}

function renderOverview() {
  const s = state.scenario;
  const rows = [
    [s.horizon, s.step || "dönem"],
    [Object.keys(s.drivers).length, "sürücü"],
    [s.strategies.length, "strateji"],
    [s.actors.length, "aktör"],
    [s.shocks.length, "şok"],
    [Object.keys(s.states).length + Object.keys(s.equations).length, "düğüm"],
  ];
  $("#modelOverview").innerHTML = rows.map(([value, label]) =>
    `<div class="overview-item"><b>${esc(value)}</b><span>${esc(label)}</span></div>`
  ).join("");
}

function renderHealth() {
  const node = $("#modelHealth");
  if (state.valid === true) {
    node.className = "model-health valid";
    node.textContent = "Model geçerli";
  } else if (state.valid === false) {
    node.className = "model-health";
    node.textContent = "Modelde hata var";
  } else {
    node.className = "model-health";
    node.textContent = state.dirty ? "Doğrulama bekliyor" : "Şablon yüklendi";
  }
}

function renderDrivers() {
  const entries = Object.entries(state.scenario.drivers);
  $("#driversEditor").innerHTML = entries.map(([id, spec]) => {
    const ar = spec.process === "ar1" || spec.process === "random_walk";
    const mean = numberFrom(spec.mean, distributionCenter(spec.initial));
    const sigma = numberFrom(spec.sigma, distributionSpread(spec.initial));
    return `<article class="driver-card" data-driver="${esc(id)}">
      <label class="field driver-id"><span>Kimlik</span><input data-key="id" value="${esc(id)}" aria-label="Sürücü kimliği"></label>
      <label class="field"><span>Süreç</span><select data-key="process"><option value="ar1" ${selected(spec.process, "ar1")}>AR(1)</option><option value="iid" ${selected(spec.process, "iid")}>Bağımsız</option><option value="random_walk" ${selected(spec.process, "random_walk")}>Rastgele yürüyüş</option><option value="constant" ${selected(spec.process, "constant")}>Sabit</option><option value="markov" ${selected(spec.process, "markov")}>Markov</option></select></label>
      <label class="field"><span>Ortalama</span><input data-key="mean" type="number" step="any" value="${esc(roundInput(mean))}" ${ar ? "" : "disabled"}></label>
      <label class="field"><span>Oynaklık</span><input data-key="sigma" type="number" min="0" step="any" value="${esc(roundInput(sigma))}" ${ar ? "" : "disabled"}></label>
      <label class="field"><span>Hafıza φ</span><input data-key="phi" type="number" min="-0.99" max="0.99" step="0.01" value="${esc(roundInput(numberFrom(spec.phi, .7)))}" ${spec.process === "ar1" ? "" : "disabled"}></label>
      <label class="field"><span>Aralık</span><input data-key="range" value="${esc(`${numberFrom(spec.min, 0)} … ${numberFrom(spec.max, 2)}`)}" disabled></label>
      <button class="icon-button delete-driver" type="button" aria-label="${esc(id)} sürücüsünü sil">×</button>
      ${spec.process === "markov" ? `<div class="driver-note">Markov durumları: ${esc((spec.states || []).join(" · "))}. Matris için gelişmiş JSON'u kullan.</div>` : ""}
    </article>`;
  }).join("") || `<p class="section-copy">Henüz sürücü yok.</p>`;

  $$(".driver-card").forEach((card) => {
    const originalId = card.dataset.driver;
    $$('[data-key]', card).forEach((input) => input.addEventListener("change", () => updateDriver(originalId, input.dataset.key, input.value)));
    $(".delete-driver", card).addEventListener("click", () => deleteDriver(originalId));
  });
}

function updateDriver(originalId, key, value) {
  const spec = state.scenario.drivers[originalId];
  if (!spec) return;
  if (key === "id") {
    const nextId = slugIdentifier(value);
    if (!nextId || nextId === originalId) return renderDrivers();
    if (state.scenario.drivers[nextId]) return toast("Bu sürücü kimliği zaten var", true);
    const rebuilt = {};
    Object.entries(state.scenario.drivers).forEach(([id, driver]) => rebuilt[id === originalId ? nextId : id] = driver);
    state.scenario.drivers = rebuilt;
    replaceDriverInCorrelations(originalId, nextId);
    replaceTokenEverywhere(originalId, nextId);
  } else if (key === "process") {
    spec.process = value;
    if (value === "constant") spec.value = numberFrom(spec.mean, 1);
    if (value === "iid" && !spec.distribution) spec.distribution = spec.initial || { dist: "normal", mean: 1, sd: .1 };
    if (value === "markov" && !spec.states) {
      spec.states = [.8, 1, 1.2];
      spec.initial_probabilities = [.2, .6, .2];
      spec.transition = [[.7,.25,.05],[.12,.76,.12],[.05,.25,.7]];
    }
  } else {
    spec[key] = numeric(value, spec[key] || 0);
  }
  markDirty();
  renderDrivers();
  renderOverview();
  renderGraph();
}

function addDriver() {
  let id = "yeni_surucu";
  let i = 2;
  while (state.scenario.drivers[id]) id = `yeni_surucu_${i++}`;
  state.scenario.drivers[id] = {
    process: "ar1",
    initial: { dist: "normal", mean: 1, sd: .1, min: .5, max: 1.5 },
    mean: 1, phi: .7, sigma: .1, min: .3, max: 1.7,
  };
  markDirty();
  renderDrivers();
  renderOverview();
  renderGraph();
  toast("Yeni belirsizlik sürücüsü eklendi");
}

function deleteDriver(id) {
  if (!confirm(`${id} sürücüsü silinsin mi? Denklemlerde kullanılıyorsa doğrulama hata verir.`)) return;
  delete state.scenario.drivers[id];
  state.scenario.correlations = (state.scenario.correlations || []).map((group) => subsetCorrelation(group, id)).filter(Boolean);
  markDirty(); renderDrivers(); renderOverview(); renderGraph();
}

function subsetCorrelation(group, removedId) {
  const index = group.drivers.indexOf(removedId);
  if (index < 0) return group;
  const drivers = group.drivers.filter((_, i) => i !== index);
  if (drivers.length < 2) return null;
  const matrix = group.matrix.filter((_, i) => i !== index).map((row) => row.filter((_, i) => i !== index));
  return { ...group, drivers, matrix };
}

function replaceDriverInCorrelations(oldId, newId) {
  (state.scenario.correlations || []).forEach((group) => group.drivers = group.drivers.map((id) => id === oldId ? newId : id));
}

function replaceTokenEverywhere(oldId, newId) {
  const pattern = new RegExp(`\\b${escapeRegExp(oldId)}\\b`, "g");
  const walk = (value) => {
    if (typeof value === "string") return value.replace(pattern, newId);
    if (Array.isArray(value)) return value.map(walk);
    if (value && typeof value === "object") {
      Object.keys(value).forEach((key) => value[key] = walk(value[key]));
    }
    return value;
  };
  [state.scenario.states, state.scenario.equations, state.scenario.metrics, state.scenario.strategies, state.scenario.actors, state.scenario.shocks, state.scenario.stress_tests].forEach(walk);
}

function renderStrategies() {
  const strategies = state.scenario.strategies;
  if (!strategies.some((item) => item.id === state.selectedStrategy)) state.selectedStrategy = strategies[0]?.id || null;
  $("#strategyTabs").innerHTML = strategies.map((item) =>
    `<button class="strategy-pill ${item.id === state.selectedStrategy ? "active" : ""}" data-strategy="${esc(item.id)}" type="button">${esc(item.label || item.id)}</button>`
  ).join("");
  $$(".strategy-pill").forEach((button) => button.addEventListener("click", () => { state.selectedStrategy = button.dataset.strategy; renderStrategies(); }));
  const strategy = strategies.find((item) => item.id === state.selectedStrategy);
  if (!strategy) {
    $("#strategyEditor").innerHTML = `<p class="section-copy">Strateji yok. En az iki strateji ekle.</p>`;
    return;
  }
  const params = Object.entries(strategy.parameters || {});
  $("#strategyEditor").innerHTML = `<div class="strategy-head">
      <label class="field"><span>Strateji adı</span><input id="strategyLabel" value="${esc(strategy.label || strategy.id)}"></label>
      <label class="field"><span>Kimlik</span><input id="strategyId" value="${esc(strategy.id)}"></label>
      <button class="button small danger" id="deleteStrategyButton" type="button">Stratejiyi sil</button>
    </div>
    <div class="parameter-grid">${params.map(([key, value]) => `<label class="parameter-field"><small title="${esc(key)}">${esc(humanize(key))}</small><input data-param="${esc(key)}" type="number" step="any" value="${esc(roundInput(value))}" aria-label="${esc(key)}"></label>`).join("")}</div>
    <div class="policy-rules"><h3>Koşullu politika kuralları</h3>${(strategy.rules || []).length ? strategy.rules.map((rule) => `<span class="rule-chip" title="${esc(rule.when || "true")}"><i></i>${esc(rule.id || "kural")}</span>`).join("") : `<span class="section-copy">Bu stratejide henüz koşullu kural yok. Gelişmiş JSON'dan eklenebilir.</span>`}</div>`;
  $("#strategyLabel").addEventListener("input", (event) => { strategy.label = event.target.value; markDirty(); renderStrategyTabsOnly(); });
  $("#strategyId").addEventListener("change", (event) => renameStrategy(strategy, event.target.value));
  $$("[data-param]", $("#strategyEditor")).forEach((input) => input.addEventListener("input", () => { strategy.parameters[input.dataset.param] = numeric(input.value, 0); markDirty(); }));
  $("#deleteStrategyButton").addEventListener("click", () => deleteStrategy(strategy.id));
}

function renderStrategyTabsOnly() {
  const strategy = state.scenario.strategies.find((item) => item.id === state.selectedStrategy);
  const button = $(`.strategy-pill[data-strategy="${cssEscape(state.selectedStrategy)}"]`);
  if (button && strategy) button.textContent = strategy.label || strategy.id;
}

function renameStrategy(strategy, rawId) {
  const id = slugIdentifier(rawId);
  if (!id || (id !== strategy.id && state.scenario.strategies.some((item) => item.id === id))) {
    toast("Geçerli ve benzersiz bir strateji kimliği gir", true); renderStrategies(); return;
  }
  const old = strategy.id;
  strategy.id = id;
  state.selectedStrategy = id;
  (state.scenario.stress_tests || []).forEach((test) => { if (test.best_strategy_id === old) test.best_strategy_id = id; });
  markDirty(); renderStrategies();
}

function addStrategy() {
  const base = state.scenario.strategies[0];
  if (!base) return toast("Önce gelişmiş JSON'da bir temel strateji tanımla", true);
  let id = "yeni_strateji";
  let i = 2;
  while (state.scenario.strategies.some((item) => item.id === id)) id = `yeni_strateji_${i++}`;
  const clone = JSON.parse(JSON.stringify(base));
  clone.id = id;
  clone.label = `Yeni Strateji ${state.scenario.strategies.length + 1}`;
  clone.rules = [];
  state.scenario.strategies.push(clone);
  state.selectedStrategy = id;
  markDirty(); renderStrategies(); renderOverview(); updateRunEstimate();
  toast("Temel politikadan yeni strateji üretildi");
}

function deleteStrategy(id) {
  if (state.scenario.strategies.length <= 2) return toast("Karşılaştırma için en az iki strateji kalmalı", true);
  if (!confirm(`${id} stratejisi silinsin mi?`)) return;
  state.scenario.strategies = state.scenario.strategies.filter((item) => item.id !== id);
  state.selectedStrategy = state.scenario.strategies[0].id;
  markDirty(); renderStrategies(); renderOverview(); updateRunEstimate();
}

function renderInventory() {
  const s = state.scenario;
  const cards = [
    ["Dinamik durum", Object.keys(s.states).length, "Stoklar ve dönemler arası hafıza"],
    ["Denklem", Object.keys(s.equations).length, "Nedensel dönüşüm ve geri besleme"],
    ["Aktör politikası", s.actors.length, "Sanal kişi/kurum eylem dağılımları"],
    ["Şok süreci", s.shocks.length, "Olasılık, süre ve model etkileri"],
    ["Sonuç metriği", Object.keys(s.metrics).length, "Dağılımı raporlanan çıktılar"],
    ["Karar amacı", s.objectives.length, "Fayda ölçeği ve tercih ağırlıkları"],
    ["Kısıt", s.constraints.length, "İflas/ruin ve kabul sınırları"],
    ["Kanıt kaydı", s.evidence.length, "Kaynak, kalite ve geçerlilik izi"],
  ];
  $("#inventoryGrid").innerHTML = cards.map(([title, count, copy]) => `<article class="inventory-card"><b>${esc(title)}<span>${count}</span></b><p>${esc(copy)}</p></article>`).join("");
}

function renderActorsAndShocks() {
  const s = state.scenario;
  const actors = s.actors.map((actor, index) => `<article class="submodel-card" data-actor-index="${index}"><header><b>${esc(humanize(actor.id))}</b><span>${(actor.actions || []).length} EYLEM</span></header><div class="submodel-fields"><label class="field"><span>Nüfus</span><input data-actor-key="population" type="number" min="1" step="1" value="${esc(actor.population || 1)}"></label><label class="field"><span>Sıcaklık</span><input data-actor-key="temperature" type="number" min="0.01" step="0.01" value="${esc(actor.temperature ?? .4)}"></label><label class="field"><span>Atalet</span><input data-actor-key="inertia" type="number" min="0" max="1" step="0.01" value="${esc(actor.inertia ?? 0)}"></label></div><div class="action-line">${esc((actor.actions || []).map((action) => action.id).join(" · ") || "eylem yok")}</div></article>`).join("") || `<p class="section-copy">Tanımlı aktör yok.</p>`;
  const shocks = s.shocks.map((shock, index) => `<article class="submodel-card" data-shock-index="${index}"><header><b>${esc(humanize(shock.id))}</b><span>${Object.keys(shock.effects || {}).length} ETKİ</span></header><label class="field shock-expression"><span>Hazard / dönem olasılığı</span><textarea data-shock-key="hazard" rows="2">${esc(shock.hazard ?? 0)}</textarea></label><div class="action-line">Etkiler: ${esc(Object.keys(shock.effects || {}).join(" · ") || "yok")}</div></article>`).join("") || `<p class="section-copy">Tanımlı şok yok.</p>`;
  $("#actorShockEditor").innerHTML = `<div class="submodel-column"><h3>Sanal aktörler</h3>${actors}</div><div class="submodel-column"><h3>Şok süreçleri</h3>${shocks}</div>`;
  $$('[data-actor-index]').forEach((card) => $$('[data-actor-key]', card).forEach((input) => input.addEventListener("input", () => {
    const actor = s.actors[Number(card.dataset.actorIndex)];
    actor[input.dataset.actorKey] = numeric(input.value, 0);
    markDirty();
  })));
  $$('[data-shock-index]').forEach((card) => $$('[data-shock-key]', card).forEach((input) => input.addEventListener("input", () => {
    const shock = s.shocks[Number(card.dataset.shockIndex)];
    shock[input.dataset.shockKey] = input.value;
    markDirty();
  })));
}

function renderPreferences() {
  const objectives = state.scenario.objectives;
  $("#preferencesEditor").innerHTML = objectives.map((objective, index) => `<article class="preference-card" data-objective-index="${index}"><header><b>${esc(humanize(objective.id || objective.metric))}</b><span>${esc(humanize(objective.metric))} · ${objective.direction === "min" ? "MİN" : "MAKS"}</span></header><div class="preference-fields"><label class="field"><span>Ağırlık</span><input data-objective-key="weight" type="number" min="0" step="0.01" value="${esc(objective.weight ?? 0)}"></label><label class="field"><span>En kötü</span><input data-objective-key="worst" type="number" step="any" value="${esc(objective.worst ?? 0)}"></label><label class="field"><span>En iyi</span><input data-objective-key="best" type="number" step="any" value="${esc(objective.best ?? 1)}"></label></div></article>`).join("") || `<p class="section-copy">Karar amacı tanımlı değil.</p>`;
  $$('[data-objective-index]').forEach((card) => $$('[data-objective-key]', card).forEach((input) => input.addEventListener("input", () => {
    const objective = objectives[Number(card.dataset.objectiveIndex)];
    objective[input.dataset.objectiveKey] = numeric(input.value, 0);
    markDirty();
  })));
}

function refreshJson() {
  if (state.scenario) $("#jsonEditor").value = JSON.stringify(state.scenario, null, 2);
}

function applyJson() {
  try {
    const parsed = JSON.parse($("#jsonEditor").value);
    state.scenario = normalizeScenario(parsed);
    state.selectedStrategy = state.scenario.strategies[0]?.id || null;
    state.selectedNode = null;
    markDirty(); renderAll();
    toast("JSON modele uygulandı; şimdi doğrula");
  } catch (error) { toast(`JSON okunamadı: ${error.message}`, true); }
}

function exportScenario() {
  downloadBlob(JSON.stringify(state.scenario, null, 2), `${slugFile(state.scenario.meta.id)}.json`, "application/json");
}

async function importScenario(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    state.scenario = normalizeScenario(JSON.parse(await file.text()));
    state.selectedStrategy = state.scenario.strategies[0]?.id || null;
    markDirty(); renderAll(); toast("Model dosyası içe aktarıldı");
  } catch (error) { toast(`Dosya okunamadı: ${error.message}`, true); }
  event.target.value = "";
}

async function validateModel() {
  const button = $("#validateButton");
  button.disabled = true; button.textContent = "Doğrulanıyor…";
  try {
    const data = await api("/api/validate", { method: "POST", body: { scenario: state.scenario } });
    state.valid = data.valid;
    renderValidation(data);
    renderHealth();
    toast(data.valid ? "Model geçerli — koşuya hazır" : "Modelde düzeltilmesi gereken hata var", !data.valid);
    return data.valid;
  } catch (error) { toast(error.message, true); return false; }
  finally { button.disabled = false; button.textContent = "Modeli doğrula"; }
}

function renderValidation(data) {
  const box = $("#validationBox");
  box.hidden = false;
  box.className = `validation-box ${data.valid ? "valid" : "invalid"}`;
  const errors = (data.issues || []).filter((issue) => issue.level === "error");
  const warnings = (data.issues || []).filter((issue) => issue.level !== "error");
  box.innerHTML = `<h3>${data.valid ? "✓ Model çalıştırılabilir" : `✕ ${errors.length} model hatası`}</h3>
    ${[...errors, ...warnings].slice(0, 20).map((issue) => `<div class="issue"><b>${issue.level === "error" ? "HATA" : "UYARI"}</b><span><code>${esc(issue.path)}</code> — ${esc(issue.message)}</span></div>`).join("") || `<p>Yapısal sözleşme, ifadeler ve nedensel grafik geçerli.</p>`}
    ${(errors.length + warnings.length) > 20 ? `<p>İlk 20 kayıt gösteriliyor.</p>` : ""}`;
  box.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function renderGraph() {
  if (!state.scenario) return;
  const s = state.scenario;
  const columns = [
    { kind: "driver", label: "SÜRÜCÜ", x: 22, nodes: Object.entries(s.drivers).map(([id, spec]) => ({ id, spec, kind: "driver" })) },
    { kind: "equation", label: "MODEL", x: 265, nodes: Object.entries(s.equations).map(([id, spec]) => ({ id, spec, kind: "equation" })) },
    { kind: "state", label: "DURUM", x: 510, nodes: Object.entries(s.states).map(([id, spec]) => ({ id, spec, kind: "state" })) },
    { kind: "metric", label: "ÇIKTI", x: 755, nodes: Object.entries(s.metrics).map(([id, spec]) => ({ id, spec, kind: "metric" })) },
  ];
  const maxRows = Math.max(1, ...columns.map((col) => col.nodes.length));
  const height = Math.max(500, 70 + maxRows * 54);
  const all = new Map();
  columns.forEach((column) => {
    const gap = (height - 85) / Math.max(1, column.nodes.length);
    column.nodes.forEach((node, index) => {
      node.x = column.x;
      node.y = 48 + index * gap;
      node.w = 205;
      node.h = 39;
      all.set(node.id, node);
    });
  });
  const edges = [];
  columns.slice(1).forEach((column) => column.nodes.forEach((target) => {
    const expression = graphExpression(target);
    const tokens = expression.match(/[A-Za-z_][A-Za-z0-9_]*/g) || [];
    [...new Set(tokens)].forEach((token) => {
      const clean = token.startsWith("prev_") ? token.slice(5) : token;
      const source = all.get(clean);
      if (source && source.id !== target.id) edges.push([source, target]);
    });
  }));
  const selectedId = state.selectedNode;
  const svg = $("#nodeGraph");
  svg.setAttribute("viewBox", `0 0 990 ${height}`);
  svg.innerHTML = `<defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 Z" fill="#2b4564"></path></marker></defs>
    ${columns.map((column) => `<text class="node-kind" x="${column.x}" y="25">${column.label} · ${column.nodes.length}</text>`).join("")}
    <g>${edges.map(([source, target]) => edgeSvg(source, target, selectedId)).join("")}</g>
    <g>${columns.flatMap((column) => column.nodes).map(nodeSvg).join("")}</g>`;
  $$(".graph-node", svg).forEach((node) => node.addEventListener("click", () => selectNode(node.dataset.node)));
  if (selectedId && all.has(selectedId)) renderNodeInspector(all.get(selectedId));
}

function graphExpression(node) {
  if (node.kind === "equation") return String(node.spec.expression || "");
  if (node.kind === "state") return String(node.spec.transition || "");
  if (node.kind === "metric") return String(node.spec.expression || node.id);
  return "";
}

function edgeSvg(source, target, selectedId) {
  const x1 = source.x + source.w;
  const y1 = source.y + source.h / 2;
  const x2 = target.x;
  const y2 = target.y + target.h / 2;
  const mx = (x1 + x2) / 2;
  const active = selectedId && (source.id === selectedId || target.id === selectedId) ? " active" : "";
  return `<path class="edge${active}" d="M${x1} ${y1} C${mx} ${y1},${mx} ${y2},${x2} ${y2}" marker-end="url(#arrow)"></path>`;
}

function nodeSvg(node) {
  const selectedClass = node.id === state.selectedNode ? " selected" : "";
  return `<g class="graph-node ${node.kind}${selectedClass}" data-node="${esc(node.id)}" transform="translate(${node.x} ${node.y})" role="button" tabindex="0" aria-label="${esc(node.kind)} ${esc(node.id)}">
    <rect width="${node.w}" height="${node.h}"></rect><text x="11" y="16" class="node-kind">${node.kind.toUpperCase()}</text><text x="11" y="31">${esc(truncate(humanize(node.id), 28))}</text></g>`;
}

function selectNode(id) {
  state.selectedNode = id;
  renderGraph();
}

function renderNodeInspector(node) {
  const spec = node.spec || {};
  const expression = graphExpression(node) || (node.kind === "driver" ? driverDescription(spec) : "—");
  $("#nodeInspector").innerHTML = `<span class="eyebrow">${esc(node.kind.toUpperCase())} NODE</span><h2>${esc(humanize(node.id))}</h2><p>${esc(nodeDescription(node))}</p>
    <div class="node-meta"><div><span>Kimlik</span><code>${esc(node.id)}</code></div><div><span>Model / süreç</span><code>${esc(spec.model_id || spec.process || spec.aggregation || "tanımlı değil")}</code></div><div><span>Denklem</span><code>${esc(expression)}</code></div><div><span>Birim</span><code>${esc(spec.unit || "boyutsuz")}</code></div><div><span>Kanıt kaydı</span><code>${esc((spec.evidence_ids || []).join(", ") || "bağlı kayıt yok")}</code></div></div>`;
}

function nodeDescription(node) {
  return {
    driver: "Dış dünyanın belirsizliğini üretir; bütün stratejiler aynı sürücü yolunu görür.",
    equation: "Aynı dönem içindeki nedenleri bir ara değere dönüştürür.",
    state: "Dönemler arası hafıza taşır ve geri besleme üretir.",
    metric: "Dünya sonunda dağılımı ölçülen karar çıktısıdır.",
  }[node.kind];
}

function driverDescription(spec) {
  if (spec.process === "markov") return `Markov: ${(spec.states || []).join(" / ")}`;
  return `${spec.process || "iid"}; μ=${numberFrom(spec.mean, distributionCenter(spec.initial))}; σ=${numberFrom(spec.sigma, distributionSpread(spec.initial))}`;
}

function updateRunEstimate() {
  if (!state.scenario) return;
  const worlds = numeric($("#runWorlds").value, 500);
  const policies = state.scenario.strategies.length;
  const periods = state.scenario.horizon;
  const cells = worlds * policies * periods;
  $("#runEstimate").textContent = `${formatInt(worlds)} olası dünya × ${policies} politika × ${periods} ${state.scenario.step} = ${formatInt(cells)} dönemsel karar hücresi.`;
  $("#runButtonSub").textContent = `${formatInt(worlds * policies)} eşlenmiş strateji-dünya`;
}

async function runSimulation() {
  const valid = await validateModel();
  if (!valid) { showScreen("model"); return; }
  const button = $("#runButton");
  button.disabled = true;
  $("#runProgress").hidden = false;
  setProgress(0, "Koşu kuyruğa alınıyor");
  try {
    const job = await api("/api/run", { method: "POST", body: {
      scenario: state.scenario,
      worlds: numeric($("#runWorlds").value, 500),
      seed: numeric($("#runSeed").value, state.scenario.simulation.seed || 20260817),
    }});
    state.jobId = job.job_id;
    await pollJob();
  } catch (error) {
    button.disabled = false;
    setProgress(0, "Koşu başlatılamadı");
    toast(error.message, true);
  }
}

async function pollJob() {
  try {
    const job = await api(`/api/jobs/${encodeURIComponent(state.jobId)}`);
    state.job = job;
    setProgress(job.progress || 0, job.message || job.status);
    if (job.status === "completed") {
      state.result = job.result;
      state.narrative = job.narrative;
      $("#runButton").disabled = false;
      $("#viewLastResultButton").disabled = false;
      renderResults();
      toast("Projeksiyon tamamlandı");
      setTimeout(() => showScreen("insights"), 350);
      return;
    }
    if (job.status === "failed") throw new Error(job.error || "Simülasyon başarısız");
    setTimeout(pollJob, 650);
  } catch (error) {
    $("#runButton").disabled = false;
    toast(error.message, true);
  }
}

function setProgress(value, message) {
  const percent = Math.max(0, Math.min(100, value * 100));
  $("#progressMessage").textContent = message;
  $("#progressPercent").textContent = `${percent.toFixed(0)}%`;
  $("#progressBar").style.width = `${percent}%`;
}

function renderResults() {
  const result = state.result;
  if (!result) return;
  $("#emptyInsights").hidden = true;
  $("#resultsWorkspace").hidden = false;
  const meta = result.metadata;
  $("#resultMeta").textContent = `${formatInt(meta.worlds)} dünya · ${meta.strategies} strateji · ${meta.horizon} ${meta.step} · ${Number(meta.runtime_seconds || 0).toFixed(1)} sn · tohum ${meta.seed}`;
  renderVerdict();
  renderRanking();
  renderIntervals();
  renderPairwise();
  renderFutures();
  renderSensitivity();
  renderStress();
}

function renderVerdict() {
  const winner = state.result.summary.ranking[0];
  const n = state.narrative || {};
  $("#verdictCard").innerHTML = `<span class="eyebrow">ÖNE ÇIKAN POLİTİKA</span><h2>${esc(n.headline || winner.label)}</h2><p>${esc(n.why || "")}</p>${n.comparison ? `<p>${esc(n.comparison)}</p>` : ""}
    <div class="verdict-grid"><div><b>${pct(winner.expected_utility)}</b><span>Beklenen fayda</span></div><div><b>${pct(winner.utility_cvar)}</b><span>En kötü %10 / CVaR</span></div><div><b>${pct(winner.success_probability)}</b><span>Başarı olasılığı</span></div></div>`;
}

function renderRanking() {
  $("#rankingGrid").innerHTML = state.result.summary.ranking.map((row, index) => `<article class="rank-card ${index === 0 ? "winner" : ""}">
    <header><span class="rank-number">#${row.rank} KARAR SKORU</span><span class="eligibility ${row.eligible ? "" : "fail"}">${row.eligible ? "KISITLARI GEÇTİ" : "KISIT İHLALİ"}</span></header>
    <h3>${esc(row.label)}</h3><div class="decision-score">${pct(row.decision_score)}</div>
    <div class="rank-metrics"><div><span>Beklenen fayda</span><b>${pct(row.expected_utility)}</b></div><div><span>En kötü %10 / CVaR</span><b>${pct(row.utility_cvar)}</b></div><div><span>Sağlamlık</span><b>${pct(row.robustness)}</b></div><div><span>Başarı</span><b>${pct(row.success_probability)}</b></div><div><span>Ruin riski</span><b>${pct(row.ruin_probability)}</b></div></div>
    <div class="rank-bar"><i style="width:${Math.max(0, Math.min(100, row.decision_score * 100))}%"></i></div>
  </article>`).join("");
}

function renderIntervals() {
  const rows = state.result.summary.ranking;
  const low = Math.min(...rows.map((row) => row.utility_p05));
  const high = Math.max(...rows.map((row) => row.utility_p95));
  const range = Math.max(.0001, high - low);
  $("#intervalChart").innerHTML = rows.map((row) => {
    const left = (row.utility_p05 - low) / range * 100;
    const width = (row.utility_p95 - row.utility_p05) / range * 100;
    const mid = (row.utility_p50 - low) / range * 100;
    return `<div class="interval-row"><div class="interval-label"><b>${esc(row.label)}</b><small>fayda dağılımı</small></div><div class="interval-axis"><i class="interval-line" style="left:${left}%;width:${width}%"></i><i class="interval-mid" style="left:${mid}%"></i></div><div class="interval-values">${pct(row.utility_p05)} · <b>${pct(row.utility_p50)}</b> · ${pct(row.utility_p95)}</div></div>`;
  }).join("");
}

function renderPairwise() {
  const labels = Object.fromEntries(state.result.summary.ranking.map((row) => [row.strategy_id, row.label]));
  $("#pairwisePanel").innerHTML = (state.result.pairwise || []).map((row) => `<article class="pair-card"><header><span>${esc(labels[row.left] || row.left)} ↔ ${esc(labels[row.right] || row.right)}</span><strong>${pct(row.p_left_better)}</strong></header><p>Soldaki politikanın daha iyi olma olasılığı. Ortalama fayda farkı ${signed(row.mean_utility_delta, 3)}; %90 aralık ${signed(row.p05_delta, 3)}…${signed(row.p95_delta, 3)}.</p></article>`).join("") || `<p class="section-copy">İkili karşılaştırma yok.</p>`;
}

function renderFutures() {
  const futures = state.result.future_families || [];
  if (state.activeFuture >= futures.length) state.activeFuture = 0;
  $("#futureList").innerHTML = futures.map((family, index) => `<button class="future-button ${index === state.activeFuture ? "active" : ""}" data-future="${index}" type="button"><span><b>Aile ${family.cluster_id}</b><strong>${pct(family.probability)}</strong></span><small>${esc(family.label)}</small></button>`).join("") || `<p>Gelecek ailesi üretilemedi.</p>`;
  $$(".future-button").forEach((button) => button.addEventListener("click", () => { state.activeFuture = Number(button.dataset.future); renderFutures(); }));
  const family = futures[state.activeFuture];
  if (!family) { $("#futureDetail").innerHTML = ""; return; }
  const labels = Object.fromEntries(state.result.summary.ranking.map((row) => [row.strategy_id, row.label]));
  const drivers = Object.entries(family.driver_z || {}).sort((a,b) => Math.abs(b[1]) - Math.abs(a[1])).slice(0, 8);
  $("#futureDetail").innerHTML = `<span class="eyebrow">GELECEK AİLESİ ${family.cluster_id}</span><h3>${esc(family.label)}</h3><div class="future-probability">${pct(family.probability)}</div><p class="section-copy">${formatInt(family.worlds)} dünya bu aileye düştü. Buradaki en iyi politika: <b>${esc(labels[family.best_strategy_id] || family.best_strategy_id)}</b>.</p>
    <div class="driver-z-list">${drivers.map(([id, z]) => `<div>${esc(humanize(id.replace(/^driver_/, "").replace(/_mean$/, "")))}<b>${signed(z, 2)}σ</b></div>`).join("")}</div>
    ${(family.strategies || []).map((row) => `<div class="family-strategy"><b>${esc(labels[row.strategy_id] || row.strategy_id)}</b><span>fayda ${pct(row.mean_utility)}</span><span>başarı ${pct(row.success_probability)}</span></div>`).join("")}`;
}

function renderSensitivity() {
  const winnerId = state.result.summary.recommended_strategy_id || state.result.summary.ranking[0].strategy_id;
  const rows = (state.result.sensitivity?.[winnerId] || []).filter((row) => row.kind === "main").slice(0, 12);
  const max = Math.max(.001, ...rows.map((row) => row.absolute_effect));
  $("#sensitivityPanel").innerHTML = rows.map((row, index) => `<button class="sensitivity-row ${row.spearman < 0 ? "negative" : ""}" data-sensitivity="${index}" type="button"><span>${esc(humanizeSensitivity(row.driver))}</span><i class="sensitivity-track"><i style="width:${row.absolute_effect / max * 100}%"></i></i><b>${signed(row.spearman, 2)}</b></button>`).join("") || `<p class="section-copy">Bu koşuda hassasiyet sıralaması üretilemedi.</p>`;
  $$("[data-sensitivity]").forEach((button) => button.addEventListener("click", () => renderTrace(rows[Number(button.dataset.sensitivity)])));
  if (rows[0]) renderTrace(rows[0]);
}

function renderTrace(row) {
  const scenario = state.scenario;
  let raw = row.driver;
  let base = raw.replace(/^driver_/, "").replace(/_(mean|min|max|final)$/, "");
  let kind = raw.startsWith("driver_") ? "Belirsizlik sürücüsü" : raw.startsWith("actor_") ? "Sanal aktör davranışı" : raw.startsWith("policy_") ? "Politika kuralı" : "Koşu özelliği";
  const linked = [];
  Object.entries(scenario.equations).forEach(([id, spec]) => {
    if (new RegExp(`\\b${escapeRegExp(base)}\\b`).test(String(spec.expression || ""))) linked.push({ id, spec });
  });
  Object.entries(scenario.states).forEach(([id, spec]) => {
    if (new RegExp(`\\b${escapeRegExp(base)}\\b`).test(String(spec.transition || ""))) linked.push({ id, spec });
  });
  const model = linked[0];
  const evidenceIds = model?.spec?.evidence_ids || [];
  const evidence = evidenceIds.map((id) => scenario.evidence.find((item) => item.id === id)).filter(Boolean);
  $("#tracePanel").innerHTML = `<span class="eyebrow">AUDIT TRAIL</span><h2>${esc(humanizeSensitivity(raw))}</h2><p>İlişki yönü <b>${row.spearman >= 0 ? "pozitif" : "negatif"}</b>; sıra korelasyonu ${signed(row.spearman, 3)}. Bu nedensellik kanıtı değil, hangi worlds ayrımının sonuçla birlikte değiştiğini gösterir.</p>
    <div class="trace-chain"><div class="trace-step"><span>Sonuç</span><b>Önerilen politikanın dünya faydası</b></div><div class="trace-step"><span>${esc(kind)}</span><code>${esc(raw)}</code></div><div class="trace-step"><span>Bağlı model</span><b>${esc(model?.spec?.model_id || model?.id || "Doğrudan bir model düğümüne eşlenmedi")}</b>${model ? `<code>${esc(graphExpression({kind: model.spec.transition ? "state" : "equation", id: model.id, spec: model.spec}))}</code>` : ""}</div><div class="trace-step"><span>Kanıt / varsayım</span>${evidence.length ? evidence.map((item) => `<b>${esc(item.id)} · kalite ${esc(item.quality || "?")}</b><code>${esc(item.source || item.note || "")}</code>`).join("") : `<b>Doğrudan kaynak kaydı yok</b><code>Bu etki aktör/politika özeti veya türetilmiş koşu özelliği olabilir.</code>`}</div></div>`;
}

function renderStress() {
  const labels = Object.fromEntries(state.result.summary.ranking.map((row) => [row.strategy_id, row.label]));
  $("#stressTable").innerHTML = (state.result.stress_profiles || []).map((stress) => {
    const winner = (stress.strategies || []).find((row) => row.strategy_id === stress.best_strategy_id) || stress.strategies?.[0];
    return `<tr><td><b>${esc(stress.label)}</b><br><small>${esc(stress.condition || "")}</small></td><td>${winner ? pct(winner.probability) : "—"}</td><td>${esc(labels[stress.best_strategy_id] || stress.best_strategy_id || "—")}</td><td>${winner ? pct(winner.expected_utility) : "—"}</td><td>${winner ? pct(winner.success_probability) : "—"}</td></tr>`;
  }).join("") || `<tr><td colspan="5">Tanımlı stres testi yok.</td></tr>`;
}

function openDownload(filename, newTab = false) {
  if (!state.jobId) return toast("Önce bir koşu tamamla", true);
  const url = `/api/jobs/${encodeURIComponent(state.jobId)}/download/${encodeURIComponent(filename)}`;
  if (newTab) window.open(url, "_blank", "noopener"); else window.location.href = url;
}

async function saveProject() {
  const name = $("#projectName").value.trim() || state.scenario.meta.name;
  try {
    const data = await api("/api/projects", { method: "POST", body: { name, scenario: state.scenario } });
    state.dirty = false;
    state.valid = true;
    renderHealth();
    const projectData = await api("/api/projects");
    state.projects = projectData.projects || [];
    toast(`Kaydedildi: ${data.id}`);
  } catch (error) { toast(error.message, true); }
}

function openProjects() {
  renderProjectList();
  const dialog = $("#projectDialog");
  if (typeof dialog.showModal === "function") dialog.showModal(); else dialog.setAttribute("open", "");
}

function renderProjectList() {
  $("#projectList").innerHTML = state.projects.map((project) => `<button class="project-item" data-project="${esc(project.id)}" type="button"><b>${esc(project.name)}</b><small>${esc(project.scenario_id)} · ${formatDate(project.modified_at)}</small></button>`).join("") || `<p class="section-copy">Henüz kayıtlı proje yok.</p>`;
  $$("[data-project]").forEach((button) => button.addEventListener("click", () => loadProject(button.dataset.project)));
}

async function loadProject(id) {
  try {
    state.scenario = normalizeScenario(await api(`/api/projects/${encodeURIComponent(id)}`));
    state.selectedStrategy = state.scenario.strategies[0]?.id || null;
    state.dirty = false; state.valid = null;
    $("#projectName").value = state.scenario.meta.name;
    $("#projectDialog").close();
    renderAll(); toast("Kayıtlı model açıldı");
  } catch (error) { toast(error.message, true); }
}

function showScreen(tab) {
  state.activeTab = tab;
  $$(".stage-tab").forEach((button) => {
    const active = button.dataset.tab === tab;
    button.classList.toggle("active", active);
    button.setAttribute("aria-selected", String(active));
  });
  $$(".workspace-screen").forEach((screen) => screen.hidden = screen.id !== `screen-${tab}`);
  if (tab === "lab") renderGraph();
  if (tab === "insights" && state.result) renderResults();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function markDirty() {
  state.dirty = true;
  state.valid = null;
  renderHealth();
}

function toast(message, error = false) {
  const node = document.createElement("div");
  node.className = `toast ${error ? "error" : ""}`;
  node.textContent = message;
  $("#toastRegion").append(node);
  setTimeout(() => node.remove(), 4200);
}

function numeric(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function numberFrom(value, fallback = 0) { return Number.isFinite(Number(value)) ? Number(value) : fallback; }
function distributionCenter(spec) {
  if (!spec || typeof spec !== "object") return numberFrom(spec, 1);
  return numberFrom(spec.mean, numberFrom(spec.median, (numberFrom(spec.low, 0) + numberFrom(spec.high, 2)) / 2));
}
function distributionSpread(spec) {
  if (!spec || typeof spec !== "object") return .1;
  return numberFrom(spec.sd, numberFrom(spec.sigma, .1));
}
function selected(value, expected) { return (value || "iid") === expected ? "selected" : ""; }
function roundInput(value) { return Number.isFinite(Number(value)) ? Number(Number(value).toPrecision(7)) : 0; }
function humanize(value) { return String(value).replace(/_/g, " ").replace(/\b\w/g, (c) => c.toLocaleUpperCase("tr-TR")); }
function humanizeSensitivity(value) { return humanize(String(value).replace(/^driver_/, "").replace(/_(mean|min|max|final)$/, "").replace(/^actor_/, "Aktör ").replace(/^policy_/, "Politika ").replace(/_share_mean$/, " payı")); }
function truncate(value, length) { return value.length > length ? `${value.slice(0, length - 1)}…` : value; }
function slugIdentifier(value) { return String(value).trim().toLocaleLowerCase("tr-TR").replace(/[çÇ]/g,"c").replace(/[ğĞ]/g,"g").replace(/[ıİ]/g,"i").replace(/[öÖ]/g,"o").replace(/[şŞ]/g,"s").replace(/[üÜ]/g,"u").replace(/[^a-z0-9_]+/g, "_").replace(/^\d+/, "").replace(/^_+|_+$/g, ""); }
function slugFile(value) { return slugIdentifier(value) || "spx-model"; }
function formatInt(value) { return new Intl.NumberFormat("tr-TR", { maximumFractionDigits: 0 }).format(Number(value || 0)); }
function formatDate(value) { try { return new Intl.DateTimeFormat("tr-TR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value)); } catch { return value; } }
function pct(value) { return value != null && Number.isFinite(Number(value)) ? `%${(Number(value) * 100).toFixed(1)}` : "—"; }
function signed(value, digits = 2) { const number = value == null ? NaN : Number(value); return Number.isFinite(number) ? `${number >= 0 ? "+" : ""}${number.toFixed(digits)}` : "—"; }
function escapeRegExp(value) { return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
function cssEscape(value) { return window.CSS?.escape ? CSS.escape(value) : String(value).replace(/"/g, "\\\""); }
function esc(value) { return String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char])); }

function downloadBlob(content, filename, type) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const link = document.createElement("a");
  link.href = url; link.download = filename; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
