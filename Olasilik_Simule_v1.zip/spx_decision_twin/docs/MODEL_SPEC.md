# `operations_v1` karar sözleşmesi

Bu belge Olasılık Simüle v1 ana motorunun JSON sözleşmesini açıklar. Elle JSON yazmak zorunlu değildir; Studio veya `spx new kararim.json` geçerli bir başlangıç üretir.

## 1. Üst seviye

| Alan | Görevi |
| --- | --- |
| `meta` | Kimlik, ad, sürüm, motor, veri statüsü, kurucu girdisi |
| `decision` | Soru, sahip, son tarih, ufuk, geri döndürülebilirlik, başarı tanımı |
| `horizon`, `step` | 3–60 ay ve `ay` zaman birimi |
| `baseline` | Karar anındaki operasyon/finans state'i |
| `uncertainty` | Dış süreç ve model parametre merkezleri |
| `simulation` | Dünya, seed, gelecek ağacı ve trace ayarları |
| `strategies` | Eylem paketleri; görünen alan + aynı motor parametresi |
| `objectives` | Çok amaçlı tercih ölçekleri |
| `constraints` | Sert/yumuşak sınırlar, risk bütçesi ve ceza |
| `success` | Başarı olayının eşikleri |
| `evidence` | Kaynak/varsayım kayıtları |
| `parameter_registry` | Merkez, aralık, statü ve kaynak bağı |
| `model_registry` | Yedi alt model ve girdi/çıktı sözleşmesi |
| `stress_tests` | Koşullu zor dünya tanımları |

## 2. Meta ve karar

```json
{
  "meta": {
    "id": "decision_ornek_uretim_18m",
    "name": "Örnek Üretim — Karar Laboratuvarı",
    "version": "1.0.0",
    "engine": "operations_v1",
    "data_status": "ILLUSTRATIVE",
    "human_approval_required": true,
    "builder_input": {}
  },
  "decision": {
    "question": "Önümüzdeki 18 ayda kapasiteyi artırmalı mıyız?",
    "owner": "İşletme sahibi",
    "deadline": "Bu ay",
    "horizon_months": 18,
    "reversibility": "medium"
  },
  "horizon": 18,
  "step": "ay"
}
```

`reversibility`: `low`, `medium` veya `high`. Bu sürüm etiketi raporlar; otomatik ağırlık değiştirmez.

## 3. Başlangıç durumu

```json
"baseline": {
  "monthly_demand": 4800.0,
  "unit_price": 140.0,
  "variable_cost_per_unit": 62.0,
  "fixed_cost_monthly": 240000.0,
  "starting_cash": 1500000.0,
  "machine_count": 4,
  "machine_capacity_per_day": 58.0,
  "worker_count": 18,
  "worker_capacity_per_day": 14.0,
  "working_days_per_month": 26,
  "starting_inventory_units": 2400.0,
  "starting_backlog_units": 120.0,
  "added_worker_monthly_cost": 20000.0,
  "machine_purchase_cost": 650000.0
}
```

`machine_count`, `worker_count` ve kapasite değerleri aynı çıktı birimini kullanmalıdır. Stok birimi de bu çıktıyla uyumlu olmalıdır.

## 4. Belirsizlik merkezleri

```json
"uncertainty": {
  "annual_demand_trend": 0.04,
  "demand_volatility": 0.14,
  "demand_persistence": 0.68,
  "annual_cost_inflation": 0.22,
  "absence_rate": 0.06,
  "supplier_normal_fill": 0.94,
  "supplier_disruption_probability": 0.08,
  "supplier_lead_months": 1,
  "failure_weibull_shape": 2.10,
  "failure_weibull_scale_days": 540.0,
  "mean_repair_days": 4.0,
  "price_elasticity": 1.25,
  "marketing_elasticity": 0.80,
  "base_defect_rate": 0.025,
  "parameter_uncertainty": 0.20
}
```

`demand_volatility` yıllıklaştırılmış log-oynaklıktır; motor aylık şok için `σ/√12` kullanır. Yüzdeler JSON'da oran olarak yazılır: `%14 = 0.14`.

## 5. Strateji

```json
{
  "id": "resilience_first",
  "label": "Dayanıklılık önce",
  "description": "Bakım, eğitim ve stok tamponu kurar.",
  "start_month": 2,
  "added_machines": 1,
  "added_workers": 2,
  "upfront_investment": 460000.0,
  "marketing_rate": 0.035,
  "price_change": 0.015,
  "maintenance_interval_days": 75,
  "maintenance_downtime_days": 1,
  "safety_stock_days": 18.0,
  "training_rate": 0.09,
  "overtime_limit": 0.08,
  "cash_brake": true,
  "parameters": {
    "start_month": 2.0,
    "added_machines": 1.0,
    "added_workers": 2.0,
    "upfront_investment": 460000.0,
    "marketing_rate": 0.035,
    "price_change": 0.015,
    "maintenance_interval_days": 75.0,
    "maintenance_downtime_days": 1.0,
    "safety_stock_days": 18.0,
    "training_rate": 0.09,
    "overtime_limit": 0.08,
    "cash_brake": 1.0
  }
}
```

Görünen kontrol ile `parameters` içindeki değer aynı olmalıdır. Motor sessizce farklı bir değer çalıştırmaz; doğrulama uyuşmazlığı hata sayar. En az iki, en fazla altı strateji kullanılır.

## 6. Tercihler, amaçlar ve kısıtlar

Studio girdisindeki `preferences` kurucu tarafından objective ve constraint listesine çevrilir. Üretilen objective örneği:

```json
{
  "id": "service",
  "metric": "average_service_level",
  "direction": "max",
  "worst": 0.45,
  "best": 0.99,
  "weight": 0.18
}
```

Desteklenen `direction`: `min`, `max`. Amaç metriği aşağıdaki motor çıktılarından biri olmalıdır:

`final_cash`, `minimum_cash`, `cumulative_profit`, `total_revenue`, `average_service_level`, `minimum_service_level`, `average_quality_rate`, `minimum_employee_energy`, `max_backlog`, `final_backlog`, `stockout_months`, `downtime_days`, `failure_count`, `preventive_events`, `lost_orders`, `ending_inventory`, `optionality_score`.

Kısıt:

```json
{
  "id": "cash_floor",
  "metric": "minimum_cash",
  "op": ">=",
  "value": 0,
  "hard": true,
  "ruin": true,
  "max_violation_probability": 0.12,
  "penalty": 0.60
}
```

`op`: `>=`, `>`, `<=`, `<`, `==`. `hard=true`, dünya bazında mutlak imkânsızlık anlamına gelmez; strateji düzeyinde ihlal olasılığı `max_violation_probability` değerini aşarsa seçeneği uygunsuz yapar. `ruin=true`, ihlali ruin olayına dahil eder.

## 7. Başarı olayı

```json
"success": {
  "minimum_cash": 0.0,
  "minimum_service_level": 0.75,
  "maximum_stockout_months": 8
}
```

Başarı ayrıca `cumulative_profit > 0` ister. Bu tanım olasılık ekranında açıkça gösterilir.

## 8. Simülasyon ve karar politikası

```json
"simulation": {
  "worlds": 1000,
  "seed": 20260817,
  "tail_alpha": 0.10,
  "future_tree_depth": 3,
  "future_tree_min_mass": 0.07,
  "trace_worlds": 4
},
"decision_policy": {
  "acceptance_utility": 0.55,
  "tail_alpha": 0.10,
  "expected_weight": 0.22,
  "tail_weight": 0.26,
  "robustness_weight": 0.22,
  "success_weight": 0.15,
  "regret_weight": 0.15
}
```

Studio API 1–100.000 dünya kabul eder. 100 dünya mekanik yön testi; 300 ilk keşif; 1.000 karar koşusu; daha büyük koşu sunum/kararlılık içindir.

## 9. Evidence Registry

```json
{
  "id": "E-BASELINE-MONTHLY-DEMAND",
  "type": "estimated",
  "source": "decision-room:baseline.monthly_demand",
  "fingerprint": "case-id:baseline.monthly_demand",
  "quality": "C",
  "validity": "until-case-update",
  "note": "Bağımsız doğrulama yapılmadı."
}
```

Yapısal denklemler ayrıca `E-MODEL-STRUCTURE` kaydına bağlanır. Bir kullanıcı değeri “ölçüldü” işaretlemekle otomatik olarak doğru olmaz; kaynak notu ve historical replay yine gerekir.

## 10. Parameter Registry

```json
{
  "id": "baseline.monthly_demand",
  "label": "monthly demand",
  "value": 4800.0,
  "low": 4272.0,
  "high": 5328.0,
  "uncertainty_kind": "measurement",
  "status": "ESTIMATED",
  "source_id": "E-BASELINE-MONTHLY-DEMAND"
}
```

Geçerli statüler: `OBSERVED`, `ESTIMATED`, `ASSUMPTION`. Motor doğrudan bu `low/value/high` aralığından örnekler; registry yalnız rapor metadatası değildir.

## 11. Model Registry

Tam yedi kayıt zorunludur:

1. `DEMAND-REGIME-AR1-v1`
2. `RELIABILITY-WEIBULL-DES-v1`
3. `WORKFORCE-COHORT-v1`
4. `SUPPLY-INVENTORY-v1`
5. `OPERATIONS-FLOW-v1`
6. `FINANCE-CASHFLOW-v1`
7. `DECISION-RDM-v1`

Her kayıt `label`, `family`, `inputs`, `outputs`, `evidence_ids` taşır. Eksik kayıt koşuyu durdurur.

## 12. Geçmiş veri içe alma

Studio beşinci adımda CSV/TSV benzeri satırları kabul eder:

```text
ay,siparis,ciro,degisken_gider,sabit_gider,devamsizlik,ariza,hizmet
2026-01,4200,588000,260400,240000,0.05,1,0.91
```

En az dört geçerli satırda desteklenen alanlar kalibre edilir:

- talep merkezi;
- birim fiyat;
- birim değişken gider;
- sabit gider;
- yıllık talep trendi ve oynaklığı;
- devamsızlık.

Arıza ve hizmet sütunları korunur fakat v1 otomatik Weibull parameter fit veya historical replay yapmaz; bunun yapıldığını iddia etmez.

## 13. Eski genel sözleşme

`meta.engine` alanı `operations_v1` değilse eski güvenli ifade/DAG sözleşmesi kullanılır. `drivers`, `correlations`, `actors`, `shocks`, `equations`, `states`, `metrics` ve string `success` alanları için v0.3 örnek JSON'larına bak. Studio'nun karar kurucusu bu genel sözleşmeyi otomatik üretmez.
