# Olasılık Simüle v1 — Ürün ve algoritma sözleşmesi

## Ürünün ana sorusu

“Şirketim gelecekte ne olacak?” değil:

> “Bu belirli kararı verirsem, hangi koşul birleşimlerinde işe yarar veya kırılır; başka bir karar aynı dünyalarda ne yapardı ve hangi yeni bilgi seçimimi değiştirebilir?”

## Ana kullanıcı akışı

1. **Karar Odası:** karar, sahibi, son tarih, ufuk, alternatifler, geri döndürülebilirlik ve başarı/başarısızlık tanımı.
2. **Sistem Haritası:** yalnız kararı etkileyen talep, kapasite, ekipman, çalışan, tedarik ve nakit modülleri.
3. **Varsayım & Kanıt:** her sayı için gözlem/tahmin/varsayım, aralık, kaynak notu ve geçerlilik.
4. **Deney Laboratuvarı:** stratejiler aynı dış dünyalarda çalışır; kullanıcı tek müdahaleyi değiştirip karşı-olgusal farkı ölçer.
5. **Gelecek Haritası:** dallar koşul, kütle, koşullu sonuç ve strateji değişimini gösterir.
6. **Karar Defteri:** karar durumu, kırılganlıklar, tetikleyiciler, veri toplama önceliği ve model sınırları.

## İlk derin model: operasyon / kapasite kararı

Model federasyonu şu alt sistemleri birleştirir:

| Alt model | Mekanik | Ana çıktılar |
|---|---|---|
| Talep | rejim + AR süreç + fiyat/pazarlama tepkisi | sipariş, kayıp talep |
| Ekipman | yaşa bağlı Weibull tehlikesi + günlük arıza/onarım olayları | makine-gün, duruş, bakım maliyeti |
| İşgücü | devamsızlık, beceri, yorgunluk ve eğitim geri beslemesi | kullanılabilir kapasite, kalite |
| Tedarik | güvenilirlik yolu, gecikme, stok tamponu | malzeme kıtlığı, stok maliyeti |
| Operasyon | talep/backlog, kapasite ve malzeme birleşimi | üretim, hizmet seviyesi, backlog |
| Finans | gelir, değişken/sabit maliyet, capex, bakım ve nakit akışı | kâr, minimum nakit, runway |

## Belirsizlik katmanları

- **Aleatory:** aynı model doğru olsa bile değişen talep, arıza günü, devamsızlık ve teslimat.
- **Epistemic:** talep elastikiyeti, arıza ölçeği veya pazarlama etkisini yeterince bilmeme.
- **Karar tercihi:** amaç ağırlıkları ve kabul eşikleri; gerçek veri gibi gösterilmez.

Her dünya bu katmanları ayrı isimlerle taşır. Arayüz, “rastgelelik” ile “daha iyi veriyle daraltılabilecek belirsizlik” arasındaki farkı gösterir.

## Gelecek Haritası

K-means listesi yerine açıklanabilir koşullu ağaç kullanılır. Her düğüm şunları taşır:

- model içindeki görülme payı;
- düğüme kadar oluşan koşullar;
- her stratejinin başarı, ruin ve utility dağılımı;
- bu koşullarda öne çıkan strateji;
- bir sonraki ayırıcı sürücü/eşik;
- sürücünün model ve kanıt izi.

İki harita üretilir:

1. **Seçim ne zaman değişiyor?** Hedef sınıf, aynı dünyada en iyi kalan stratejidir.
2. **Plan nerede kırılıyor?** Hedef sınıf, seçili stratejinin başarısızlık/sert kısıt olayıdır.

## Yüzdeden kaynağa zinciri

Her kritik yüzde için:

```text
sonuç yüzdesi
  → olayın açık tanımı ve pay/payda
  → Monte Carlo standart hatası ve yaklaşık %95 aralık
  → gelecek yapraklarının toplam katkısı
  → yaprağı ayıran sürücüler/eşikler
  → sürücüyü üreten alt model ve parametreler
  → gözlem/tahmin/varsayım kaynağı
```

## Karar durumu

Sistem her zaman bir “kazanan” ilan etmez:

- **Net:** eşlenmiş fayda farkı aralığı sıfırı dışarıda bırakır ve sert kısıtlar geçilir.
- **Yakın:** bir seçenek önde görünür fakat fark küçük veya örnekleme hatasıyla uyumludur.
- **Çözümsüz:** farklı gelecek aileleri farklı stratejileri seçer; tetikleyici/adaptif plan gerekir.
- **Uygun seçenek yok:** bütün stratejiler bir sert sınırı kabul edilenden fazla ihlal eder.

## Doğrulama kapıları

1. Şema, birim ve kaynak bütünlüğü.
2. Aynı seed ile byte-düzeyinde tekrar üretilebilirlik.
3. No-op karşı-olgusalda sıfır fark.
4. Yön testi: daha yoğun bakımın arızayı azaltması, tamponun stockout'u azaltması gibi mekanik beklentiler.
5. Ağaç kütlelerinin toplamı ve çocukların ayrıklığı.
6. Dünya sayısı yakınsama kontrolü.
7. Sentetik historical replay ve model kartı.
8. Mobil 320–736 px arayüz ve uçtan uca API testi.

