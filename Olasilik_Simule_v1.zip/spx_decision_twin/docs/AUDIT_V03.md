# SPX Studio v0.3 — Ürün ve model denetimi

## Hüküm

v0.3 teknik olarak çalışan ve tekrarlanabilir bir Monte Carlo kabuğudur; fakat hedeflenen “Decision Twin / Future Graph” ürününün kendisi değildir. En büyük sorun arayüz rengi veya metin uzunluğu değil, ürünün yanlış soyutlamayla başlamasıdır: kullanıcıdan şirket özeti alıp bütün sektörlere aynı genel denklemleri uygular ve sonucu bir sıralama raporuna indirger.

## Kalacak parçalar

- Güvenli ifade çalıştırıcısı ve DAG döngü kontrolü.
- Anahtar tabanlı deterministik tohumlar ve eşlenmiş dünyalar.
- Evidence/model kimlikleri, senaryo hash'i ve yerel SQLite kayıt defteri.
- Termux'ta bağımlılıksız çalışma, yerel HTTP sunucusu ve proje kaydetme.
- CVaR, sert kısıt, pişmanlık ve Pareto gibi karar ölçülerinin ham çıktıları.

## Yeniden yazılacak parçalar

- **Kurulum akışı:** “şirketi tanıt” yerine “tek kritik kararı tanımla”.
- **Model kurucu:** sektör katsayılarıyla tek genel denklem yerine karar sınıfına özgü model modülleri.
- **Simülasyon:** yalnız dönemsel denklemler yerine talep + ekipman güvenilirliği + işgücü + tedarik + nakit alt modellerinin ortak dünyada çalışması.
- **Gelecek aileleri:** k-means etiketi yerine koşullu olasılıkları açık, tıklanabilir karar/failure ağacı.
- **Sonuç anlatımı:** “kazanan strateji” yerine karar durumu, fark belirsizliği, kırılma koşulları, veri ihtiyacı ve karşı-olgusal etki.
- **Kanıt izi:** düğüm seviyesindeki kaba referans yerine parametre → kaynak → model → sonuç zinciri.
- **Arayüz:** model sayıları ve teknik JSON merkezinden; Gelecek Haritası ve Karşı-Olgusal Laboratuvar merkezine.

## Silinecek veya ana akıştan çıkarılacak fikirler

- Her sektörü birkaç bağımlılık katsayısıyla “otomatik simüle ettiği” iddiası.
- Kalibrasyonsuz genel modelde tek bir karar skoru üzerinden kesin öneri.
- Spearman korelasyonunu “neden” açıklaması gibi gösterme.
- 23 düğüm / 6 sürücü gibi model büyüklüğü sayaçlarını kalite göstergesi olarak sunma.
- Başlangıç kullanıcısına AR(1), seed, hazard ve ham JSON'u erken gösterme.

## Bilimsel ve ürün ilkeleri

1. Model şirketin tamamını değil, tek karar için gerekli alt sistemi temsil eder.
2. Rastlantısal değişkenlik ile bilgi/model eksikliği ayrı tutulur.
3. Bir yüzde; olay tanımı, pay/payda, örnekleme hatası ve dayandığı varsayımlarla açılabilir olmalıdır.
4. Hassasiyet nedensellik değildir; gerçek müdahale yalnız yapısal model içinde `do` benzeri değişiklikle hesaplanır.
5. Karar, ortalama puanla değil sert kısıtlar, kötü kuyruk, sağlamlık, trade-off ve kararın tersine döndüğü koşullarla sunulur.
6. Kalibrasyon yoksa sistem güven üretmez; veri boşluğunu görünür kılar.
7. İlk derin dikey “operasyon / kapasite / dayanıklılık”tır. Diğer sektörler ancak ayrı model reçetesiyle eklenir.

