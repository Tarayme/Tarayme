# Olasılık Simüle v1 algoritması

Bu belge Studio'nun ana motoru `operations_v1` için gerçek hesap akışını açıklar. Eski genel DAG motoru geriye dönük uyumluluk amacıyla ayrıca korunur.

## 1. Karar mimarisi

Akış bir şirket “tahmini” değil, tek karar deneyidir:

```text
karar sözleşmesi
  → veri statülü parametre kayıtları
  → ortak dış dünyalar + bilgi belirsizliği
  → yedi bağlı alt model
  → dünya × strateji sonuçları
  → sert sınır + çok amaçlı dağılım
  → gelecek ağacı + olasılık lineage'ı
  → insan onaylı karar durumu
```

Motorun temel ilkesi “en olası geleceği bulmak” değil, geniş bir gelecek kümesinde hangi kararın yeterince iyi kaldığını ve nerede bozulduğunu göstermektir. Bu yaklaşım sağlam karar verme / deep uncertainty literatüründeki çoklu-gelecek düşüncesiyle uyumludur; yazılım belirli bir kurumsal yöntemin eksiksiz uygulaması olduğunu iddia etmez.

## 2. İki belirsizlik katmanı

### 2.1 Bilgi eksikliği (epistemic)

Her parametre kayıt defterinde merkez, alt, üst ve statü taşır:

- `OBSERVED`: merkez çevresinde yaklaşık ±%3;
- `ESTIMATED`: kullanıcının global belirsizlik genişliğinin %55'i;
- `ASSUMPTION`: global genişliğin tamamı.

Her dünya için kayıtlı üçgen dağılımdan bir kez çekilir:

\[
\theta_w \sim \operatorname{Triangular}(\theta_L,\theta_M,\theta_H)
\]

Talep merkezi, birim ekonomi, sabit gider, kapasite, başlangıç nakdi/stoku, trend, oynaklık, tedarik, arıza ve davranış parametreleri bu katmanda değişebilir. Aynı dünya içindeki bütün stratejiler aynı `θ_w` değerini görür.

### 2.2 Doğal rastlantı (aleatory)

Bir parametre doğru bilinse bile talep şoku, arıza günü, devamsız çalışan veya tedarik bozulması rastlantısaldır. Bunlar dönem/gün bazlı çekilir. Bilgi toplamak bu rastlantıyı yok etmez; yalnız parametre aralığını daraltır.

## 3. Anahtar tabanlı tekrar üretilebilirlik

Her uniform/normal çekiliş BLAKE2b tabanlı kararlı bir anahtardan üretilir:

\[
u = H(s_0,w,b,t,d,\ldots)/2^{64}
\]

Burada `s₀` tohum, `w` dünya, `b` bileşen, `t` ay ve `d` gündür. Dış dünya anahtarında strateji kimliği bulunmaz. Böylece Dünya 137'deki talep, tedarik ve temel olay çekilişleri bütün stratejiler için aynıdır. Strateji kapasiteyi değiştirdiğinde aynı çekiliş farklı fiziksel sonuç doğurabilir; bu beklenen karşı-olgusal mekanizmadır.

## 4. Talep ve ekonomik rejim

Ekonomik rejim üç durumlu Markov zinciridir: daralma, normal, genişleme. Her durum talep çarpanı üretir.

Talep log-sapması:

\[
e_t=\rho e_{t-1}+\frac{\sigma_y}{\sqrt{12}}z_t
\]

Yıllık trend zaman içinde gerçekten birikir:

\[
D^{exo}_t=\operatorname{clip}\left(
M_t\exp\left(\frac{t}{12}\log(1+g_y)+e_t\right),0.20,3.50
\right)
\]

Strateji ve müşteri güveni eklendiğinde sipariş merkezi:

\[
\bar Q_t=Q_0D^{exo}_t
\exp(2.4\,\beta_m m_t)
\exp(-\beta_p\Delta p)
(0.72+0.38T_{t-1})
\]

Gerçek sipariş, bu merkez çevresinde ölçeği `√Q` olan ortak normal inovasyonla oluşur. Model fiyat/pazarlama katsayılarını nedensel olarak keşfetmez; kullanıcı aralığı içinde yapısal varsayım olarak çalıştırır.

Maliyet endeksi yıllık log-drift ve aylık şokla çarpımsal yürür. Daralma rejiminde ek maliyet baskısı uygulanır.

## 5. Ekipman güvenilirliği ve olay simülasyonu

Her makine günlük yaş taşır. Weibull kümülatif hazard:

\[
H(a)=\left(\frac{a}{\eta}\right)^k
\]

Yaşı `a` olan makinenin sonraki gün arıza olasılığı:

\[
p_f(a)=1-\exp[-(H(a+1)-H(a))]
\]

Arıza olursa lognormal-benzeri onarım süresi çekilir ve makine olay bitene kadar kapasite üretmez. Onarım sonrası etkin yaş kısmen, önleyici bakım sonrası daha güçlü azaltılır. Bakım aralığına ulaşan makine planlı duruş ve bakım maliyeti üretir.

Bu ayrı bir dış DES paketi değil, aylık model içine gömülmüş günlük olay zamanlamasıdır. Makine-durum vektörü, onarım/bakım sayaçları ve olay sırası gerçek state olarak saklanır.

## 6. Çalışan kapasitesi

Her iş günündeki mevcut çalışan sayısı, cohort büyüklüğü ve devamsızlık olasılığından yaklaşık binomial çekilir. Devamsızlık:

\[
p_{abs,t}=\operatorname{clip}(p^{exo}_{abs,t}+0.11F_{t-1}-0.05r_{train},0,0.75)
\]

Eğitim kısa vadede üretilebilir iş gününü azaltır, uzun vadede beceriyi yükseltir. Fazla mesai darboğaz baskısına göre sınırlı açılır; yorgunluğu ve kalite hatasını artırır. Beceri, yorgunluk ve çalışan enerjisi aylık geri besleme state'leridir.

## 7. Tedarik ve stok kuyruğu

Her sipariş `due_month → quantity` olay kuyruğuna girer. Vadesi gelen miktarın yalnız tedarik karşılama oranı kadar kısmı alınır; kalan miktar sonraki aya yeniden kuyruğa girer. Şiddetli tedarik baskısı lead-time'a bir ay ekler.

Yeni sipariş politikası:

\[
Order_{t+L}=\max(0,\bar Q_t+TargetStock_t-Inventory_t-Pipeline_t)
\]

\[
TargetStock_t=\bar Q_t\frac{SafetyDays}{WorkingDays}
\]

Alınan malzeme geldiği ay nakit çıkışı yaratır. Stockout, talep/kapasiteyle üretilebilecek miktarın yalnız malzeme eksikliği nedeniyle üretilememesi olarak tanımlanır.

## 8. Operasyon akışı

Toplam istek yeni sipariş ile önceki backlog'un, iptal sonrası kalan toplamıdır. Kapasite üç darboğazın minimumudur:

\[
Production_t=\min(Request_t,MachineCapacity_t,WorkerCapacity_t,Inventory_t)
\]

Kalite hatası yorgunluk, yüksek kullanım ve fazla mesaiyle artar; eğitimle azalır. Hizmet seviyesi iyi birimlerin o ay karşılanması gereken toplam isteğe oranıdır:

\[
Service_t=\operatorname{clip}\left(\frac{GoodUnits_t}{Request_t},0,1\right)
\]

Backlog, güveni; güven de sonraki talebi ve iptali etkiler. Böylece kapasite problemi yalnız tek dönemli bir formül değil, davranışsal geri besleme üretir.

## 9. Nakit ve kârlılık

Kâr tahakkuk görünümünde satıştan COGS ve dönem giderleri düşülür. Nakit görünümünde malzeme gideri satış anında değil tedarik tesliminde çıkar:

\[
Cash_t=Cash_{t-1}+Revenue_t-Procurement_t-Fixed_t-Labor_t
-Maintenance_t-Quality_t-Capex_t
\]

Minimum nakit bütün ufuk boyunca izlenir. Stratejinin `cash_brake` politikası tetiklenirse pazarlama, fazla mesai, eğitim ve stok hedefi otomatik sınırlandırılır. Bu adaptif bir yedek politikadır; sonuç raporunda kaç kez devreye girdiği trace üzerinden görülebilir.

## 10. Amaçlar, kısıtlar ve utility

Her amaç `worst → best` tercih ölçeğinde `[0,1]` desirability'ye dönüşür:

\[
d_i(y)=\operatorname{clip}\left(\frac{y-w_i}{b_i-w_i},0,1\right)^{q_i}
\]

Minimizasyon yönünde ölçek ters çevrilir. Ağırlıklı temel fayda:

\[
U^0_w=\frac{\sum_i\omega_i d_i(y_w)}{\sum_i\omega_i}
\]

Kısıt cezaları toplamsal çıkarılıp sıfıra yığılmaz; ihlal başına çarpan uygulanır:

\[
U_w=U^0_w\prod_{k\in V_w}(1-\lambda_k)
\]

Böylece kötü kuyrukta farklı şiddette sonuçlar ayrışmaya devam eder. Bir stratejinin hard constraint ihlal olasılığı izin verilen risk bütçesini aşarsa strateji “uygun” değildir; tek karar skoru bu elemenin üstüne geçemez.

## 11. Dağılım tabanlı karar ölçüleri

- Beklenen fayda `E[U]`.
- P5/P50/P95 utility.
- Alt-kuyruk CVaR: `E[U | U ≤ Qα(U)]`.
- Başarı: pozitif kâr + nakit/hizmet/stockout sözleşmesi.
- Ruin: hayatta kalma etiketi taşıyan sert sınır ihlali.
- Sağlamlık: kabul utility'si ve bütün tanımlı sınırları geçen dünya payı.
- Pişmanlık: `max_j U(w,j) - U(w,s)`.
- Pareto: amaçların ortalama metriklerinde başka bir strateji tarafından domine edilmeyen seçenekler.

Karar skoru beklenen fayda, CVaR, sağlamlık, başarı ve `1−ortalama pişmanlık` bileşimidir. Ham bileşenler daima ayrıca gösterilir.

## 12. Karar durumu

Sistem sıralamadaki ilk etiketi otomatik öneri saymaz:

1. Hiç uygun strateji yoksa `no_eligible_option`.
2. Yalnız bir strateji risk bütçesini geçiyorsa `single_eligible`; bu “kesin üstünlük” değildir.
3. Birden çok uygun stratejide ilk iki seçenek için eşlenmiş utility farkı, yaklaşık %95 ortalama fark aralığı, `P(önde > rakip)` ve dünyalarda yerel kazanma payı hesaplanır.
4. Güçlü ve tutarlı ayrım varsa `clear`; farklı geleceklerde iki tarafın da anlamlı payı varsa `conditional`; aksi halde `close`.

Yalnız `clear` durumu otomatik öneri kimliği taşır. Model yine insan onayı ister.

## 13. Tıklanabilir gelecek ağacı

Her dünya için yalnız dış sürücü ve epistemic özellikler kullanılır; strateji sonucundan türeyen satış/nakit gibi post-treatment değerler bölme adayı değildir.

Her düğümde aday quantile eşikleri denenir. Gini safsızlık kazanımı ve dal dengesiyle en iyi açıklayıcı bölme seçilir. Minimum yaprak kütlesi, maksimum derinlik ve minimum kazanım aşırı parçalanmayı sınırlar. İki ağaç kurulur:

- aynı dünyada yerel utility'yi hangi stratejinin kazandığı;
- öndeki planın başarı/ruin sözleşmesinin nerede kırıldığı.

Yapraklar ayrık ve kökü eksiksiz kaplar. Eşik bir açıklama kuralıdır; nedensel eşik olduğu iddia edilmez.

## 14. Olasılığı kaynağa açma

Başarı, ruin ve sağlamlık için:

- pay ve payda;
- Wilson yaklaşık %95 aralığı;
- standart hata;
- gelecek yaprağı kütlesi `P(F)`;
- yaprak içi olay oranı `P(E|F)`;
- katkı `P(F)P(E|F)`

raporlanır. Ayrık yaprak katkılarının toplamı ana olasılığa test düzeyinde eşittir. Her bölme özelliği Model Registry → Parameter Registry → Evidence Registry zincirine bağlanır.

## 15. Ölçme/izleme önceliği proxy'si

Bu özellik gerçek Expected Value of Perfect Information değildir. Her sürücü/epistemic özellik üç quantile kutusuna ayrılır ve strateji kazananıyla mutual information hesaplanır:

\[
I(X;S)=\sum_{x,s}p(x,s)\log\frac{p(x,s)}{p(x)p(s)}
\]

Sonuç yalnız “bu koşuda seçimi en çok ayıran ve henüz gözlenmemiş değişken hangisi?” sorusuna ölçme/izleme önceliği verir. Maliyet, ölçülebilirlik ve bilginin karardan önce elde edilip edilemeyeceği ayrıca insan tarafından değerlendirilmelidir.

## 16. Yakınsama

50/100/250/500/... dünya checkpoint'lerinde başarı olasılığı ve eşlenmiş fark yeniden hesaplanır. Başarı Wilson-normal yaklaşım aralığı yeterince dar, son checkpoint'lerde fark işareti kararlı ve en az 500 dünya varsa örnekleme “kararlı” işaretlenir. Bu yalnız Monte Carlo örneklemesi içindir; model-form hatasını ölçmez.

## 17. Karşı-olgusal müdahale

Seçilen stratejinin iki kopyası oluşturulur. Yalnız izin verilen bir veya birkaç kontrol değiştirilir; bütün dış dünya ve bilgi çekilişleri aynı tohum/anahtarı kullanır:

\[
\Delta_w=U_w(\text{mevcut})-U_w(\text{müdahale})
\]

No-op müdahalenin her dünyada tam sıfır fark vermesi otomatik testtir. Rapor kazanma payı, ortalama eşlenmiş fark ve P5–P95 farkını gösterir.

## 18. Doğrulama ve audit

Koşu öncesi şu sözleşmeler reddedilir:

- eksik/tekrarlı strateji, model, parametre veya kanıt kimliği;
- ekranda görünen strateji kontrolü ile motor parametresi uyuşmazlığı;
- sınır dışı veya sayısal olmayan değer;
- tanımsız metrik, bozuk objective ölçeği veya kısıt işleci;
- kaynaksız parametre/model;
- yedi alt modelden eksik kayıt.

Audit çıktısı senaryo hash'i, seed, motor sürümü, ortak rassal sayı etiketi, model/parametre/kanıt registry'leri ve feature lineage taşır.

## 19. Yöntem kaynakları

- RAND, [Robust Decision Making](https://www.rand.org/global-and-emerging-risks/centers/pardee/dmdu-decision-making-under-deep-uncertainty/robust-decision-making.html)
- NIST, [Digital Twin Verification, Validation and Uncertainty Quantification](https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=935765)
- PyWhy/DoWhy, [causal effect workflow](https://www.pywhy.org/dowhy/v0.10.1/user_guide/causal_tasks/estimating_causal_effects/index.html)
- EMA Workbench, [scenario discovery examples](https://emaworkbench.readthedocs.io/en/latest/examples/scenario_discovery.html)
- SimPy, [discrete-event simulation concepts](https://simpy.readthedocs.io/en/latest/simpy_intro/basic_concepts.html)
- SALib, [sensitivity analysis documentation](https://salib.readthedocs.io/en/latest/)

Bu kaynaklar tasarım yönünü destekler; Olasılık Simüle bu paketlerin kodunu veya sertifikasyon statüsünü devralmaz.

## 20. Eski genel motor

`examples/channel_24m.json` ve `examples/operations_12m.json`, v0.3 genel DAG motoruyla çalışmaya devam eder. O motor; AR(1)/IID/random walk/Markov driver, korelasyon, aktör, hazard şoku, güvenli ifade DAG'ı ve adaptif kural taşır. Yeni Studio bu yapıyı başka sektörler için otomatik “doğru model” gibi sunmaz.
