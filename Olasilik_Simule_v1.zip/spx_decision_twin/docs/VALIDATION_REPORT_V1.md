# Olasılık Simüle v1 doğrulama raporu

Tarih: 17 Ağustos 2026  
Motor: `operations_v1` / `1.0.0`  
Kapsam: kod, algoritmik yön, olasılık muhasebesi, API, CLI, çıktı ve paketlenebilirlik

## 1. Sonuç

v1, v0.3 arayüzüne yapılmış kozmetik güncelleme değildir. Karar sözleşmesi, yedi alt model, iki katmanlı belirsizlik, karar durumu, gelecek ağacı, olasılık lineage'ı ve karşı-olgusal müdahale yeni ana akış olarak kurulmuştur.

Son tam test turunda:

- Python birim/entegrasyon testleri: **38/38 geçti**;
- JavaScript sözdizimi: geçti;
- üç Termux/bash başlatıcısının shell sözdizimi: geçti;
- 1.000 dünya × 3 strateji × 18 ay karar koşusu: tamamlandı;
- 3.000 dünya-strateji sonucu ve 3.001 satırlık CSV: üretildi;
- çevrimdışı HTML, JSON, CSV, trace, audit, snapshot ve SQLite ledger: üretildi;
- teslim ZIP'i temiz geçici klasöre çıkarıldı; paket içinden 38 test, sürüm komutu ve canlı HTTP başlangıcı tekrar geçti;
- aynı model/tohum tekrar üretilebilirlik testi: geçti;
- olasılık gelecek-dalı katkılarının ana olasılığa toplamı: geçti;
- no-op karşı-olgusalın her dünyada tam sıfır farkı: geçti.

## 2. v0.3 denetiminden kapatılan ana açıklar

| v0.3 açığı | v1 karşılığı | Durum |
| --- | --- | --- |
| Şirket profiliyle başlayan geniş/genel akış | Tek kritik kararla başlayan beş adımlı karar sözleşmesi | Kapatıldı |
| Farklı sektörleri benzer denkleme zorlama | Yalnız operasyon/kapasite/dayanıklılık için derin motor; diğerleri `design_required` | Kapatıldı |
| Arıza için gerçek olay state'i yok | Günlük Weibull koşullu hazard, onarım/bakım sayaçları | Kapatıldı |
| Tedarik yalnız katsayı | Lead-time shipment kuyruğu, kısmi teslim ve yeniden kuyruk | Kapatıldı |
| Doğal ve bilgi belirsizliği ayrılmıyor | Dünya parametresi çekilişi + dönem/gün olayı ayrımı | Kapatıldı |
| Veri statüsü yalnız etiket | Registry aralığından gerçek epistemic örnekleme | Kapatıldı |
| Hassasiyet “neden” gibi okunabiliyor | Gelecek ağacı ve MI proxy açıkça açıklayıcı/ayırıcı olarak etiketlendi | Kapatıldı |
| Her zaman tek kazanan | `clear`, `single_eligible`, `conditional`, `close`, `no_eligible_option` | Kapatıldı |
| Yüzde drill-down yok | Olay → pay/payda → Wilson aralığı → dal katkısı → model → parametre → kanıt | Kapatıldı |
| Tek kontrol counterfactual yok | Aynı dünyada müdahale API'si ve UI laboratuvarı | Kapatıldı |

## 3. Algoritmik regresyonlar

### 3.1 Yıllık trend birikimi

Sıfır trendli ve `%12` yıllık trendli iki model aynı dünya şoklarıyla üretildi. Her ay talep yolu oranının `(1.12)^(ay/12)` değerine eşit olduğu ondalık 10 basamakta doğrulandı. Bu test, trendin AR sapması içinde yanlışlıkla sönümlenmesini engeller.

### 3.2 Veri statüsü etkisi

Aynı `failure_weibull_scale_days` parametresi varsayım ve ölçülmüş statülerinde 80 dünyada örneklendi. Ölçülmüş statüde oluşan çekiliş aralığının varsayım aralığının dörtte birinden küçük olduğu doğrulandı.

### 3.3 Mekanik yön testleri

- Daha kısa önleyici bakım aralığı, aynı dünyalarda ortalama arıza sayısını azalttı.
- Daha yüksek güvenlik stoku, aynı dünyalarda stockout aylarını artırmadı.
- Malzeme stockout'u kapasite değil, yalnız malzemenin üretimi bağladığı durumda sayıldı.
- No-op müdahale için `p_tie=1`, ortalama/P5/P95 utility farkı tam `0` çıktı.

### 3.4 Gelecek ağacı muhasebesi

Her iç düğümde çocuk dünya sayıları ve olasılık kütleleri ebeveyne eşit. Yaprak dünya kimlikleri ayrık ve kökü eksiksiz kaplıyor. Başarı/ruin/sağlamlık olasılığında `Σ P(yaprak)P(olay|yaprak) = P(olay)` eşitliği test edildi.

### 3.5 Karar dili

Yalnız bir seçeneğin sert risk bütçesini geçtiği sentetik sonuç, “net üstünlük” olarak etiketlenmedi; `single_eligible` üretildi ve otomatik öneri kimliği boş kaldı.

## 4. 1.000-dünya referans koşusu

Senaryo hash'i: `b1fc673b471df1a1737bded4e8a04bc5c2faea1c4505711b8055952c75081d84`  
Tohum: `20260817`  
Çalışma süresi: yaklaşık `20.27 s` (bu doğrulama ortamında)  
Yakınsama etiketi: `stable=true`

| Sıra | Seçenek | Uygun | Karar skoru | Başarı | Ruin | Kötü %10 utility |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 1 | Mevcut düzen | Evet | 0.585 | %64,5 | %0,9 | 0.202 |
| 2 | Dayanıklılık önce | Evet | 0.529 | %49,6 | %11,5 | 0.103 |
| 3 | Kapasite yatırımı | Hayır | -0.729 | %15,5 | %65,2 | 0.053 |

Karar durumu `clear` üretildi: eşlenmiş ortalama utility farkı `0.0176`, yaklaşık %95 aralık `[0.0110, 0.0241]`, `P(önde > rakip)=%74,1`.

Bu sonuç **ürün iddiası değildir**. Referans örnekte gözlenmiş parametre yoktur; model güveni `C0 / Kalibrasyon öncesi`, historical replay `not_run` olarak raporlanmıştır. Sonuç yalnız mekanik ve açıklama akışının uçtan uca çalıştığını gösterir.

## 5. API ve arayüz sözleşmesi

Test edilen rotalar:

- `GET /`, `/static/app.js`, `/static/styles.css`;
- `GET /api/bootstrap`;
- `POST /api/decision/build`;
- `POST /api/decision/intervene`;
- `POST /api/validate`;
- `POST/GET /api/projects`;
- `POST /api/run`, `GET /api/jobs/{id}`;
- `GET /api/jobs/{id}/download/report.html`.

HTML kimlikleri tekil, JavaScript'teki bütün statik `#id` referansları HTML'de mevcut. Inline olay işleyici yok. 380px altı mobil breakpoint, body yatay taşma koruması, reduced-motion ve `aria-live` sözleşmeleri statik testte doğrulandı.

Bu ortamda Playwright paketi vardı fakat Chromium ikilisi yoktu; piksel ekran görüntüsü regresyonu çalıştırılamadı. Bu boşluk, mobil statik sözleşme ve canlı HTTP/API testleriyle kısmen kapatıldı; gerçek Termux/Chrome cihaz turu dağıtım sonrası hâlâ önerilir.

## 6. Bilinçli olarak açık bırakılanlar

- Otomatik causal discovery yok.
- Geçmiş veri girişi sınırlı alanları başlangıçta kalibre eder; otomatik Weibull fit ve historical replay henüz yok.
- MI tabanlı ölçme önceliği parasal EVPI değildir.
- Model-form belirsizliği için otomatik challenger ensemble yok; Model Registry ve audit zemini hazır.
- Başka karar dikeyleri genel operasyon denklemlerine zorlanmaz; yeni model reçetesi gerekir.
- UI için gerçek Android Chrome piksel/performans testi ayrı cihaz turu gerektirir.

## 7. Tekrar çalıştırma komutları

```bash
python -m unittest discover -s tests -v
node --check spx/webui/app.js
bash -n START-STUDIO.sh install-termux.sh spx-run

spx new kararim.json --company "Şirketim" --horizon 18
spx validate kararim.json
spx run kararim.json --worlds 1000 --seed 20260817 --output runs/kararim
```
