# Olasılık Simüle v1 kullanım kılavuzu

## 1. İlk 10 dakika

1. `spx studio` komutunu çalıştır.
2. Karar ekranında hazır örneğin sorusunu oku.
3. **Dünya modeli** ekranında yedi kutuya sırayla dokun; girdi, çıktı ve kaynak izini gör.
4. **Deney** ekranında 100 dünya seçip çalıştır.
5. **Gelecek** ekranında karar durumunu ve iki ağaç modunu aç.
6. Bir başarı veya ruin yüzdesine dokunup **Güven** ekranında pay/payda ve lineage zincirini izle.
7. Deney ekranına dön; bakım aralığını tek-değişken karşı-olgusal olarak değiştir.

Bu tur mekaniği anlamak içindir. Kendi kararın için 1.000 dünya koşmadan önce veri ve yön testlerini tamamla.

## 2. Veri hazırlama

| Alan | Tercih edilen kaynak | Veri yoksa |
| --- | --- | --- |
| Aylık talep | Sipariş satırları | Normal/kötü/iyi ay tahmini |
| Fiyat | Net satış / satılan adet | Ürün karması ağırlıklı ortalama |
| Değişken gider | Malzeme + satışla artan gider | Son ay yaklaşık birim gider |
| Sabit gider | Muhasebe aylık giderleri | Son üç ay ortalaması |
| Nakit | Gerçek kullanılabilir bakiye | Borç/taahhüt düşülmüş yaklaşık bakiye |
| Makine kapasitesi | Vardiya/üretim kaydı | Normal gün ölçümü |
| Çalışan kapasitesi | Puantaj + çıktı | Ekip lideri tahmini |
| Stok ve backlog | ERP/depo/sipariş listesi | Sayım günü yaklaşık değer |
| Arıza | Bakım emri ve duruş | Son 12 ay olay + ortalama onarım |
| Devamsızlık | Puantaj | Toplu vardiya oranı |
| Tedarik | Sipariş–teslim tarihleri | Geç ay payı ve normal doluluk |

Para alanlarında aynı para birimini; talep, kapasite ve stokta aynı fiziksel birimi kullan. KDV dahil/hariç karıştırma.

## 3. Karar ekranı

### Adım 1 — Karar

- Soruyu tek eylem ailesine daralt.
- Ufuk, yatırımın etkisinin görülmesi için yeterli; model varsayımlarının anlamsızlaşacağı kadar uzun olmamalı.
- Karar sahibi ve son tarih rapor bağlamıdır.
- Geri döndürülebilirlik şu an raporlanır; otomatik puan ağırlığı değildir.

### Adım 2 — Bugün

Her sayıda statü seç:

- **Kayıttan ölçüldü:** doğrulanabilir kayıt var.
- **Yaklaşık tahmin:** uzman veya kaba hesap.
- **Model varsayımı:** henüz şirket verisi yok.

“Ölçüldü” etiketi belirsizlik aralığını daraltır. Gerçekte kaydı olmayan sayıyı bu etikete geçirmek sonucu yapay olarak kesinleştirir.

### Adım 3 — Belirsizlik

Talep oynaklığı yıllıklaştırılmıştır. Geçmiş aylık log-değişim standart sapması `√12` ile çarpılarak tahmin edilir. Makine Weibull shape değeri 1'in üstündeyse yaşla arıza tehlikesi artar; bu teknik parametre bilinmiyorsa varsayım olarak bırak.

### Adım 4 — Seçenekler

Seçenekler karşılıklı dışlayıcı karar yolları olmalıdır. Aynı karar içinde “bir makine al” ile “Instagram reklamı ver” gibi farklı soru ailelerini rastgele karıştırma. Her yol için gerçek başlangıç ayını ve bütün nakit yatırımını gir.

`cash_brake`, nakit belirli tamponun altına düşerse pazarlama, stok hedefi, eğitim ve fazla mesaiyi kısar. Bu politika şirketin gerçekten uygulayacağı bir davranış değilse kapat.

### Adım 5 — Başarı ve veri

Sert sınırları sonuca bakıp sonradan değiştirme; koşudan önce yaz. Eşik sonradan değiştirilirse bu yeni tercih sözleşmesi olarak kaydedilmeli ve yeniden koşulmalıdır.

Geçmiş veri alanına en az dört ay yapıştırırsan desteklenen başlangıç alanları yeniden hesaplanır. Virgül, noktalı virgül veya tab kullanılabilir; ondalık virgül içeren veride ayırıcı olarak noktalı virgül kullan.

## 4. Dünya modeli ekranı

Kutular hesaplanan alt modellerdir. Bir kutuya dokunduğunda:

- okuduğu parametreler;
- ölçülen/tahmin/varsayım statüsü;
- ürettiği çıktılar;
- evidence kimlikleri

görünür. Oklar matematiksel nedenselliği kanıtlamaz; yazılımda kurulan bilgi akışını gösterir.

Varsayım defterinde geniş aralıklı, yüksek etkili ve varsayım statülü alanlar ilk veri toplama adaylarıdır.

## 5. Deney ekranı

### Dünya sayısı

- **100:** bakım artınca arıza azalıyor mu gibi yön testi.
- **300:** ilk gelecek ağacı ve arayüz keşfi.
- **1.000:** karar görüşmesi için asgari normal koşu.
- **3.000:** daha dar örnekleme aralığı gereken sunum koşusu.

1.000 yerine 10.000 dünya kullanmak model yapısını doğrulamaz; yalnız örnekleme gürültüsünü azaltır.

### Tohum

Aynı senaryo hash'i, dünya sayısı ve tohum aynı sonucu üretir. Model veya parametre değiştiğinde hash değişir.

### Karşı-olgusal laboratuvar

Bir strateji ve kontrol seç. Sistem mevcut ve değiştirilmiş kopyayı aynı 300 dünyada çalıştırır. Sonuç:

- müdahalenin daha iyi olduğu dünya payı;
- ortalama utility farkı;
- P5–P95 eşlenmiş fark

olarak gösterilir. Aynı anda çok kontrol değiştirirsen hangi kontrolün etki yarattığını ayıramazsın; Studio bu nedenle tek kontrol arayüzü sunar.

## 6. Gelecek ekranı

### Karar kartı

“Önde” ile “öneriliyor” aynı şey değildir. Öneri kimliği yalnız net üstünlükte oluşur. Tek uygun seçenek etiketi sert sınırlarla eleme sonucudur.

### Dağılım kartları

- Yatay bant P5–P95 utility aralığıdır.
- İşaret P50'dir.
- CVaR kötü yüzde 10 dünyadaki ortalama utility'dir.
- Başarı ve ruin tıklanabilir olasılıklardır.
- “Sınır aşıyor” etiketi, stratejinin hangi hard constraint risk bütçesini geçtiğini söyler.

### Gelecek ağacı

Bir düğüme dokun:

- kökten düğüme kadar koşullar;
- bu koşullardaki dünya payı;
- her stratejinin koşullu fayda/başarı/ruin/nakit özeti;
- bir sonraki ayırıcı eşik

açılır. Eşik, koşudaki dünyaları açıklamak için seçilmiştir. İş kararı tetikleyicisine çevirmeden önce değişkenin karar anında gözlenebilir olduğundan emin ol.

## 7. Güven ekranı

Bir yüzde şu sırayla açılır:

1. Olay tanımı.
2. Başarılı dünya / toplam dünya.
3. Yaklaşık %95 örnekleme aralığı.
4. Ayrık gelecek dallarının toplam katkısı.
5. Dal koşulunu üreten özellik.
6. Alt model.
7. Parametre ve aralığı.
8. Kanıt/varsayım kaydı.

“Ölçme/izleme önceliği” mutual-information proxy'sidir; gerçek parasal bilgi değeri değildir. Bilginin maliyeti ve karar tarihinden önce elde edilip edilemeyeceği ayrıca değerlendirilir.

Model güven seviyeleri:

- **C0:** kalibrasyon öncesi;
- **C1:** kısmen veriye bağlı;
- **C2:** yüksek ölçülen parametre payı ve örnekleme kararlılığı; yine de doğrulanmış dijital ikiz sertifikası değildir.

## 8. Karar toplantısı kontrol listesi

- Karar sorusu gerçekten tek mi?
- Bütün uygulanabilir seçenekler var mı?
- “Mevcut düzen” karşılaştırması var mı?
- Para ve fiziksel birimler tutarlı mı?
- Ölçüldü etiketlerinin kaynağı gösterilebilir mi?
- Sert sınırlar sonuç görülmeden önce mi yazıldı?
- Yön testleri geçti mi?
- En az 1.000 dünyada sonuç kararlı mı?
- Hangi dalda seçim değişiyor?
- Tetikleyici karar verilmeden veya plan uygulanırken gözlenebilir mi?
- En değerli veri gerçekten toplanabilir mi?
- Historical replay ve uzman incelemesi yapıldı mı?
- Nihai insan onayı kimde?

## 9. Aylık öğrenme döngüsü

1. Gerçek talep, satış, gider, arıza, devamsızlık, tedarik ve hizmeti kaydet.
2. Tahmin edilen alanları gözlenmiş alanlarla değiştir.
3. Aynı karar hâlâ açıksa modeli aynı seed ve daha güncel veriyle yeniden koş.
4. Senaryo hash'i ve karar durumundaki değişimi kaydet.
5. Karar alındıysa öngörülen ikili olayları ledger'a ekleyip Brier/log-loss kalibrasyonunu izle.
6. Modelin sistematik yanıldığı koşullarda denklemi veya yeni alt modeli gözden geçir.

## 10. Sık hatalar

- Ciro ve gideri girip kapasiteyi uydurmak.
- Bütün varsayımları “ölçüldü” işaretlemek.
- Çok farklı karar türlerini tek strateji listesinde karıştırmak.
- Sonuca göre başarı eşiği değiştirmek.
- Beklenen faydayı tek başına okumak.
- Ruin düşük diye hizmet ihlalini görmezden gelmek.
- Gelecek ağacı eşiklerini nedensellik kanıtı saymak.
- 100 dünyalık sonucu kesin yüzde gibi sunmak.

## 11. Sorun giderme

### Tarayıcı açılmıyor

Termux açıkken Chrome'a `http://127.0.0.1:8765/` yaz. Port doluysa Studio sıradaki boş portu dener ve gerçek adresi terminalde gösterir.

### Android “permission denied”

Projeyi ortak depolamadan Termux ana dizinine kopyala:

```bash
cp -r /storage/emulated/0/simulatörrr/spx_decision_twin "$HOME/"
cd "$HOME/spx_decision_twin"
chmod +x install-termux.sh START-STUDIO.sh spx-run
```

### Koşu uzun sürüyor

Önce 100/300 dünya kullan. Model ufku, strateji sayısı ve makine sayısı günlük olay sayısını artırır. Koşu sırasında sayfayı kapatma; terminal sunucusu açık kalmalıdır.

### Eski proje açılmıyor

v0.3 genel JSON senaryoları CLI ve şablon rotasında korunur; yeni karar arayüzü yalnız `operations_v1` projelerini düzenler. Eski senaryoyu `spx validate dosya.json` ile doğrula ve gerekirse CLI ile çalıştır.
