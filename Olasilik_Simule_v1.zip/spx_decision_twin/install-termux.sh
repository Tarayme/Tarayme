#!/data/data/com.termux/files/usr/bin/bash
set -eu

if ! command -v python >/dev/null 2>&1; then
  echo "Python bulunamadı. Önce: pkg install python"
  exit 1
fi

if [ -z "${PREFIX:-}" ] || [ ! -d "$PREFIX/bin" ]; then
  echo "Bu kurucu Termux PREFIX dizinini bulamadı. Proje klasöründe 'python -m spx' kullanabilirsin."
  exit 1
fi

spx_project_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
chmod +x "$spx_project_dir/spx-run"

if [ -e "$PREFIX/bin/spx" ] && [ ! -L "$PREFIX/bin/spx" ]; then
  echo "$PREFIX/bin/spx zaten var ve symlink değil; üzerine yazılmadı."
  exit 1
fi

ln -sfn "$spx_project_dir/spx-run" "$PREFIX/bin/spx"

echo
echo "Olasılık Simüle kuruldu. Etkileşimli aracı aç:"
echo "  spx studio"
echo
echo "Komut satırı kullanımı:"
echo "  spx new kararim.json --company 'Şirketim' --horizon 18"
echo "  spx validate kararim.json"
echo "  spx run kararim.json --worlds 1000 --output runs/kararim"
