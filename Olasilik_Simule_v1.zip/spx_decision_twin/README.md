# Olasılık Simüle v1 — Karar Laboratuvarı

Olasılık Simüle, “şirketim ne olacak?” diye tek gelecek tahmini üretmez. Yanlış verilirse pahalı olacak **bir kararı** seçer; gerçek alternatifleri aynı talep, arıza, çalışan, tedarik ve maliyet dünyalarında karşılaştırır. Çıktısı tek bir kazanan değil, kararın çalıştığı ve kırıldığı gelecek koşullarıdır.

Tamamen yerel çalışır; Python 3.10+ dışında bağımlılık, API anahtarı veya internet gerekmez. Termux/Android, Linux, macOS ve Windows/WSL üzerinde kullanılabilir.

## v1 neden baştan kuruldu?

Önceki genel şirket sihirbazı, farklı sektörleri benzer denklemlere zorluyor ve hassasiyet ilişkisini karar açıklaması gibi gösterebiliyordu. v1 şu ilkelerle yeniden kuruldu:

- önce şirket profili değil **karar sözleşmesi**;
- geniş ama yüzeysel sektör şablonları yerine bir derin dikey: **operasyon, kapasite ve dayanıklılık**;
- tek Monte Carlo özeti yerine talep rejimi + günlük ekipman olayı + çalışan cohort'u + tedarik kuyruğu + stok/akış + nakit modeli;
- alternatifleri aynı rassal dünyalarda çalıştıran eşlenmiş karşılaştırma;
- doğal rastlantı ile bilgi eksikliğini ayrı üretme;
- “ölçüldü / tahmin / varsayım” etiketinin parametre aralığını gerçekten değiştirmesi;
- sert sınır, başarı, kötü kuyruk, pişmanlık ve Pareto sonuçlarını birlikte gösterme;
- tıklanabilir gelecek ağacı ve yüzde → pay/payda → dal → model → parametre → kaynak izi;
- yalnız bir kontrolü değiştirip aynı dünyaları yeniden kullanan karşı-olgusal laboratuvar;
- net üstünlük yoksa otomatik öneri vermeyen karar durumu.

Eski genel JSON/DAG motoru geriye dönük uyumluluk için korunur; yeni Studio'nun ana akışı `operations_v1` motorudur.

## Termux hızlı başlangıç

```bash
pkg install python
cd /storage/emulated/0/simulatörrr
unzip -o Olasilik_Simule_v1.zip
cp -r spx_decision_twin "$HOME/"
cd "$HOME/spx_decision_twin"
chmod +x install-termux.sh START-STUDIO.sh spx-run
./install-termux.sh
spx studio
```

Tarayıcı açılmazsa Chrome'da `http://127.0.0.1:8765/` adresine git. Kapatmak için Termux'ta `CTRL+C` kullan. Kayıtlı projeler `$HOME/spx-studio-data` altında tutulur; kod klasörünü güncellemek onları silmez.

Kurulum yapmadan proje klasöründe de çalışır:

```bash
./START-STUDIO.sh
```

## Studio akışı

1. **Karar:** soru, ufuk, sahibi, başlangıç durumu, belirsizlikler, seçenekler ve kabul edilemez sınırlar.
2. **Dünya modeli:** bağlı yedi alt model, girdileri, çıktıları ve varsayım defteri.
3. **Deney:** 100–3.000 ortak dünya, sabit tohum ve tek-değişken karşı-olgusal müdahale.
4. **Gelecek:** karar durumu, dağılımlar, seçim ağacı ve planın kırıldığı koşullar.
5. **Güven:** olasılığın pay/paydasından model ve kaynak kaydına kadar denetim izi.

Studio ilk açılışta çalışan, kalibrasyon öncesi bir üretim örneği yükler. Örneği inceleyebilir veya Karar ekranındaki beş adımda kendi modelini kurabilirsin.

## Kendi kararını adım adım kur

### 1. Kararı daralt

İyi soru süre, eylem ve trade-off taşır:

> “Önümüzdeki 18 ayda iki makineyi şimdi mi almalıyız, önce bakım ve stok dayanıklılığı mı kurmalıyız, yoksa mevcut düzende mi kalmalıyız?”

“Şirket başarılı olur mu?” gibi geniş bir soru model sözleşmesi değildir.

### 2. Başlangıç mekaniğini gir

Motor ciroyu tek sayı olarak kullanmaz. Aylık talep, fiyat, değişken gider, sabit gider, nakit, makine/çalışan kapasitesi, stok ve bekleyen siparişi ayrı ister. Her alanı kayıttan ölçülen, yaklaşık tahmin veya varsayım olarak işaretle.

### 3. Belirsizliği ayır

- **Doğal rastlantı:** arızanın hangi gün olacağı, ayın talep şoku, tedarik bozulmasının zamanı.
- **Bilgi eksikliği:** makine ömür ölçeği, fiyat hassasiyeti veya normal talep merkezini tam bilmemek.

Ölçülen bir parametre varsayım parametresinden daha dar aralıkta örneklenir. En az dört aylık geçmiş veri girilirse desteklenen talep, birim ekonomi ve devamsızlık alanları başlangıç düzeyinde kalibre edilir.

### 4. Gerçek seçenekleri tanımla

Her seçenek; başlama ayı, yatırım, makine/çalışan, bakım aralığı, güvenlik stoku, eğitim, fazla mesai, fiyat ve pazarlama kontrolünden oluşur. “Mevcut düzen” seçeneğini silme; yatırım hiçbir şey yapmamaya karşı da değer üretmelidir.

### 5. Başarı ve sert sınırları yaz

Minimum nakit, minimum hizmet seviyesi ve kabul edilen stockout ayı karar sahibinin tercihidir; veri gerçeği değildir. Bir seçenek risk bütçesini aşarsa puanı yüksek olsa bile “uygun” sayılmaz.

## Sonucu nasıl oku?

Önce karar durumuna bak:

- **Net üstünlük:** eşlenmiş fark, dünya payı ve sert sınırlar birlikte yeterince güçlü.
- **Tek uygun seçenek:** yalnız bir yol risk bütçesini geçti; bu kesin üstünlük değil, eleme sonucudur.
- **Koşula bağlı karar:** farklı geleceklerde farklı yollar öne çıkıyor; tetikleyici ve yedek plan gerekir.
- **Sonuç yakın:** örnekleme aralığı kesin ayrım göstermiyor.
- **Uygun seçenek yok:** seçenekleri veya hayatta kalma planını yeniden tasarla.

Sonra sırasıyla kötü yüzde 10 ortalaması (CVaR), ruin olasılığı, sert sınır ihlalleri, gelecek ağacı ve model güven kartını incele. Kalibrasyon öncesi bir yüzde, gerçek şirket frekansı değil “bu model ve aralıklar altında oluşan dünya payı”dır.

## Komut satırı

```bash
# Düzenlenebilir yeni karar sözleşmesi oluştur
spx new kararim.json --company "Şirketim" --horizon 18

# Doğrula ve mimariyi incele
spx validate kararim.json
spx inspect kararim.json

# 1.000 eşlenmiş dünyada çalıştır
spx run kararim.json --worlds 1000 --seed 42 --output runs/kararim

# Etkileşimli Studio
spx studio

# Gerçekleşen ikili tahminlerle kalibrasyon hafızası
spx calibrate --db runs/kararim/spx_ledger.sqlite3 \
  --import-csv examples/calibration_sample.csv \
  --output runs/kararim/calibration.json
```

`spx new` mevcut bir dosyanın üzerine yazmaz. Aynı senaryo + dünya sayısı + tohum aynı sonucu üretir.

## Çıktılar

| Dosya | İçerik |
| --- | --- |
| `report.html` | Çevrimdışı karar raporu, sıralama ve gelecek ağaçları |
| `summary.json` | Karar durumu, dağılımlar, stres, karşılaştırma ve güven verisi |
| `worlds.csv` | Her dünya × strateji için metrikler, utility ve sürücüler |
| `traces.json` | Örnek dünyaların aylık operasyon yolları |
| `audit.json` | Model/parametre/kanıt registry'si, hash, seed ve lineage |
| `scenario.snapshot.json` | Koşuda kullanılan karar sözleşmesinin tam kopyası |
| `spx_ledger.sqlite3` | Koşu ve kalibrasyon hafızası |

## Modelin kısa özeti

- Talep: Markov ekonomik rejimi + zaman trendi + AR(1) sapması + strateji fiyat/pazarlama etkisi.
- Ekipman: günlük, yaşa bağlı Weibull koşullu hazard; arıza, onarım ve önleyici bakım olayları.
- Çalışan: günlük cohort devamsızlığı, beceri, eğitim, fazla mesai ve yorgunluk geri beslemesi.
- Tedarik: teslim süresi kuyruğu, kısmi karşılama, gecikmiş miktarın yeniden kuyruğa girmesi ve güvenlik stoku politikası.
- Operasyon: sipariş + backlog, makine/çalışan/malzeme darboğazı, kalite ve hizmet.
- Finans: tahsilat, tedarik nakit çıkışı, sabit/işgücü/bakım/kalite gideri, yatırım ve minimum nakit.
- Karar: çok amaçlı fayda, çarpan kısıt cezaları, sert risk bütçesi, CVaR, sağlamlık ve pişmanlık.

Ayrıntılar için [algoritma](docs/ALGORITHM.md), [model sözleşmesi](docs/MODEL_SPEC.md), [kullanım kılavuzu](docs/KULLANIM_KILAVUZU.md), [v1 doğrulama raporu](docs/VALIDATION_REPORT_V1.md) ve [v0.3 denetimi](docs/AUDIT_V03.md) dosyalarına bak.

## Test

```bash
python -m unittest discover -s tests -v
node --check spx/webui/app.js
```

Testler; tekrar üretilebilirlik, eşlenmiş dünya muhasebesi, gelecek ağacı kütle koruması, olasılık katkılarının toplamı, no-op karşı-olgusalın tam sıfır olması, bakım/arıza ve stok/stockout yön testleri, yıllık trend birikimi, veri statüsünün gerçek belirsizlik aralığına etkisi, API ve çevrimdışı rapor üretimini kapsar.

## Bilinçli sınırlar

- Motor nedenselliği keşfetmez; yazılan mekanizmayı çalıştırır.
- Gelecek ağacı ve sensitivity, ayırıcı ilişki gösterir; nedensellik kanıtı değildir.
- Çok dünya çalıştırmak yanlış denklemi doğru yapmaz.
- Bu derin motor operasyon/kapasite kararları içindir; başka karar sınıfları ayrı model reçetesi gerektirir.
- Historical replay otomatik tamamlanmış sayılmaz. Yüksek etkili kararda geçmiş dönem yeniden oynatma, uzman incelemesi, challenger model ve insan onayı gerekir.

## Lisans

MIT. Karar sorumluluğu kullanıcıdadır.
