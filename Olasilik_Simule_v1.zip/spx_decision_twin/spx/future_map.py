from __future__ import annotations

import math
from collections import Counter, defaultdict
from typing import Any, Callable, Mapping, Sequence

from .util import clamp, mean, quantile, stdev


def build_future_maps(
    outcomes: Sequence[Mapping[str, Any]],
    strategies: Sequence[Mapping[str, Any]],
    leading_strategy_id: str,
    *,
    max_depth: int = 3,
    min_mass: float = 0.07,
) -> dict[str, Any]:
    """Karar değişimini ve başarısızlığı açıklayan iki koşullu gelecek ağacı kurar."""
    strategy_ids = [str(item["id"]) for item in strategies]
    by_key = {(int(row["world_id"]), str(row["strategy_id"])): row for row in outcomes}
    world_ids = sorted({int(row["world_id"]) for row in outcomes})
    if not world_ids:
        return {"switch": {}, "failure": {}}
    base_id = strategy_ids[0]
    feature_rows = {wid: dict(by_key[(wid, base_id)].get("features", {})) for wid in world_ids}
    feature_names = sorted(
        feature
        for feature in feature_rows[world_ids[0]]
        if feature.startswith("driver_") or feature.startswith("epistemic_")
    )

    def winner(wid: int) -> str:
        return max(strategy_ids, key=lambda sid: float(by_key[(wid, sid)]["utility"]))

    def failure(wid: int) -> str:
        row = by_key[(wid, leading_strategy_id)]
        failed = (not bool(row.get("success"))) or bool(row.get("ruin"))
        return "breaks" if failed else "holds"

    minimum_leaf = max(8, int(math.ceil(len(world_ids) * clamp(min_mass, 0.02, 0.30))))
    switch_tree = _build_tree(
        world_ids,
        feature_rows,
        feature_names,
        winner,
        by_key,
        strategy_ids,
        max_depth=max_depth,
        minimum_leaf=minimum_leaf,
        title="Seçim hangi koşulda değişiyor?",
        target_label="aynı dünyadaki en iyi strateji",
    )
    failure_tree = _build_tree(
        world_ids,
        feature_rows,
        feature_names,
        failure,
        by_key,
        strategy_ids,
        max_depth=max_depth,
        minimum_leaf=minimum_leaf,
        title="Öndeki plan hangi koşulda kırılıyor?",
        target_label=f"{leading_strategy_id} başarı durumu",
    )
    return {"switch": switch_tree, "failure": failure_tree}


def _build_tree(
    root_worlds: list[int],
    feature_rows: Mapping[int, Mapping[str, Any]],
    feature_names: Sequence[str],
    target: Callable[[int], str],
    by_key: Mapping[tuple[int, str], Mapping[str, Any]],
    strategy_ids: Sequence[str],
    *,
    max_depth: int,
    minimum_leaf: int,
    title: str,
    target_label: str,
) -> dict[str, Any]:
    root_count = len(root_worlds)
    node_counter = 0

    def walk(worlds: list[int], depth: int, conditions: list[dict[str, Any]], used: set[str]) -> dict[str, Any]:
        nonlocal node_counter
        node_counter += 1
        node_id = f"n{node_counter}"
        labels = [target(wid) for wid in worlds]
        counts = Counter(labels)
        dominant, dominant_count = counts.most_common(1)[0]
        node: dict[str, Any] = {
            "id": node_id,
            "depth": depth,
            "worlds": len(worlds),
            "probability": len(worlds) / root_count,
            "conditions": list(conditions),
            "dominant_outcome": dominant,
            "dominant_share": dominant_count / len(worlds),
            "outcome_mix": {key: count / len(worlds) for key, count in sorted(counts.items())},
            "strategies": _strategy_stats(worlds, by_key, strategy_ids),
            "world_ids": list(worlds),
            "children": [],
        }
        node["best_strategy_id"] = max(node["strategies"], key=lambda row: row["mean_utility"])["strategy_id"]
        if depth >= max_depth or len(counts) <= 1 or len(worlds) < minimum_leaf * 2:
            node["leaf"] = True
            return node
        split = _best_split(worlds, feature_rows, feature_names, labels, used, minimum_leaf)
        if split is None or split["gain"] < 0.006:
            node["leaf"] = True
            return node
        feature, threshold = split["feature"], split["threshold"]
        below = [wid for wid in worlds if float(feature_rows[wid].get(feature, 0.0)) <= threshold]
        above = [wid for wid in worlds if float(feature_rows[wid].get(feature, 0.0)) > threshold]
        node["leaf"] = False
        node["split"] = {
            "feature": feature,
            "label": feature_label(feature),
            "threshold": threshold,
            "gain": split["gain"],
            "below_worlds": len(below),
            "above_worlds": len(above),
        }
        next_used = set(used) | {feature}
        node["children"] = [
            walk(
                below,
                depth + 1,
                conditions + [{"feature": feature, "label": feature_label(feature), "op": "<=", "threshold": threshold}],
                next_used,
            ),
            walk(
                above,
                depth + 1,
                conditions + [{"feature": feature, "label": feature_label(feature), "op": ">", "threshold": threshold}],
                next_used,
            ),
        ]
        return node

    root = walk(root_worlds, 0, [], set())
    return {
        "title": title,
        "target": target_label,
        "worlds": root_count,
        "minimum_leaf_worlds": minimum_leaf,
        "root": root,
    }


def _best_split(
    worlds: Sequence[int],
    features: Mapping[int, Mapping[str, Any]],
    feature_names: Sequence[str],
    labels: Sequence[str],
    used: set[str],
    minimum_leaf: int,
) -> dict[str, Any] | None:
    parent_impurity = _gini(labels)
    best: dict[str, Any] | None = None
    for feature in feature_names:
        if feature in used:
            continue
        ordered = sorted((float(features[wid].get(feature, 0.0)), wid, label) for wid, label in zip(worlds, labels))
        if ordered[0][0] == ordered[-1][0]:
            continue
        candidate_indices = sorted({
            max(minimum_leaf, min(len(ordered) - minimum_leaf, int(round(len(ordered) * q))))
            for q in (0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80)
        })
        for split_index in candidate_indices:
            if split_index < minimum_leaf or len(ordered) - split_index < minimum_leaf:
                continue
            if ordered[split_index - 1][0] >= ordered[split_index][0]:
                continue
            left_labels = [item[2] for item in ordered[:split_index]]
            right_labels = [item[2] for item in ordered[split_index:]]
            weighted = (len(left_labels) * _gini(left_labels) + len(right_labels) * _gini(right_labels)) / len(ordered)
            gain = parent_impurity - weighted
            balance = min(len(left_labels), len(right_labels)) / (len(ordered) / 2)
            score = gain * (0.65 + 0.35 * balance)
            candidate = {
                "feature": feature,
                "threshold": (ordered[split_index - 1][0] + ordered[split_index][0]) / 2,
                "gain": gain,
                "score": score,
            }
            if best is None or candidate["score"] > best["score"]:
                best = candidate
    return best


def _gini(labels: Sequence[str]) -> float:
    if not labels:
        return 0.0
    counts = Counter(labels)
    return 1.0 - sum((count / len(labels)) ** 2 for count in counts.values())


def _strategy_stats(
    worlds: Sequence[int],
    by_key: Mapping[tuple[int, str], Mapping[str, Any]],
    strategy_ids: Sequence[str],
) -> list[dict[str, Any]]:
    rows = []
    for strategy_id in strategy_ids:
        values = [by_key[(wid, strategy_id)] for wid in worlds]
        utilities = [float(row["utility"]) for row in values]
        rows.append(
            {
                "strategy_id": strategy_id,
                "mean_utility": mean(utilities),
                "p50_utility": quantile(utilities, 0.50),
                "success_probability": mean([1.0 if row.get("success") else 0.0 for row in values]),
                "ruin_probability": mean([1.0 if row.get("ruin") else 0.0 for row in values]),
                "minimum_cash_p50": quantile([float(row.get("metrics", {}).get("minimum_cash", 0.0)) for row in values], 0.50),
            }
        )
    return rows


def decision_status(
    outcomes: Sequence[Mapping[str, Any]],
    summary: Mapping[str, Any],
    strategies: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    ranking = list(summary.get("ranking", []))
    if not ranking:
        return {"code": "no_result", "label": "Sonuç yok", "explanation": "Simülasyon sonucu üretilmedi."}
    top = ranking[0]
    eligible_rows = [row for row in ranking if bool(row.get("eligible"))]
    contender = eligible_rows[1] if len(eligible_rows) > 1 else (ranking[1] if len(ranking) > 1 else None)
    leading = str(top["strategy_id"])
    if not any(bool(row.get("eligible")) for row in ranking):
        return {
            "code": "no_eligible_option",
            "label": "Uygun seçenek yok",
            "leading_strategy_id": leading,
            "recommended_strategy_id": None,
            "explanation": "Bütün seçenekler en az bir sert sınırı kabul edilenden fazla ihlal ediyor.",
        }
    if contender is None:
        return {"code": "single", "label": "Tek seçenek", "leading_strategy_id": leading, "recommended_strategy_id": leading}
    other = str(contender["strategy_id"])
    by_key = {(int(row["world_id"]), str(row["strategy_id"])): row for row in outcomes}
    world_ids = sorted({int(row["world_id"]) for row in outcomes})
    deltas = [float(by_key[(wid, leading)]["utility"]) - float(by_key[(wid, other)]["utility"]) for wid in world_ids]
    delta_mean = mean(deltas)
    delta_sd = stdev(deltas, sample=True)
    se = delta_sd / math.sqrt(max(1, len(deltas)))
    low, high = delta_mean - 1.96 * se, delta_mean + 1.96 * se
    p_better = mean([1.0 if value > 0 else 0.0 for value in deltas])
    winner_counts = Counter(
        max((str(item["id"]) for item in strategies), key=lambda sid: float(by_key[(wid, sid)]["utility"]))
        for wid in world_ids
    )
    leading_mass = winner_counts[leading] / len(world_ids)
    rival_mass = 1.0 - leading_mass
    if len(eligible_rows) == 1:
        code, label = "single_eligible", "Tek uygun seçenek"
        explanation = "Yalnız öndeki seçenek tanımlı risk bütçesini topluca geçiyor. Bu kesin üstünlük değil, sert sınırlarla eleme sonucudur; diğer seçenekler ancak koşullu yedek olarak incelenmelidir."
        recommended = None
    elif low > 0 and p_better >= 0.65 and leading_mass >= 0.62 and top.get("eligible", False):
        code, label = "clear", "Net üstünlük"
        explanation = "Öndeki seçenek aynı dünyalarda rakibinden tutarlı biçimde daha iyi kaldı; yine de model varsayımları doğrulanmalıdır."
        recommended = leading
    elif rival_mass >= 0.30 and leading_mass >= 0.30:
        code, label = "conditional", "Koşula bağlı karar"
        explanation = "Tek bir seçenek bütün geleceklerde üstün değil. Kararı bir tetikleyiciye bağlamak veya adaptif plan kurmak daha doğru."
        recommended = None
    else:
        code, label = "close", "Sonuç birbirine yakın"
        explanation = "Bir seçenek önde görünse de eşlenmiş farkın yaklaşık %95 aralığı kesin üstünlük göstermiyor."
        recommended = None
    return {
        "code": code,
        "label": label,
        "leading_strategy_id": leading,
        "contender_strategy_id": other,
        "recommended_strategy_id": recommended,
        "paired_mean_delta": delta_mean,
        "paired_delta_interval95": [low, high],
        "p_leading_better": p_better,
        "leading_world_share": leading_mass,
        "winner_mix": {key: count / len(world_ids) for key, count in winner_counts.items()},
        "explanation": explanation,
    }


def convergence_diagnostics(
    outcomes: Sequence[Mapping[str, Any]],
    leading: str,
    contender: str | None,
) -> dict[str, Any]:
    by_key = {(int(row["world_id"]), str(row["strategy_id"])): row for row in outcomes}
    world_ids = sorted({int(row["world_id"]) for row in outcomes})
    if not world_ids:
        return {"stable": False, "checkpoints": []}
    targets = sorted({min(len(world_ids), size) for size in (50, 100, 250, 500, 1000, 2000, 5000) if size <= len(world_ids)} | {len(world_ids)})
    checkpoints = []
    for size in targets:
        ids = world_ids[:size]
        success = mean([1.0 if by_key[(wid, leading)].get("success") else 0.0 for wid in ids])
        success_se = math.sqrt(max(0.0, success * (1 - success)) / size)
        item: dict[str, Any] = {
            "worlds": size,
            "success_probability": success,
            "success_interval95": [clamp(success - 1.96 * success_se, 0, 1), clamp(success + 1.96 * success_se, 0, 1)],
        }
        if contender:
            deltas = [float(by_key[(wid, leading)]["utility"]) - float(by_key[(wid, contender)]["utility"]) for wid in ids]
            se = stdev(deltas, sample=True) / math.sqrt(size)
            center = mean(deltas)
            item.update({"paired_mean_delta": center, "paired_delta_interval95": [center - 1.96 * se, center + 1.96 * se]})
        checkpoints.append(item)
    final = checkpoints[-1]
    success_width = final["success_interval95"][1] - final["success_interval95"][0]
    stable_sign = True
    if contender:
        signs = []
        for item in checkpoints[-3:]:
            center = item["paired_mean_delta"]
            signs.append(1 if center > 0 else -1 if center < 0 else 0)
        stable_sign = len(set(signs)) == 1
    stable = success_width <= 0.06 and stable_sign and len(world_ids) >= 500
    return {
        "stable": stable,
        "worlds": len(world_ids),
        "checkpoints": checkpoints,
        "message": "Örnekleme kararlı görünüyor." if stable else "Daha fazla dünya veya daha iyi veri sıralamayı değiştirebilir.",
    }


def probability_drilldowns(
    outcomes: Sequence[Mapping[str, Any]],
    strategies: Sequence[Mapping[str, Any]],
    summary: Mapping[str, Any],
    future_maps: Mapping[str, Any],
    feature_lineage: Mapping[str, Any],
) -> dict[str, Any]:
    by_key = {(int(row["world_id"]), str(row["strategy_id"])): row for row in outcomes}
    world_ids = sorted({int(row["world_id"]) for row in outcomes})
    leaves = flatten_leaves(future_maps.get("failure", {}).get("root", {}))
    acceptance = float(summary.get("acceptance_utility", 0.55))
    result: dict[str, Any] = {}
    for strategy in strategies:
        sid = str(strategy["id"])
        events = {
            "success": lambda row: bool(row.get("success")),
            "ruin": lambda row: bool(row.get("ruin")),
            "robust": lambda row: float(row.get("utility", 0)) >= acceptance and not any(row.get("constraint_violations", {}).values()),
        }
        for event_id, predicate in events.items():
            event_worlds = [wid for wid in world_ids if predicate(by_key[(wid, sid)])]
            p = len(event_worlds) / max(1, len(world_ids))
            low, high = _wilson(len(event_worlds), len(world_ids))
            contributions = []
            for leaf in leaves:
                ids = list(leaf.get("world_ids", []))
                if not ids:
                    continue
                rate = mean([1.0 if predicate(by_key[(wid, sid)]) else 0.0 for wid in ids])
                mass = len(ids) / len(world_ids)
                contributions.append(
                    {
                        "future_id": leaf["id"],
                        "conditions": leaf.get("conditions", []),
                        "probability": mass,
                        "conditional_rate": rate,
                        "contribution": mass * rate,
                        "lineage": _lineage_for_conditions(leaf.get("conditions", []), feature_lineage),
                    }
                )
            contributions.sort(key=lambda row: row["contribution"], reverse=True)
            result[f"{event_id}:{sid}"] = {
                "id": f"{event_id}:{sid}",
                "strategy_id": sid,
                "event": event_id,
                "value": p,
                "numerator": len(event_worlds),
                "denominator": len(world_ids),
                "interval95": [low, high],
                "standard_error": math.sqrt(max(0.0, p * (1 - p)) / max(1, len(world_ids))),
                "definition": {
                    "success": "Kâr pozitif, nakit ve hizmet sınırları geçiliyor; stockout sınırı aşılmıyor.",
                    "ruin": "En az bir hayatta kalma niteliğindeki sert sınır ihlal ediliyor.",
                    "robust": "Fayda kabul eşiğinin üstünde ve tanımlı sınırların hiçbiri ihlal edilmiyor.",
                }[event_id],
                "future_contributions": contributions,
            }
    return result


def value_of_information(
    outcomes: Sequence[Mapping[str, Any]],
    strategies: Sequence[Mapping[str, Any]],
    parameter_registry: Sequence[Mapping[str, Any]],
    feature_lineage: Mapping[str, Any],
    limit: int = 8,
) -> list[dict[str, Any]]:
    strategy_ids = [str(item["id"]) for item in strategies]
    by_key = {(int(row["world_id"]), str(row["strategy_id"])): row for row in outcomes}
    world_ids = sorted({int(row["world_id"]) for row in outcomes})
    if not world_ids:
        return []
    base_id = strategy_ids[0]
    winners = [max(strategy_ids, key=lambda sid: float(by_key[(wid, sid)]["utility"])) for wid in world_ids]
    feature_names = sorted(
        key for key in by_key[(world_ids[0], base_id)].get("features", {})
        if key.startswith("epistemic_") or key.startswith("driver_")
    )
    registry = {str(item.get("id")): item for item in parameter_registry}
    rows = []
    for feature in feature_names:
        values = [float(by_key[(wid, base_id)]["features"].get(feature, 0.0)) for wid in world_ids]
        if max(values) - min(values) <= 1e-12:
            continue
        q1, q2 = quantile(values, 1 / 3), quantile(values, 2 / 3)
        bins = [0 if value <= q1 else 1 if value <= q2 else 2 for value in values]
        information = _mutual_information(bins, winners)
        lineage = dict(feature_lineage.get(feature, {}))
        parameter_ids = list(lineage.get("parameter_ids", []))
        status = "ASSUMPTION"
        if parameter_ids:
            statuses = [str(registry.get(pid, {}).get("status", "ASSUMPTION")) for pid in parameter_ids]
            status = min(statuses, key=lambda item: {"ASSUMPTION": 0, "ESTIMATED": 1, "OBSERVED": 2}.get(item, 0))
        rows.append(
            {
                "feature": feature,
                "label": feature_label(feature),
                "decision_information": information,
                "status": status,
                "range": [min(values), max(values)],
                "model_ids": lineage.get("model_ids", []),
                "parameter_ids": parameter_ids,
                "source_ids": lineage.get("source_ids", []),
                "priority_score": information * {"ASSUMPTION": 1.0, "ESTIMATED": 0.70, "OBSERVED": 0.15}.get(status, 1.0),
                "action_kind": "monitor" if feature.startswith("driver_") else "measure",
                "interpretation": "Bu değişkenin düşük/orta/yüksek bölgeleri farklı stratejileri ayırıyor." if information > 0.01 else "Bu koşuda strateji seçimini zayıf ayırıyor.",
            }
        )
    rows.sort(key=lambda row: (row["priority_score"], row["decision_information"]), reverse=True)
    return rows[:limit]


def flatten_leaves(node: Mapping[str, Any]) -> list[dict[str, Any]]:
    if not node:
        return []
    if node.get("leaf") or not node.get("children"):
        return [dict(node)]
    result = []
    for child in node.get("children", []):
        result.extend(flatten_leaves(child))
    return result


def strip_world_ids(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {key: strip_world_ids(item) for key, item in value.items() if key != "world_ids"}
    if isinstance(value, list):
        return [strip_world_ids(item) for item in value]
    return value


def feature_label(feature: str) -> str:
    value = feature
    replacements = {
        "driver_demand_mean": "ortalama talep",
        "driver_demand_min": "en düşük talep",
        "driver_demand_max": "en yüksek talep",
        "driver_cost_mean": "ortalama maliyet endeksi",
        "driver_cost_max": "en yüksek maliyet endeksi",
        "driver_absence_mean": "ortalama devamsızlık",
        "driver_supplier_fill_mean": "tedarik karşılama oranı",
        "driver_supplier_fill_min": "en düşük tedarik karşılama oranı",
        "driver_macro_mean": "ekonomik rejim",
        "epistemic_price_elasticity": "fiyat hassasiyeti varsayımı",
        "epistemic_marketing_elasticity": "pazarlama etkisi varsayımı",
        "epistemic_failure_scale_days": "arıza ömrü varsayımı",
        "epistemic_failure_shape": "arıza yaşlanma varsayımı",
        "epistemic_repair_days": "onarım süresi varsayımı",
        "epistemic_baseline_demand": "başlangıç talep tahmini",
        "epistemic_unit_margin": "birim katkı marjı tahmini",
        "epistemic_fixed_cost": "sabit gider tahmini",
        "epistemic_machine_capacity": "makine kapasitesi tahmini",
        "epistemic_worker_capacity": "çalışan kapasitesi tahmini",
        "epistemic_annual_demand_trend": "yıllık talep eğilimi tahmini",
        "epistemic_annual_cost_inflation": "yıllık maliyet artışı tahmini",
        "epistemic_supplier_disruption": "tedarik bozulması tahmini",
    }
    if value in replacements:
        return replacements[value]
    for suffix in ("_mean", "_min", "_max", "_final"):
        value = value.removesuffix(suffix)
    return value.removeprefix("driver_").removeprefix("epistemic_").replace("_", " ")


def _lineage_for_conditions(conditions: Sequence[Mapping[str, Any]], feature_lineage: Mapping[str, Any]) -> list[dict[str, Any]]:
    result = []
    seen: set[str] = set()
    for condition in conditions:
        feature = str(condition.get("feature", ""))
        if not feature or feature in seen:
            continue
        seen.add(feature)
        result.append({"feature": feature, **dict(feature_lineage.get(feature, {}))})
    return result


def _wilson(successes: int, total: int, z: float = 1.96) -> tuple[float, float]:
    if total <= 0:
        return 0.0, 0.0
    p = successes / total
    denominator = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denominator
    half = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denominator
    return clamp(center - half, 0, 1), clamp(center + half, 0, 1)


def _mutual_information(left: Sequence[Any], right: Sequence[Any]) -> float:
    if not left or len(left) != len(right):
        return 0.0
    n = len(left)
    joint = Counter(zip(left, right))
    left_counts, right_counts = Counter(left), Counter(right)
    total = 0.0
    for (a, b), count in joint.items():
        p_ab = count / n
        total += p_ab * math.log(max(1e-15, p_ab / ((left_counts[a] / n) * (right_counts[b] / n))))
    return total
