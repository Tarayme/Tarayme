from __future__ import annotations

import json
import math
import platform
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Mapping, Sequence

from .analysis import (
    cluster_futures,
    decision_boundaries,
    pairwise_comparisons,
    sensitivity_analysis,
    stress_profiles,
    summarize_run,
)
from .decision import ENGINE_ID, case_overview, validate_decision_case
from .future_map import (
    build_future_maps,
    convergence_diagnostics,
    decision_status,
    probability_drilldowns,
    strip_world_ids,
    value_of_information,
)
from .schema import Scenario
from .util import clamp, mean, object_hash, stable_seed


ProgressCallback = Callable[[int, int], None]


@dataclass(frozen=True)
class OperationsWorld:
    paths: dict[str, list[float]]
    parameters: dict[str, float]
    features: dict[str, float]


@dataclass
class OperationsRunResult:
    metadata: dict[str, Any]
    summary: dict[str, Any]
    pairwise: list[dict[str, Any]]
    sensitivity: dict[str, list[dict[str, Any]]]
    clusters: list[dict[str, Any]]
    boundaries: list[dict[str, Any]]
    stress: list[dict[str, Any]]
    outcomes: list[dict[str, Any]]
    traces: list[dict[str, Any]]
    audit: dict[str, Any]
    validation: list[dict[str, Any]] = field(default_factory=list)
    future_maps: dict[str, Any] = field(default_factory=dict)
    drilldowns: dict[str, Any] = field(default_factory=dict)
    decision: dict[str, Any] = field(default_factory=dict)
    convergence: dict[str, Any] = field(default_factory=dict)
    information_value: list[dict[str, Any]] = field(default_factory=list)
    model_health: dict[str, Any] = field(default_factory=dict)

    def compact(self) -> dict[str, Any]:
        return {
            "metadata": self.metadata,
            "summary": self.summary,
            "decision_status": self.decision,
            "pairwise": self.pairwise,
            "sensitivity": self.sensitivity,
            "future_families": self.clusters,
            "future_maps": self.future_maps,
            "probability_drilldowns": self.drilldowns,
            "decision_boundaries": self.boundaries,
            "stress_profiles": self.stress,
            "convergence": self.convergence,
            "value_of_information": self.information_value,
            "model_health": self.model_health,
            "audit": self.audit,
            "validation": self.validation,
        }


class OperationsEngine:
    """Operasyon/kapasite kararı için bağımlılıksız hibrit simülasyon motoru."""

    ENGINE_VERSION = "1.0.0"

    def __init__(self, scenario: Scenario):
        if scenario.meta.get("engine") != ENGINE_ID:
            raise ValueError(f"OperationsEngine yalnız {ENGINE_ID} senaryosu çalıştırır")
        self.scenario = scenario
        self.raw = scenario.raw
        self.baseline = dict(self.raw["baseline"])
        self.uncertainty = dict(self.raw["uncertainty"])
        self.horizon = int(self.raw["horizon"])
        self.strategy_ids = [str(item["id"]) for item in self.raw["strategies"]]
        self.parameter_registry = {
            str(item.get("id")): dict(item)
            for item in self.raw.get("parameter_registry", [])
            if item.get("id")
        }
        self.ruin_constraint_ids = {
            str(item.get("id")) for item in self.raw.get("constraints", []) if item.get("ruin")
        }
        self.feature_lineage = _feature_lineage(self.raw)

    def run(
        self,
        *,
        worlds: int | None = None,
        seed: int | None = None,
        progress: ProgressCallback | None = None,
        validation: list[dict[str, Any]] | None = None,
    ) -> OperationsRunResult:
        issues = validate_decision_case(self.raw)
        errors = [issue for issue in issues if issue["level"] == "error"]
        if errors:
            raise ValueError("Karar modeli geçersiz: " + "; ".join(item["message"] for item in errors))
        simulation = dict(self.raw.get("simulation", {}))
        world_count = int(worlds if worlds is not None else simulation.get("worlds", 1000))
        base_seed = int(seed if seed is not None else simulation.get("seed", 20260817))
        if not 1 <= world_count <= 100_000:
            raise ValueError("Dünya sayısı 1–100.000 arasında olmalı")

        started_wall = datetime.now(timezone.utc)
        started = time.perf_counter()
        outcomes: list[dict[str, Any]] = []
        traces: list[dict[str, Any]] = []
        trace_worlds = max(0, int(simulation.get("trace_worlds", 4)))
        total = world_count * len(self.raw["strategies"])
        completed = 0
        for world_id in range(world_count):
            world = self._generate_world(world_id, base_seed)
            for strategy in self.raw["strategies"]:
                outcome, trace = self._simulate_strategy(
                    world_id,
                    world,
                    strategy,
                    base_seed,
                    keep_trace=world_id < trace_worlds,
                )
                outcomes.append(outcome)
                if trace:
                    traces.append(trace)
                completed += 1
                if progress:
                    progress(completed, total)

        summary = summarize_run(
            outcomes,
            self.raw["strategies"],
            self.raw["objectives"],
            self.raw["constraints"],
            self.raw["decision_policy"],
        )
        pairwise = pairwise_comparisons(outcomes, self.raw["strategies"])
        sensitivity = sensitivity_analysis(outcomes, self.raw["strategies"], 14)
        clusters = cluster_futures(outcomes, self.raw["strategies"], 6)
        boundaries = decision_boundaries(outcomes, self.raw["strategies"], 12)
        stress = stress_profiles(
            outcomes,
            self.raw["strategies"],
            self.raw.get("stress_tests", []),
            float(summary["tail_alpha"]),
        )
        decision = decision_status(outcomes, summary, self.raw["strategies"])
        leading = str(decision.get("leading_strategy_id", summary["ranking"][0]["strategy_id"]))
        contender = decision.get("contender_strategy_id")
        internal_maps = build_future_maps(
            outcomes,
            self.raw["strategies"],
            leading,
            max_depth=int(simulation.get("future_tree_depth", 3)),
            min_mass=float(simulation.get("future_tree_min_mass", 0.07)),
        )
        drilldowns = probability_drilldowns(
            outcomes,
            self.raw["strategies"],
            summary,
            internal_maps,
            self.feature_lineage,
        )
        public_maps = strip_world_ids(internal_maps)
        convergence = convergence_diagnostics(outcomes, leading, str(contender) if contender else None)
        information_value = value_of_information(
            outcomes,
            self.raw["strategies"],
            self.raw.get("parameter_registry", []),
            self.feature_lineage,
        )
        model_health = self._model_health(issues, convergence)
        runtime_seconds = time.perf_counter() - started
        metadata = {
            "run_id": f"{self.scenario.scenario_id}-{started_wall.strftime('%Y%m%dT%H%M%SZ')}-{base_seed}",
            "scenario_id": self.scenario.scenario_id,
            "scenario_name": self.scenario.name,
            "scenario_version": self.scenario.meta.get("version", "0"),
            "scenario_hash": self.scenario.hash,
            "engine": ENGINE_ID,
            "engine_version": self.ENGINE_VERSION,
            "worlds": world_count,
            "strategies": len(self.raw["strategies"]),
            "horizon": self.horizon,
            "step": "ay",
            "seed": base_seed,
            "common_random_numbers": True,
            "uncertainty_layers": ["aleatory", "epistemic", "preference"],
            "started_at": started_wall.isoformat(),
            "runtime_seconds": runtime_seconds,
            "python": platform.python_version(),
            "data_status": self.scenario.meta.get("data_status", "ILLUSTRATIVE"),
        }
        audit = self._audit_manifest(base_seed)
        all_validation = validation if validation is not None else issues
        return OperationsRunResult(
            metadata=metadata,
            summary=summary,
            pairwise=pairwise,
            sensitivity=sensitivity,
            clusters=clusters,
            boundaries=boundaries,
            stress=stress,
            outcomes=outcomes,
            traces=traces,
            audit=audit,
            validation=all_validation,
            future_maps=public_maps,
            drilldowns=drilldowns,
            decision=decision,
            convergence=convergence,
            information_value=information_value,
            model_health=model_health,
        )

    def _generate_world(self, world_id: int, seed: int) -> OperationsWorld:
        u = self.uncertainty
        b = self.baseline

        def draw(path: str, key: str, fallback: float) -> float:
            item = self.parameter_registry.get(path)
            if not item:
                return float(fallback)
            mode = float(item.get("value", fallback))
            low = float(item.get("low", mode))
            high = float(item.get("high", mode))
            return _triangular_bounds(low, mode, high, _uniform(seed, world_id, "epi", key))

        parameters = {
            "monthly_demand": max(1.0, draw("baseline.monthly_demand", "base-demand", b["monthly_demand"])),
            "unit_price": max(0.01, draw("baseline.unit_price", "unit-price", b["unit_price"])),
            "variable_cost_per_unit": max(0.0, draw("baseline.variable_cost_per_unit", "variable-cost", b["variable_cost_per_unit"])),
            "fixed_cost_monthly": max(0.0, draw("baseline.fixed_cost_monthly", "fixed-cost", b["fixed_cost_monthly"])),
            "starting_cash": draw("baseline.starting_cash", "starting-cash", b["starting_cash"]),
            "machine_capacity_per_day": max(0.01, draw("baseline.machine_capacity_per_day", "machine-capacity", b["machine_capacity_per_day"])),
            "worker_capacity_per_day": max(0.01, draw("baseline.worker_capacity_per_day", "worker-capacity", b["worker_capacity_per_day"])),
            "starting_inventory_units": max(0.0, draw("baseline.starting_inventory_units", "starting-inventory", b["starting_inventory_units"])),
            "starting_backlog_units": max(0.0, draw("baseline.starting_backlog_units", "starting-backlog", b["starting_backlog_units"])),
            "added_worker_monthly_cost": max(0.0, draw("baseline.added_worker_monthly_cost", "worker-cost", b["added_worker_monthly_cost"])),
            "machine_purchase_cost": max(0.0, draw("baseline.machine_purchase_cost", "machine-cost", b["machine_purchase_cost"])),
            "annual_demand_trend": max(-0.95, draw("uncertainty.annual_demand_trend", "demand-trend", u["annual_demand_trend"])),
            "demand_volatility": max(0.005, draw("uncertainty.demand_volatility", "demand-volatility", u["demand_volatility"])),
            "demand_persistence": clamp(draw("uncertainty.demand_persistence", "demand-persistence", u["demand_persistence"]), 0.0, 0.98),
            "annual_cost_inflation": max(-0.95, draw("uncertainty.annual_cost_inflation", "cost-inflation", u["annual_cost_inflation"])),
            "absence_rate": clamp(draw("uncertainty.absence_rate", "absence-rate", u["absence_rate"]), 0.0, 0.60),
            "supplier_normal_fill": clamp(draw("uncertainty.supplier_normal_fill", "supplier-fill", u["supplier_normal_fill"]), 0.20, 1.0),
            "supplier_disruption_probability": clamp(draw("uncertainty.supplier_disruption_probability", "supplier-disruption", u["supplier_disruption_probability"]), 0.0, 0.80),
            "supplier_lead_months": clamp(draw("uncertainty.supplier_lead_months", "supplier-lead", u["supplier_lead_months"]), 0.0, 12.0),
            "price_elasticity": max(0.0, draw("uncertainty.price_elasticity", "price", u["price_elasticity"])),
            "marketing_elasticity": max(0.0, draw("uncertainty.marketing_elasticity", "marketing", u["marketing_elasticity"])),
            "failure_shape": max(0.35, draw("uncertainty.failure_weibull_shape", "failure-shape", u["failure_weibull_shape"])),
            "failure_scale_days": max(10.0, draw("uncertainty.failure_weibull_scale_days", "failure-scale", u["failure_weibull_scale_days"])),
            "repair_days": max(0.25, draw("uncertainty.mean_repair_days", "repair", u["mean_repair_days"])),
            "defect_rate": clamp(draw("uncertainty.base_defect_rate", "defect", u["base_defect_rate"]), 0.0, 0.50),
        }

        macro_states = [0.88, 1.0, 1.12]
        transition = ((0.74, 0.23, 0.03), (0.11, 0.78, 0.11), (0.04, 0.25, 0.71))
        macro_index = _categorical((0.20, 0.62, 0.18), _uniform(seed, world_id, "macro", "initial"))
        demand_deviation = 0.0
        cost_index = 1.0
        supplier_state = parameters["supplier_normal_fill"]
        demand_path: list[float] = []
        cost_path: list[float] = []
        absence_path: list[float] = []
        supplier_path: list[float] = []
        macro_path: list[float] = []
        annual_trend = parameters["annual_demand_trend"]
        monthly_trend = math.log1p(annual_trend) / 12.0
        demand_sigma = parameters["demand_volatility"] / math.sqrt(12.0)
        cost_drift = math.log1p(parameters["annual_cost_inflation"]) / 12.0
        for t in range(self.horizon):
            macro = macro_states[macro_index]
            macro_path.append(macro)
            demand_deviation = (
                parameters["demand_persistence"] * demand_deviation
                + demand_sigma * _normal(seed, world_id, "demand", t)
            )
            demand_path.append(clamp(math.exp(monthly_trend * (t + 1) + demand_deviation) * macro, 0.20, 3.50))
            cost_index *= math.exp(cost_drift + (0.018 + 0.015 * abs(cost_drift)) * _normal(seed, world_id, "cost", t))
            cost_path.append(clamp(cost_index * (1.0 + 0.08 * (1.0 - macro)), 0.45, 8.0))
            season = (1.22, 1.18, 1.08, 0.98, 0.90, 0.84, 0.80, 0.82, 0.91, 1.0, 1.10, 1.20)[t % 12]
            absence = parameters["absence_rate"] * season + 0.012 * _normal(seed, world_id, "absence", t)
            absence_path.append(clamp(absence, 0.0, 0.60))
            supplier_state = 0.72 * supplier_state + 0.28 * parameters["supplier_normal_fill"] + 0.025 * _normal(seed, world_id, "supplier", t)
            if _uniform(seed, world_id, "supplier-disruption", t) < parameters["supplier_disruption_probability"]:
                supplier_state *= 0.35 + 0.38 * _uniform(seed, world_id, "supplier-depth", t)
            supplier_state = clamp(supplier_state, 0.18, 1.0)
            supplier_path.append(supplier_state)
            macro_index = _categorical(transition[macro_index], _uniform(seed, world_id, "macro", t))

        features = {
            "driver_demand_mean": mean(demand_path),
            "driver_demand_min": min(demand_path),
            "driver_demand_max": max(demand_path),
            "driver_cost_mean": mean(cost_path),
            "driver_cost_max": max(cost_path),
            "driver_absence_mean": mean(absence_path),
            "driver_supplier_fill_mean": mean(supplier_path),
            "driver_supplier_fill_min": min(supplier_path),
            "driver_macro_mean": mean(macro_path),
            "epistemic_price_elasticity": parameters["price_elasticity"],
            "epistemic_marketing_elasticity": parameters["marketing_elasticity"],
            "epistemic_failure_scale_days": parameters["failure_scale_days"],
            "epistemic_failure_shape": parameters["failure_shape"],
            "epistemic_repair_days": parameters["repair_days"],
            "epistemic_baseline_demand": parameters["monthly_demand"],
            "epistemic_unit_margin": parameters["unit_price"] - parameters["variable_cost_per_unit"],
            "epistemic_fixed_cost": parameters["fixed_cost_monthly"],
            "epistemic_machine_capacity": parameters["machine_capacity_per_day"],
            "epistemic_worker_capacity": parameters["worker_capacity_per_day"],
            "epistemic_annual_demand_trend": parameters["annual_demand_trend"],
            "epistemic_annual_cost_inflation": parameters["annual_cost_inflation"],
            "epistemic_supplier_disruption": parameters["supplier_disruption_probability"],
        }
        return OperationsWorld(
            paths={
                "demand": demand_path,
                "cost": cost_path,
                "absence": absence_path,
                "supplier_fill": supplier_path,
                "macro": macro_path,
            },
            parameters=parameters,
            features=features,
        )

    def _simulate_strategy(
        self,
        world_id: int,
        world: OperationsWorld,
        strategy_spec: Mapping[str, Any],
        seed: int,
        *,
        keep_trace: bool,
    ) -> tuple[dict[str, Any], dict[str, Any] | None]:
        b = self.baseline
        p = {key: float(value) for key, value in strategy_spec.get("parameters", {}).items()}
        for key in (
            "start_month", "added_machines", "added_workers", "upfront_investment", "marketing_rate",
            "price_change", "maintenance_interval_days", "maintenance_downtime_days", "safety_stock_days",
            "training_rate", "overtime_limit",
        ):
            if key not in p:
                p[key] = float(strategy_spec.get(key, 0.0))
        cash_brake_enabled = bool(strategy_spec.get("cash_brake", p.get("cash_brake", 1.0)))
        working_days = int(b["working_days_per_month"])
        machines = int(b["machine_count"])
        workers = int(b["worker_count"])
        scale = world.parameters["failure_scale_days"]
        machine_ages = [
            scale * 0.62 * _uniform(seed, world_id, "machine-age", machine)
            for machine in range(machines)
        ]
        repair_remaining = [0] * machines
        maintenance_remaining = [0] * machines
        inventory = world.parameters["starting_inventory_units"]
        backlog = world.parameters["starting_backlog_units"]
        cash = world.parameters["starting_cash"]
        minimum_cash = cash
        trust = 0.76
        skill = 0.72
        fatigue = 0.20
        investment_done = False
        shipments: dict[int, float] = defaultdict(float)
        initial_target = world.parameters["monthly_demand"] * max(0.0, p["safety_stock_days"]) / working_days
        shipments[0] = world.parameters["monthly_demand"] + max(0.0, initial_target - inventory)

        totals = defaultdict(float)
        minima = {"employee_energy": 1.0, "service": 1.0}
        maxima = {"backlog": backlog}
        trace_rows: list[dict[str, Any]] = []
        for t in range(self.horizon):
            month = t + 1
            capex = 0.0
            if not investment_done and month >= int(round(p["start_month"])):
                investment_done = True
                machines += int(round(p["added_machines"]))
                workers += int(round(p["added_workers"]))
                added = machines - len(machine_ages)
                for _ in range(max(0, added)):
                    machine_ages.append(0.0)
                    repair_remaining.append(0)
                    maintenance_remaining.append(0)
                capex = p["upfront_investment"]

            cash_brake = cash_brake_enabled and cash < max(world.parameters["fixed_cost_monthly"] * 1.5, 0.0)
            marketing_rate = min(p["marketing_rate"], 0.012) if cash_brake else p["marketing_rate"]
            overtime_limit = 0.0 if cash_brake else p["overtime_limit"]
            safety_stock_days = min(p["safety_stock_days"], 5.0) if cash_brake else p["safety_stock_days"]
            training_rate = min(p["training_rate"], 0.02) if cash_brake else p["training_rate"]

            ordered_due = shipments.pop(t, 0.0)
            supplier_fill = world.paths["supplier_fill"][t]
            received = ordered_due * supplier_fill
            delayed = max(0.0, ordered_due - received)
            if delayed > 0:
                shipments[t + 1] += delayed
            inventory += received
            procurement_cash = received * world.parameters["variable_cost_per_unit"] * world.paths["cost"][t]

            active_machine_days = 0.0
            downtime_days = 0.0
            failures = 0
            preventive_events = 0
            repair_cost = 0.0
            maintenance_cost = 0.0
            shape = world.parameters["failure_shape"]
            interval = max(15, int(round(p["maintenance_interval_days"])))
            maintenance_duration = max(0, int(round(p["maintenance_downtime_days"])))
            for day in range(working_days):
                for machine in range(machines):
                    if repair_remaining[machine] > 0:
                        repair_remaining[machine] -= 1
                        downtime_days += 1
                        if repair_remaining[machine] == 0:
                            machine_ages[machine] *= 0.34
                        continue
                    if maintenance_remaining[machine] > 0:
                        maintenance_remaining[machine] -= 1
                        downtime_days += 1
                        if maintenance_remaining[machine] == 0:
                            machine_ages[machine] *= 0.18
                        continue
                    if maintenance_duration > 0 and machine_ages[machine] >= interval:
                        maintenance_remaining[machine] = maintenance_duration
                        downtime_days += 1
                        maintenance_remaining[machine] -= 1
                        preventive_events += 1
                        maintenance_cost += world.parameters["machine_purchase_cost"] * 0.0045
                        if maintenance_remaining[machine] == 0:
                            machine_ages[machine] *= 0.18
                        continue
                    age = max(0.0, machine_ages[machine])
                    cumulative_increment = ((age + 1.0) / scale) ** shape - (age / scale) ** shape
                    hazard = clamp(1.0 - math.exp(-max(0.0, cumulative_increment)), 0.0, 0.90)
                    draw = _uniform(seed, world_id, "failure", machine, t, day)
                    if draw < hazard:
                        duration_draw = _normal(seed, world_id, "repair-duration", machine, t, day)
                        duration = max(1, int(round(world.parameters["repair_days"] * math.exp(0.28 * duration_draw))))
                        repair_remaining[machine] = duration
                        failures += 1
                        downtime_days += 1
                        repair_remaining[machine] -= 1
                        repair_cost += world.parameters["machine_purchase_cost"] * (0.010 + 0.004 * duration)
                    else:
                        active_machine_days += 1
                        machine_ages[machine] += 1

            absence_probability = clamp(world.paths["absence"][t] + 0.11 * fatigue - 0.05 * training_rate, 0, 0.75)
            worker_days = 0.0
            for day in range(working_days):
                z = _normal(seed, world_id, "workforce", t, day)
                worker_days += _binomial_normal(workers, 1.0 - absence_probability, z)
            worker_days *= max(0.70, 1.0 - 0.22 * training_rate)

            machine_capacity = active_machine_days * world.parameters["machine_capacity_per_day"]
            worker_capacity_base = worker_days * world.parameters["worker_capacity_per_day"] * (0.72 + 0.38 * skill)
            demand_mean = (
                world.parameters["monthly_demand"]
                * world.paths["demand"][t]
                * math.exp(2.4 * world.parameters["marketing_elasticity"] * marketing_rate)
                * math.exp(-world.parameters["price_elasticity"] * p["price_change"])
                * (0.72 + 0.38 * trust)
            )
            demand_noise = _normal(seed, world_id, "orders", t)
            new_orders = max(0.0, demand_mean + math.sqrt(max(1.0, demand_mean)) * demand_noise)
            preliminary_capacity = max(1.0, min(machine_capacity, worker_capacity_base))
            pressure = max(0.0, (new_orders + backlog) / preliminary_capacity - 0.92)
            overtime = min(overtime_limit, pressure * 0.40)
            worker_capacity = worker_capacity_base * (1.0 + overtime)
            effective_capacity = max(0.0, min(machine_capacity, worker_capacity))

            cancellations = backlog * clamp(0.05 + 0.22 * (1.0 - trust), 0.02, 0.35)
            backlog = max(0.0, backlog - cancellations)
            total_requested = new_orders + backlog
            material_needed = min(total_requested, effective_capacity)
            produced = min(material_needed, inventory)
            inventory -= produced
            utilization = produced / max(1.0, effective_capacity)
            defect_rate = clamp(
                world.parameters["defect_rate"]
                + 0.055 * fatigue
                + 0.045 * max(0.0, utilization - 0.88)
                + 0.035 * overtime
                - 0.040 * training_rate,
                0.002,
                0.35,
            )
            good_units = produced * (1.0 - defect_rate)
            backlog = max(0.0, total_requested - produced)
            service_level = clamp(good_units / max(1.0, total_requested), 0.0, 1.0)
            stockout = 1.0 if produced + 1e-9 < material_needed else 0.0

            selling_price = world.parameters["unit_price"] * (1.0 + p["price_change"])
            revenue = produced * selling_price
            cogs = produced * world.parameters["variable_cost_per_unit"] * world.paths["cost"][t]
            fixed_cost = world.parameters["fixed_cost_monthly"] * (0.88 + 0.12 * world.paths["cost"][t])
            added_workers = max(0, workers - int(b["worker_count"]))
            added_labor_cost = added_workers * world.parameters["added_worker_monthly_cost"]
            marketing_cost = marketing_rate * world.parameters["monthly_demand"] * world.parameters["unit_price"]
            training_cost = training_rate * workers * world.parameters["added_worker_monthly_cost"] * 0.45
            overtime_cost = overtime * workers * world.parameters["added_worker_monthly_cost"] * 0.75
            holding_cost = inventory * world.parameters["variable_cost_per_unit"] * 0.018
            quality_cost = produced * selling_price * defect_rate * 0.42
            operating_profit = revenue - cogs - fixed_cost - added_labor_cost - marketing_cost - training_cost - overtime_cost - maintenance_cost - repair_cost - holding_cost - quality_cost
            cash_flow = revenue - procurement_cash - fixed_cost - added_labor_cost - marketing_cost - training_cost - overtime_cost - maintenance_cost - repair_cost - holding_cost - quality_cost - capex
            cash += cash_flow
            minimum_cash = min(minimum_cash, cash)

            target_inventory = max(0.0, demand_mean / working_days * safety_stock_days)
            outstanding = sum(quantity for due, quantity in shipments.items() if due > t)
            next_order = max(0.0, demand_mean + target_inventory - inventory - outstanding)
            lead = int(round(world.parameters["supplier_lead_months"]))
            if supplier_fill < 0.72:
                lead += 1
            shipments[t + max(1, lead)] += next_order

            fatigue = clamp(fatigue + 0.075 * max(0.0, utilization - 0.82) + 0.10 * overtime - 0.08 * training_rate - 0.025 * (1.0 - utilization), 0.03, 0.95)
            skill = clamp(skill + 0.08 * training_rate * (1.0 - skill) - 0.012 * fatigue, 0.25, 1.0)
            trust = clamp(0.82 * trust + 0.18 * (0.62 * service_level + 0.38 * (1.0 - defect_rate)) - 0.04 * min(1.0, backlog / max(1.0, demand_mean)), 0.12, 1.0)
            employee_energy = 1.0 - fatigue
            optionality = clamp(
                0.36 * clamp(cash / max(1.0, world.parameters["fixed_cost_monthly"] * 4), 0, 1)
                + 0.28 * clamp(1.0 - utilization, 0, 1)
                + 0.20 * clamp(inventory / max(1.0, target_inventory), 0, 1)
                + 0.16 * employee_energy,
                0,
                1,
            )

            totals["cumulative_profit"] += operating_profit
            totals["total_revenue"] += revenue
            totals["service_sum"] += service_level
            totals["quality_sum"] += 1.0 - defect_rate
            totals["stockout_months"] += stockout
            totals["downtime_days"] += downtime_days
            totals["failure_count"] += failures
            totals["preventive_events"] += preventive_events
            totals["lost_orders"] += cancellations
            totals["optionality_sum"] += optionality
            minima["employee_energy"] = min(minima["employee_energy"], employee_energy)
            minima["service"] = min(minima["service"], service_level)
            maxima["backlog"] = max(maxima["backlog"], backlog)

            if keep_trace:
                trace_rows.append(
                    {
                        "period": month,
                        "demand": new_orders,
                        "sales": produced,
                        "service_level": service_level,
                        "backlog": backlog,
                        "inventory": inventory,
                        "cash": cash,
                        "operating_profit": operating_profit,
                        "active_machine_days": active_machine_days,
                        "downtime_days": downtime_days,
                        "failures": failures,
                        "employee_energy": employee_energy,
                        "supplier_fill": supplier_fill,
                        "cash_brake": 1.0 if cash_brake else 0.0,
                    }
                )

        metrics = {
            "final_cash": cash,
            "minimum_cash": minimum_cash,
            "cumulative_profit": totals["cumulative_profit"],
            "total_revenue": totals["total_revenue"],
            "average_service_level": totals["service_sum"] / self.horizon,
            "minimum_service_level": minima["service"],
            "average_quality_rate": totals["quality_sum"] / self.horizon,
            "minimum_employee_energy": minima["employee_energy"],
            "max_backlog": maxima["backlog"],
            "final_backlog": backlog,
            "stockout_months": totals["stockout_months"],
            "downtime_days": totals["downtime_days"],
            "failure_count": totals["failure_count"],
            "preventive_events": totals["preventive_events"],
            "lost_orders": totals["lost_orders"],
            "ending_inventory": inventory,
            "optionality_score": totals["optionality_sum"] / self.horizon,
        }
        violations = _constraint_violations(metrics, self.raw["constraints"])
        utility, objective_scores = _utility(metrics, violations, self.raw["objectives"], self.raw["constraints"])
        success_spec = self.raw["success"]
        success = (
            metrics["cumulative_profit"] > 0
            and metrics["minimum_cash"] >= float(success_spec["minimum_cash"])
            and metrics["average_service_level"] >= float(success_spec["minimum_service_level"])
            and metrics["stockout_months"] <= float(success_spec["maximum_stockout_months"])
        )
        ruin = any(violations.get(cid, False) for cid in self.ruin_constraint_ids)
        features = dict(world.features)
        features.update(
            {
                "event_failure_count": float(totals["failure_count"]),
                "event_stockout_months": float(totals["stockout_months"]),
            }
        )
        outcome = {
            "world_id": world_id,
            "strategy_id": str(strategy_spec["id"]),
            "strategy_label": str(strategy_spec.get("label", strategy_spec["id"])),
            "metrics": metrics,
            "utility": utility,
            "objective_scores": objective_scores,
            "success": success,
            "ruin": ruin,
            "constraint_violations": violations,
            "features": features,
            "terminal_state": {
                "cash": cash,
                "backlog": backlog,
                "inventory": inventory,
                "trust": trust,
                "skill": skill,
                "employee_energy": 1.0 - fatigue,
            },
        }
        trace = None
        if keep_trace:
            trace = {
                "world_id": world_id,
                "strategy_id": str(strategy_spec["id"]),
                "periods": trace_rows,
                "metrics": metrics,
                "utility": utility,
                "success": success,
                "ruin": ruin,
            }
        return outcome, trace

    def _model_health(self, issues: Sequence[Mapping[str, Any]], convergence: Mapping[str, Any]) -> dict[str, Any]:
        registry = list(self.raw.get("parameter_registry", []))
        counts = {
            status: sum(1 for item in registry if item.get("status") == status)
            for status in ("OBSERVED", "ESTIMATED", "ASSUMPTION")
        }
        observed_share = counts["OBSERVED"] / max(1, len(registry))
        if observed_share >= 0.70 and convergence.get("stable"):
            tier, label = "C2", "Kalibrasyona hazır"
        elif observed_share >= 0.35:
            tier, label = "C1", "Kısmen veriye bağlı"
        else:
            tier, label = "C0", "Kalibrasyon öncesi"
        return {
            "credibility_tier": tier,
            "label": label,
            "parameter_status": counts,
            "observed_share": observed_share,
            "validation_warnings": [dict(item) for item in issues if item.get("level") == "warning"],
            "historical_replay": "not_run",
            "calibration": "not_established" if observed_share < 0.35 else "partial",
            "convergence_stable": bool(convergence.get("stable")),
            "claim": "Sonuçlar bu model ve girilen aralıklar altındaki karar deneyidir; gerçek şirket tahmini değildir.",
        }

    def _audit_manifest(self, seed: int) -> dict[str, Any]:
        return {
            "seed": seed,
            "scenario_hash": self.scenario.hash,
            "engine": ENGINE_ID,
            "engine_version": self.ENGINE_VERSION,
            "model_registry": self.raw.get("model_registry", []),
            "parameter_registry": self.raw.get("parameter_registry", []),
            "evidence_registry": self.raw.get("evidence", []),
            "feature_lineage": self.feature_lineage,
            "common_random_numbers": True,
            "distribution_first": True,
            "uncertainty_layers": ["aleatory", "epistemic", "preference"],
            "human_approval_required": True,
            "case_overview": case_overview(self.raw),
        }


def run_intervention(
    raw: Mapping[str, Any],
    *,
    strategy_id: str,
    changes: Mapping[str, Any],
    worlds: int = 300,
    seed: int = 20260817,
) -> dict[str, Any]:
    case = json.loads(json.dumps(raw))
    source = next((item for item in case["strategies"] if str(item["id"]) == strategy_id), None)
    if source is None:
        raise ValueError("Karşı-olgusal için strateji bulunamadı")
    allowed = {
        "start_month", "added_machines", "added_workers", "upfront_investment", "marketing_rate",
        "price_change", "maintenance_interval_days", "maintenance_downtime_days", "safety_stock_days",
        "training_rate", "overtime_limit",
    }
    unknown = set(changes) - allowed
    if unknown:
        raise ValueError("Değiştirilemeyen müdahale alanı: " + ", ".join(sorted(unknown)))
    baseline = json.loads(json.dumps(source))
    baseline["id"] = "counterfactual_baseline"
    baseline["label"] = f"{source.get('label', strategy_id)} · mevcut"
    modified = json.loads(json.dumps(source))
    modified["id"] = "counterfactual_modified"
    modified["label"] = f"{source.get('label', strategy_id)} · müdahale"
    for key, value in changes.items():
        modified[key] = float(value)
        modified.setdefault("parameters", {})[key] = float(value)
    case["strategies"] = [baseline, modified]
    case["meta"]["id"] = f"{case['meta']['id']}_counterfactual"
    result = OperationsEngine(Scenario(case)).run(worlds=worlds, seed=seed)
    pair = result.pairwise[0]
    ranking = result.summary["ranking"]
    return {
        "strategy_id": strategy_id,
        "changes": dict(changes),
        "worlds": worlds,
        "seed": seed,
        "paired": pair,
        "ranking": ranking,
        "decision_status": result.decision,
        "interpretation": (
            "Müdahale aynı dış dünyalarda daha sık üstün geldi."
            if pair["p_left_better"] < 0.42
            else "Mevcut ayar aynı dış dünyalarda daha sık üstün kaldı."
            if pair["p_left_better"] > 0.58
            else "Müdahalenin etkisi bu koşuda net ayrışmadı."
        ),
    }


def _constraint_violations(metrics: Mapping[str, float], constraints: Sequence[Mapping[str, Any]]) -> dict[str, bool]:
    result = {}
    for index, item in enumerate(constraints):
        cid = str(item.get("id", f"constraint-{index+1}"))
        value = float(metrics[str(item["metric"])])
        threshold = float(item.get("value", item.get("threshold", 0.0)))
        op = str(item.get("op", ">="))
        passed = {
            ">=": value >= threshold,
            ">": value > threshold,
            "<=": value <= threshold,
            "<": value < threshold,
            "==": value == threshold,
        }.get(op)
        if passed is None:
            raise ValueError(f"Bilinmeyen kısıt işlemi: {cid}: {op}")
        result[cid] = not passed
    return result


def _utility(
    metrics: Mapping[str, float],
    violations: Mapping[str, bool],
    objectives: Sequence[Mapping[str, Any]],
    constraints: Sequence[Mapping[str, Any]],
) -> tuple[float, dict[str, float]]:
    scores: dict[str, float] = {}
    weighted = 0.0
    total_weight = 0.0
    for index, objective in enumerate(objectives):
        oid = str(objective.get("id", f"objective-{index+1}"))
        value = float(metrics[str(objective["metric"])])
        worst, best = float(objective["worst"]), float(objective["best"])
        if str(objective.get("direction", "max")) == "min":
            score = (worst - value) / max(1e-12, worst - best)
        else:
            score = (value - worst) / max(1e-12, best - worst)
        score = clamp(score, 0, 1) ** float(objective.get("shape", 1.0))
        weight = max(0.0, float(objective.get("weight", 1.0)))
        scores[oid] = score
        weighted += score * weight
        total_weight += weight
    utility = weighted / max(1e-12, total_weight)
    for index, item in enumerate(constraints):
        cid = str(item.get("id", f"constraint-{index+1}"))
        if violations.get(cid):
            utility *= 1.0 - clamp(float(item.get("penalty", 0.35)), 0.0, 1.0)
    return clamp(utility, 0, 1), scores


def _feature_lineage(raw: Mapping[str, Any]) -> dict[str, Any]:
    params = {str(item.get("id")): item for item in raw.get("parameter_registry", [])}

    def lineage(model_ids: list[str], parameter_ids: list[str]) -> dict[str, Any]:
        return {
            "model_ids": model_ids,
            "parameter_ids": parameter_ids,
            "source_ids": sorted({str(params[item].get("source_id")) for item in parameter_ids if item in params}),
        }

    mapping = {
        "driver_demand_mean": lineage(["DEMAND-REGIME-AR1-v1"], ["baseline.monthly_demand", "uncertainty.annual_demand_trend", "uncertainty.demand_volatility"]),
        "driver_demand_min": lineage(["DEMAND-REGIME-AR1-v1"], ["baseline.monthly_demand", "uncertainty.demand_volatility"]),
        "driver_demand_max": lineage(["DEMAND-REGIME-AR1-v1"], ["baseline.monthly_demand", "uncertainty.demand_volatility"]),
        "driver_cost_mean": lineage(["FINANCE-CASHFLOW-v1"], ["baseline.variable_cost_per_unit", "baseline.fixed_cost_monthly", "uncertainty.annual_cost_inflation"]),
        "driver_cost_max": lineage(["FINANCE-CASHFLOW-v1"], ["uncertainty.annual_cost_inflation"]),
        "driver_absence_mean": lineage(["WORKFORCE-COHORT-v1"], ["uncertainty.absence_rate", "baseline.worker_count"]),
        "driver_supplier_fill_mean": lineage(["SUPPLY-INVENTORY-v1"], ["uncertainty.supplier_normal_fill", "uncertainty.supplier_disruption_probability"]),
        "driver_supplier_fill_min": lineage(["SUPPLY-INVENTORY-v1"], ["uncertainty.supplier_disruption_probability"]),
        "driver_macro_mean": lineage(["DEMAND-REGIME-AR1-v1"], []),
        "epistemic_price_elasticity": lineage(["DEMAND-REGIME-AR1-v1"], ["uncertainty.price_elasticity"]),
        "epistemic_marketing_elasticity": lineage(["DEMAND-REGIME-AR1-v1"], ["uncertainty.marketing_elasticity"]),
        "epistemic_failure_scale_days": lineage(["RELIABILITY-WEIBULL-DES-v1"], ["uncertainty.failure_weibull_scale_days"]),
        "epistemic_failure_shape": lineage(["RELIABILITY-WEIBULL-DES-v1"], ["uncertainty.failure_weibull_shape"]),
        "epistemic_repair_days": lineage(["RELIABILITY-WEIBULL-DES-v1"], ["uncertainty.mean_repair_days"]),
        "epistemic_baseline_demand": lineage(["DEMAND-REGIME-AR1-v1"], ["baseline.monthly_demand"]),
        "epistemic_unit_margin": lineage(["FINANCE-CASHFLOW-v1"], ["baseline.unit_price", "baseline.variable_cost_per_unit"]),
        "epistemic_fixed_cost": lineage(["FINANCE-CASHFLOW-v1"], ["baseline.fixed_cost_monthly"]),
        "epistemic_machine_capacity": lineage(["RELIABILITY-WEIBULL-DES-v1", "OPERATIONS-FLOW-v1"], ["baseline.machine_capacity_per_day"]),
        "epistemic_worker_capacity": lineage(["WORKFORCE-COHORT-v1", "OPERATIONS-FLOW-v1"], ["baseline.worker_capacity_per_day"]),
        "epistemic_annual_demand_trend": lineage(["DEMAND-REGIME-AR1-v1"], ["uncertainty.annual_demand_trend"]),
        "epistemic_annual_cost_inflation": lineage(["FINANCE-CASHFLOW-v1"], ["uncertainty.annual_cost_inflation"]),
        "epistemic_supplier_disruption": lineage(["SUPPLY-INVENTORY-v1"], ["uncertainty.supplier_disruption_probability"]),
    }
    return mapping


def _uniform(*parts: Any) -> float:
    return (stable_seed(*parts) + 0.5) / (2**64)


def _normal(*parts: Any) -> float:
    u1 = max(1e-15, _uniform(*parts, "u1"))
    u2 = _uniform(*parts, "u2")
    return math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)


def _triangular_bounds(low: float, mode: float, high: float, draw: float) -> float:
    """Kayıt defterindeki gerçek alt–merkez–üst aralığından örnekle."""
    low, high = min(float(low), float(high)), max(float(low), float(high))
    mode = clamp(float(mode), low, high)
    if high <= low:
        return mode
    fraction = (mode - low) / (high - low)
    if draw < fraction:
        return low + math.sqrt(draw * (high - low) * (mode - low))
    return high - math.sqrt((1.0 - draw) * (high - low) * (high - mode))


def _categorical(weights: Sequence[float], draw: float) -> int:
    total = sum(max(0.0, float(value)) for value in weights) or 1.0
    cumulative = 0.0
    for index, value in enumerate(weights):
        cumulative += max(0.0, float(value)) / total
        if draw <= cumulative:
            return index
    return len(weights) - 1


def _binomial_normal(n: int, probability: float, z: float) -> int:
    probability = clamp(probability, 0.0, 1.0)
    center = n * probability
    spread = math.sqrt(max(0.0, n * probability * (1.0 - probability)))
    return int(clamp(round(center + spread * z), 0, n))
