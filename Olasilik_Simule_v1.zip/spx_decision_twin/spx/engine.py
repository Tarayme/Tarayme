from __future__ import annotations

import math
import platform
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Mapping

from .actors import ActorRuntime, run_actors
from .analysis import (
    cluster_futures,
    decision_boundaries,
    pairwise_comparisons,
    sensitivity_analysis,
    stress_profiles,
    summarize_run,
)
from .distributions import sample_distribution
from .drivers import DriverGenerator, DriverPath
from .graph import EquationGraph
from .safeexpr import CompiledExpression, compile_expression
from .schema import Scenario
from .util import clamp, object_hash, stable_seed


ProgressCallback = Callable[[int, int], None]


@dataclass
class RunResult:
    metadata: dict[str, Any]
    summary: dict[str, Any]
    pairwise: list[dict[str, Any]]
    sensitivity: dict[str, list[dict[str, Any]]]
    clusters: list[dict[str, Any]]
    boundaries: list[dict[str, Any]]
    stress: list[dict[str, Any]]
    outcomes: list[dict[str, Any]]
    traces: list[dict[str, Any]]
    audit: dict[str, Any]
    validation: list[dict[str, Any]] = field(default_factory=list)

    def compact(self) -> dict[str, Any]:
        return {
            "metadata": self.metadata,
            "summary": self.summary,
            "pairwise": self.pairwise,
            "sensitivity": self.sensitivity,
            "future_families": self.clusters,
            "decision_boundaries": self.boundaries,
            "stress_profiles": self.stress,
            "audit": self.audit,
            "validation": self.validation,
        }


class _StrategyRuntime:
    def __init__(self, spec: Mapping[str, Any]):
        self.spec = dict(spec)
        self.strategy_id = str(spec["id"])
        self.params = {str(key): float(value) for key, value in spec.get("parameters", {}).items()}
        self.rules: list[dict[str, Any]] = []
        for index, rule in enumerate(spec.get("rules", [])):
            rule_id = str(rule.get("id", f"rule-{index+1}"))
            self.rules.append(
                {
                    "id": rule_id,
                    "when": compile_expression(rule.get("when", "true")),
                    "set": {str(key): compile_expression(value) for key, value in rule.get("set", {}).items()},
                    "once": bool(rule.get("once", False)),
                    "fired": False,
                    "count": 0,
                }
            )
        self.initial_state = {
            str(key): compile_expression(value)
            for key, value in spec.get("initial_state", {}).items()
        }

    def apply_initial_state(self, states: dict[str, float], context: dict[str, Any]) -> None:
        context.update(self.params)
        context.update(states)
        for state_id, expression in self.initial_state.items():
            if state_id not in states:
                raise ValueError(f"Strateji tanımsız state'i değiştiriyor: {self.strategy_id}: {state_id}")
            states[state_id] = float(expression.evaluate(context))
            context[state_id] = states[state_id]

    def apply_rules(self, context: dict[str, Any]) -> None:
        context.update(self.params)
        for rule in self.rules:
            if rule["once"] and rule["fired"]:
                continue
            if bool(rule["when"].evaluate(context)):
                updates = {key: float(expression.evaluate(context)) for key, expression in rule["set"].items()}
                self.params.update(updates)
                context.update(updates)
                rule["fired"] = True
                rule["count"] += 1

    def rule_counts(self) -> dict[str, int]:
        return {f"policy_{rule['id']}_fires": int(rule["count"]) for rule in self.rules}


class _ShockRuntime:
    def __init__(self, spec: Mapping[str, Any]):
        self.spec = dict(spec)
        self.shock_id = str(spec["id"])
        self.hazard = compile_expression(spec.get("hazard", 0.0))
        self.duration = spec.get("duration", 1)
        self.effects = {
            str(key): compile_expression(value) for key, value in spec.get("effects", {}).items()
        }
        self.once = bool(spec.get("once", False))
        self.active_remaining = 0
        self.triggered = 0

    def step(
        self,
        context: dict[str, Any],
        trigger_rng: random.Random,
        duration_rng: random.Random,
    ) -> dict[str, float]:
        if self.active_remaining <= 0 and (not self.once or self.triggered == 0):
            probability = clamp(float(self.hazard.evaluate(context)), 0.0, 1.0)
            if trigger_rng.random() < probability:
                self.active_remaining = max(1, int(round(sample_distribution(self.duration, duration_rng))))
                self.triggered += 1
        active = self.active_remaining > 0
        context[f"shock_{self.shock_id}"] = 1.0 if active else 0.0
        effects = {
            key: float(expression.evaluate(context)) if active else 0.0
            for key, expression in self.effects.items()
        }
        if active:
            self.active_remaining -= 1
        return effects


class Engine:
    """Dağılım-öncelikli, çok dönemli stratejik karar simülasyon motoru."""

    ENGINE_VERSION = "0.3.0"

    def __init__(self, scenario: Scenario):
        self.scenario = scenario
        self.graph = EquationGraph(scenario.equations, scenario.states)
        self.metric_expressions = {
            metric_id: compile_expression(spec.get("expression", metric_id) if isinstance(spec, Mapping) else spec)
            for metric_id, spec in scenario.metrics.items()
        }
        self.success_expression = compile_expression(scenario.success_expression)
        self.constraint_expressions = {
            str(spec.get("id", spec.get("name", f"constraint-{index+1}"))):
                compile_expression(spec["expression"]) if "expression" in spec else None
            for index, spec in enumerate(scenario.constraints)
        }
        self.actor_effect_names = {
            str(effect)
            for actor in scenario.actors
            for action in actor.get("actions", [])
            for effect in action.get("effects", {})
        }
        self.shock_effect_names = {
            str(effect) for shock in scenario.shocks for effect in shock.get("effects", {})
        }

    def run(
        self,
        *,
        worlds: int | None = None,
        seed: int | None = None,
        progress: ProgressCallback | None = None,
        validation: list[dict[str, Any]] | None = None,
    ) -> RunResult:
        simulation = self.scenario.simulation
        world_count = int(worlds if worlds is not None else simulation.get("worlds", 2000))
        base_seed = int(seed if seed is not None else simulation.get("seed", 20260817))
        if world_count < 1:
            raise ValueError("worlds en az 1 olmalı")
        started_wall = datetime.now(timezone.utc)
        started = time.perf_counter()
        driver_generator = DriverGenerator(
            self.scenario.drivers,
            self.scenario.correlations,
            self.scenario.horizon,
            base_seed,
        )
        outcomes: list[dict[str, Any]] = []
        traces: list[dict[str, Any]] = []
        trace_world_count = max(0, int(simulation.get("trace_worlds", 3)))
        total_steps = world_count * len(self.scenario.strategies)
        completed = 0
        for world_id in range(world_count):
            driver_path = driver_generator.generate(world_id)
            for strategy in self.scenario.strategies:
                outcome, trace = self._simulate_strategy(
                    world_id,
                    strategy,
                    driver_path,
                    base_seed,
                    keep_trace=world_id < trace_world_count,
                )
                outcomes.append(outcome)
                if trace:
                    traces.append(trace)
                completed += 1
                if progress:
                    progress(completed, total_steps)
        decision_policy = dict(self.scenario.raw.get("decision_policy", {}))
        summary = summarize_run(
            outcomes,
            self.scenario.strategies,
            self.scenario.objectives,
            self.scenario.constraints,
            decision_policy,
        )
        pairwise = pairwise_comparisons(outcomes, self.scenario.strategies)
        sensitivity = sensitivity_analysis(
            outcomes,
            self.scenario.strategies,
            int(simulation.get("sensitivity_limit", 12)),
        )
        clusters = cluster_futures(
            outcomes,
            self.scenario.strategies,
            int(simulation.get("clusters", 6)),
        )
        boundaries = decision_boundaries(
            outcomes,
            self.scenario.strategies,
            int(simulation.get("boundary_limit", 12)),
        )
        stress = stress_profiles(
            outcomes,
            self.scenario.strategies,
            self.scenario.stress_tests,
            float(summary["tail_alpha"]),
        )
        runtime_seconds = time.perf_counter() - started
        metadata = {
            "run_id": f"{self.scenario.scenario_id}-{started_wall.strftime('%Y%m%dT%H%M%SZ')}-{base_seed}",
            "scenario_id": self.scenario.scenario_id,
            "scenario_name": self.scenario.name,
            "scenario_version": self.scenario.meta.get("version", "0"),
            "scenario_hash": self.scenario.hash,
            "engine_version": self.ENGINE_VERSION,
            "worlds": world_count,
            "strategies": len(self.scenario.strategies),
            "horizon": self.scenario.horizon,
            "step": self.scenario.step,
            "seed": base_seed,
            "common_random_numbers": True,
            "started_at": started_wall.isoformat(),
            "runtime_seconds": runtime_seconds,
            "python": platform.python_version(),
            "data_status": self.scenario.meta.get("data_status", "UNSPECIFIED"),
        }
        audit = self._audit_manifest(base_seed)
        return RunResult(
            metadata=metadata,
            summary=summary,
            pairwise=pairwise,
            sensitivity=sensitivity,
            clusters=clusters,
            boundaries=boundaries,
            stress=stress,
            outcomes=outcomes,
            traces=traces,
            audit=audit,
            validation=validation or [],
        )

    def _simulate_strategy(
        self,
        world_id: int,
        strategy_spec: Mapping[str, Any],
        driver_path: DriverPath,
        base_seed: int,
        *,
        keep_trace: bool,
    ) -> tuple[dict[str, Any], dict[str, Any] | None]:
        strategy = _StrategyRuntime(strategy_spec)
        states = self._initial_states(world_id, base_seed)
        initial_context = {"t": 0.0, "period": 1.0, "horizon": float(self.scenario.horizon)}
        initial_context.update(driver_path.period(0))
        strategy.apply_initial_state(states, initial_context)
        actors = [ActorRuntime(spec) for spec in self.scenario.actors]
        shocks = [_ShockRuntime(spec) for spec in self.scenario.shocks]
        metric_state: dict[str, dict[str, Any]] = {
            metric_id: {"values": [], "value": None} for metric_id in self.scenario.metrics
        }
        actor_share_sums: dict[str, float] = {}
        trace_rows: list[dict[str, Any]] = []
        last_context: dict[str, Any] = {}
        trace_nodes = list(self.scenario.simulation.get("trace_nodes", []))
        for t in range(self.scenario.horizon):
            context: dict[str, Any] = {
                "t": float(t),
                "period": float(t + 1),
                "horizon": float(self.scenario.horizon),
            }
            context.update(driver_path.period(t))
            context.update(strategy.params)
            context.update(states)
            context.update({f"prev_{key}": value for key, value in states.items()})
            for effect in self.actor_effect_names | self.shock_effect_names:
                context[effect] = 0.0
            for shock in shocks:
                context[f"shock_{shock.shock_id}"] = 0.0
            strategy.apply_rules(context)
            _, actor_shares = run_actors(
                actors,
                context,
                lambda actor_id: random.Random(stable_seed(base_seed, world_id, "actor", actor_id, t)),
            )
            for actor_id, shares in actor_shares.items():
                for action_id, share in shares.items():
                    key = f"actor_{actor_id}_{action_id}_share_mean"
                    actor_share_sums[key] = actor_share_sums.get(key, 0.0) + share
            shock_effects = {key: 0.0 for key in self.shock_effect_names}
            for shock in shocks:
                effects = shock.step(
                    context,
                    random.Random(stable_seed(base_seed, world_id, "shock", shock.shock_id, "trigger", t)),
                    random.Random(stable_seed(base_seed, world_id, "shock", shock.shock_id, "duration", t)),
                )
                for key, value in effects.items():
                    shock_effects[key] = shock_effects.get(key, 0.0) + value
            for key, value in shock_effects.items():
                context[key] = context.get(key, 0.0) + value
            produced = self.graph.evaluate(context)
            states = {state_id: produced[state_id] for state_id in self.scenario.states}
            self._accumulate_metrics(metric_state, context, t)
            if keep_trace:
                keys = trace_nodes or list(self.scenario.states) + list(self.scenario.drivers)
                trace_rows.append({"period": t + 1, **{key: float(context.get(key, 0.0)) for key in keys}})
            last_context = context
        metrics = self._finalize_metrics(metric_state)
        constraint_violations = self._constraint_violations(metrics)
        utility, objective_scores = self._utility(metrics, constraint_violations)
        success_context = dict(metrics)
        success_context.update({f"constraint_{key}_ok": not value for key, value in constraint_violations.items()})
        success = bool(self.success_expression.evaluate(success_context))
        features = driver_path.summaries()
        features.update({key: value / self.scenario.horizon for key, value in actor_share_sums.items()})
        features.update({f"event_{shock.shock_id}_count": float(shock.triggered) for shock in shocks})
        features.update({key: float(value) for key, value in strategy.rule_counts().items()})
        outcome = {
            "world_id": world_id,
            "strategy_id": strategy.strategy_id,
            "strategy_label": str(strategy_spec.get("label", strategy.strategy_id)),
            "metrics": metrics,
            "utility": utility,
            "objective_scores": objective_scores,
            "success": success,
            "constraint_violations": constraint_violations,
            "features": features,
            "terminal_state": states,
        }
        trace = None
        if keep_trace:
            trace = {
                "world_id": world_id,
                "strategy_id": strategy.strategy_id,
                "periods": trace_rows,
                "metrics": metrics,
                "utility": utility,
                "success": success,
            }
        return outcome, trace

    def _initial_states(self, world_id: int, base_seed: int) -> dict[str, float]:
        states: dict[str, float] = {}
        for state_id, spec in self.scenario.states.items():
            initial = spec.get("initial", 0.0) if isinstance(spec, Mapping) else 0.0
            rng = random.Random(stable_seed(base_seed, world_id, "state", state_id, "initial"))
            value = sample_distribution(initial, rng)
            if isinstance(spec, Mapping):
                value = clamp(value, float(spec.get("min", -1e300)), float(spec.get("max", 1e300)))
            states[state_id] = value
        return states

    def _accumulate_metrics(
        self, metric_state: dict[str, dict[str, Any]], context: Mapping[str, Any], t: int
    ) -> None:
        for metric_id, spec in self.scenario.metrics.items():
            spec = spec if isinstance(spec, Mapping) else {"expression": spec}
            value = float(self.metric_expressions[metric_id].evaluate(context))
            aggregation = str(spec.get("aggregation", "final"))
            bucket = metric_state[metric_id]
            bucket["values"].append(value)
            if aggregation == "discounted_sum":
                rate = float(spec.get("discount_rate", 0.0))
                bucket["value"] = float(bucket["value"] or 0.0) + value / ((1.0 + rate) ** t)

    def _finalize_metrics(self, metric_state: Mapping[str, Mapping[str, Any]]) -> dict[str, float]:
        metrics: dict[str, float] = {}
        for metric_id, spec in self.scenario.metrics.items():
            spec = spec if isinstance(spec, Mapping) else {"expression": spec}
            aggregation = str(spec.get("aggregation", "final"))
            values = list(metric_state[metric_id]["values"])
            if aggregation == "final":
                value = values[-1]
            elif aggregation == "sum":
                value = sum(values)
            elif aggregation == "mean":
                value = sum(values) / len(values)
            elif aggregation == "min":
                value = min(values)
            elif aggregation == "max":
                value = max(values)
            elif aggregation == "discounted_sum":
                value = float(metric_state[metric_id]["value"])
            else:
                raise ValueError(f"Bilinmeyen metric aggregation: {metric_id}: {aggregation}")
            metrics[metric_id] = float(value)
        return metrics

    def _constraint_violations(self, metrics: Mapping[str, float]) -> dict[str, bool]:
        result: dict[str, bool] = {}
        for index, spec in enumerate(self.scenario.constraints):
            constraint_id = str(spec.get("id", spec.get("name", f"constraint-{index+1}")))
            expression = self.constraint_expressions[constraint_id]
            if expression is not None:
                passed = bool(expression.evaluate(metrics))
            else:
                metric = str(spec["metric"])
                value = float(metrics[metric])
                threshold = float(spec.get("value", spec.get("threshold", 0.0)))
                operation = str(spec.get("op", ">="))
                if operation == ">=":
                    passed = value >= threshold
                elif operation == ">":
                    passed = value > threshold
                elif operation == "<=":
                    passed = value <= threshold
                elif operation == "<":
                    passed = value < threshold
                elif operation == "==":
                    passed = value == threshold
                elif operation == "between":
                    passed = float(spec["low"]) <= value <= float(spec["high"])
                else:
                    raise ValueError(f"Bilinmeyen constraint op: {constraint_id}: {operation}")
            result[constraint_id] = not passed
        return result

    def _utility(
        self, metrics: Mapping[str, float], violations: Mapping[str, bool]
    ) -> tuple[float, dict[str, float]]:
        scores: dict[str, float] = {}
        weighted = 0.0
        total_weight = 0.0
        for index, objective in enumerate(self.scenario.objectives):
            objective_id = str(objective.get("id", objective.get("metric", f"objective-{index+1}")))
            metric = str(objective["metric"])
            value = float(metrics[metric])
            direction = str(objective.get("direction", "max"))
            worst = float(objective["worst"])
            best = float(objective["best"])
            if direction == "max":
                score = (value - worst) / max(1e-15, best - worst)
            elif direction == "min":
                score = (worst - value) / max(1e-15, worst - best)
            elif direction == "target":
                target = float(objective.get("target", best))
                tolerance = max(1e-15, float(objective.get("tolerance", abs(best - worst))))
                score = 1.0 - abs(value - target) / tolerance
            else:
                raise ValueError(f"Bilinmeyen objective direction: {objective_id}: {direction}")
            score = clamp(score, 0.0, 1.0) ** float(objective.get("shape", 1.0))
            weight = max(0.0, float(objective.get("weight", 1.0)))
            scores[objective_id] = score
            weighted += weight * score
            total_weight += weight
        utility = weighted / total_weight if total_weight > 0 else 0.0
        for index, constraint in enumerate(self.scenario.constraints):
            constraint_id = str(constraint.get("id", constraint.get("name", f"constraint-{index+1}")))
            if violations.get(constraint_id, False):
                utility -= float(constraint.get("penalty", 0.35))
        return clamp(utility, 0.0, 1.0), scores

    def _audit_manifest(self, seed: int) -> dict[str, Any]:
        evidence_ids = {str(item.get("id")) for item in self.scenario.evidence}
        model_registry = []
        for node_id in self.graph.order:
            node = self.graph.nodes[node_id]
            model_registry.append(
                {
                    "node_id": node_id,
                    "kind": node.kind,
                    "unit": node.unit,
                    "model_id": node.model_id,
                    "model_hash": object_hash({"expression": node.expression.source, "unit": node.unit}),
                    "evidence_ids": list(node.evidence_ids),
                    "unresolved_evidence_ids": sorted(set(node.evidence_ids) - evidence_ids),
                    "dependencies": sorted(self.graph.dependencies[node_id]),
                }
            )
        fingerprints: dict[str, list[str]] = {}
        for evidence in self.scenario.evidence:
            fingerprint = str(evidence.get("fingerprint", evidence.get("source", evidence.get("id", "unknown"))))
            fingerprints.setdefault(fingerprint, []).append(str(evidence.get("id")))
        overlaps = [ids for ids in fingerprints.values() if len(ids) > 1]
        return {
            "seed": seed,
            "scenario_hash": self.scenario.hash,
            "model_registry": model_registry,
            "evidence_registry": self.scenario.evidence,
            "evidence_overlap_groups": overlaps,
            "separation_of_concerns": [
                "evidence",
                "model",
                "fusion",
                "simulation",
                "decision",
            ],
            "common_random_numbers": True,
            "distribution_first": True,
            "human_approval_required": bool(self.scenario.meta.get("human_approval_required", True)),
        }


def run_scenario(
    scenario: Scenario,
    *,
    worlds: int | None = None,
    seed: int | None = None,
    progress: ProgressCallback | None = None,
    validation: list[dict[str, Any]] | None = None,
):
    """Senaryonun kayıtlı motoruna yönlendir; eski ifade motorunu geriye uyumlu tut."""
    if scenario.meta.get("engine") == "operations_v1":
        from .operations import OperationsEngine

        return OperationsEngine(scenario).run(
            worlds=worlds,
            seed=seed,
            progress=progress,
            validation=validation,
        )
    return Engine(scenario).run(
        worlds=worlds,
        seed=seed,
        progress=progress,
        validation=validation,
    )
