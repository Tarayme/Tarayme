from __future__ import annotations

import json
import math
import mimetypes
import shutil
import socket
import subprocess
import threading
import traceback
import uuid
import webbrowser
from dataclasses import dataclass, field
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import unquote, urlparse

from .artifacts import write_run
from .company import (
    build_company_scenario,
    company_builder_catalog,
    company_scenario_explanation,
)
from .decision import build_operations_case, case_overview, decision_builder_catalog
from .engine import run_scenario
from .operations import run_intervention
from .schema import Scenario, load_scenario
from .util import safe_slug, write_json
from .validation import raise_for_errors, validate_scenario


MAX_REQUEST_BYTES = 5 * 1024 * 1024
DOWNLOAD_FILES = {
    "report.html",
    "summary.json",
    "worlds.csv",
    "traces.json",
    "audit.json",
    "scenario.snapshot.json",
    "spx_ledger.sqlite3",
}


@dataclass
class StudioJob:
    job_id: str
    scenario_id: str
    status: str = "queued"
    completed: int = 0
    total: int = 1
    message: str = "Sırada"
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    started_at: str | None = None
    finished_at: str | None = None
    output_directory: Path | None = None
    compact_result: dict[str, Any] | None = None
    narrative: dict[str, Any] | None = None
    error: str | None = None
    traceback_text: str | None = None

    def public(self, *, include_result: bool = True) -> dict[str, Any]:
        progress = self.completed / self.total if self.total else 0.0
        payload: dict[str, Any] = {
            "job_id": self.job_id,
            "scenario_id": self.scenario_id,
            "status": self.status,
            "completed": self.completed,
            "total": self.total,
            "progress": progress,
            "message": self.message,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "error": self.error,
        }
        if include_result and self.status == "completed":
            payload["result"] = self.compact_result
            payload["narrative"] = self.narrative
            payload["downloads"] = sorted(DOWNLOAD_FILES)
        return payload


class StudioState:
    def __init__(self, workspace: Path, template_paths: list[Path]):
        self.workspace = workspace.expanduser().resolve()
        self.projects_directory = self.workspace / "projects"
        self.runs_directory = self.workspace / "runs"
        self.projects_directory.mkdir(parents=True, exist_ok=True)
        self.runs_directory.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.jobs: dict[str, StudioJob] = {}
        self.templates: dict[str, dict[str, Any]] = {}
        decision_case = build_operations_case(None)
        decision_scenario = Scenario(decision_case)
        self.templates[decision_scenario.scenario_id] = {
            "id": decision_scenario.scenario_id,
            "name": decision_scenario.name,
            "description": str(decision_scenario.meta.get("description", "")),
            "scenario": decision_case,
            "source": "built-in:operations_v1",
        }
        for path in template_paths:
            if not path.exists():
                continue
            scenario = load_scenario(path)
            self.templates[scenario.scenario_id] = {
                "id": scenario.scenario_id,
                "name": scenario.name,
                "description": str(scenario.meta.get("description", "")),
                "scenario": scenario.raw,
                "source": str(path),
            }
        if not self.templates:
            raise ValueError("Studio için en az bir senaryo şablonu gerekli")

    def template_list(self) -> list[dict[str, Any]]:
        return [
            {key: value for key, value in template.items() if key != "scenario"}
            for template in self.templates.values()
        ]

    def default_template(self) -> dict[str, Any]:
        return next(iter(self.templates.values()))["scenario"]

    def list_projects(self) -> list[dict[str, Any]]:
        projects: list[dict[str, Any]] = []
        for path in sorted(self.projects_directory.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                scenario = load_scenario(path)
                projects.append(
                    {
                        "id": path.stem,
                        "scenario_id": scenario.scenario_id,
                        "name": scenario.name,
                        "modified_at": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat(),
                    }
                )
            except Exception:
                continue
        return projects

    def load_project(self, project_id: str) -> dict[str, Any]:
        path = self._project_path(project_id)
        return load_scenario(path).raw

    def save_project(self, name: str, raw: Mapping[str, Any]) -> dict[str, Any]:
        saved_raw = json.loads(json.dumps(raw))
        if name.strip():
            saved_raw.setdefault("meta", {})["name"] = name.strip()[:120]
        scenario = Scenario(saved_raw)
        issues = validate_scenario(scenario)
        raise_for_errors(issues)
        project_id = safe_slug(name or scenario.name) or scenario.scenario_id
        path = self._project_path(project_id)
        write_json(path, scenario.raw)
        return {
            "id": project_id,
            "name": scenario.name,
            "path": str(path),
            "issues": [issue.to_dict() for issue in issues],
        }

    def _project_path(self, project_id: str) -> Path:
        safe_id = safe_slug(project_id)
        if not safe_id or safe_id != project_id:
            raise ValueError("Geçersiz proje kimliği")
        path = (self.projects_directory / f"{safe_id}.json").resolve()
        if self.projects_directory not in path.parents:
            raise ValueError("Geçersiz proje yolu")
        return path

    def start_job(self, raw: Mapping[str, Any], worlds: int | None, seed: int | None) -> StudioJob:
        scenario = Scenario(json.loads(json.dumps(raw)))
        issues = validate_scenario(scenario)
        raise_for_errors(issues)
        requested_worlds = int(worlds if worlds is not None else scenario.simulation.get("worlds", 2000))
        if requested_worlds < 1 or requested_worlds > 100_000:
            raise ValueError("Dünya sayısı 1–100.000 arasında olmalı")
        requested_seed = int(seed if seed is not None else scenario.simulation.get("seed", 20260817))
        job_id = uuid.uuid4().hex[:12]
        job = StudioJob(
            job_id=job_id,
            scenario_id=scenario.scenario_id,
            total=requested_worlds * len(scenario.strategies),
            message="Model doğrulandı",
        )
        with self.lock:
            self.jobs[job_id] = job
        worker = threading.Thread(
            target=self._run_job,
            args=(job, scenario, requested_worlds, requested_seed, issues),
            name=f"spx-job-{job_id}",
            daemon=True,
        )
        worker.start()
        return job

    def _run_job(self, job: StudioJob, scenario: Scenario, worlds: int, seed: int, issues) -> None:
        with self.lock:
            job.status = "running"
            job.started_at = datetime.now(timezone.utc).isoformat()
            job.message = "Ortak dünyalar çalışıyor"

        def progress(completed: int, total: int) -> None:
            with self.lock:
                job.completed = completed
                job.total = total
                job.message = f"{completed:,}/{total:,} strateji-dünya tamamlandı"

        try:
            result = run_scenario(
                scenario,
                worlds=worlds,
                seed=seed,
                progress=progress,
                validation=[issue.to_dict() for issue in issues],
            )
            output = self.runs_directory / job.job_id
            write_run(output, result, scenario)
            compact = result.compact()
            narrative = compose_narrative(compact)
            with self.lock:
                job.status = "completed"
                job.completed = job.total
                job.output_directory = output
                job.compact_result = json_safe(compact)
                job.narrative = json_safe(narrative)
                job.finished_at = datetime.now(timezone.utc).isoformat()
                job.message = "Projeksiyon tamamlandı"
        except Exception as exc:
            with self.lock:
                job.status = "failed"
                job.error = str(exc)
                job.traceback_text = traceback.format_exc()
                job.finished_at = datetime.now(timezone.utc).isoformat()
                job.message = "Koşu başarısız"

    def get_job(self, job_id: str) -> StudioJob:
        with self.lock:
            if job_id not in self.jobs:
                raise KeyError("Koşu bulunamadı")
            return self.jobs[job_id]


class StudioHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, handler, studio_state: StudioState):
        super().__init__(address, handler)
        self.studio_state = studio_state


class StudioHandler(BaseHTTPRequestHandler):
    server_version = "OlasilikSimule/1.0"

    @property
    def state(self) -> StudioState:
        return self.server.studio_state  # type: ignore[attr-defined]

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        try:
            if path == "/":
                return self._send_static("index.html")
            if path.startswith("/static/"):
                return self._send_static(path.removeprefix("/static/"))
            if path == "/api/health":
                return self._json({"ok": True, "version": "1.0.0"})
            if path == "/api/bootstrap":
                return self._json(
                    {
                        "templates": self.state.template_list(),
                        "default_scenario": self.state.default_template(),
                        "projects": self.state.list_projects(),
                        "company_builder": company_builder_catalog(),
                        "decision_builder": decision_builder_catalog(),
                    }
                )
            if path.startswith("/api/templates/"):
                template_id = path.removeprefix("/api/templates/")
                template = self.state.templates.get(template_id)
                if not template:
                    return self._error(HTTPStatus.NOT_FOUND, "Şablon bulunamadı")
                return self._json(template["scenario"])
            if path == "/api/projects":
                return self._json({"projects": self.state.list_projects()})
            if path.startswith("/api/projects/"):
                project_id = path.removeprefix("/api/projects/")
                return self._json(self.state.load_project(project_id))
            if path.startswith("/api/jobs/"):
                return self._get_job_route(path)
            return self._error(HTTPStatus.NOT_FOUND, "Sayfa bulunamadı")
        except KeyError as exc:
            return self._error(HTTPStatus.NOT_FOUND, str(exc))
        except ValueError as exc:
            return self._error(HTTPStatus.BAD_REQUEST, str(exc))
        except Exception as exc:
            return self._error(HTTPStatus.INTERNAL_SERVER_ERROR, str(exc))

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        try:
            payload = self._read_json()
            if path == "/api/company/build":
                scenario = build_company_scenario(
                    payload.get("profile", {}), payload.get("strategies")
                )
                return self._json(
                    {
                        "scenario": scenario,
                        "explanation": company_scenario_explanation(scenario),
                        "overview": scenario_overview(Scenario(scenario)),
                    },
                    status=HTTPStatus.CREATED,
                )
            if path == "/api/decision/build":
                scenario = build_operations_case(payload.get("case", payload.get("profile", payload)))
                return self._json(
                    {
                        "scenario": scenario,
                        "overview": case_overview(scenario),
                        "issues": [issue.to_dict() for issue in validate_scenario(Scenario(scenario))],
                    },
                    status=HTTPStatus.CREATED,
                )
            if path == "/api/decision/intervene":
                result = run_intervention(
                    payload["scenario"],
                    strategy_id=str(payload["strategy_id"]),
                    changes=payload.get("changes", {}),
                    worlds=int(payload.get("worlds", 300)),
                    seed=int(payload.get("seed", 20260817)),
                )
                return self._json(result)
            if path == "/api/validate":
                scenario = Scenario(payload.get("scenario", payload))
                issues = validate_scenario(scenario)
                return self._json(
                    {
                        "valid": not any(issue.level == "error" for issue in issues),
                        "issues": [issue.to_dict() for issue in issues],
                        "overview": scenario_overview(scenario),
                    }
                )
            if path == "/api/projects":
                saved = self.state.save_project(str(payload.get("name", "")), payload["scenario"])
                return self._json(saved, status=HTTPStatus.CREATED)
            if path == "/api/run":
                job = self.state.start_job(
                    payload["scenario"], payload.get("worlds"), payload.get("seed")
                )
                return self._json(job.public(include_result=False), status=HTTPStatus.ACCEPTED)
            return self._error(HTTPStatus.NOT_FOUND, "API yolu bulunamadı")
        except KeyError as exc:
            return self._error(HTTPStatus.BAD_REQUEST, f"Eksik alan: {exc}")
        except ValueError as exc:
            return self._error(HTTPStatus.BAD_REQUEST, str(exc))
        except Exception as exc:
            return self._error(HTTPStatus.INTERNAL_SERVER_ERROR, str(exc))

    def _get_job_route(self, path: str) -> None:
        parts = [part for part in path.split("/") if part]
        if len(parts) < 3:
            return self._error(HTTPStatus.NOT_FOUND, "Koşu yolu eksik")
        job = self.state.get_job(parts[2])
        if len(parts) == 3:
            return self._json(job.public(include_result=True))
        if len(parts) == 5 and parts[3] == "download":
            filename = parts[4]
            if filename not in DOWNLOAD_FILES or not job.output_directory:
                return self._error(HTTPStatus.NOT_FOUND, "Çıktı bulunamadı")
            file_path = (job.output_directory / filename).resolve()
            if job.output_directory.resolve() not in file_path.parents or not file_path.exists():
                return self._error(HTTPStatus.NOT_FOUND, "Çıktı bulunamadı")
            return self._send_file(file_path, attachment=filename != "report.html")
        return self._error(HTTPStatus.NOT_FOUND, "Koşu çıktısı bulunamadı")

    def _read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0 or length > MAX_REQUEST_BYTES:
            raise ValueError("JSON gövdesi boş veya çok büyük")
        raw = self.rfile.read(length)
        value = json.loads(raw.decode("utf-8"))
        if not isinstance(value, dict):
            raise ValueError("JSON kökü nesne olmalı")
        return value

    def _send_static(self, filename: str) -> None:
        allowed = {"index.html", "app.js", "styles.css"}
        if filename not in allowed:
            return self._error(HTTPStatus.NOT_FOUND, "Statik dosya bulunamadı")
        path = Path(__file__).resolve().parent / "webui" / filename
        return self._send_file(path)

    def _send_file(self, path: Path, *, attachment: bool = False) -> None:
        if not path.exists():
            return self._error(HTTPStatus.NOT_FOUND, "Dosya bulunamadı")
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        data = path.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8" if content_type.startswith("text/") else content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        if attachment:
            self.send_header("Content-Disposition", f'attachment; filename="{path.name}"')
        self.end_headers()
        self.wfile.write(data)

    def _json(self, payload: Any, *, status: HTTPStatus = HTTPStatus.OK) -> None:
        data = json.dumps(json_safe(payload), ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)

    def _error(self, status: HTTPStatus, message: str) -> None:
        return self._json({"error": message, "status": int(status)}, status=status)

    def log_message(self, format: str, *args: Any) -> None:
        if self.path.startswith("/api/jobs/"):
            return
        super().log_message(format, *args)


def scenario_overview(scenario: Scenario) -> dict[str, Any]:
    if scenario.meta.get("engine") == "operations_v1":
        return case_overview(scenario.raw)
    return {
        "scenario_id": scenario.scenario_id,
        "name": scenario.name,
        "horizon": scenario.horizon,
        "step": scenario.step,
        "drivers": len(scenario.drivers),
        "strategies": len(scenario.strategies),
        "actors": len(scenario.actors),
        "shocks": len(scenario.shocks),
        "nodes": len(scenario.states) + len(scenario.equations),
        "metrics": len(scenario.metrics),
        "hash": scenario.hash,
    }


def compose_narrative(compact: Mapping[str, Any]) -> dict[str, Any]:
    ranking = compact["summary"]["ranking"]
    winner = ranking[0]
    contender = ranking[1] if len(ranking) > 1 else None
    status = compact.get("decision_status", {})
    top_driver = None
    driver_rows = compact.get("sensitivity", {}).get(winner["strategy_id"], [])
    if driver_rows:
        top_driver = driver_rows[0]
    weakest_stress = None
    for stress in compact.get("stress_profiles", []):
        row = next(
            (item for item in stress.get("strategies", []) if item["strategy_id"] == winner["strategy_id"]),
            None,
        )
        if row and math.isfinite(float(row.get("expected_utility", math.nan))) and (
            weakest_stress is None or row["expected_utility"] < weakest_stress["expected_utility"]
        ):
            weakest_stress = {**row, "label": stress["label"]}
    why = (
        f"{winner['label']}; beklenen fayda %{winner['expected_utility']*100:.1f}, "
        f"en kötü kuyruk %{winner['utility_cvar']*100:.1f} ve sağlamlık %{winner['robustness']*100:.1f} üretti. "
        f"Karar durumu: {status.get('label', 'sıralama')}"
    )
    comparison = None
    score_gap = None
    if contender:
        score_gap = winner["decision_score"] - contender["decision_score"]
        comparison = (
            f"İkinci sıradaki {contender['label']} ile karar skoru farkı {score_gap:.3f}. "
            "Fark küçükse iki politika birbirine yakın kabul edilmelidir."
        )
    actions = []
    if status.get("code") == "no_eligible_option":
        actions.append("Hiçbir seçenek sert sınırları yeterince geçemedi; seçenekleri veya hayatta kalma planını yeniden tasarla.")
    elif status.get("code") == "single_eligible":
        actions.append("Öndeki seçenek yalnızca risk bütçesini geçen tek yol; bunu kesin üstünlük değil, sert sınırlarla eleme sonucu olarak doğrula.")
    elif status.get("code") in {"conditional", "close"}:
        actions.append("Tek kazanan ilan etme; gelecek ağacındaki gözlenebilir koşula bağlı tetikleyici ve yedek plan tanımla.")
    if winner.get("ruin_probability", 0.0) > 0.10:
        actions.append("Önerilen politikada ciddi nakit/çöküş riski var; önce nakit tabanını ve sert kısıtları gözden geçir.")
    if top_driver:
        actions.append(
            f"Sonucu en çok ayıran özellik '{top_driver['driver']}'. Bu girdiyi gerçek veriyle daraltmak karar güvenini artırır."
        )
    if weakest_stress:
        actions.append(
            f"Önerilen politika en çok '{weakest_stress['label']}' stresinde zorlanıyor; bu koşul için yedek plan tanımla."
        )
    actions.append("Gerçekleşen aylık sonuçları kaydedip aynı modeli yeni verilerle tekrar çalıştır.")
    worlds = int(compact.get("metadata", {}).get("worlds", 0))
    confidence_note = (
        "Bu hızlı deneme koşusudur; nihai yorum için en az 1.000 dünya çalıştır."
        if worlds < 1000
        else "Dünya sayısı karar dağılımını okumak için yeterli; model varsayımları yine de doğrulanmalıdır."
    )
    headline = (
        f"Net üstünlük: {winner['label']}"
        if status.get("recommended_strategy_id")
        else f"{status.get('label', 'Koşullu sonuç')}: şu an {winner['label']} önde"
    )
    return {
        "headline": headline,
        "why": why,
        "comparison": comparison,
        "score_gap": score_gap,
        "confidence_note": confidence_note,
        "recommended_actions": actions,
        "top_driver": top_driver,
        "weakest_stress": weakest_stress,
        "caveat": "Sonuçlar yalnızca bu model, veri ve tercih ağırlıkları altında geçerlidir; yüksek etkili kararda insan onayı gerekir.",
    }


def json_safe(value: Any) -> Any:
    """Tarayıcı API'si için NaN/Infinity değerlerini JSON null'a çevir."""
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Mapping):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    return value


def discover_templates(primary: Path | None = None) -> list[Path]:
    root = Path(__file__).resolve().parents[1]
    candidates: list[Path] = []
    if primary:
        candidates.append(primary.expanduser().resolve())
    candidates.extend(sorted((root / "examples").glob("*.json")))
    result: list[Path] = []
    seen: set[Path] = set()
    for path in candidates:
        if path.name.endswith(".snapshot.json") or path in seen:
            continue
        seen.add(path)
        result.append(path)
    return result


def find_available_port(host: str, preferred: int) -> int:
    for port in range(preferred, preferred + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            try:
                probe.bind((host, port))
            except OSError:
                continue
            return port
    raise OSError(f"{preferred}–{preferred+19} aralığında boş port bulunamadı")


def open_studio_url(url: str) -> None:
    command = shutil.which("termux-open-url")
    if command:
        try:
            subprocess.Popen([command, url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        except OSError:
            pass
    webbrowser.open(url)


def create_server(
    *, workspace: Path, template_paths: list[Path], host: str = "127.0.0.1", port: int = 8765
) -> StudioHTTPServer:
    state = StudioState(workspace, template_paths)
    return StudioHTTPServer((host, port), StudioHandler, state)


def serve_studio(
    *,
    workspace: Path,
    primary_scenario: Path | None = None,
    host: str = "127.0.0.1",
    port: int = 8765,
    open_browser: bool = True,
) -> None:
    actual_port = find_available_port(host, port)
    server = create_server(
        workspace=workspace,
        template_paths=discover_templates(primary_scenario),
        host=host,
        port=actual_port,
    )
    url = f"http://{host}:{actual_port}/"
    print("Olasılık Simüle hazır")
    print(f"Adres: {url}")
    print("Kapatmak için CTRL+C")
    if open_browser:
        timer = threading.Timer(0.5, open_studio_url, args=(url,))
        timer.daemon = True
        timer.start()
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        print("\nOlasılık Simüle kapatıldı.")
    finally:
        server.server_close()
