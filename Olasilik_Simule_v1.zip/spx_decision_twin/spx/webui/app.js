"use strict";

const state = {
  catalog: null,
  caseInput: null,
  scenario: null,
  projects: [],
  result: null,
  jobId: null,
  screen: "room",
  wizardStep: 0,
  worlds: 300,
  futureMode: "switch",
  selectedFutureId: null,
  selectedModelId: null,
  assumptionFilter: "ALL",
  selectedDrilldown: null,
  selectedContribution: 0,
  guideTab: "quick",
  tourIndex: 0,
  historyText: "",
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

const WIZARD_STEPS = [
  ["Karar", "Ne seçiyoruz?"],
  ["Bugün", "Başlangıç durumu"],
  ["Belirsizlik", "Neyi bilmiyoruz?"],
  ["Seçenekler", "Neyi değiştirebiliriz?"],
  ["Başarı & veri", "Hangi sınırlar geçerli?"],
];

const STATUS_OPTIONS = [
  ["OBSERVED", "Kayıttan ölçüldü"],
  ["ESTIMATED", "Yaklaşık tahmin"],
  ["ASSUMPTION", "Model varsayımı"],
];

const BASELINE_FIELDS = [
  ["monthly_demand", "Aylık talep / sipariş", "Normal bir ayda gelen toplam talep.", "adet", 1, 1],
  ["unit_price", "Birim satış fiyatı", "Bir satıştan alınan ortalama fiyat.", "₺", 0.01, 1],
  ["variable_cost_per_unit", "Birim değişken gider", "Malzeme ve satışla birlikte artan gider.", "₺", 0, 1],
  ["fixed_cost_monthly", "Aylık sabit gider", "Maaşların mevcut kısmı dahil, satış olmasa da çıkan gider.", "₺", 0, 1000],
  ["starting_cash", "Kullanılabilir nakit", "Karar günü kasada gerçekten kullanılabilen tutar.", "₺", -1e12, 1000],
  ["machine_count", "Makine / ana ekipman", "Kapasiteyi taşıyan benzer ekipman sayısı.", "adet", 1, 1],
  ["machine_capacity_per_day", "Bir makinenin günlük kapasitesi", "Normal bir iş günündeki iyi üretim kapasitesi.", "adet/gün", 0.01, 1],
  ["worker_count", "Operasyon çalışanı", "Üretim veya hizmet kapasitesine doğrudan katkı veren çalışan.", "kişi", 1, 1],
  ["worker_capacity_per_day", "Bir çalışanın günlük kapasitesi", "Normal koşulda kişi başı çıktı.", "adet/gün", 0.01, 1],
  ["working_days_per_month", "Aylık iş günü", "Model her ayı bu kadar operasyon günüyle açar.", "gün", 1, 1],
  ["starting_inventory_units", "Başlangıç malzeme stoku", "Üretime hazır ham madde / ürün karşılığı.", "adet", 0, 1],
  ["starting_backlog_units", "Bekleyen sipariş", "Karar günü henüz karşılanmamış talep.", "adet", 0, 1],
  ["added_worker_monthly_cost", "Yeni çalışan aylık maliyeti", "Maaş + işverene toplam ek aylık maliyet.", "₺", 0, 1000],
  ["machine_purchase_cost", "Makine yenileme değeri", "Arıza ve bakım maliyetini ölçeklemek için kullanılır.", "₺", 0, 1000],
];

const UNCERTAINTY_FIELDS = [
  ["annual_demand_trend", "Yıllık talep eğilimi", "Talebin merkezinin yılda ne kadar değişeceği.", "%", -80, 0.01, 100],
  ["demand_volatility", "Yıllıklaştırılmış talep oynaklığı", "Aylık sapmaların yıllıklaştırılmış büyüklüğü; geçmiş aylardan kalibre edilebilir.", "%", 0.5, 0.1, 100],
  ["annual_cost_inflation", "Yıllık maliyet artışı", "Malzeme ve sabit gider endeksinin merkezi.", "%", -50, 0.1, 100],
  ["absence_rate", "Normal devamsızlık", "Bir iş gününde beklenen çalışan eksikliği.", "%", 0, 0.1, 100],
  ["supplier_normal_fill", "Normal tedarik karşılama", "Sipariş edilen malzemenin normal dönemde gelen payı.", "%", 20, 0.1, 100],
  ["supplier_disruption_probability", "Aylık tedarik bozulması", "Normal akıştan belirgin sapma olasılığı.", "%", 0, 0.1, 100],
  ["failure_weibull_scale_days", "Makine ömür ölçeği", "Arıza yaşlanma modelinin gün cinsinden ölçeği; kesin ortalama değildir.", "gün", 10, 1, 1],
  ["mean_repair_days", "Ortalama onarım süresi", "Bir arızanın ekipmanı kaç gün durdurduğu.", "gün", 0.25, 0.25, 1],
];

const ADVANCED_UNCERTAINTIES = [
  ["demand_persistence", "Talep kalıcılığı", "Kötü veya iyi ayın sonraki aya taşınma gücü.", "oran", 0, 0.01, 1],
  ["failure_weibull_shape", "Arıza yaşlanma şekli", "1'in üstünde yaş arttıkça arıza tehlikesi büyür.", "katsayı", 0.35, 0.05, 1],
  ["price_elasticity", "Fiyat hassasiyeti", "Fiyat değişiminin talep üzerindeki model katsayısı.", "katsayı", 0, 0.05, 1],
  ["marketing_elasticity", "Pazarlama etkisi", "Pazarlama bütçesinin talep üzerindeki model katsayısı.", "katsayı", 0, 0.05, 1],
  ["base_defect_rate", "Temel hata oranı", "Yorgunluk ve kapasite baskısı yokken kalite kaybı.", "%", 0, 0.1, 100],
  ["parameter_uncertainty", "Model parametresi belirsizliği", "Tahmin/varsayımların dünya bazında oynadığı aralık.", "%", 0, 1, 100],
  ["supplier_lead_months", "Normal tedarik süresi", "Siparişin stoka girmesine kadar geçen ay.", "ay", 0, 1, 1],
];

const STRATEGY_FIELDS = [
  ["start_month", "Başlama ayı", "ay", 1, 60, 1],
  ["added_machines", "Eklenecek makine", "adet", 0, 100, 1],
  ["added_workers", "Eklenecek çalışan", "kişi", 0, 10000, 1],
  ["upfront_investment", "Başlangıç yatırımı", "₺", 0, 1e15, 10000],
  ["marketing_rate", "Pazarlama / baz ciro", "%", 0, 50, 0.5, 100],
  ["price_change", "Fiyat değişimi", "%", -50, 150, 0.5, 100],
  ["maintenance_interval_days", "Bakım aralığı", "gün", 15, 2000, 5],
  ["maintenance_downtime_days", "Bakımda duruş", "gün", 0, 60, 1],
  ["safety_stock_days", "Güvenlik stoku", "günlük talep", 0, 180, 1],
  ["training_rate", "Eğitim yoğunluğu", "%", 0, 50, 0.5, 100],
  ["overtime_limit", "Fazla mesai tavanı", "%", 0, 80, 1, 100],
];

const CF_FIELDS = {
  maintenance_interval_days: ["Bakım aralığı", "gün"],
  safety_stock_days: ["Güvenlik stoku", "günlük talep"],
  added_machines: ["Eklenecek makine", "adet"],
  added_workers: ["Eklenecek çalışan", "kişi"],
  marketing_rate: ["Pazarlama oranı", "oran (0.05 = %5)"],
  price_change: ["Fiyat değişimi", "oran (0.02 = %2)"],
  start_month: ["Başlama ayı", "ay"],
  upfront_investment: ["Başlangıç yatırımı", "₺"],
};

const TOUR_STEPS = [
  ["room", "Kararı daralt", "İlk iş şirketi anlatmak değil; yanlış verilirse pahalı olacak tek kararı ve gerçek alternatifleri yazmak."],
  ["room", "Başlangıç durumunu sabitle", "Ciro yerine modelin kullandığı mekanikleri gir: talep, birim ekonomi, makine, çalışan, stok ve nakit."],
  ["model", "Dünya modelini sorgula", "Her modüle dokun. Hangi girdinin hangi matematikle çıktıya dönüştüğünü ve kaynağını gör."],
  ["lab", "Aynı dünyalarda yarıştır", "Önce 100–300 dünya ile mekaniği kontrol et; sonra 1.000 dünyaya çık."],
  ["future", "Tek kazanan arama", "Ağaçta hangi koşulların seçimi değiştirdiğini ve öndeki planın nerede kırıldığını aç."],
  ["evidence", "Yüzdeyi parçala", "Başarı yüzdesinin paydasını, hata aralığını, gelecek katkılarını, modeli ve kaynağı geriye doğru izle."],
  ["lab", "Gerçek müdahaleyi dene", "Karşı-olgusal laboratuvarda yalnız bir kararı değiştir; dış dünyayı aynı tutup etkiyi ölç."],
];

const GUIDE = {
  quick: `
    <ol class="guide-steps">
      <li><b>Kararı tek cümleye indir.</b><span>“Şirket ne olacak?” değil; “18 ay içinde kapasite yatırımını şimdi mi, sonra mı yapmalıyım?”</span></li>
      <li><b>Gerçek seçenekleri yaz.</b><span>Mevcut düzen de bir seçenektir. Yapmayacağın hayalî alternatifi ekleme.</span></li>
      <li><b>Başlangıç mekaniğini gir.</b><span>Talep, birim fiyat/gider, makine, çalışan, stok, backlog ve nakit.</span></li>
      <li><b>Her sayının kökenini işaretle.</b><span>Kayıt, yaklaşık tahmin veya model varsayımı.</span></li>
      <li><b>100 dünyada yön testi yap.</b><span>Bakım artınca arıza azalıyor mu? Stok artınca stockout azalıyor mu? Tersiyse modeli düzelt.</span></li>
      <li><b>1.000 dünyada kararı oku.</b><span>Öndeki seçeneğin yanında kötü kuyruk, sert sınırlar ve gelecek dallarına bak.</span></li>
    </ol>`,
  data: `
    <div class="guide-copy"><h3>Asgari veri paketi</h3><p>Son 6–12 ay için aylık sipariş, satış, birim değişken gider, sabit gider, devamsızlık, arıza/duruş ve hizmet seviyesi. Veri yoksa yaklaşık değer kullanılabilir; fakat “ölçüldü” diye işaretlenmez.</p>
    <table><tr><th>Alan</th><th>Tercih edilen kaynak</th><th>Yoksa</th></tr><tr><td>Talep</td><td>Sipariş kayıtları</td><td>Normal ay + kötü/iyi ay aralığı</td></tr><tr><td>Arıza</td><td>Bakım emri / duruş kaydı</td><td>Son 12 ay olay sayısı ve onarım günü</td></tr><tr><td>Devamsızlık</td><td>Puantaj, toplu oran</td><td>Vardiya yöneticisi tahmini</td></tr><tr><td>Tedarik</td><td>Sipariş–teslim tarihleri</td><td>Geç kalan ay payı</td></tr></table></div>`,
  logic: `
    <div class="guide-copy"><h3>Tek algoritma yok; model federasyonu var</h3><p>Talep rejim/zaman süreciyle, makine yaşa bağlı Weibull tehlikesi ve günlük olaylarla, çalışan cohort devamsızlığıyla, tedarik lead-time kuyruğuyla, finans ise nakit stokuyla çalışır. Monte Carlo bu parçaların belirsiz girdilerini ortak dünyalarda yürütür.</p>
    <p><b>İki belirsizlik ayrılır:</b> doğal rastlantı (hangi gün arıza olacağı) ve bilgi eksikliği (makine ömür ölçeğini tam bilmemek). İkincisi daha iyi veriyle daraltılabilir.</p></div>`,
  read: `
    <div class="guide-copy"><h3>Dört soruyla oku</h3><ol><li>Herhangi bir seçenek sert sınırları geçiyor mu?</li><li>Öndeki seçenek kötü yüzde 10 dünyada ne yapıyor?</li><li>Hangi gelecek dalında seçim tersine dönüyor?</li><li>Hangi tahmin/varsayım seçim üzerinde en yüksek ayırma gücüne sahip?</li></ol><p>Karar durumu “koşula bağlı” ise tek kazanan arama; gözlenebilir bir tetikleyici ve yedek plan kur.</p></div>`,
  limits: `
    <div class="guide-copy"><h3>Bu araç neyi kanıtlamaz?</h3><ul><li>Kalibrasyonsuz yüzde gerçek şirket olasılığı değildir.</li><li>Hassasiyet ilişkisi nedensellik kanıtı değildir.</li><li>Çok dünya çalıştırmak yanlış denklemi doğru yapmaz.</li><li>Başka sektör, aynı katsayıları değiştirerek otomatik olarak modellenmez.</li><li>Yüksek etkili kararda historical replay, uzman incelemesi ve insan onayı gerekir.</li></ul></div>`,
};

document.addEventListener("DOMContentLoaded", boot);

async function boot() {
  bindEvents();
  setServer("loading", "Bağlanıyor");
  try {
    const data = await api("/api/bootstrap");
    state.catalog = data.decision_builder;
    state.projects = data.projects || [];
    state.caseInput = clone(data.decision_builder.default_input);
    if (data.default_scenario?.meta?.engine === "operations_v1") {
      state.scenario = data.default_scenario;
      state.caseInput = clone(data.default_scenario.meta?.builder_input || state.caseInput);
    }
    state.selectedModelId = state.scenario?.model_registry?.[0]?.id || null;
    renderAll();
    setServer("ready", "Yerel motor hazır");
  } catch (error) {
    setServer("error", "Bağlantı yok");
    toast(error.message, true);
  }
}

function bindEvents() {
  document.addEventListener("click", (event) => {
    const go = event.target.closest("[data-go]");
    if (go) return showScreen(go.dataset.go);
    const close = event.target.closest("[data-close]");
    if (close) return closeDialog(close.dataset.close);
    const wizard = event.target.closest("[data-wizard-step]");
    if (wizard) return jumpWizard(Number(wizard.dataset.wizardStep));
    const world = event.target.closest("[data-worlds]");
    if (world) return selectWorlds(Number(world.dataset.worlds));
    const model = event.target.closest("[data-model-id]");
    if (model) { state.selectedModelId = model.dataset.modelId; renderModel(); return; }
    const filter = event.target.closest("[data-filter]");
    if (filter) { state.assumptionFilter = filter.dataset.filter; renderAssumptions(); return; }
    const mode = event.target.closest("[data-mode]");
    if (mode) { state.futureMode = mode.dataset.mode; state.selectedFutureId = null; renderFuture(); return; }
    const future = event.target.closest("[data-future-id]");
    if (future) { state.selectedFutureId = future.dataset.futureId; renderFuture(); return; }
    const drill = event.target.closest("[data-drill-key]");
    if (drill) { state.selectedDrilldown = drill.dataset.drillKey; state.selectedContribution = 0; showScreen("evidence"); renderEvidence(); return; }
    const contribution = event.target.closest("[data-contribution-index]");
    if (contribution) { state.selectedContribution = Number(contribution.dataset.contributionIndex); renderEvidence(); return; }
    const guideTab = event.target.closest("[data-guide-tab]");
    if (guideTab) { state.guideTab = guideTab.dataset.guideTab; renderGuide(); return; }
    const loadProject = event.target.closest("[data-project-id]");
    if (loadProject) return loadProjectById(loadProject.dataset.projectId);
  });
  document.addEventListener("input", handleFormInput);
  document.addEventListener("change", handleFormInput);
  $("#wizardBackButton").addEventListener("click", () => moveWizard(-1));
  $("#wizardNextButton").addEventListener("click", () => moveWizard(1));
  $("#loadExampleButton").addEventListener("click", resetExample);
  $("#runButton").addEventListener("click", runSimulation);
  $("#whatIsPairedButton").addEventListener("click", () => openDialog("pairedDialog"));
  $("#cfRunButton").addEventListener("click", runCounterfactual);
  $("#cfStrategy").addEventListener("change", syncCounterfactualValue);
  $("#cfField").addEventListener("change", syncCounterfactualValue);
  $("#drilldownSelect").addEventListener("change", (event) => { state.selectedDrilldown = event.target.value; state.selectedContribution = 0; renderEvidence(); });
  $("#guideButton").addEventListener("click", () => { renderGuide(); openDialog("guideDialog"); });
  $("#startTourButton").addEventListener("click", startTour);
  $("#tourNextButton").addEventListener("click", nextTour);
  $("#tourExitButton").addEventListener("click", endTour);
  $("#projectsButton").addEventListener("click", openProjects);
  $("#saveButton").addEventListener("click", openSave);
  $("#confirmSaveButton").addEventListener("click", saveProject);
}

function handleFormInput(event) {
  const input = event.target.closest("[data-path]");
  if (input) {
    const scale = Number(input.dataset.scale || 1);
    let value = input.type === "checkbox" ? input.checked : input.value;
    if (input.dataset.kind === "number") value = numeric(value, 0) / scale;
    setPath(state.caseInput, input.dataset.path, value);
    markCaseDirty();
    const output = input.closest(".range-field")?.querySelector("output");
    if (output) output.textContent = formatInputValue(value, input.dataset.unit, scale);
  }
  const status = event.target.closest("[data-status-path]");
  if (status) {
    state.caseInput.data_status[status.dataset.statusPath] = status.value;
    status.className = `status-select status-${status.value.toLowerCase()}`;
    markCaseDirty();
  }
  if (event.target.id === "historyText") {
    state.historyText = event.target.value;
    markCaseDirty();
  }
}

function markCaseDirty() {
  if (state.scenario || state.result) {
    state.scenario = null;
    state.result = null;
    state.jobId = null;
    state.selectedFutureId = null;
    state.selectedDrilldown = null;
  }
  $("#saveButton").disabled = true;
  renderContext();
  const status = $("#wizardStatus");
  if (status) status.textContent = "Değişiklikler henüz motora uygulanmadı";
}

function renderAll() {
  renderContext();
  renderWizard();
  renderModel();
  renderLab();
  renderFuture();
  renderEvidence();
  renderGuide();
  $("#saveButton").disabled = !state.scenario;
}

function renderContext() {
  const decision = state.scenario?.decision || state.caseInput?.decision;
  const company = state.scenario?.decision?.company_name || state.caseInput?.company?.name;
  $("#caseContextLabel").textContent = decision?.question ? truncate(decision.question, 65) : "Yeni karar";
  $("#caseContextName").textContent = company || "Henüz kurulmadı";
}

function renderWizard() {
  $("#wizardSteps").innerHTML = WIZARD_STEPS.map((item, index) => `
    <button class="${index === state.wizardStep ? "active" : ""} ${index < state.wizardStep ? "done" : ""}" data-wizard-step="${index}" type="button"><span>${index + 1}</span><b>${esc(item[0])}</b><small>${esc(item[1])}</small></button>
  `).join("");
  const renderers = [renderDecisionStep, renderBaselineStep, renderUncertaintyStep, renderStrategiesStep, renderSuccessStep];
  $("#wizardSurface").innerHTML = renderers[state.wizardStep]();
  $("#wizardBackButton").disabled = state.wizardStep === 0;
  $("#wizardNextButton").textContent = state.wizardStep === WIZARD_STEPS.length - 1 ? "Karar modelini kur →" : "İleri →";
  $("#wizardStatus").textContent = `Adım ${state.wizardStep + 1} / ${WIZARD_STEPS.length}`;
}

function renderDecisionStep() {
  const c = state.caseInput.company;
  const d = state.caseInput.decision;
  return `<div class="wizard-copy"><span class="step-number">01</span><div><h2>Hangi karar yanlış verilirse pahalı olur?</h2><p>Şirketin bütün geleceğini değil, bugün gerçekten seçebileceğin alternatifleri etkileyen tek soruyu yaz.</p></div></div>
    <div class="form-grid two">
      ${textField("company.name", "Şirket / proje adı", c.name, "Örn. Konya Üretim Tesisi")}
      ${textField("company.sector_note", "Operasyonun kısa tanımı", c.sector_note, "Örn. paketli gıda, e-ticaret deposu")}
      <label class="field span-2"><span>Karar sorusu</span><textarea data-path="decision.question" rows="3" placeholder="Önümüzdeki 18 ayda…">${esc(d.question)}</textarea><small>İyi soru: süre + eylem + trade-off içerir.</small></label>
      ${textField("decision.owner", "Karar sahibi", d.owner, "Bu kararı kim onaylayacak?")}
      ${textField("decision.deadline", "Karar son tarihi", d.deadline, "Örn. bu ay / 1 Ekim")}
      ${numberField("decision.horizon_months", "Kaç ay ileri?", d.horizon_months, "ay", 3, 60, 1)}
      <label class="field"><span>Geri döndürülebilirlik</span><select data-path="decision.reversibility"><option value="high" ${selected(d.reversibility, "high")}>Kolay — geri alınabilir</option><option value="medium" ${selected(d.reversibility, "medium")}>Orta — maliyetli ama mümkün</option><option value="low" ${selected(d.reversibility, "low")}>Zor — büyük/kalıcı yatırım</option></select><small>Geri dönüş zorsa kuyruk riski daha önemlidir.</small></label>
    </div>
    <aside class="plain-note"><b>Doğru kapsam:</b> “Yeni makine hattı şimdi mi alınmalı, 6 ay beklenmeli mi, yoksa dış kaynak mı kullanılmalı?” <span>Yanlış kapsam: “Şirketim başarılı olur mu?”</span></aside>`;
}

function renderBaselineStep() {
  const b = state.caseInput.baseline;
  return `<div class="wizard-copy"><span class="step-number">02</span><div><h2>Karar verilmeden hemen önce sistem nerede?</h2><p>Bu değerler başlangıç state'idir. Her sayı için kayıttan mı, tahmin mi olduğunu işaretle.</p></div></div>
    <div class="datum-grid">${BASELINE_FIELDS.map((field) => datumField("baseline", b, field)).join("")}</div>
    <aside class="plain-note"><b>İpucu:</b> “Ciro” tek başına kapasiteyi anlatmaz. Bu nedenle fiyat × adet × değişken gider ayrı sorulur.</aside>`;
}

function renderUncertaintyStep() {
  const u = state.caseInput.uncertainty;
  return `<div class="wizard-copy"><span class="step-number">03</span><div><h2>Neyi kontrol edemiyoruz, neyi tam bilmiyoruz?</h2><p>Talep ve olay rastlantısı ile parametre bilgi eksikliğini motor ayrı taşır.</p></div></div>
    <div class="datum-grid">${UNCERTAINTY_FIELDS.map((field) => uncertaintyField(u, field)).join("")}</div>
    <details class="advanced-fields"><summary>İleri model varsayımları</summary><p>Bunları bilmiyorsan varsayım olarak bırak; sistem Güven ekranında veri açığını gösterecek.</p><div class="datum-grid">${ADVANCED_UNCERTAINTIES.map((field) => uncertaintyField(u, field)).join("")}</div></details>
    <aside class="uncertainty-explainer"><div><b>Doğal rastlantı</b><span>Arızanın hangi gün olacağı</span></div><i>≠</i><div><b>Bilgi eksikliği</b><span>Makine ömür ölçeğini tam bilmemek</span></div></aside>`;
}

function renderStrategiesStep() {
  return `<div class="wizard-copy"><span class="step-number">04</span><div><h2>Gerçekten yapabileceğin yolları kur</h2><p>Her seçenek bir etiket değil; başlangıç zamanı, yatırım, kapasite, bakım, stok ve tepki politikasıdır.</p></div></div>
    <div class="strategy-editor">${state.caseInput.strategies.map((strategy, index) => strategyEditor(strategy, index)).join("")}</div>
    <aside class="plain-note"><b>Adil karşılaştırma:</b> “Mevcut düzen” seçeneğini silme. Bir yatırım, hiçbir şey yapmamaya karşı da değer üretmelidir.</aside>`;
}

function renderSuccessStep() {
  const p = state.caseInput.preferences;
  const historyCount = parseHistory(state.historyText).length;
  return `<div class="wizard-copy"><span class="step-number">05</span><div><h2>“Başarılı” ve “kabul edilemez” ne demek?</h2><p>Bu eşikler veri değil, karar sahibinin tercih ve hayatta kalma sınırlarıdır.</p></div></div>
    <div class="form-grid three">
      ${numberField("preferences.minimum_cash", "En düşük kabul edilen nakit", p.minimum_cash, "₺", -1e15, 1e15, 1000)}
      ${numberField("preferences.minimum_service_level", "Minimum ortalama hizmet", p.minimum_service_level * 100, "%", 0, 100, 1, 100)}
      ${numberField("preferences.maximum_stockout_months", "En fazla stockout ayı", p.maximum_stockout_months, "ay", 0, 60, 1)}
    </div>
    <details class="history-import" ${state.historyText ? "open" : ""}><summary>Geçmiş aylık veriyi ekle <span>${historyCount ? historyCount + " ay algılandı" : "isteğe bağlı"}</span></summary>
      <p>Bir satır bir ay. Başlık kullanabilirsin: <code>ay,siparis,ciro,degisken_gider,sabit_gider,devamsizlik,ariza</code></p>
      <textarea id="historyText" rows="7" placeholder="2026-01,4200,588000,260400,240000,0.05,1\n2026-02,4500,630000,279000,240000,0.06,0">${esc(state.historyText)}</textarea>
      <small>En az 4 geçerli ay varsa talep merkezi/oynaklığı, birim ekonomi ve devamsızlık başlangıç değerleri kayıttan kalibre edilir.</small>
    </details>
    <section class="case-review">${caseReview()}</section>`;
}

function datumField(group, values, field) {
  const [key, label, help, unit, min, step] = field;
  const path = `${group}.${key}`;
  const status = state.caseInput.data_status[path] || "ESTIMATED";
  return `<label class="datum"><span>${esc(label)}</span><div class="value-input"><input data-path="${path}" data-kind="number" type="number" value="${numeric(values[key], 0)}" min="${min}" step="${step}"><b>${esc(unit)}</b></div><small>${esc(help)}</small>${statusSelect(path, status)}</label>`;
}

function uncertaintyField(values, field) {
  const [key, label, help, unit, min, step, scale] = field;
  const path = `uncertainty.${key}`;
  const status = state.caseInput.data_status[path] || "ASSUMPTION";
  const shown = numeric(values[key], 0) * scale;
  const origin = key === "parameter_uncertainty"
    ? `<span class="fixed-status">MODEL AYARI · kaynak statüsü değildir</span>`
    : statusSelect(path, status);
  return `<label class="datum"><span>${esc(label)}</span><div class="value-input"><input data-path="${path}" data-kind="number" data-scale="${scale}" type="number" value="${round(shown, 4)}" min="${min}" step="${step}"><b>${esc(unit)}</b></div><small>${esc(help)}</small>${origin}</label>`;
}

function strategyEditor(strategy, index) {
  return `<article class="strategy-edit-card"><header><span>${index + 1}</span><div><input class="strategy-name" data-path="strategies.${index}.label" value="${esc(strategy.label)}" aria-label="Strateji adı"><textarea data-path="strategies.${index}.description" rows="2" aria-label="Strateji açıklaması">${esc(strategy.description || "")}</textarea></div></header><div class="strategy-fields">${STRATEGY_FIELDS.map((field) => strategyField(strategy, index, field)).join("")}</div><label class="check-field"><input type="checkbox" data-path="strategies.${index}.cash_brake" ${strategy.cash_brake ? "checked" : ""}><span>Nakit daralırsa pazarlama, fazla mesai ve stok hedefini otomatik frenle</span></label></article>`;
}

function strategyField(strategy, index, field) {
  const [key, label, unit, min, max, step, scale = 1] = field;
  return `<label class="mini-field"><span>${esc(label)}</span><div><input data-path="strategies.${index}.${key}" data-kind="number" data-scale="${scale}" type="number" value="${round(numeric(strategy[key], 0) * scale, 4)}" min="${min}" max="${max}" step="${step}"><b>${esc(unit)}</b></div></label>`;
}

function statusSelect(path, value) {
  return `<select class="status-select status-${value.toLowerCase()}" data-status-path="${path}" aria-label="${esc(path)} veri kaynağı">${STATUS_OPTIONS.map((item) => `<option value="${item[0]}" ${selected(value, item[0])}>${item[1]}</option>`).join("")}</select>`;
}

function caseReview() {
  const i = state.caseInput;
  const observed = Object.values(i.data_status).filter((value) => value === "OBSERVED").length;
  const estimated = Object.values(i.data_status).filter((value) => value === "ESTIMATED").length;
  const assumptions = Object.values(i.data_status).filter((value) => value === "ASSUMPTION").length;
  return `<span class="eyebrow">KOŞU ÖNCESİ ÖZET</span><h3>${esc(i.decision.question)}</h3><div class="review-grid"><div><b>${i.decision.horizon_months}</b><span>ay ufuk</span></div><div><b>${i.strategies.length}</b><span>gerçek seçenek</span></div><div><b>${observed}</b><span>ölçülen alan</span></div><div><b>${estimated + assumptions}</b><span>tahmin / varsayım</span></div></div><p>Motor, ${esc(i.company.name)} için “bütün şirket” modeli değil; bu kararın operasyon–nakit alt sistemini kuracak.</p>`;
}

function jumpWizard(step) {
  if (step > state.wizardStep && !validateWizard(state.wizardStep)) return;
  state.wizardStep = clamp(step, 0, WIZARD_STEPS.length - 1);
  renderWizard();
}

function moveWizard(direction) {
  if (direction < 0) return jumpWizard(state.wizardStep - 1);
  if (!validateWizard(state.wizardStep)) return;
  if (state.wizardStep === WIZARD_STEPS.length - 1) return buildDecisionCase();
  state.wizardStep += 1;
  renderWizard();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function validateWizard(step) {
  const i = state.caseInput;
  const problems = [];
  if (step === 0) {
    if (!String(i.company.name || "").trim()) problems.push("Şirket/proje adı boş.");
    if (String(i.decision.question || "").trim().length < 15) problems.push("Karar sorusunu biraz daha açık yaz.");
  }
  if (step === 1) {
    if (numeric(i.baseline.monthly_demand, 0) <= 0) problems.push("Aylık talep sıfırdan büyük olmalı.");
    if (numeric(i.baseline.machine_count, 0) < 1 || numeric(i.baseline.worker_count, 0) < 1) problems.push("En az bir ekipman ve bir çalışan gerekli.");
  }
  if (step === 3) {
    const names = i.strategies.map((item) => String(item.label || "").trim().toLowerCase());
    if (names.some((name) => !name)) problems.push("Bütün stratejilerin adı olmalı.");
    if (new Set(names).size !== names.length) problems.push("Strateji adları farklı olmalı.");
  }
  if (problems.length) {
    toast(problems[0], true);
    return false;
  }
  return true;
}

async function buildDecisionCase() {
  state.caseInput.history = parseHistory(state.historyText);
  const button = $("#wizardNextButton");
  button.disabled = true;
  button.textContent = "Karar modeli kuruluyor…";
  try {
    const payload = await api("/api/decision/build", { method: "POST", body: { case: state.caseInput } });
    state.scenario = payload.scenario;
    state.caseInput = clone(payload.scenario.meta.builder_input || state.caseInput);
    state.result = null;
    state.selectedModelId = state.scenario.model_registry?.[0]?.id || null;
    state.jobId = null;
    renderAll();
    showScreen("model");
    const warningCount = (payload.issues || []).filter((item) => item.level === "warning").length;
    toast(warningCount ? `Model kuruldu; ${warningCount} güven uyarısı var.` : "Karar modeli kuruldu.");
  } catch (error) {
    toast(error.message, true);
  } finally {
    button.disabled = false;
    button.textContent = "Karar modelini kur →";
  }
}

function resetExample() {
  if (!state.catalog) return;
  state.caseInput = clone(state.catalog.default_input);
  state.historyText = "";
  state.wizardStep = 0;
  state.scenario = null;
  state.result = null;
  renderAll();
  toast("Çalışan örnek başlangıç değerleri geri yüklendi.");
}

function renderModel() {
  const ready = Boolean(state.scenario?.meta?.engine === "operations_v1");
  $("#modelEmpty").hidden = ready;
  $("#modelWorkspace").hidden = !ready;
  if (!ready) return;
  const registry = state.scenario.parameter_registry || [];
  const counts = statusCounts(registry);
  $("#modelHealthStrip").innerHTML = `
    <div><span>Karar kapsamı</span><b>1 karar · ${state.scenario.strategies.length} seçenek</b></div>
    <div><span>Alt model</span><b>${state.scenario.model_registry.length} bağlı mekanik</b></div>
    <div><span>Kaynak durumu</span><b>${counts.OBSERVED} ölçülen · ${counts.ESTIMATED} tahmin · ${counts.ASSUMPTION} varsayım</b></div>
    <div class="health-warning"><span>İddia seviyesi</span><b>${counts.OBSERVED ? "Kısmi veri" : "Kalibrasyon öncesi"}</b></div>`;
  const models = state.scenario.model_registry || [];
  const byId = Object.fromEntries(models.map((model) => [model.id, model]));
  const ids = {
    demand: "DEMAND-REGIME-AR1-v1",
    reliability: "RELIABILITY-WEIBULL-DES-v1",
    workforce: "WORKFORCE-COHORT-v1",
    supply: "SUPPLY-INVENTORY-v1",
    operations: "OPERATIONS-FLOW-v1",
    finance: "FINANCE-CASHFLOW-v1",
    decision: "DECISION-RDM-v1",
  };
  $("#moduleFlow").innerHTML = `
    <div class="flow-band external"><span>Dış dünya ve bilgi eksikliği</span><button ${modelButton(byId[ids.demand], "Talep", "rejim · fiyat · pazarlama")}</button></div>
    <div class="flow-arrow">↓</div>
    <div class="flow-band resources"><span>Operasyon kaynakları</span><div>
      <button ${modelButton(byId[ids.reliability], "Ekipman", "yaş · arıza · onarım")}</button>
      <button ${modelButton(byId[ids.workforce], "Çalışan", "devamsızlık · beceri · yorgunluk")}</button>
      <button ${modelButton(byId[ids.supply], "Tedarik", "teslimat · stok · gecikme")}</button>
    </div></div>
    <div class="flow-arrow merge">↘ &nbsp; ↓ &nbsp; ↙</div>
    <button ${modelButton(byId[ids.operations], "Operasyon akışı", "talep × kapasite × malzeme", "flow-core")}</button>
    <div class="flow-arrow">↓</div>
    <button ${modelButton(byId[ids.finance], "Nakit ve kârlılık", "gelir · gider · capex · minimum nakit", "flow-core finance")}</button>
    <div class="flow-arrow">↓</div>
    <button ${modelButton(byId[ids.decision], "Karar motoru", "sert sınır · kötü kuyruk · pişmanlık", "flow-core decision")}</button>`;
  renderModelInspector();
  renderAssumptions();
}

function modelButton(model, title, subtitle, extraClass = "") {
  if (!model) return `class="${esc(extraClass || "model-module")}" type="button" disabled><b>${esc(title)}</b><small>Model eksik</small>`;
  const active = state.selectedModelId === model.id ? "active" : "";
  return `class="${esc(extraClass || "model-module")} ${active}" data-model-id="${esc(model.id)}" type="button"><b>${esc(title)}</b><small>${esc(subtitle)}</small>`;
}

function renderModelInspector() {
  const model = (state.scenario.model_registry || []).find((item) => item.id === state.selectedModelId) || state.scenario.model_registry[0];
  if (!model) return;
  state.selectedModelId = model.id;
  const registry = Object.fromEntries((state.scenario.parameter_registry || []).map((item) => [item.id, item]));
  const inputs = (model.inputs || []).map((input) => {
    const match = Object.values(registry).find((item) => item.id.endsWith(`.${input}`));
    return `<li><code>${esc(input)}</code>${match ? `<span class="status-dot ${match.status.toLowerCase()}">${statusLabel(match.status)}</span>` : ""}</li>`;
  }).join("");
  const sources = new Set();
  (model.evidence_ids || []).forEach((id) => sources.add(id));
  (model.inputs || []).forEach((input) => {
    const match = Object.values(registry).find((item) => item.id.endsWith(`.${input}`));
    if (match?.source_id) sources.add(match.source_id);
  });
  $("#modelInspector").innerHTML = `<span class="eyebrow">SEÇİLİ ALT MODEL</span><h2>${esc(model.label)}</h2><p class="model-family">${esc(model.family)}</p><div class="inspector-block"><b>Okuduğu girdiler</b><ul>${inputs || "<li>Üst model çıktıları</li>"}</ul></div><div class="inspector-block"><b>Ürettiği çıktılar</b><div class="output-chips">${(model.outputs || []).map((item) => `<span>${esc(humanize(item))}</span>`).join("")}</div></div><div class="inspector-block"><b>Kanıt / varsayım izi</b><p>${Array.from(sources).map((id) => `<code>${esc(id)}</code>`).join(" · ") || "Yapısal model kaydı"}</p></div><p class="inspector-caveat">Bu kutu nedenselliği kendi kendine keşfetmez; yazılan ve doğrulanması gereken mekanizmayı çalıştırır.</p>`;
}

function renderAssumptions() {
  if (!state.scenario) return;
  $$("#assumptionFilters button").forEach((button) => button.classList.toggle("active", button.dataset.filter === state.assumptionFilter));
  const evidence = Object.fromEntries((state.scenario.evidence || []).map((item) => [item.id, item]));
  const rows = (state.scenario.parameter_registry || []).filter((item) => state.assumptionFilter === "ALL" || item.status === state.assumptionFilter);
  $("#assumptionList").innerHTML = rows.map((item) => {
    const source = evidence[item.source_id] || {};
    const width = numeric(item.high, 0) - numeric(item.low, 0);
    return `<button class="assumption-row" type="button" data-assumption-id="${esc(item.id)}"><span class="status-dot ${String(item.status).toLowerCase()}">${statusLabel(item.status)}</span><div><b>${esc(humanize(item.id.split(".").pop()))}</b><small>${esc(item.id)} · ${esc(source.note || "Kaynak notu yok")}</small></div><strong>${num(item.value)}</strong><span class="range">${num(item.low)} — ${num(item.high)}<small>aralık ${num(width)}</small></span></button>`;
  }).join("") || `<div class="empty-inline">Bu filtrede parametre yok.</div>`;
}

function renderLab() {
  const ready = Boolean(state.scenario?.meta?.engine === "operations_v1");
  $("#labEmpty").hidden = ready;
  $("#labWorkspace").hidden = !ready;
  if (!ready) return;
  $("#strategyRace").innerHTML = state.scenario.strategies.map((strategy, index) => {
    const p = strategy.parameters || strategy;
    return `<article><span>${index + 1}</span><h3>${esc(strategy.label)}</h3><p>${esc(strategy.description || "")}</p><div><small>Başlangıç</small><b>${num(p.start_month)}. ay</b></div><div><small>Yatırım</small><b>${money(p.upfront_investment)}</b></div><div><small>Makine / çalışan</small><b>+${num(p.added_machines)} / +${num(p.added_workers)}</b></div><div><small>Bakım / stok</small><b>${num(p.maintenance_interval_days)} gün / ${num(p.safety_stock_days)} gün</b></div></article>`;
  }).join("");
  $$("#worldOptions button").forEach((button) => button.classList.toggle("active", Number(button.dataset.worlds) === state.worlds));
  const operations = state.worlds * state.scenario.strategies.length * state.scenario.horizon;
  $("#runOperationCount").textContent = num(operations);
  $("#runButtonDetail").textContent = `${num(state.worlds)} dünya`;
  $("#counterfactualLab").hidden = !state.result;
  if (state.result) renderCounterfactualControls();
}

function selectWorlds(worlds) {
  if (state.worlds !== worlds) {
    state.result = null;
    state.jobId = null;
    state.selectedFutureId = null;
    state.selectedDrilldown = null;
  }
  state.worlds = worlds;
  renderLab();
}

async function runSimulation() {
  if (!state.scenario) return toast("Önce karar modelini kur.", true);
  const button = $("#runButton");
  state.result = null;
  state.selectedFutureId = null;
  state.selectedDrilldown = null;
  $("#counterfactualLab").hidden = true;
  button.disabled = true;
  $("#runReady").hidden = true;
  $("#runProgress").hidden = false;
  updateProgress({ progress: 0, completed: 0, total: state.worlds * state.scenario.strategies.length, message: "Model doğrulanıyor" });
  try {
    const seed = Math.trunc(numeric($("#runSeed").value, 20260817));
    const job = await api("/api/run", { method: "POST", body: { scenario: state.scenario, worlds: state.worlds, seed } });
    state.jobId = job.job_id;
    pollJob();
  } catch (error) {
    finishRunUi();
    toast(error.message, true);
  }
}

async function pollJob() {
  try {
    const job = await api(`/api/jobs/${encodeURIComponent(state.jobId)}`);
    updateProgress(job);
    if (job.status === "completed") {
      state.result = job.result;
      state.selectedFutureId = null;
      state.selectedDrilldown = defaultDrilldownKey();
      state.selectedContribution = 0;
      finishRunUi();
      renderAll();
      showScreen("future");
      toast("Karar deneyi tamamlandı.");
      return;
    }
    if (job.status === "failed") throw new Error(job.error || "Simülasyon başarısız");
    setTimeout(pollJob, 700);
  } catch (error) {
    finishRunUi();
    toast(error.message, true);
  }
}

function updateProgress(job) {
  const progress = clamp(numeric(job.progress, 0), 0, 1);
  $("#progressBar").style.width = `${progress * 100}%`;
  $("#progressPercent").textContent = `${Math.round(progress * 100)}%`;
  $("#progressMessage").textContent = progress < 0.78 ? "Aynı dünyalarda stratejiler yürütülüyor" : progress < 1 ? "Gelecek ağacı ve karar sınırları çıkarılıyor" : "Tamamlandı";
  $("#progressDetail").textContent = job.message || `${num(job.completed)} / ${num(job.total)}`;
}

function finishRunUi() {
  $("#runButton").disabled = false;
  $("#runReady").hidden = false;
  $("#runProgress").hidden = true;
}

function renderCounterfactualControls() {
  const strategySelect = $("#cfStrategy");
  const fieldSelect = $("#cfField");
  const previousStrategy = strategySelect.value;
  const previousField = fieldSelect.value;
  strategySelect.innerHTML = state.scenario.strategies.map((item) => `<option value="${esc(item.id)}">${esc(item.label)}</option>`).join("");
  fieldSelect.innerHTML = Object.entries(CF_FIELDS).map(([key, item]) => `<option value="${key}">${esc(item[0])}</option>`).join("");
  if (previousStrategy && state.scenario.strategies.some((item) => item.id === previousStrategy)) strategySelect.value = previousStrategy;
  if (previousField && CF_FIELDS[previousField]) fieldSelect.value = previousField;
  syncCounterfactualValue();
}

function syncCounterfactualValue() {
  if (!state.scenario) return;
  const strategy = state.scenario.strategies.find((item) => item.id === $("#cfStrategy").value) || state.scenario.strategies[0];
  const field = $("#cfField").value || Object.keys(CF_FIELDS)[0];
  $("#cfValue").value = numeric(strategy.parameters?.[field] ?? strategy[field], 0);
  $("#cfUnit").textContent = CF_FIELDS[field]?.[1] || "";
}

async function runCounterfactual() {
  const button = $("#cfRunButton");
  button.disabled = true;
  button.textContent = "Aynı dünyalar yeniden çalışıyor…";
  $("#counterfactualResult").innerHTML = `<div class="inline-loading"><i></i><span>Yalnız müdahale değiştiriliyor.</span></div>`;
  try {
    const strategyId = $("#cfStrategy").value;
    const field = $("#cfField").value;
    const value = numeric($("#cfValue").value, 0);
    const result = await api("/api/decision/intervene", { method: "POST", body: { scenario: state.scenario, strategy_id: strategyId, changes: { [field]: value }, worlds: 300, seed: Math.trunc(numeric($("#runSeed").value, 20260817)) } });
    const pair = result.paired;
    const modifiedWin = 1 - numeric(pair.p_left_better, 0) - numeric(pair.p_tie, 0);
    $("#counterfactualResult").innerHTML = `<span class="eyebrow">EŞLENMİŞ ETKİ</span><h3>${esc(result.interpretation)}</h3><div class="cf-stats"><div><span>Müdahalenin üstün geldiği dünya</span><b>${pct(modifiedWin)}</b></div><div><span>Fayda farkı (müdahale − mevcut)</span><b>${signed(-numeric(pair.mean_utility_delta, 0))}</b></div><div><span>Fark aralığı P5–P95</span><b>${signed(-numeric(pair.p95_delta, 0))} — ${signed(-numeric(pair.p05_delta, 0))}</b></div></div><p>Değişen tek kontrol: <code>${esc(field)}</code> → <b>${num(value)}</b>. Model ve dış dünya tohumu aynı kaldı.</p>`;
  } catch (error) {
    $("#counterfactualResult").innerHTML = `<p class="error-text">${esc(error.message)}</p>`;
  } finally {
    button.disabled = false;
    button.textContent = "Aynı 300 dünyada dene";
  }
}

function renderFuture() {
  const ready = Boolean(state.result?.summary?.ranking?.length);
  $("#futureEmpty").hidden = ready;
  $("#futureWorkspace").hidden = !ready;
  if (!ready) return;
  const status = state.result.decision_status || {};
  const labels = strategyLabels();
  const leading = labels[status.leading_strategy_id] || humanize(status.leading_strategy_id);
  const recommendation = status.code === "no_eligible_option"
    ? "Hiçbir seçenek tanımlanan sert sınırların tamamını kabul edilebilir sıklıkta geçemedi."
    : status.code === "single_eligible"
      ? `Yalnız ${leading} tanımlı risk bütçesini geçti; bu nedenle sonuç üstünlük değil, eleme olarak okunmalı.`
    : status.recommended_strategy_id
      ? `Model, bu koşullarda ${leading} seçeneğini öneri eşiğinin üstünde görüyor.`
      : `Şu an ${leading} önde; fakat sistem otomatik öneri vermiyor.`;
  const statusClass = { no_eligible_option: "no-eligible", single_eligible: "conditional", conditional: "conditional", clear: "clear", close: "close", single: "clear" }[status.code] || "close";
  $("#decisionStatus").className = `decision-status status-${statusClass}`;
  $("#decisionStatus").innerHTML = `<div><span class="eyebrow">KARAR DURUMU</span><h1>${esc(status.label || "Sonuç")}</h1><p>${esc(status.explanation || "")}</p></div><aside><b>${esc(recommendation)}</b><div><span>Öndeki seçeneğin daha iyi olduğu dünya</span><strong>${pct(status.p_leading_better ?? status.leading_world_share)}</strong></div><div><span>Seçimi kazandığı dünya payı</span><strong>${pct(status.leading_world_share)}</strong></div><button class="btn ghost" data-drill-key="success:${esc(status.leading_strategy_id)}" type="button">Başarı yüzdesini aç</button></aside>`;
  $("#distributionStrip").innerHTML = state.result.summary.ranking.map((row) => `<article class="${row.strategy_id === status.leading_strategy_id ? "leading" : ""}"><span>#${row.rank} · ${row.eligible ? "risk bütçesini geçti" : `sınır aşıyor: ${(row.hard_constraint_breaches || []).join(", ")}`}</span><h3>${esc(row.label)}</h3><div class="interval"><i style="left:${clamp(row.utility_p05,0,1)*100}%;width:${Math.max(1,(row.utility_p95-row.utility_p05)*100)}%"></i><b style="left:${clamp(row.utility_p50,0,1)*100}%"></b></div><p><span>Kötü kuyruk ${pct(row.utility_cvar)}</span><span>Başarı <button data-drill-key="success:${esc(row.strategy_id)}" type="button">${pct(row.success_probability)}</button></span><span>Ruin <button data-drill-key="ruin:${esc(row.strategy_id)}" type="button">${pct(row.ruin_probability)}</button></span></p></article>`).join("");
  $$("#futureMode button").forEach((button) => button.classList.toggle("active", button.dataset.mode === state.futureMode));
  const tree = state.result.future_maps?.[state.futureMode]?.root;
  if (!tree) {
    $("#futureTree").innerHTML = `<div class="empty-inline">Bu koşuda açıklanabilir dal oluşmadı.</div>`;
    $("#futureInspector").innerHTML = "";
    return;
  }
  if (!state.selectedFutureId) state.selectedFutureId = tree.id;
  $("#futureTree").innerHTML = futureNodeMarkup(tree, true);
  renderFutureInspector(tree);
}

function futureNodeMarkup(node, root = false) {
  const labels = strategyLabels();
  const condition = node.conditions?.length ? conditionText(node.conditions[node.conditions.length - 1]) : "Bütün olası dünyalar";
  const winner = labels[node.best_strategy_id] || humanize(node.best_strategy_id);
  const selectedClass = node.id === state.selectedFutureId ? "selected" : "";
  const children = (node.children || []).map((child) => futureNodeMarkup(child)).join("");
  return `<div class="future-node-wrap ${root ? "root" : ""}"><button class="future-node ${selectedClass}" data-future-id="${esc(node.id)}" type="button"><span class="node-probability">${pct(node.probability)}</span><div><b>${esc(condition)}</b><small>${num(node.worlds)} dünya · öne çıkan ${esc(winner)}</small></div><i>${node.leaf ? "son dal" : "ikiye ayrılıyor"}</i></button>${children ? `<div class="future-children">${children}</div>` : ""}</div>`;
}

function renderFutureInspector(root) {
  const node = findFutureNode(root, state.selectedFutureId) || root;
  const labels = strategyLabels();
  const conditions = node.conditions?.length ? node.conditions.map((item) => `<li>${esc(conditionText(item))}</li>`).join("") : "<li>Henüz koşul uygulanmadı; bütün dünyalar.</li>";
  const rows = (node.strategies || []).slice().sort((a, b) => b.mean_utility - a.mean_utility).map((row) => `<div class="node-strategy"><b>${esc(labels[row.strategy_id] || humanize(row.strategy_id))}</b><span>Fayda ${pct(row.mean_utility)}</span><span>Başarı ${pct(row.success_probability)}</span><span>Ruin ${pct(row.ruin_probability)}</span><span>Medyan minimum nakit ${money(row.minimum_cash_p50)}</span></div>`).join("");
  const split = node.split ? `<div class="next-split"><span>Bir sonraki ayrım</span><b>${esc(node.split.label)} = ${num(node.split.threshold)}</b><small>Bu eşik, bu düğümde hedef sınıfları en iyi ayıran açıklama kuralıdır; nedensellik kanıtı değildir.</small></div>` : `<div class="next-split"><span>Son dal</span><b>Ek bir kararlı ayrım bulunmadı</b></div>`;
  $("#futureInspector").innerHTML = `<span class="eyebrow">SEÇİLİ GELECEK DALI</span><h2>${pct(node.probability)} dünya payı</h2><ul class="condition-list">${conditions}</ul><div class="node-strategies">${rows}</div>${split}<button class="btn ghost block" data-drill-key="success:${esc(state.result.decision_status.leading_strategy_id)}" type="button">Bu daldan sonuç yüzdesine git →</button>`;
}

function renderEvidence() {
  const ready = Boolean(state.result?.probability_drilldowns);
  $("#evidenceEmpty").hidden = ready;
  $("#evidenceWorkspace").hidden = !ready;
  if (!ready) return;
  const drilldowns = state.result.probability_drilldowns;
  if (!state.selectedDrilldown || !drilldowns[state.selectedDrilldown]) state.selectedDrilldown = defaultDrilldownKey();
  const select = $("#drilldownSelect");
  select.innerHTML = Object.entries(drilldowns).map(([key, item]) => `<option value="${esc(key)}" ${selected(state.selectedDrilldown, key)}>${esc(drilldownLabel(item))}</option>`).join("");
  const item = drilldowns[state.selectedDrilldown];
  const width = item.interval95[1] - item.interval95[0];
  $("#probabilityAnatomy").innerHTML = `<article><span>SONUÇ</span><b>${pct(item.value)}</b><small>${esc(drilldownLabel(item))}</small></article><i>→</i><article><span>PAY / PAYDA</span><b>${num(item.numerator)} / ${num(item.denominator)}</b><small>${esc(item.definition)}</small></article><i>→</i><article><span>YAKLAŞIK %95 ARALIK</span><b>${pct(item.interval95[0])} — ${pct(item.interval95[1])}</b><small>Genişlik ${pct(width)} · yalnız örnekleme hatası</small></article>`;
  const contributions = item.future_contributions || [];
  state.selectedContribution = clamp(state.selectedContribution, 0, Math.max(0, contributions.length - 1));
  $("#futureContributions").innerHTML = contributions.map((row, index) => `<button class="contribution-row ${index === state.selectedContribution ? "active" : ""}" data-contribution-index="${index}" type="button"><span>${index + 1}</span><div><b>${row.conditions?.length ? row.conditions.map(conditionText).join(" · ") : "Bütün dünyalar"}</b><small>Dal payı ${pct(row.probability)} · bu dalda olay ${pct(row.conditional_rate)}</small></div><strong>${pct(row.contribution)}<small>toplama katkı</small></strong></button>`).join("") || `<div class="empty-inline">Katkı dalı yok.</div>`;
  renderLineage(contributions[state.selectedContribution]);
  renderCredibility();
  renderInformationValue();
}

function renderLineage(contribution) {
  if (!contribution) {
    $("#lineagePanel").innerHTML = `<span class="eyebrow">MODEL İZİ</span><h2>Bir gelecek dalı seç</h2>`;
    return;
  }
  const audit = state.result.audit || {};
  const models = Object.fromEntries((audit.model_registry || []).map((item) => [item.id, item]));
  const evidence = Object.fromEntries((audit.evidence_registry || []).map((item) => [item.id, item]));
  const params = Object.fromEntries((audit.parameter_registry || []).map((item) => [item.id, item]));
  const chains = (contribution.lineage || []).map((line) => {
    const modelHtml = (line.model_ids || []).map((id) => `<li><b>${esc(models[id]?.label || id)}</b><small>${esc(models[id]?.family || "model")}</small></li>`).join("");
    const paramHtml = (line.parameter_ids || []).map((id) => `<li><b>${esc(humanize(id.split(".").pop()))}</b><small>${statusLabel(params[id]?.status)} · ${num(params[id]?.low)} — ${num(params[id]?.high)}</small></li>`).join("");
    const evidenceHtml = (line.source_ids || []).map((id) => `<li><b>${esc(id)}</b><small>${esc(evidence[id]?.note || "Kaynak notu yok")}</small></li>`).join("");
    return `<article class="lineage-chain"><h3>${esc(featureLabel(line.feature))}</h3><div><span>SÜRÜCÜ</span><b>${esc(line.feature)}</b></div><i>↓</i><div><span>ALT MODEL</span><ul>${modelHtml || "<li>Yapısal model</li>"}</ul></div><i>↓</i><div><span>PARAMETRE</span><ul>${paramHtml || "<li>Sabit model yapısı</li>"}</ul></div><i>↓</i><div><span>KAYNAK</span><ul>${evidenceHtml || "<li>E-MODEL-STRUCTURE</li>"}</ul></div></article>`;
  }).join("");
  $("#lineagePanel").innerHTML = `<span class="eyebrow">DALDAN KAYNAĞA</span><h2>Bu dalı ayıran iz</h2>${chains || `<p>Bu katkı kök düğümden geliyor; özel bir ayırıcı koşul taşımıyor.</p>`}`;
}

function renderCredibility() {
  const health = state.result.model_health || {};
  const counts = health.parameter_status || {};
  const convergence = state.result.convergence || {};
  $("#modelCredibility").innerHTML = `<span class="eyebrow">MODEL GÜVEN KARTI</span><div class="credibility-head"><b>${esc(health.credibility_tier || "C0")}</b><div><h2>${esc(health.label || "Kalibrasyon öncesi")}</h2><p>${esc(health.claim || "")}</p></div></div><div class="credibility-bars"><div><span>Ölçülen parametre</span><b>${num(counts.OBSERVED || 0)}</b></div><div><span>Tahmin</span><b>${num(counts.ESTIMATED || 0)}</b></div><div><span>Varsayım</span><b>${num(counts.ASSUMPTION || 0)}</b></div></div><div class="convergence ${convergence.stable ? "good" : "warning"}"><b>${convergence.stable ? "Örnekleme kararlı" : "Örnekleme / seçim henüz kararlı değil"}</b><span>${esc(convergence.message || "")}</span></div><p class="model-limit"><b>Historical replay:</b> ${health.historical_replay === "not_run" ? "çalıştırılmadı" : esc(health.historical_replay)} · <b>Kalibrasyon:</b> ${health.calibration === "not_established" ? "kurulmadı" : "kısmi"}</p>`;
}

function renderInformationValue() {
  const rows = state.result.value_of_information || [];
  const max = Math.max(...rows.map((row) => numeric(row.priority_score ?? row.decision_information, 0)), 0.0001);
  $("#informationValue").innerHTML = rows.map((row, index) => {
    const priority = numeric(row.priority_score ?? row.decision_information, 0);
    const action = row.action_kind === "monitor" ? "İzlenecek dış koşul" : "Daraltılacak parametre";
    return `<article><span>${index + 1}</span><div><b>${esc(row.label)}</b><small>${esc(action)} · ${statusLabel(row.status)} · ${esc(row.interpretation)}</small><i><em style="width:${priority / max * 100}%"></em></i></div><strong>${priority.toFixed(3)}</strong></article>`;
  }).join("") || `<p>Kararı ayıran ek veri hedefi bulunamadı.</p>`;
}

function showScreen(name) {
  state.screen = name;
  $$(".screen").forEach((screen) => {
    const active = screen.dataset.screen === name;
    screen.hidden = !active;
    screen.classList.toggle("active", active);
  });
  $$(".nav-item").forEach((button) => button.classList.toggle("active", button.dataset.go === name));
  if (name === "model") renderModel();
  if (name === "lab") renderLab();
  if (name === "future") renderFuture();
  if (name === "evidence") renderEvidence();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function renderGuide() {
  $$(".guide-tabs button").forEach((button) => button.classList.toggle("active", button.dataset.guideTab === state.guideTab));
  $("#guideContent").innerHTML = GUIDE[state.guideTab] || GUIDE.quick;
}

function startTour() {
  closeDialog("guideDialog");
  state.tourIndex = 0;
  renderTour();
  openDialog("tourDialog");
}

function renderTour() {
  const [screen, title, body] = TOUR_STEPS[state.tourIndex];
  showScreen(screen);
  $("#tourStep").textContent = `ADIM ${state.tourIndex + 1} / ${TOUR_STEPS.length}`;
  $("#tourTitle").textContent = title;
  $("#tourBody").textContent = body;
  $("#tourMeter").style.width = `${(state.tourIndex + 1) / TOUR_STEPS.length * 100}%`;
  $("#tourNextButton").textContent = state.tourIndex === TOUR_STEPS.length - 1 ? "Turu tamamla" : "İleri →";
}

function nextTour() {
  if (state.tourIndex >= TOUR_STEPS.length - 1) return endTour();
  state.tourIndex += 1;
  renderTour();
}

function endTour() {
  closeDialog("tourDialog");
  toast("Tur tamamlandı; dilediğin ekrandan devam et.");
}

function openProjects() {
  renderProjects();
  openDialog("projectsDialog");
}

function renderProjects() {
  $("#projectList").innerHTML = state.projects.length ? state.projects.map((project) => `<button data-project-id="${esc(project.id)}" type="button"><div><b>${esc(project.name)}</b><small>${esc(project.scenario_id)} · ${formatDate(project.modified_at)}</small></div><span>Aç →</span></button>`).join("") : `<div class="empty-inline">Henüz kayıtlı karar yok.</div>`;
}

async function loadProjectById(id) {
  try {
    const scenario = await api(`/api/projects/${encodeURIComponent(id)}`);
    state.scenario = scenario;
    state.caseInput = clone(scenario.meta?.builder_input || state.caseInput);
    state.result = null;
    state.jobId = null;
    state.selectedModelId = scenario.model_registry?.[0]?.id || null;
    closeDialog("projectsDialog");
    renderAll();
    showScreen("model");
    toast("Karar modeli açıldı.");
  } catch (error) {
    toast(error.message, true);
  }
}

function openSave() {
  if (!state.scenario) return;
  $("#saveProjectName").value = state.scenario.meta?.name || "Karar modeli";
  openDialog("saveDialog");
}

async function saveProject() {
  const name = $("#saveProjectName").value.trim();
  if (!name) return toast("Proje adı boş olamaz.", true);
  try {
    await api("/api/projects", { method: "POST", body: { name, scenario: state.scenario } });
    const list = await api("/api/projects");
    state.projects = list.projects || [];
    closeDialog("saveDialog");
    toast("Karar modeli kaydedildi.");
  } catch (error) {
    toast(error.message, true);
  }
}

function parseHistory(text) {
  if (!String(text || "").trim()) return [];
  const rows = String(text).trim().split(/\r?\n/).map((line) => line.split(/[;,\t]/).map((cell) => cell.trim()));
  const first = rows[0].map((cell) => cell.toLowerCase());
  const hasHeader = first.some((cell) => /sip|demand|ciro|revenue|gider|cost/.test(cell));
  const data = hasHeader ? rows.slice(1) : rows;
  const header = hasHeader ? first : ["ay", "siparis", "ciro", "degisken_gider", "sabit_gider", "devamsizlik", "ariza", "hizmet"];
  const index = (patterns, fallback) => {
    const found = header.findIndex((cell) => patterns.some((pattern) => cell.includes(pattern)));
    return found >= 0 ? found : fallback;
  };
  const idx = {
    demand: index(["sip", "demand", "talep"], 1),
    revenue: index(["ciro", "revenue"], 2),
    variable_cost: index(["degisken", "variable"], 3),
    fixed_cost: index(["sabit", "fixed"], 4),
    absence_rate: index(["devams", "absence"], 5),
    failures: index(["ariza", "failure"], 6),
    service_level: index(["hizmet", "service"], 7),
  };
  return data.map((row) => Object.fromEntries(Object.entries(idx).map(([key, position]) => [key, parseLocaleNumber(row[position])]))).filter((row) => row.demand > 0);
}

function defaultDrilldownKey() {
  const leading = state.result?.decision_status?.leading_strategy_id || state.result?.summary?.ranking?.[0]?.strategy_id;
  const candidate = `success:${leading}`;
  if (state.result?.probability_drilldowns?.[candidate]) return candidate;
  return Object.keys(state.result?.probability_drilldowns || {})[0] || null;
}

function drilldownLabel(item) {
  const labels = strategyLabels();
  const event = { success: "başarı", ruin: "ruin / hayatta kalma ihlali", robust: "sağlam sonuç" }[item.event] || item.event;
  return `${labels[item.strategy_id] || humanize(item.strategy_id)} · ${event}`;
}

function findFutureNode(node, id) {
  if (!node) return null;
  if (node.id === id) return node;
  for (const child of node.children || []) {
    const found = findFutureNode(child, id);
    if (found) return found;
  }
  return null;
}

function conditionText(item) {
  const op = item.op === "<=" ? "≤" : item.op === ">" ? ">" : item.op;
  return `${item.label || featureLabel(item.feature)} ${op} ${num(item.threshold)}`;
}

function featureLabel(value) {
  const labels = {
    driver_demand_mean: "ortalama talep",
    driver_demand_min: "en düşük talep",
    driver_demand_max: "en yüksek talep",
    driver_cost_mean: "ortalama maliyet",
    driver_cost_max: "en yüksek maliyet",
    driver_absence_mean: "ortalama devamsızlık",
    driver_supplier_fill_mean: "tedarik karşılama",
    driver_supplier_fill_min: "en düşük tedarik",
    driver_macro_mean: "ekonomik rejim",
    epistemic_price_elasticity: "fiyat hassasiyeti varsayımı",
    epistemic_marketing_elasticity: "pazarlama etkisi varsayımı",
    epistemic_failure_scale_days: "makine ömür varsayımı",
    epistemic_failure_shape: "arıza yaşlanma varsayımı",
    epistemic_repair_days: "onarım süresi varsayımı",
    epistemic_baseline_demand: "başlangıç talep tahmini",
    epistemic_unit_margin: "birim katkı marjı tahmini",
    epistemic_fixed_cost: "sabit gider tahmini",
    epistemic_machine_capacity: "makine kapasitesi tahmini",
    epistemic_worker_capacity: "çalışan kapasitesi tahmini",
    epistemic_annual_demand_trend: "yıllık talep eğilimi tahmini",
    epistemic_annual_cost_inflation: "yıllık maliyet artışı tahmini",
    epistemic_supplier_disruption: "tedarik bozulması tahmini",
  };
  return labels[value] || humanize(value);
}

function strategyLabels() {
  return Object.fromEntries((state.scenario?.strategies || []).map((item) => [item.id, item.label]));
}

function statusCounts(registry) {
  return ["OBSERVED", "ESTIMATED", "ASSUMPTION"].reduce((acc, status) => {
    acc[status] = registry.filter((item) => item.status === status).length;
    return acc;
  }, {});
}

function statusLabel(status) {
  return { OBSERVED: "Ölçülen", ESTIMATED: "Tahmin", ASSUMPTION: "Varsayım" }[status] || status || "Belirsiz";
}

function textField(path, label, value, placeholder = "") {
  return `<label class="field"><span>${esc(label)}</span><input data-path="${path}" type="text" value="${esc(value)}" placeholder="${esc(placeholder)}"></label>`;
}

function numberField(path, label, value, unit, min, max, step, scale = 1) {
  return `<label class="field"><span>${esc(label)}</span><div class="field-unit"><input data-path="${path}" data-kind="number" data-scale="${scale}" type="number" value="${round(numeric(value,0),4)}" min="${min}" max="${max}" step="${step}"><b>${esc(unit)}</b></div></label>`;
}

function setPath(object, path, value) {
  const parts = path.split(".");
  let cursor = object;
  for (let index = 0; index < parts.length - 1; index += 1) {
    const key = /^\d+$/.test(parts[index]) ? Number(parts[index]) : parts[index];
    cursor = cursor[key];
  }
  const last = /^\d+$/.test(parts.at(-1)) ? Number(parts.at(-1)) : parts.at(-1);
  cursor[last] = value;
}

async function api(path, options = {}) {
  const config = { ...options, headers: { ...(options.headers || {}) } };
  if (options.body !== undefined) {
    config.headers["Content-Type"] = "application/json";
    config.body = JSON.stringify(options.body);
  }
  const response = await fetch(path, config);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || `Sunucu hatası (${response.status})`);
  return payload;
}

function openDialog(id) {
  const dialog = $(`#${id}`);
  if (dialog && !dialog.open) dialog.showModal();
}

function closeDialog(id) {
  const dialog = $(`#${id}`);
  if (dialog?.open) dialog.close();
}

function toast(message, error = false) {
  const node = document.createElement("div");
  node.className = `toast ${error ? "error" : ""}`;
  node.textContent = message;
  $("#toastRegion").appendChild(node);
  setTimeout(() => node.remove(), 4200);
}

function setServer(kind, label) {
  const node = $("#serverState");
  node.className = `server-state ${kind}`;
  $("span", node).textContent = label;
}

function selected(value, candidate) { return String(value) === String(candidate) ? "selected" : ""; }
function clone(value) { return JSON.parse(JSON.stringify(value)); }
function numeric(value, fallback = 0) { const number = Number(value); return Number.isFinite(number) ? number : fallback; }
function clamp(value, low, high) { return Math.max(low, Math.min(high, numeric(value, low))); }
function round(value, digits = 2) { const factor = 10 ** digits; return Math.round(numeric(value, 0) * factor) / factor; }
function truncate(value, length) { const text = String(value || ""); return text.length > length ? `${text.slice(0, length - 1)}…` : text; }
function esc(value) { return String(value ?? "").replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char])); }
function humanize(value) { return String(value ?? "").replace(/^driver_|^epistemic_/, "").replaceAll("_", " ").replace(/\b\w/g, (char) => char.toUpperCase()); }
function pct(value, digits = 1) { const number = Number(value); return Number.isFinite(number) ? `%${(number * 100).toLocaleString("tr-TR", { maximumFractionDigits: digits, minimumFractionDigits: digits })}` : "—"; }
function signed(value) { const number = numeric(value, 0); return `${number >= 0 ? "+" : ""}${number.toFixed(3)}`; }
function num(value) { const number = Number(value); if (!Number.isFinite(number)) return "—"; const abs = Math.abs(number); if (abs >= 1e9) return `${(number / 1e9).toFixed(2)} Mr`; if (abs >= 1e6) return `${(number / 1e6).toFixed(2)} Mn`; if (abs >= 1e3) return `${(number / 1e3).toFixed(1)} B`; if (abs >= 100) return number.toFixed(0); if (abs >= 10) return number.toFixed(1); return number.toFixed(2); }
function money(value) { const number = Number(value); return Number.isFinite(number) ? `${num(number)} ₺` : "—"; }
function formatInputValue(value, unit, scale) { return `${num(numeric(value,0) * numeric(scale,1))} ${unit || ""}`; }
function parseLocaleNumber(value) { if (value === undefined || value === null || value === "") return 0; const text = String(value).trim().replace(/\s/g, ""); const normalized = text.includes(",") && !text.includes(".") ? text.replace(",", ".") : text.replace(/,/g, ""); return numeric(normalized, 0); }
function formatDate(value) { const date = new Date(value); return Number.isNaN(date.getTime()) ? "" : date.toLocaleString("tr-TR", { dateStyle: "short", timeStyle: "short" }); }
