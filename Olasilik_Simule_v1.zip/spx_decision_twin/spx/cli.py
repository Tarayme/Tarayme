from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .artifacts import write_run
from .decision import build_operations_case, case_overview
from .engine import run_scenario
from .registry import calibration_report, import_forecasts, list_runs
from .schema import ScenarioError, load_scenario
from .studio import serve_studio
from .util import write_json
from .validation import ScenarioValidationError, raise_for_errors, validate_scenario


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="spx",
        description="SPX — dağılım-öncelikli stratejik projeksiyon ve karar ikizi motoru",
    )
    parser.add_argument("--version", action="version", version="Olasılık Simüle 1.0.0")
    subparsers = parser.add_subparsers(dest="command", required=True)

    new = subparsers.add_parser("new", help="Yeni operasyon kararı sözleşmesi oluştur")
    new.add_argument("output", type=Path, help="Oluşturulacak JSON dosyası")
    new.add_argument("--company", default="Şirketim", help="Şirket veya proje adı")
    new.add_argument("--horizon", type=int, default=18, help="Karar ufku (ay)")

    validate = subparsers.add_parser("validate", help="Senaryo sözleşmesini ve nedensel grafiği doğrula")
    validate.add_argument("scenario", type=Path)
    validate.add_argument("--strict", action="store_true", help="Uyarıları da hata say")

    inspect = subparsers.add_parser("inspect", help="Senaryonun mimari özetini göster")
    inspect.add_argument("scenario", type=Path)

    run = subparsers.add_parser("run", help="Eşlenmiş dünyalarda stratejileri çalıştır ve raporla")
    run.add_argument("scenario", type=Path)
    run.add_argument("--worlds", type=int, help="Dünya sayısını senaryo ayarının üzerine yaz")
    run.add_argument("--seed", type=int, help="Rastgelelik tohumunu senaryo ayarının üzerine yaz")
    run.add_argument("--output", type=Path, default=Path("runs/latest"), help="Çıktı klasörü")
    run.add_argument("--no-progress", action="store_true")

    calibrate = subparsers.add_parser("calibrate", help="Gerçekleşen sonuçlarla Brier/log-loss/kalibrasyon ölç")
    calibrate.add_argument("--db", type=Path, required=True, help="SPX ledger SQLite dosyası")
    calibrate.add_argument("--import-csv", type=Path, help="Tahmin-gerçekleşme CSV'sini içe aktar")
    calibrate.add_argument("--output", type=Path, help="Kalibrasyon raporu JSON yolu")

    ledger = subparsers.add_parser("ledger", help="Kayıtlı simülasyon koşularını listele")
    ledger.add_argument("--db", type=Path, required=True)
    ledger.add_argument("--limit", type=int, default=20)

    studio = subparsers.add_parser("studio", help="Karar-odaklı etkileşimli Olasılık Simüle Studio'yu aç")
    studio.add_argument("scenario", nargs="?", type=Path, help="Başlangıçta yüklenecek senaryo")
    studio.add_argument("--host", default="127.0.0.1")
    studio.add_argument("--port", type=int, default=8765)
    studio.add_argument("--workspace", type=Path, default=Path.home() / "spx-studio-data")
    studio.add_argument("--no-open", action="store_true", help="Tarayıcıyı otomatik açma")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "new":
            return _new(args)
        if args.command == "validate":
            return _validate(args)
        if args.command == "inspect":
            return _inspect(args)
        if args.command == "run":
            return _run(args)
        if args.command == "calibrate":
            return _calibrate(args)
        if args.command == "ledger":
            return _ledger(args)
        if args.command == "studio":
            return _studio(args)
    except (ScenarioError, ScenarioValidationError, ValueError, KeyError) as exc:
        print(f"HATA: {exc}", file=sys.stderr)
        return 2
    return 0


def _validate(args: argparse.Namespace) -> int:
    scenario = load_scenario(args.scenario)
    issues = validate_scenario(scenario)
    for issue in issues:
        icon = "✗" if issue.level == "error" else "!"
        print(f"{icon} {issue.level.upper():7} {issue.code:28} {issue.path}: {issue.message}")
    errors = [issue for issue in issues if issue.level == "error"]
    warnings = [issue for issue in issues if issue.level == "warning"]
    if not issues:
        print("✓ Senaryo sözleşmesi, ifadeler ve grafik geçerli.")
    else:
        print(f"\nSonuç: {len(errors)} hata, {len(warnings)} uyarı")
    return 2 if errors or (args.strict and warnings) else 0


def _inspect(args: argparse.Namespace) -> int:
    scenario = load_scenario(args.scenario)
    issues = validate_scenario(scenario)
    raise_for_errors(issues)
    print(f"{scenario.name}  [{scenario.scenario_id}] v{scenario.meta.get('version', '0')}")
    print(f"Ufuk: {scenario.horizon} {scenario.step}")
    print(f"Stratejiler: {', '.join(str(item['id']) for item in scenario.strategies)}")
    if scenario.meta.get("engine") == "operations_v1":
        overview = case_overview(scenario.raw)
        counts = overview["status_counts"]
        print(f"Karar: {overview['decision_question']}")
        print(f"Alt model / parametre / kanıt: {overview['models']} / {overview['parameters']} / {overview['evidence']}")
        print(f"Kaynak durumu: {counts['OBSERVED']} ölçülen / {counts['ESTIMATED']} tahmin / {counts['ASSUMPTION']} varsayım")
        print(f"Dünya: {int(scenario.simulation.get('worlds', 0)):,}; tohum: {scenario.simulation.get('seed')}")
        print(f"Scenario hash: {scenario.hash}")
        print(f"Doğrulama: 0 hata, {len([i for i in issues if i.level == 'warning'])} uyarı")
        return 0
    print(f"Driver / state / equation: {len(scenario.drivers)} / {len(scenario.states)} / {len(scenario.equations)}")
    print(f"Aktör / şok / metrik: {len(scenario.actors)} / {len(scenario.shocks)} / {len(scenario.metrics)}")
    print(f"Evidence / objective / constraint: {len(scenario.evidence)} / {len(scenario.objectives)} / {len(scenario.constraints)}")
    print(f"Dünya: {int(scenario.simulation.get('worlds', 0)):,}; tohum: {scenario.simulation.get('seed')}")
    print(f"Scenario hash: {scenario.hash}")
    print(f"Doğrulama: 0 hata, {len([i for i in issues if i.level == 'warning'])} uyarı")
    return 0


def _run(args: argparse.Namespace) -> int:
    scenario = load_scenario(args.scenario)
    issues = validate_scenario(scenario)
    raise_for_errors(issues)
    progress = None if args.no_progress else _progress_printer()
    result = run_scenario(
        scenario,
        worlds=args.worlds,
        seed=args.seed,
        progress=progress,
        validation=[issue.to_dict() for issue in issues],
    )
    if progress:
        print()
    paths = write_run(args.output, result, scenario)
    decision = getattr(result, "decision", {})
    if decision:
        print(f"\nKARAR DURUMU: {decision.get('label', 'Sonuç')}")
        print(decision.get("explanation", ""))
    print("\nKARAR SIRALAMASI")
    for row in result.summary["ranking"]:
        eligibility = "geçti" if row["eligible"] else "KISIT İHLALİ"
        print(
            f"#{row['rank']} {row['label']}: skor={row['decision_score']:.3f} "
            f"EU={row['expected_utility']:.3f} CVaR={row['utility_cvar']:.3f} "
            f"sağlamlık={row['robustness']:.1%} başarı={row['success_probability']:.1%} [{eligibility}]"
        )
    print(f"\nRapor: {paths['report']}")
    print(f"Özet:  {paths['summary']}")
    print(f"Dünya: {paths['worlds']}")
    return 0


def _new(args: argparse.Namespace) -> int:
    horizon = int(args.horizon)
    if not 3 <= horizon <= 60:
        raise ValueError("Karar ufku 3–60 ay arasında olmalı")
    raw = build_operations_case(
        {
            "company": {"name": str(args.company)},
            "decision": {
                "horizon_months": horizon,
                "question": f"Önümüzdeki {horizon} ayda kapasiteyi artırmalı mıyız, yoksa önce dayanıklılığa mı yatırım yapmalıyız?",
            },
        }
    )
    output = args.output.expanduser().resolve()
    if output.exists():
        raise ValueError(f"Dosya zaten var; üzerine yazılmadı: {output}")
    write_json(output, raw)
    print(f"Karar sözleşmesi oluşturuldu: {output}")
    print("Düzenle, doğrula ve çalıştır:")
    print(f"  spx validate {output}")
    print(f"  spx run {output} --worlds 1000 --output runs/karar")
    return 0


def _calibrate(args: argparse.Namespace) -> int:
    if args.import_csv:
        count = import_forecasts(args.db, args.import_csv)
        print(f"{count} tahmin-gerçekleşme kaydı içe aktarıldı.")
    report = calibration_report(args.db)
    if args.output:
        write_json(args.output.resolve(), report)
        print(f"Kalibrasyon raporu: {args.output.resolve()}")
    else:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


def _ledger(args: argparse.Namespace) -> int:
    rows = list_runs(args.db, args.limit)
    if not rows:
        print("Ledger boş.")
        return 0
    for row in rows:
        print(f"{row['created_at']}  {row['scenario_id']}  {row['worlds']} dünya  {row['horizon']} dönem  {row['run_id']}")
    return 0


def _studio(args: argparse.Namespace) -> int:
    serve_studio(
        workspace=args.workspace,
        primary_scenario=args.scenario,
        host=args.host,
        port=args.port,
        open_browser=not args.no_open,
    )
    return 0


def _progress_printer():
    last = {"bucket": -1}

    def progress(completed: int, total: int) -> None:
        bucket = int(completed / total * 40)
        if bucket == last["bucket"] and completed != total:
            return
        last["bucket"] = bucket
        bar = "█" * bucket + "·" * (40 - bucket)
        print(f"\r[{bar}] {completed}/{total}", end="", flush=True)

    return progress


if __name__ == "__main__":
    raise SystemExit(main())
