from __future__ import annotations

import json
import math
import re
import unicodedata
from statistics import mean, pstdev
from typing import Any, Mapping, Sequence

from .util import object_hash


DECISION_BUILDER_VERSION = "1.0.0"
ENGINE_ID = "operations_v1"


DEFAULT_INPUT: dict[str, Any] = {
    "company": {
        "name": "Örnek Üretim İşletmesi",
        "sector_note": "Paketli gıda üretimi",
    },
    "decision": {
        "question": "Önümüzdeki 18 ayda kapasiteyi artırmalı mıyız, yoksa önce dayanıklılığa mı yatırım yapmalıyız?",
        "owner": "İşletme sahibi",
        "deadline": "Bu ay",
        "horizon_months": 18,
        "reversibility": "medium",
    },
    "baseline": {
        "monthly_demand": 4800.0,
        "unit_price": 140.0,
        "variable_cost_per_unit": 62.0,
        "fixed_cost_monthly": 240000.0,
        "starting_cash": 1500000.0,
        "machine_count": 4,
        "machine_capacity_per_day": 58.0,
        "worker_count": 18,
        "worker_capacity_per_day": 14.0,
        "working_days_per_month": 26,
        "starting_inventory_units": 2400.0,
        "starting_backlog_units": 120.0,
        "added_worker_monthly_cost": 20000.0,
        "machine_purchase_cost": 650000.0,
    },
    "uncertainty": {
        "annual_demand_trend": 0.04,
        "demand_volatility": 0.14,
        "demand_persistence": 0.68,
        "annual_cost_inflation": 0.22,
        "absence_rate": 0.06,
        "supplier_normal_fill": 0.94,
        "supplier_disruption_probability": 0.08,
        "supplier_lead_months": 1,
        "failure_weibull_shape": 2.10,
        "failure_weibull_scale_days": 540.0,
        "mean_repair_days": 4.0,
        "price_elasticity": 1.25,
        "marketing_elasticity": 0.80,
        "base_defect_rate": 0.025,
        "parameter_uncertainty": 0.20,
    },
    "preferences": {
        "minimum_cash": 0.0,
        "minimum_service_level": 0.65,
        "maximum_stockout_months": 8,
        "weights": {
            "profit": 0.24,
            "cash": 0.22,
            "service": 0.18,
            "quality": 0.10,
            "downtime": 0.12,
            "backlog": 0.08,
            "optionality": 0.06,
        },
    },
    "data_status": {},
    "history": [],
    "strategies": [
        {
            "id": "current_course",
            "label": "Mevcut düzen",
            "description": "Büyük yatırım yapmadan mevcut kapasiteyi ve nakdi korur.",
            "start_month": 1,
            "added_machines": 0,
            "added_workers": 0,
            "upfront_investment": 0.0,
            "marketing_rate": 0.02,
            "price_change": 0.0,
            "maintenance_interval_days": 120,
            "maintenance_downtime_days": 1,
            "safety_stock_days": 14.0,
            "training_rate": 0.02,
            "overtime_limit": 0.08,
            "cash_brake": True,
        },
        {
            "id": "capacity_expansion",
            "label": "Kapasite yatırımı",
            "description": "İki makine ve beş çalışan ekleyip talep artışını yakalamaya çalışır.",
            "start_month": 3,
            "added_machines": 2,
            "added_workers": 5,
            "upfront_investment": 920000.0,
            "marketing_rate": 0.08,
            "price_change": -0.02,
            "maintenance_interval_days": 120,
            "maintenance_downtime_days": 1,
            "safety_stock_days": 12.0,
            "training_rate": 0.04,
            "overtime_limit": 0.14,
            "cash_brake": True,
        },
        {
            "id": "resilience_first",
            "label": "Dayanıklılık önce",
            "description": "Bir makine, bakım, eğitim ve stok tamponuyla kırılganlığı azaltır.",
            "start_month": 2,
            "added_machines": 1,
            "added_workers": 2,
            "upfront_investment": 460000.0,
            "marketing_rate": 0.035,
            "price_change": 0.015,
            "maintenance_interval_days": 75,
            "maintenance_downtime_days": 1,
            "safety_stock_days": 18.0,
            "training_rate": 0.09,
            "overtime_limit": 0.08,
            "cash_brake": True,
        },
    ],
}


STRATEGY_FIELDS: dict[str, tuple[float, float]] = {
    "start_month": (1, 60),
    "added_machines": (0, 1000),
    "added_workers": (0, 100000),
    "upfront_investment": (0, 1e15),
    "marketing_rate": (0, 0.50),
    "price_change": (-0.50, 1.50),
    "maintenance_interval_days": (15, 2000),
    "maintenance_downtime_days": (0, 60),
    "safety_stock_days": (0, 180),
    "training_rate": (0, 0.50),
    "overtime_limit": (0, 0.80),
}


def decision_builder_catalog() -> dict[str, Any]:
    return {
        "version": DECISION_BUILDER_VERSION,
        "decision_types": [
            {
                "id": ENGINE_ID,
                "label": "Operasyon, kapasite ve dayanıklılık",
                "description": "Talep, makine, çalışan, tedarik, stok ve nakit aynı modelde çalışır.",
                "status": "deep",
            },
            {
                "id": "custom_future",
                "label": "Başka karar sınıfı",
                "description": "Önce karar sözleşmesi kurulur; uygun alt model reçetesi ayrıca tasarlanır.",
                "status": "design_required",
            },
        ],
        "default_input": json.loads(json.dumps(DEFAULT_INPUT)),
        "data_statuses": [
            {"id": "OBSERVED", "label": "Kayıttan ölçüldü"},
            {"id": "ESTIMATED", "label": "Yaklaşık tahmin"},
            {"id": "ASSUMPTION", "label": "Model varsayımı"},
        ],
    }


def normalize_decision_input(raw: Mapping[str, Any] | None) -> dict[str, Any]:
    incoming = dict(raw or {})
    value = json.loads(json.dumps(DEFAULT_INPUT))
    _deep_merge(value, incoming)
    company = value["company"]
    company["name"] = str(company.get("name", "Şirketim")).strip()[:100] or "Şirketim"
    company["sector_note"] = str(company.get("sector_note", "")).strip()[:160]

    decision = value["decision"]
    decision["question"] = str(decision.get("question", "")).strip()[:600]
    decision["owner"] = str(decision.get("owner", "")).strip()[:120]
    decision["deadline"] = str(decision.get("deadline", "")).strip()[:120]
    decision["horizon_months"] = int(_bound(decision.get("horizon_months"), 3, 60, 18))
    decision["reversibility"] = str(decision.get("reversibility", "medium"))
    if decision["reversibility"] not in {"low", "medium", "high"}:
        decision["reversibility"] = "medium"

    b = value["baseline"]
    b["monthly_demand"] = _bound(b.get("monthly_demand"), 1, 1e12, 4800)
    b["unit_price"] = _bound(b.get("unit_price"), 0.01, 1e12, 140)
    b["variable_cost_per_unit"] = _bound(b.get("variable_cost_per_unit"), 0, 1e12, 62)
    b["fixed_cost_monthly"] = _bound(b.get("fixed_cost_monthly"), 0, 1e15, 240000)
    b["starting_cash"] = _bound(b.get("starting_cash"), -1e15, 1e15, 1500000)
    b["machine_count"] = int(_bound(b.get("machine_count"), 1, 10000, 4))
    b["machine_capacity_per_day"] = _bound(b.get("machine_capacity_per_day"), 0.01, 1e10, 58)
    b["worker_count"] = int(_bound(b.get("worker_count"), 1, 1_000_000, 18))
    b["worker_capacity_per_day"] = _bound(b.get("worker_capacity_per_day"), 0.01, 1e10, 14)
    b["working_days_per_month"] = int(_bound(b.get("working_days_per_month"), 1, 31, 26))
    b["starting_inventory_units"] = _bound(b.get("starting_inventory_units"), 0, 1e12, 2400)
    b["starting_backlog_units"] = _bound(b.get("starting_backlog_units"), 0, 1e12, 120)
    b["added_worker_monthly_cost"] = _bound(b.get("added_worker_monthly_cost"), 0, 1e12, 20000)
    b["machine_purchase_cost"] = _bound(b.get("machine_purchase_cost"), 0, 1e15, 650000)

    u = value["uncertainty"]
    u["annual_demand_trend"] = _bound(u.get("annual_demand_trend"), -0.80, 5.0, 0.04)
    u["demand_volatility"] = _bound(u.get("demand_volatility"), 0.005, 1.50, 0.14)
    u["demand_persistence"] = _bound(u.get("demand_persistence"), 0, 0.98, 0.68)
    u["annual_cost_inflation"] = _bound(u.get("annual_cost_inflation"), -0.50, 10.0, 0.22)
    u["absence_rate"] = _bound(u.get("absence_rate"), 0, 0.60, 0.06)
    u["supplier_normal_fill"] = _bound(u.get("supplier_normal_fill"), 0.20, 1.0, 0.94)
    u["supplier_disruption_probability"] = _bound(u.get("supplier_disruption_probability"), 0, 0.80, 0.08)
    u["supplier_lead_months"] = int(_bound(u.get("supplier_lead_months"), 0, 12, 1))
    u["failure_weibull_shape"] = _bound(u.get("failure_weibull_shape"), 0.35, 8.0, 2.1)
    u["failure_weibull_scale_days"] = _bound(u.get("failure_weibull_scale_days"), 10, 10000, 540)
    u["mean_repair_days"] = _bound(u.get("mean_repair_days"), 0.25, 180, 4)
    u["price_elasticity"] = _bound(u.get("price_elasticity"), 0, 10, 1.25)
    u["marketing_elasticity"] = _bound(u.get("marketing_elasticity"), 0, 10, 0.80)
    u["base_defect_rate"] = _bound(u.get("base_defect_rate"), 0, 0.50, 0.025)
    u["parameter_uncertainty"] = _bound(u.get("parameter_uncertainty"), 0, 1.0, 0.20)

    pref = value["preferences"]
    pref["minimum_cash"] = _bound(pref.get("minimum_cash"), -1e15, 1e15, 0)
    pref["minimum_service_level"] = _bound(pref.get("minimum_service_level"), 0, 1, 0.65)
    pref["maximum_stockout_months"] = int(_bound(pref.get("maximum_stockout_months"), 0, 60, 8))
    weights = dict(pref.get("weights", {}))
    defaults = DEFAULT_INPUT["preferences"]["weights"]
    for key, fallback in defaults.items():
        weights[key] = _bound(weights.get(key), 0, 1, fallback)
    total = sum(weights.values()) or 1.0
    pref["weights"] = {key: val / total for key, val in weights.items()}

    statuses = dict(value.get("data_status", {}))
    for key in list(statuses):
        status = str(statuses[key]).upper()
        statuses[key] = status if status in {"OBSERVED", "ESTIMATED", "ASSUMPTION"} else "ESTIMATED"
    value["data_status"] = statuses
    value["history"] = _normalize_history(value.get("history"))
    value["strategies"] = _normalize_strategies(value.get("strategies"), decision["horizon_months"])
    if len(value["history"]) >= 4:
        _calibrate_from_history(value)
    return value


def build_operations_case(raw: Mapping[str, Any] | None) -> dict[str, Any]:
    value = normalize_decision_input(raw)
    company, decision = value["company"], value["decision"]
    b, u, pref = value["baseline"], value["uncertainty"], value["preferences"]
    horizon = int(decision["horizon_months"])
    case_id = f"decision_{_identifier(company['name'], 'company')}_{horizon}m"
    evidence, registry = _build_evidence(value, case_id)

    strategies = []
    for item in value["strategies"]:
        strategy = dict(item)
        strategy["parameters"] = {
            field: float(strategy[field])
            for field in STRATEGY_FIELDS
        }
        strategy["parameters"]["cash_brake"] = 1.0 if strategy.get("cash_brake", True) else 0.0
        strategies.append(strategy)

    baseline_profit = b["monthly_demand"] * (b["unit_price"] - b["variable_cost_per_unit"]) - b["fixed_cost_monthly"]
    horizon_revenue = b["monthly_demand"] * b["unit_price"] * horizon
    cash_span = max(abs(b["starting_cash"]), b["fixed_cost_monthly"] * 3, 1.0)
    weights = pref["weights"]
    case: dict[str, Any] = {
        "meta": {
            "id": case_id,
            "name": f"{company['name']} — Karar Laboratuvarı",
            "version": DECISION_BUILDER_VERSION,
            "engine": ENGINE_ID,
            "data_status": _overall_status(value["data_status"]),
            "human_approval_required": True,
            "description": "Tek bir operasyon/kapasite kararı için hibrit talep, güvenilirlik, işgücü, tedarik ve nakit modeli.",
            "builder_input": value,
        },
        "decision": {
            **decision,
            "company_name": company["name"],
            "sector_note": company["sector_note"],
            "success_definition": {
                "minimum_cash": pref["minimum_cash"],
                "minimum_service_level": pref["minimum_service_level"],
                "maximum_stockout_months": pref["maximum_stockout_months"],
            },
        },
        "horizon": horizon,
        "step": "ay",
        "baseline": b,
        "uncertainty": u,
        "simulation": {
            "worlds": 1000,
            "seed": 20260817,
            "tail_alpha": 0.10,
            "future_tree_depth": 3,
            "future_tree_min_mass": 0.07,
            "trace_worlds": 4,
        },
        "decision_policy": {
            "acceptance_utility": 0.55,
            "tail_alpha": 0.10,
            "expected_weight": 0.22,
            "tail_weight": 0.26,
            "robustness_weight": 0.22,
            "success_weight": 0.15,
            "regret_weight": 0.15,
        },
        "strategies": strategies,
        "objectives": [
            {"id": "profit", "metric": "cumulative_profit", "direction": "max", "worst": min(-0.35 * horizon_revenue, baseline_profit * horizon * 0.4), "best": max(0.20 * horizon_revenue, baseline_profit * horizon * 2.0), "weight": weights["profit"]},
            {"id": "cash", "metric": "final_cash", "direction": "max", "worst": pref["minimum_cash"] - cash_span, "best": b["starting_cash"] + max(cash_span, baseline_profit * horizon * 1.8), "weight": weights["cash"]},
            {"id": "service", "metric": "average_service_level", "direction": "max", "worst": 0.45, "best": 0.99, "weight": weights["service"]},
            {"id": "quality", "metric": "average_quality_rate", "direction": "max", "worst": 0.80, "best": 0.995, "weight": weights["quality"]},
            {"id": "downtime", "metric": "downtime_days", "direction": "min", "worst": horizon * b["working_days_per_month"] * max(1, b["machine_count"]) * 0.40, "best": 0.0, "weight": weights["downtime"]},
            {"id": "backlog", "metric": "max_backlog", "direction": "min", "worst": b["monthly_demand"] * 3.0, "best": 0.0, "weight": weights["backlog"]},
            {"id": "optionality", "metric": "optionality_score", "direction": "max", "worst": 0.0, "best": 1.0, "weight": weights["optionality"]},
        ],
        "constraints": [
            {"id": "cash_floor", "metric": "minimum_cash", "op": ">=", "value": pref["minimum_cash"], "hard": True, "ruin": True, "max_violation_probability": 0.12, "penalty": 0.60},
            {"id": "service_floor", "metric": "average_service_level", "op": ">=", "value": pref["minimum_service_level"], "hard": True, "ruin": False, "max_violation_probability": 0.25, "penalty": 0.40},
            {"id": "stockout_limit", "metric": "stockout_months", "op": "<=", "value": pref["maximum_stockout_months"], "hard": False, "ruin": False, "max_violation_probability": 0.35, "penalty": 0.20},
        ],
        "success": {
            "minimum_cash": pref["minimum_cash"],
            "minimum_service_level": pref["minimum_service_level"],
            "maximum_stockout_months": pref["maximum_stockout_months"],
        },
        "evidence": evidence,
        "parameter_registry": registry,
        "model_registry": _model_registry(),
        "stress_tests": [
            {"id": "demand_slump", "label": "Talep daralması", "condition": "driver_demand_mean < 0.88"},
            {"id": "demand_surge", "label": "Talep sıçraması", "condition": "driver_demand_mean > 1.14"},
            {"id": "cost_squeeze", "label": "Maliyet sıkışması", "condition": "driver_cost_mean > 1.15"},
            {"id": "supply_pressure", "label": "Tedarik baskısı", "condition": "driver_supplier_fill_mean < 0.82"},
            {"id": "staffing_pressure", "label": "Çalışan baskısı", "condition": "driver_absence_mean > 0.10"},
            {"id": "compound_storm", "label": "Bileşik kötü dönem", "condition": "driver_demand_mean < 0.94 and driver_cost_mean > 1.10 and driver_supplier_fill_mean < 0.88"},
        ],
    }
    errors = [item for item in validate_decision_case(case) if item["level"] == "error"]
    if errors:
        raise ValueError("Karar modeli kurulamadı: " + "; ".join(item["message"] for item in errors))
    return case


def validate_decision_case(raw: Mapping[str, Any]) -> list[dict[str, str]]:
    issues: list[dict[str, str]] = []

    def add(level: str, code: str, path: str, message: str) -> None:
        issues.append({"level": level, "code": code, "path": path, "message": message})

    if raw.get("meta", {}).get("engine") != ENGINE_ID:
        add("error", "engine", "meta.engine", f"Beklenen motor: {ENGINE_ID}")
    if not str(raw.get("meta", {}).get("id", "")).strip():
        add("error", "meta.id", "meta.id", "Karar modeli kimliği eksik")
    if not str(raw.get("meta", {}).get("name", "")).strip():
        add("error", "meta.name", "meta.name", "Karar modeli adı eksik")
    try:
        horizon = int(raw.get("horizon", 0))
    except (TypeError, ValueError):
        horizon = 0
    if horizon < 3:
        add("error", "horizon", "horizon", "Karar ufku en az 3 ay olmalı")
    strategies = list(raw.get("strategies", []))
    if len(strategies) < 2:
        add("error", "strategies.count", "strategies", "En az iki gerçek karar alternatifi gerekli")
    ids: set[str] = set()
    labels: set[str] = set()
    for index, strategy in enumerate(strategies):
        sid = str(strategy.get("id", ""))
        if not sid or sid in ids or not re.fullmatch(r"[a-z_][a-z0-9_]*", sid):
            add("error", "strategy.id", f"strategies[{index}].id", "Strateji kimliği eksik veya tekrarlı")
        ids.add(sid)
        label = str(strategy.get("label", "")).strip().casefold()
        if not label or label in labels:
            add("error", "strategy.label", f"strategies[{index}].label", "Strateji etiketi eksik veya tekrarlı")
        labels.add(label)
        params = strategy.get("parameters", {})
        if not isinstance(params, Mapping):
            add("error", "strategy.parameters", f"strategies[{index}].parameters", "Strateji parametreleri nesne olmalı")
            params = {}
        for field, (low, high) in STRATEGY_FIELDS.items():
            if field not in strategy:
                add("error", "strategy.field", f"strategies[{index}].{field}", f"Strateji alanı eksik: {field}")
                continue
            try:
                value = float(strategy[field])
            except (TypeError, ValueError):
                add("error", "strategy.numeric", f"strategies[{index}].{field}", f"Strateji alanı sayısal olmalı: {field}")
                continue
            if not math.isfinite(value) or value < low or value > high:
                add("error", "strategy.range", f"strategies[{index}].{field}", f"Strateji alanı izin verilen aralığın dışında: {field}")
            if field == "start_month" and value > horizon:
                add("error", "strategy.start", f"strategies[{index}].{field}", "Strateji başlangıcı karar ufkundan sonra olamaz")
            if field not in params:
                add("error", "strategy.parameters.missing", f"strategies[{index}].parameters.{field}", f"Motor parametresi eksik: {field}")
            else:
                try:
                    parameter_value = float(params[field])
                except (TypeError, ValueError):
                    add("error", "strategy.parameters.numeric", f"strategies[{index}].parameters.{field}", f"Motor parametresi sayısal olmalı: {field}")
                else:
                    if not math.isclose(value, parameter_value, rel_tol=0.0, abs_tol=1e-9):
                        add("error", "strategy.parameters.mismatch", f"strategies[{index}].parameters.{field}", f"Görünen değer ile motor parametresi farklı: {field}")
    baseline = raw.get("baseline", {})
    for key in ("monthly_demand", "unit_price", "machine_count", "worker_count"):
        try:
            value = float(baseline.get(key, 0))
        except (TypeError, ValueError):
            value = 0.0
        if not math.isfinite(value) or value <= 0:
            add("error", "baseline.positive", f"baseline.{key}", f"{key} sıfırdan büyük olmalı")
    evidence_ids = {str(item.get("id")) for item in raw.get("evidence", [])}
    if not evidence_ids:
        add("error", "evidence.empty", "evidence", "Kanıt/varsayım kayıt sistemi boş")
    elif len(evidence_ids) != len(raw.get("evidence", [])):
        add("error", "evidence.duplicate", "evidence", "Kanıt kimlikleri tekrarlanamaz")
    parameter_ids: set[str] = set()
    for index, parameter in enumerate(raw.get("parameter_registry", [])):
        parameter_id = str(parameter.get("id", ""))
        if not parameter_id or parameter_id in parameter_ids:
            add("error", "parameter.id", f"parameter_registry[{index}].id", "Parametre kimliği eksik veya tekrarlı")
        parameter_ids.add(parameter_id)
        if str(parameter.get("source_id")) not in evidence_ids:
            add("error", "parameter.source", f"parameter_registry[{index}].source_id", "Parametre tanımsız kaynağa bağlı")
        if str(parameter.get("status")) not in {"OBSERVED", "ESTIMATED", "ASSUMPTION"}:
            add("error", "parameter.status", f"parameter_registry[{index}].status", "Parametre veri statüsü geçersiz")
        try:
            value = float(parameter.get("value", 0))
            low = float(parameter.get("low", value))
            high = float(parameter.get("high", value))
        except (TypeError, ValueError):
            add("error", "parameter.numeric", f"parameter_registry[{index}]", "Parametre değeri ve aralığı sayısal olmalı")
        else:
            if not all(math.isfinite(item) for item in (low, value, high)) or low > value or value > high:
                add("error", "parameter.range", f"parameter_registry[{index}]", "Parametre için alt ≤ merkez ≤ üst olmalı")
    expected_models = {str(item["id"]) for item in _model_registry()}
    models = list(raw.get("model_registry", []))
    model_ids = {str(item.get("id")) for item in models}
    if model_ids != expected_models or len(models) != len(model_ids):
        add("error", "models.registry", "model_registry", "Operasyon motorunun yedi kayıtlı alt modeli eksiksiz ve tekil olmalı")
    for index, model in enumerate(models):
        refs = model.get("evidence_ids", [])
        missing = set(map(str, refs if isinstance(refs, Sequence) and not isinstance(refs, (str, bytes)) else [])) - evidence_ids
        if missing:
            add("error", "models.evidence", f"model_registry[{index}].evidence_ids", "Alt model tanımsız kanıt kaydına bağlı")
    metric_names = {
        "final_cash", "minimum_cash", "cumulative_profit", "total_revenue", "average_service_level",
        "minimum_service_level", "average_quality_rate", "minimum_employee_energy", "max_backlog",
        "final_backlog", "stockout_months", "downtime_days", "failure_count", "preventive_events",
        "lost_orders", "ending_inventory", "optionality_score",
    }
    objectives = list(raw.get("objectives", []))
    objective_weight = 0.0
    for index, item in enumerate(objectives):
        try:
            weight = float(item.get("weight", 0))
        except (TypeError, ValueError):
            add("error", "objective.weight", f"objectives[{index}].weight", "Amaç ağırlığı sayısal olmalı")
            continue
        if not math.isfinite(weight) or weight < 0:
            add("error", "objective.weight", f"objectives[{index}].weight", "Amaç ağırlığı sonlu ve negatif olmayan sayı olmalı")
            continue
        objective_weight += weight
    if not objectives or objective_weight <= 0:
        add("error", "objectives.empty", "objectives", "En az bir pozitif ağırlıklı karar amacı gerekli")
    for index, objective in enumerate(objectives):
        if str(objective.get("metric")) not in metric_names:
            add("error", "objective.metric", f"objectives[{index}].metric", "Amaç motorun üretmediği bir metriğe bağlı")
        try:
            worst, best = float(objective["worst"]), float(objective["best"])
        except (KeyError, TypeError, ValueError):
            add("error", "objective.scale", f"objectives[{index}]", "Amaç için sayısal worst/best ölçeği gerekli")
        else:
            direction = str(objective.get("direction", "max"))
            if direction not in {"min", "max"} or (direction == "max" and best <= worst) or (direction == "min" and best >= worst):
                add("error", "objective.order", f"objectives[{index}]", "Amaç yönü ile worst/best sırası uyumsuz")
    for index, constraint in enumerate(raw.get("constraints", [])):
        if str(constraint.get("metric")) not in metric_names:
            add("error", "constraint.metric", f"constraints[{index}].metric", "Kısıt motorun üretmediği bir metriğe bağlı")
        if str(constraint.get("op")) not in {">=", ">", "<=", "<", "=="}:
            add("error", "constraint.op", f"constraints[{index}].op", "Kısıt işleci geçersiz")
    observed = sum(1 for item in raw.get("parameter_registry", []) if item.get("status") == "OBSERVED")
    total = len(raw.get("parameter_registry", []))
    if observed == 0:
        add("warning", "calibration.none", "parameter_registry", "Modelde gözlenmiş olarak işaretlenmiş parametre yok; yüzdeler kalibrasyon öncesidir")
    elif observed < total * 0.4:
        add("warning", "calibration.low", "parameter_registry", "Parametrelerin çoğu tahmin veya varsayım; model güveni sınırlıdır")
    if not raw.get("decision", {}).get("question"):
        add("error", "decision.question", "decision.question", "Karar sorusu boş")
    return issues


def case_overview(raw: Mapping[str, Any]) -> dict[str, Any]:
    registry = list(raw.get("parameter_registry", []))
    status_counts = {status: sum(1 for item in registry if item.get("status") == status) for status in ("OBSERVED", "ESTIMATED", "ASSUMPTION")}
    return {
        "scenario_id": raw.get("meta", {}).get("id"),
        "name": raw.get("meta", {}).get("name"),
        "engine": raw.get("meta", {}).get("engine"),
        "decision_question": raw.get("decision", {}).get("question"),
        "horizon": raw.get("horizon"),
        "strategies": len(raw.get("strategies", [])),
        "models": len(raw.get("model_registry", [])),
        "parameters": len(registry),
        "evidence": len(raw.get("evidence", [])),
        "status_counts": status_counts,
        "hash": object_hash(raw),
    }


def _normalize_strategies(raw: Any, horizon: int) -> list[dict[str, Any]]:
    provided = list(raw) if isinstance(raw, Sequence) and not isinstance(raw, (str, bytes)) else []
    if not provided:
        provided = DEFAULT_INPUT["strategies"]
    result = []
    seen: set[str] = set()
    for index, item in enumerate(provided[:6]):
        base = DEFAULT_INPUT["strategies"][min(index, len(DEFAULT_INPUT["strategies"]) - 1)]
        value = dict(base)
        if isinstance(item, Mapping):
            value.update(item)
        sid = _identifier(value.get("id") or value.get("label"), f"strategy_{index+1}")
        suffix = 2
        candidate = sid
        while candidate in seen:
            candidate = f"{sid}_{suffix}"
            suffix += 1
        value["id"] = candidate
        seen.add(candidate)
        value["label"] = str(value.get("label", candidate)).strip()[:80] or candidate
        value["description"] = str(value.get("description", "")).strip()[:300]
        for field, (low, high) in STRATEGY_FIELDS.items():
            if field == "start_month":
                high = min(high, horizon)
            number = _bound(value.get(field), low, high, base[field])
            if field in {"start_month", "added_machines", "added_workers", "maintenance_interval_days", "maintenance_downtime_days"}:
                number = int(round(number))
            value[field] = number
        value["cash_brake"] = bool(value.get("cash_brake", True))
        result.append(value)
    return result


def _normalize_history(raw: Any) -> list[dict[str, float]]:
    if not isinstance(raw, Sequence) or isinstance(raw, (str, bytes)):
        return []
    rows = []
    for item in raw[-36:]:
        if not isinstance(item, Mapping):
            continue
        row: dict[str, float] = {}
        for key in ("demand", "revenue", "variable_cost", "fixed_cost", "absence_rate", "failures", "service_level"):
            try:
                row[key] = float(item.get(key, 0))
            except (TypeError, ValueError):
                row[key] = 0.0
        if row["demand"] > 0:
            rows.append(row)
    return rows


def _calibrate_from_history(value: dict[str, Any]) -> None:
    rows = value["history"]
    b, u, status = value["baseline"], value["uncertainty"], value["data_status"]
    demands = [row["demand"] for row in rows if row["demand"] > 0]
    b["monthly_demand"] = mean(demands)
    status["baseline.monthly_demand"] = "OBSERVED"
    revenues = [row["revenue"] for row in rows if row["revenue"] > 0]
    if revenues:
        b["unit_price"] = mean(revenues) / max(1.0, mean(demands))
        status["baseline.unit_price"] = "OBSERVED"
    fixed = [row["fixed_cost"] for row in rows if row["fixed_cost"] > 0]
    if fixed:
        b["fixed_cost_monthly"] = mean(fixed)
        status["baseline.fixed_cost_monthly"] = "OBSERVED"
    variable = [row["variable_cost"] / max(1.0, row["demand"]) for row in rows if row["variable_cost"] > 0]
    if variable:
        b["variable_cost_per_unit"] = mean(variable)
        status["baseline.variable_cost_per_unit"] = "OBSERVED"
    changes = [math.log(demands[i] / demands[i - 1]) for i in range(1, len(demands)) if demands[i - 1] > 0]
    if len(changes) >= 2:
        u["demand_volatility"] = max(0.005, min(1.5, pstdev(changes) * math.sqrt(12)))
        u["annual_demand_trend"] = max(-0.8, min(5.0, math.exp(mean(changes) * 12) - 1.0))
        status["uncertainty.demand_volatility"] = "OBSERVED"
        status["uncertainty.annual_demand_trend"] = "OBSERVED"
    absences = [row["absence_rate"] for row in rows if 0 <= row["absence_rate"] <= 1 and row["absence_rate"] > 0]
    if absences:
        u["absence_rate"] = mean(absences)
        status["uncertainty.absence_rate"] = "OBSERVED"


def _build_evidence(value: Mapping[str, Any], case_id: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    statuses = value.get("data_status", {})
    uncertainty_width = float(value["uncertainty"]["parameter_uncertainty"])
    evidence: list[dict[str, Any]] = []
    registry: list[dict[str, Any]] = []
    groups = (("baseline", value["baseline"]), ("uncertainty", value["uncertainty"]))
    for group, fields in groups:
        for key, raw_value in fields.items():
            if not isinstance(raw_value, (int, float)) or key == "parameter_uncertainty":
                continue
            path = f"{group}.{key}"
            status = str(statuses.get(path, "ESTIMATED" if group == "baseline" else "ASSUMPTION")).upper()
            source_id = "E-" + re.sub(r"[^A-Z0-9]+", "-", path.upper()).strip("-")
            evidence.append(
                {
                    "id": source_id,
                    "type": status.lower(),
                    "source": f"decision-room:{path}",
                    "fingerprint": f"{case_id}:{path}",
                    "quality": {"OBSERVED": "B", "ESTIMATED": "C", "ASSUMPTION": "D"}[status],
                    "validity": "until-case-update",
                    "note": "Kullanıcı kararı kurulurken girilen değer; kaynak notu eklenmediyse bağımsız doğrulanmamıştır.",
                }
            )
            number = float(raw_value)
            width = 0.03 if status == "OBSERVED" else uncertainty_width * (0.55 if status == "ESTIMATED" else 1.0)
            if number == 0:
                low, high = -width, width
            else:
                low, high = number * (1 - width), number * (1 + width)
                if number > 0:
                    low = max(0.0, low)
            registry.append(
                {
                    "id": path,
                    "label": key.replace("_", " "),
                    "value": number,
                    "low": min(low, high),
                    "high": max(low, high),
                    "uncertainty_kind": "epistemic" if group == "uncertainty" else "measurement",
                    "status": status,
                    "source_id": source_id,
                }
            )
    evidence.append(
        {
            "id": "E-MODEL-STRUCTURE",
            "type": "structural_hypothesis",
            "source": f"operations-model:{DECISION_BUILDER_VERSION}",
            "fingerprint": f"operations-model:{DECISION_BUILDER_VERSION}",
            "quality": "C",
            "validity": "requires-historical-replay",
            "note": "Alt model denklemleri genel operasyon mekaniğidir; şirket verisiyle doğrulanmalıdır.",
        }
    )
    return evidence, registry


def _model_registry() -> list[dict[str, Any]]:
    return [
        {"id": "DEMAND-REGIME-AR1-v1", "label": "Talep ve rejim modeli", "family": "state-space/regime", "inputs": ["annual_demand_trend", "demand_volatility", "price_elasticity", "marketing_elasticity"], "outputs": ["orders"], "evidence_ids": ["E-MODEL-STRUCTURE"]},
        {"id": "RELIABILITY-WEIBULL-DES-v1", "label": "Makine güvenilirliği", "family": "Weibull + günlük olay simülasyonu", "inputs": ["failure_weibull_shape", "failure_weibull_scale_days", "mean_repair_days"], "outputs": ["active_machine_days", "failures", "downtime_days"], "evidence_ids": ["E-MODEL-STRUCTURE"]},
        {"id": "WORKFORCE-COHORT-v1", "label": "İşgücü kapasitesi", "family": "cohort Bernoulli + stok/geri besleme", "inputs": ["absence_rate", "training_rate", "overtime_limit"], "outputs": ["worker_days", "fatigue", "skill"], "evidence_ids": ["E-MODEL-STRUCTURE"]},
        {"id": "SUPPLY-INVENTORY-v1", "label": "Tedarik ve stok", "family": "lead-time event queue", "inputs": ["supplier_normal_fill", "supplier_disruption_probability", "safety_stock_days"], "outputs": ["receipts", "inventory", "stockout"], "evidence_ids": ["E-MODEL-STRUCTURE"]},
        {"id": "OPERATIONS-FLOW-v1", "label": "Sipariş-kapasite akışı", "family": "stok-akış/kısıt", "inputs": ["orders", "active_machine_days", "worker_days", "inventory"], "outputs": ["sales", "backlog", "service", "quality"], "evidence_ids": ["E-MODEL-STRUCTURE"]},
        {"id": "FINANCE-CASHFLOW-v1", "label": "Nakit ve kârlılık", "family": "stokastik cash-flow", "inputs": ["sales", "cost_index", "strategy_costs"], "outputs": ["profit", "cash", "minimum_cash"], "evidence_ids": ["E-MODEL-STRUCTURE"]},
        {"id": "DECISION-RDM-v1", "label": "Sağlam karar motoru", "family": "multi-objective robust satisficing", "inputs": ["outcomes", "constraints", "preferences"], "outputs": ["robustness", "regret", "decision_status"], "evidence_ids": ["E-MODEL-STRUCTURE"]},
    ]


def _overall_status(statuses: Mapping[str, Any]) -> str:
    values = {str(value).upper() for value in statuses.values()}
    if values and values == {"OBSERVED"}:
        return "OBSERVED"
    if "OBSERVED" in values:
        return "MIXED"
    return "ILLUSTRATIVE"


def _identifier(value: Any, fallback: str) -> str:
    text = str(value or "").strip().lower().translate(str.maketrans("çğıöşü", "cgiosu"))
    text = "".join(char for char in unicodedata.normalize("NFKD", text) if not unicodedata.combining(char))
    text = re.sub(r"[^a-z0-9_]+", "_", text)
    text = re.sub(r"^\d+", "", text).strip("_")
    return text or fallback


def _bound(value: Any, low: float, high: float, fallback: float) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        number = float(fallback)
    if not math.isfinite(number):
        number = float(fallback)
    return max(low, min(high, number))


def _deep_merge(target: dict[str, Any], update: Mapping[str, Any]) -> None:
    for key, value in update.items():
        if isinstance(value, Mapping) and isinstance(target.get(key), dict):
            _deep_merge(target[key], value)
        else:
            target[key] = value
