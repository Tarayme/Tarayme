from __future__ import annotations

import html
import math
from typing import Any, Mapping

from .schema import Scenario


def build_decision_html_report(result, scenario: Scenario) -> str:
    compact = result.compact()
    ranking = compact["summary"]["ranking"]
    status = compact.get("decision_status", {})
    labels = {str(item["id"]): str(item.get("label", item["id"])) for item in scenario.strategies}
    status_label = str(status.get("label", "Karar sonucu"))
    leading_id = str(status.get("leading_strategy_id", ranking[0]["strategy_id"]))
    leading_label = labels.get(leading_id, leading_id)
    decision_line = (
        f"Önerilen seçenek: {leading_label}"
        if status.get("recommended_strategy_id")
        else f"Şu an önde: {leading_label}; otomatik öneri üretilmedi"
    )
    ranking_html = "".join(_ranking_card(row, index == 0) for index, row in enumerate(ranking))
    switch_tree = _tree(compact.get("future_maps", {}).get("switch", {}).get("root", {}), labels)
    failure_tree = _tree(compact.get("future_maps", {}).get("failure", {}).get("root", {}), labels)
    stress_rows = _stress_rows(compact.get("stress_profiles", []), labels)
    voi_rows = "".join(
        f"<tr><td>{_e(item.get('label'))}</td><td>{_e(item.get('status'))}</td><td>{float(item.get('decision_information',0)):.3f}</td><td>{_e(item.get('interpretation'))}</td></tr>"
        for item in compact.get("value_of_information", [])
    )
    health = compact.get("model_health", {})
    validation = compact.get("validation", [])
    warnings = "".join(f"<li>{_e(item.get('message'))}</li>" for item in validation if item.get("level") == "warning")
    return f"""<!doctype html>
<html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{_e(scenario.name)} — Olasılık Simüle</title>
<style>
:root{{--bg:#071018;--panel:#0e1c28;--line:#294052;--text:#edf7fb;--muted:#9fb3bf;--accent:#61d8c6;--warn:#ffc466;--bad:#ff7b79;--good:#6ae69a}}
*{{box-sizing:border-box}}body{{margin:0;background:linear-gradient(145deg,#071018,#09141f 55%,#081119);color:var(--text);font:15px/1.55 system-ui,-apple-system,Segoe UI,sans-serif}}
main{{max-width:1080px;margin:auto;padding:24px 16px 64px}}h1{{font-size:clamp(30px,6vw,58px);line-height:1.05;margin:.25em 0}}h2{{margin:38px 0 13px}}h3{{margin:.2em 0}}
.hero,.card,.panel,details.node{{border:1px solid var(--line);background:var(--panel);border-radius:17px}}.hero{{padding:26px;background:linear-gradient(145deg,#102536,#0b1923)}}.eyebrow{{text-transform:uppercase;letter-spacing:.16em;color:var(--accent);font-size:12px}}.decision{{font-size:20px;color:var(--accent)}}.notice{{border-left:3px solid var(--warn);padding:10px 12px;background:#ffc46612;color:#ffe1a8}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px}}.card,.panel{{padding:16px}}.card.best{{border-color:var(--accent)}}.rank{{color:var(--muted);font-size:12px}}.score{{font-size:30px}}.row{{display:flex;justify-content:space-between;gap:15px;border-top:1px solid #1d3342;padding-top:7px;margin-top:7px}}.good{{color:var(--good)}}.bad{{color:var(--bad)}}.muted{{color:var(--muted)}}
.tree{{display:grid;gap:10px}}details.node{{padding:10px 12px}}details.node summary{{cursor:pointer;display:flex;gap:10px;justify-content:space-between;align-items:center}}.branch{{margin:10px 0 0 14px;border-left:2px solid #2a4657;padding-left:12px}}.condition{{color:#c7dae3}}.pill{{display:inline-block;border:1px solid var(--line);border-radius:999px;padding:3px 8px;color:var(--muted);font-size:12px}}
table{{border-collapse:collapse;width:100%;min-width:650px}}th,td{{padding:9px;border-bottom:1px solid #1d3342;text-align:left}}th{{font-size:12px;color:var(--muted)}}.scroll{{overflow:auto}}code{{color:#9ff2e5}}ul{{padding-left:20px}}@media(max-width:600px){{.hero{{padding:19px}}.row{{font-size:13px}}}}
</style></head><body><main>
<section class="hero"><span class="eyebrow">Olasılık Simüle · Karar Deneyi</span><h1>{_e(scenario.raw.get('decision',{}).get('question',scenario.name))}</h1><p class="decision">{_e(status_label)} — {_e(decision_line)}</p><p>{_e(status.get('explanation',''))}</p><p class="notice">{_e(health.get('claim','Bu çıktı model varsayımları altında geçerlidir.'))}</p><p><span class="pill">{int(result.metadata['worlds']):,} eşlenmiş dünya</span> <span class="pill">{int(result.metadata['horizon'])} ay</span> <span class="pill">tohum {int(result.metadata['seed'])}</span> <span class="pill">{_e(health.get('credibility_tier','C0'))} {_e(health.get('label',''))}</span></p></section>
<h2>Seçeneklerin dağılımı</h2><section class="grid">{ranking_html}</section>
<h2>Gelecek Haritası — seçim ne zaman değişiyor?</h2><section class="tree">{switch_tree}</section>
<h2>Kırılma Haritası — öndeki plan nerede bozuluyor?</h2><section class="tree">{failure_tree}</section>
<h2>Stres dünyaları</h2><div class="panel scroll"><table><tr><th>Koşul</th><th>Strateji</th><th>Dünya payı</th><th>Beklenen fayda</th><th>Başarı</th></tr>{stress_rows}</table></div>
<h2>Hangi yeni bilgi en değerli?</h2><div class="panel scroll"><table><tr><th>Değişken</th><th>Kaynak durumu</th><th>Kararı ayırma</th><th>Yorum</th></tr>{voi_rows}</table></div>
<h2>Model güveni ve sınırlar</h2><section class="panel"><p><strong>{_e(health.get('credibility_tier'))} — {_e(health.get('label'))}</strong></p><p>Gözlenmiş parametre payı: {_pct(health.get('observed_share',0))}. Yakınsama: {'kararlı' if health.get('convergence_stable') else 'henüz kararlı değil'}.</p><ul>{warnings or '<li>Ek doğrulama uyarısı yok.</li>'}</ul><p class="muted">Hassasiyet ve gelecek ağacı, model koşullarını ayırır; dışarıdan nedensellik kanıtlamaz. Yüksek etkili karar insan onayı ve historical replay gerektirir.</p></section>
</main></body></html>"""


def _ranking_card(row: Mapping[str, Any], best: bool) -> str:
    cash = row.get("metrics", {}).get("final_cash", {}).get("p50")
    service = row.get("metrics", {}).get("average_service_level", {}).get("p50")
    return f"""<article class="card {'best' if best else ''}"><span class="rank">#{int(row.get('rank',0))}</span><h3>{_e(row.get('label'))}</h3><div class="score">{_pct(row.get('decision_score'))}</div>
<div class="row"><span>Başarı</span><strong>{_pct(row.get('success_probability'))}</strong></div><div class="row"><span>Kötü kuyruk</span><strong>{_pct(row.get('utility_cvar'))}</strong></div><div class="row"><span>Ruin</span><strong class="{'bad' if float(row.get('ruin_probability',0))>.1 else 'good'}">{_pct(row.get('ruin_probability'))}</strong></div><div class="row"><span>Medyan nakit</span><strong>{_num(cash)}</strong></div><div class="row"><span>Medyan hizmet</span><strong>{_pct(service)}</strong></div><p class="muted">{'Sert sınırlar geçti' if row.get('eligible') else 'En az bir sert sınır aşılıyor'}</p></article>"""


def _tree(node: Mapping[str, Any], labels: Mapping[str, str]) -> str:
    if not node:
        return '<div class="panel muted">Bu koşuda anlamlı bir dal üretilemedi.</div>'
    conditions = node.get("conditions", [])
    condition = " · ".join(f"{item.get('label')} {item.get('op')} {_num(item.get('threshold'))}" for item in conditions[-1:]) or "Bütün dünyalar"
    winner = labels.get(str(node.get("best_strategy_id")), str(node.get("best_strategy_id", "—")))
    body = ""
    if node.get("children"):
        body = '<div class="branch">' + "".join(_tree(child, labels) for child in node["children"]) + "</div>"
    return f"""<details class="node" {'open' if int(node.get('depth',0))<1 else ''}><summary><span><strong>{_e(condition)}</strong><br><span class="muted">{int(node.get('worlds',0)):,} dünya · öne çıkan {_e(winner)}</span></span><span class="pill">{_pct(node.get('probability'))}</span></summary>{body}</details>"""


def _stress_rows(stress, labels) -> str:
    rows = []
    for profile in stress:
        for index, item in enumerate(profile.get("strategies", [])):
            rows.append(f"<tr><td>{_e(profile.get('label')) if index==0 else ''}</td><td>{_e(labels.get(str(item.get('strategy_id')),item.get('strategy_id')))}</td><td>{_pct(profile.get('probability'))}</td><td>{_pct(item.get('expected_utility'))}</td><td>{_pct(item.get('success_probability'))}</td></tr>")
    return "".join(rows)


def _e(value: Any) -> str:
    return html.escape(str(value if value is not None else "—"))


def _pct(value: Any) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "—"
    return "—" if not math.isfinite(number) else f"%{number*100:.1f}"


def _num(value: Any) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "—"
    if not math.isfinite(number):
        return "—"
    if abs(number) >= 1_000_000:
        return f"{number/1_000_000:.2f}M"
    if abs(number) >= 1_000:
        return f"{number/1_000:.1f}K"
    return f"{number:.2f}"
