import json
import unittest

from spx.decision import build_operations_case
from spx.engine import run_scenario
from spx.future_map import build_future_maps, decision_status, flatten_leaves
from spx.operations import OperationsEngine, run_intervention
from spx.schema import Scenario


class OperationsEngineTests(unittest.TestCase):
    def setUp(self):
        self.case = build_operations_case(None)

    def test_repeatable_and_probability_accounting(self):
        first = run_scenario(Scenario(self.case), worlds=40, seed=99)
        second = run_scenario(Scenario(self.case), worlds=40, seed=99)
        self.assertEqual(first.outcomes, second.outcomes)
        self.assertEqual(first.future_maps, second.future_maps)
        self.assertEqual(first.decision, second.decision)
        for drilldown in first.drilldowns.values():
            total = sum(item["contribution"] for item in drilldown["future_contributions"])
            self.assertAlmostEqual(total, drilldown["value"], places=10)

    def test_noop_counterfactual_is_exactly_zero(self):
        result = run_intervention(
            self.case,
            strategy_id="current_course",
            changes={},
            worlds=35,
            seed=123,
        )
        self.assertEqual(result["paired"]["p_tie"], 1.0)
        self.assertEqual(result["paired"]["mean_utility_delta"], 0.0)
        self.assertEqual(result["paired"]["p05_delta"], 0.0)
        self.assertEqual(result["paired"]["p95_delta"], 0.0)

    def test_preventive_maintenance_reduces_failures(self):
        case = json.loads(json.dumps(self.case))
        base = case["strategies"][0]
        reactive = json.loads(json.dumps(base))
        preventive = json.loads(json.dumps(base))
        reactive.update({"id": "reactive", "label": "Reaktif", "maintenance_interval_days": 900})
        preventive.update({"id": "preventive", "label": "Önleyici", "maintenance_interval_days": 55})
        reactive["parameters"]["maintenance_interval_days"] = 900
        preventive["parameters"]["maintenance_interval_days"] = 55
        case["strategies"] = [reactive, preventive]
        result = run_scenario(Scenario(case), worlds=90, seed=321)
        metrics = {row["strategy_id"]: row["metrics"] for row in result.summary["ranking"]}
        self.assertLess(metrics["preventive"]["failure_count"]["mean"], metrics["reactive"]["failure_count"]["mean"])

    def test_safety_stock_reduces_stockout(self):
        case = json.loads(json.dumps(self.case))
        base = case["strategies"][0]
        low = json.loads(json.dumps(base))
        high = json.loads(json.dumps(base))
        low.update({"id": "low_stock", "label": "Düşük stok", "safety_stock_days": 0})
        high.update({"id": "high_stock", "label": "Yüksek stok", "safety_stock_days": 28})
        low["parameters"]["safety_stock_days"] = 0
        high["parameters"]["safety_stock_days"] = 28
        case["strategies"] = [low, high]
        result = run_scenario(Scenario(case), worlds=90, seed=654)
        metrics = {row["strategy_id"]: row["metrics"] for row in result.summary["ranking"]}
        self.assertLessEqual(metrics["high_stock"]["stockout_months"]["mean"], metrics["low_stock"]["stockout_months"]["mean"])

    def test_future_tree_children_are_exhaustive(self):
        result = run_scenario(Scenario(self.case), worlds=60, seed=777)
        leading = result.decision.get("leading_strategy_id", result.summary["ranking"][0]["strategy_id"])
        trees = build_future_maps(result.outcomes, self.case["strategies"], leading, max_depth=3, min_mass=0.07)
        for tree in trees.values():
            self._assert_tree(tree["root"])
            leaves = flatten_leaves(tree["root"])
            all_worlds = [wid for leaf in leaves for wid in leaf["world_ids"]]
            self.assertEqual(len(all_worlds), len(set(all_worlds)))
            self.assertEqual(len(all_worlds), 60)

    def test_annual_demand_trend_accumulates_over_time(self):
        flat = json.loads(json.dumps(self.case))
        growth = json.loads(json.dumps(self.case))
        for raw, value in ((flat, 0.0), (growth, 0.12)):
            raw["uncertainty"]["annual_demand_trend"] = value
            row = next(item for item in raw["parameter_registry"] if item["id"] == "uncertainty.annual_demand_trend")
            row.update({"value": value, "low": value, "high": value})
        flat_world = OperationsEngine(Scenario(flat))._generate_world(0, 987)
        growth_world = OperationsEngine(Scenario(growth))._generate_world(0, 987)
        for month, (base_value, growth_value) in enumerate(zip(flat_world.paths["demand"], growth_world.paths["demand"]), start=1):
            self.assertAlmostEqual(growth_value / base_value, 1.12 ** (month / 12.0), places=10)

    def test_observed_status_really_narrows_epistemic_draws(self):
        assumed_case = build_operations_case(None)
        observed_case = build_operations_case({"data_status": {"uncertainty.failure_weibull_scale_days": "OBSERVED"}})
        assumed = OperationsEngine(Scenario(assumed_case))
        observed = OperationsEngine(Scenario(observed_case))
        assumed_draws = [assumed._generate_world(world_id, 51).parameters["failure_scale_days"] for world_id in range(80)]
        observed_draws = [observed._generate_world(world_id, 51).parameters["failure_scale_days"] for world_id in range(80)]
        assumed_span = max(assumed_draws) - min(assumed_draws)
        observed_span = max(observed_draws) - min(observed_draws)
        self.assertLess(observed_span, assumed_span * 0.25)

    def test_single_eligible_is_not_called_clear_superiority(self):
        outcomes = []
        for world_id in range(12):
            outcomes.extend(
                [
                    {"world_id": world_id, "strategy_id": "safe", "utility": 0.55 + world_id / 100},
                    {"world_id": world_id, "strategy_id": "risky", "utility": 0.70 - world_id / 100},
                ]
            )
        summary = {
            "ranking": [
                {"strategy_id": "safe", "eligible": True},
                {"strategy_id": "risky", "eligible": False},
            ]
        }
        status = decision_status(outcomes, summary, [{"id": "safe"}, {"id": "risky"}])
        self.assertEqual(status["code"], "single_eligible")
        self.assertIsNone(status["recommended_strategy_id"])

    def _assert_tree(self, node):
        self.assertGreater(node["worlds"], 0)
        children = node.get("children", [])
        if children:
            self.assertEqual(node["worlds"], sum(child["worlds"] for child in children))
            self.assertAlmostEqual(node["probability"], sum(child["probability"] for child in children), places=12)
            for child in children:
                self._assert_tree(child)


if __name__ == "__main__":
    unittest.main()
