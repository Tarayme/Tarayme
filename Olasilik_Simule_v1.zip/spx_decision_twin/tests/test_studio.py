from __future__ import annotations

import json
import math
import tempfile
import threading
import time
import unittest
from pathlib import Path
from urllib.request import Request, urlopen

from spx.studio import create_server, json_safe


ROOT = Path(__file__).resolve().parents[1]
SCENARIO = ROOT / "examples" / "operations_12m.json"


class StudioServerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.server = create_server(
            workspace=Path(self.temp.name),
            template_paths=[SCENARIO],
            host="127.0.0.1",
            port=0,
        )
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.temp.cleanup()

    def request(self, path: str, payload=None):
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        request = Request(
            f"http://127.0.0.1:{self.port}{path}",
            data=data,
            headers={"Content-Type": "application/json"} if data else {},
        )
        with urlopen(request, timeout=10) as response:
            return response.status, json.loads(response.read().decode("utf-8"))

    def test_bootstrap_validate_save_and_load(self) -> None:
        with urlopen(f"http://127.0.0.1:{self.port}/", timeout=10) as response:
            page = response.read().decode("utf-8")
            self.assertEqual(response.status, 200)
        self.assertIn("Şirketi değil, <em>kararı</em> simüle et", page)
        self.assertIn("YÜZDEDEN KAYNAĞA", page)

        with urlopen(f"http://127.0.0.1:{self.port}/static/app.js", timeout=10) as response:
            app_js = response.read().decode("utf-8")
        with urlopen(f"http://127.0.0.1:{self.port}/static/styles.css", timeout=10) as response:
            styles = response.read().decode("utf-8")
        self.assertIn("renderFuture", app_js)
        self.assertIn("@media (max-width: 380px)", styles)

        status, bootstrap = self.request("/api/bootstrap")
        self.assertEqual(status, 200)
        self.assertTrue(bootstrap["templates"][0]["id"].startswith("decision_"))
        self.assertEqual(bootstrap["company_builder"]["version"], "0.3.0")
        self.assertEqual(bootstrap["decision_builder"]["version"], "1.0.0")
        scenario = bootstrap["default_scenario"]
        self.assertEqual(scenario["meta"]["engine"], "operations_v1")

        decision_input = bootstrap["decision_builder"]["default_input"]
        decision_input["company"]["name"] = "API Karar Şirketi"
        status, decision = self.request("/api/decision/build", {"case": decision_input})
        self.assertEqual(status, 201)
        self.assertEqual(decision["scenario"]["meta"]["engine"], "operations_v1")
        self.assertEqual(decision["overview"]["models"], 7)
        self.assertTrue(any(item["code"] == "calibration.none" for item in decision["issues"]))

        status, built = self.request(
            "/api/company/build",
            {
                "profile": {
                    "company_name": "API Test Şirketi",
                    "sector": "service",
                    "monthly_revenue": 700000,
                    "monthly_cost": 520000,
                }
            },
        )
        self.assertEqual(status, 201)
        self.assertEqual(built["scenario"]["meta"]["builder_version"], "0.3.0")
        self.assertEqual(built["explanation"]["sector_label"], "Hizmet şirketi")

        status, validation = self.request("/api/validate", {"scenario": scenario})
        self.assertEqual(status, 200)
        self.assertTrue(validation["valid"])

        status, saved = self.request("/api/projects", {"name": "Fabrika Deneyi", "scenario": scenario})
        self.assertEqual(status, 201)
        self.assertEqual(saved["id"], "fabrika-deneyi")

        status, loaded = self.request(f"/api/projects/{saved['id']}")
        self.assertEqual(status, 200)
        self.assertEqual(loaded["meta"]["id"], scenario["meta"]["id"])
        self.assertEqual(loaded["meta"]["name"], "Fabrika Deneyi")

    def test_paired_counterfactual_endpoint(self) -> None:
        _, bootstrap = self.request("/api/bootstrap")
        scenario = bootstrap["default_scenario"]
        source = scenario["strategies"][0]
        status, result = self.request(
            "/api/decision/intervene",
            {
                "scenario": scenario,
                "strategy_id": source["id"],
                "changes": {"maintenance_interval_days": source["maintenance_interval_days"]},
                "worlds": 8,
                "seed": 41,
            },
        )
        self.assertEqual(status, 200)
        self.assertAlmostEqual(result["paired"]["mean_utility_delta"], 0.0)
        self.assertAlmostEqual(result["paired"]["p_tie"], 1.0)

    def test_async_run_and_download(self) -> None:
        _, bootstrap = self.request("/api/bootstrap")
        scenario = bootstrap["default_scenario"]
        status, created = self.request(
            "/api/run", {"scenario": scenario, "worlds": 4, "seed": 17}
        )
        self.assertEqual(status, 202)

        deadline = time.monotonic() + 12
        job = None
        while time.monotonic() < deadline:
            _, job = self.request(f"/api/jobs/{created['job_id']}")
            if job["status"] in {"completed", "failed"}:
                break
            time.sleep(0.05)
        self.assertIsNotNone(job)
        self.assertEqual(job["status"], "completed", job.get("error"))
        self.assertEqual(job["result"]["metadata"]["worlds"], 4)
        self.assertEqual(len(job["result"]["summary"]["ranking"]), 3)

        with urlopen(
            f"http://127.0.0.1:{self.port}/api/jobs/{created['job_id']}/download/report.html",
            timeout=10,
        ) as response:
            body = response.read()
            self.assertEqual(response.status, 200)
            self.assertIn(b"<!doctype html>", body.lower())

    def test_json_safe_replaces_nonfinite_values(self) -> None:
        value = json_safe({"a": math.nan, "b": [math.inf, 1.0]})
        self.assertEqual(value, {"a": None, "b": [None, 1.0]})


if __name__ == "__main__":
    unittest.main()
