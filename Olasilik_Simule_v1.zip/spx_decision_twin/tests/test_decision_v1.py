import json
import unittest

from spx.decision import (
    build_operations_case,
    case_overview,
    decision_builder_catalog,
    validate_decision_case,
)


class DecisionCaseTests(unittest.TestCase):
    def test_builder_is_decision_first_and_traceable(self):
        case = build_operations_case(None)
        self.assertEqual(case["meta"]["engine"], "operations_v1")
        self.assertTrue(case["decision"]["question"])
        self.assertGreaterEqual(len(case["strategies"]), 2)
        self.assertEqual([], [item for item in validate_decision_case(case) if item["level"] == "error"])
        evidence = {item["id"] for item in case["evidence"]}
        self.assertGreater(len(case["parameter_registry"]), 20)
        self.assertTrue(all(item["source_id"] in evidence for item in case["parameter_registry"]))
        overview = case_overview(case)
        self.assertEqual(overview["models"], 7)
        self.assertEqual(overview["status_counts"]["OBSERVED"], 0)

    def test_history_calibrates_only_supported_fields(self):
        rows = []
        for month in range(8):
            demand = 4000 + month * 80
            rows.append(
                {
                    "demand": demand,
                    "revenue": demand * 120,
                    "variable_cost": demand * 55,
                    "fixed_cost": 210000,
                    "absence_rate": 0.04 + month * 0.001,
                }
            )
        case = build_operations_case({"history": rows})
        source = case["meta"]["builder_input"]
        self.assertAlmostEqual(source["baseline"]["unit_price"], 120.0, places=6)
        self.assertAlmostEqual(source["baseline"]["variable_cost_per_unit"], 55.0, places=6)
        self.assertEqual(source["data_status"]["baseline.monthly_demand"], "OBSERVED")
        observed = [item for item in case["parameter_registry"] if item["status"] == "OBSERVED"]
        self.assertGreaterEqual(len(observed), 6)

    def test_catalog_is_honest_about_vertical_scope(self):
        catalog = decision_builder_catalog()
        deep = [item for item in catalog["decision_types"] if item["status"] == "deep"]
        future = [item for item in catalog["decision_types"] if item["status"] == "design_required"]
        self.assertEqual(["operations_v1"], [item["id"] for item in deep])
        self.assertTrue(future)

    def test_validation_rejects_hidden_parameter_mismatch(self):
        case = build_operations_case(None)
        case["strategies"][0]["maintenance_interval_days"] = 45
        issues = validate_decision_case(case)
        self.assertTrue(any(item["code"] == "strategy.parameters.mismatch" for item in issues))

    def test_validation_reports_malformed_values_without_crashing(self):
        case = build_operations_case(None)
        case["horizon"] = "not-a-number"
        case["baseline"]["monthly_demand"] = "unknown"
        case["objectives"][0]["weight"] = "many"
        issues = validate_decision_case(case)
        codes = {item["code"] for item in issues}
        self.assertIn("horizon", codes)
        self.assertIn("baseline.positive", codes)
        self.assertIn("objective.weight", codes)


if __name__ == "__main__":
    unittest.main()
