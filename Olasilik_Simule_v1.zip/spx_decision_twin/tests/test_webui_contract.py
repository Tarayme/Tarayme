import re
import unittest
from html.parser import HTMLParser
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "spx" / "webui"


class _IdParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
        self.inline_handlers = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if values.get("id"):
            self.ids.append(values["id"])
        self.inline_handlers.extend(key for key in values if key.startswith("on"))


class WebUiContractTests(unittest.TestCase):
    def setUp(self):
        self.html = (WEB / "index.html").read_text(encoding="utf-8")
        self.js = (WEB / "app.js").read_text(encoding="utf-8")
        self.css = (WEB / "styles.css").read_text(encoding="utf-8")

    def test_static_js_id_references_exist_and_ids_are_unique(self):
        parser = _IdParser()
        parser.feed(self.html)
        self.assertEqual(len(parser.ids), len(set(parser.ids)))
        static_refs = set(re.findall(r'\$\("#([A-Za-z0-9_-]+)"\)', self.js))
        self.assertEqual(set(), static_refs - set(parser.ids))
        self.assertEqual([], parser.inline_handlers)

    def test_mobile_and_accessibility_contract(self):
        self.assertIn("width=device-width", self.html)
        self.assertIn("@media (max-width: 380px)", self.css)
        self.assertIn("overflow-x: hidden", self.css)
        self.assertIn("prefers-reduced-motion", self.css)
        self.assertIn('aria-live="polite"', self.html)

    def test_decision_first_surfaces_are_present(self):
        for phrase in (
            "KARAR SÖZLEŞMESİ",
            "EŞLENMİŞ DÜNYALAR",
            "TIKLANABİLİR GELECEK AĞACI",
            "YÜZDEDEN KAYNAĞA",
            "KARŞI-OLGUSAL LABORATUVAR",
        ):
            self.assertIn(phrase, self.html)


if __name__ == "__main__":
    unittest.main()
