# Olasılık Simüle — Termux kurulumu

Bu paket, simülasyon düğmesi düzeltilmiş çalışan kaynak koddur.

## 1. Gerekli araçları kur

```bash
pkg update
pkg install nodejs-lts git coreutils
```

Node.js sürümünü kontrol et:

```bash
node -v
```

Sürüm `22.13.0` veya daha yeni olmalıdır.

## 2. ZIP'i aç ve klasöre gir

```bash
unzip Olasilik_Simule_v1.1_Calisan.zip
cd Olasilik_Simule
```

## 3. Bağımlılıkları kur

```bash
npm install
```

## 4. Uygulamayı çalıştır

```bash
npm run dev -- --host 0.0.0.0
```

Termux'un gösterdiği adrese tarayıcıdan gir. Genellikle:

```text
http://127.0.0.1:5173
```

Sunucuyu durdurmak için Termux'ta `Ctrl+C` kullan.

## Test

Simülasyon motorunu kontrol etmek için:

```bash
npm run test:simulation
```

Tüm uygulamayı derleyip test etmek için:

```bash
npm test
```

## Bu sürümde düzeltilenler

- “Simülasyonu çalıştır” düğmesi artık açıklamasız şekilde pasif kalmaz.
- Eksik veya hatalı veri varsa nedenini gösterir ve ilgili adıma götürür.
- Seçilmemiş planlardaki eski değerler simülasyonu engellemez.
- Monte Carlo motoru aynı tohumla tekrarlanabilir sonuç üretir.
