import Link from "next/link";

const steps = [
  {
    number: "01",
    title: "Kararı seç",
    text: "Önce ‘neyi öğrenmek istiyorum?’ sorusunu netleştir. Örneğin: Yeni makine mi, ek vardiya mı?",
  },
  {
    number: "02",
    title: "Şirketi tarif et",
    text: "Kapasite, talep, maliyet, nakit ve riskleri sade alanlara gir. Teknik terim bilmen gerekmez.",
  },
  {
    number: "03",
    title: "Seçenekleri karşılaştır",
    text: "Mevcut düzeni; kapasite yatırımı, bakım, iş gücü ve dış kaynak alternatifleriyle aynı koşullarda test et.",
  },
  {
    number: "04",
    title: "Sonucun nedenini gör",
    text: "Sadece bir yüzde değil; hangi riskin sonucu değiştirdiğini, kötü senaryoyu ve yönetim sınırlarını incele.",
  },
];

const exampleRows = [
  { label: "Dış kaynak tamponu", value: "₺13,6 Mn", risk: "%1 teslimat · %8 nakit", tone: "success" },
  { label: "Mevcut düzen", value: "₺14,1 Mn", risk: "%27 teslimat riski", tone: "danger" },
  { label: "Kapasite yatırımı", value: "₺6,8 Mn", risk: "%100 nakit riski", tone: "danger" },
];

export default function Home() {
  return (
    <main>
      <header className="site-header">
        <div className="shell header-inner">
          <Link className="brand" href="/" aria-label="Olasılık Simüle ana sayfa">
            <span className="brand-mark" aria-hidden="true">
              <span />
            </span>
            <span>
              <strong>Olasılık</strong>
              <small>Simüle</small>
            </span>
          </Link>

          <nav className="main-nav" aria-label="Ana menü">
            <a href="#nasil-calisir">Nasıl çalışır?</a>
            <Link href="/ornek-senaryo">Örnek senaryo</Link>
            <Link href="/rehber">Rehber</Link>
            <Link href="/metodoloji">Metodoloji</Link>
          </nav>

          <Link className="button button-small button-ghost" href="/model-kur">
            Model kur
          </Link>
        </div>
      </header>

      <section className="hero shell" id="basla">
        <div className="hero-copy">
          <div className="eyebrow">
            <span className="eyebrow-dot" />
            Karar simülasyonu · Monte Carlo
          </div>
          <h1>
            Karar vermeden önce,
            <span> binlerce olası geleceği deneyin.</span>
          </h1>
          <p className="hero-lead">
            Şirketinizin kapasitesini, talebini, maliyetini ve risklerini anlaşılır
            adımlarla tanımlayın. Sistem seçeneklerinizi aynı koşullarda test etsin;
            hangi kararın neden daha dayanıklı olduğunu göstersin.
          </p>
          <div className="hero-actions">
            <Link className="button button-primary" href="/model-kur">
              Kendi modelimi kur
              <span aria-hidden="true">→</span>
            </Link>
            <a className="button button-secondary" href="#ornek">
              Örnek sonucu incele
            </a>
          </div>
          <div className="hero-proof" aria-label="Ürün özellikleri">
            <span>Teknik bilgi gerekmez</span>
            <span>Her alan açıklamalı</span>
            <span>Sonuçlar nedenleriyle birlikte</span>
          </div>
        </div>

        <aside className="hero-panel" aria-label="Kullanım özeti">
          <div className="panel-topline">
            <span>İlk simülasyonun</span>
            <span className="status-pill">6 adım</span>
          </div>
          <h2>Bir şirketi nasıl simüle edeceğim?</h2>
          <ol className="quick-steps">
            <li>
              <span>1</span>
              <div>
                <strong>Şirket türünü seç</strong>
                <small>Üretim, hizmet veya depo/lojistik</small>
              </div>
            </li>
            <li>
              <span>2</span>
              <div>
                <strong>Gerçek çalışma düzenini gir</strong>
                <small>Aylık talep, kapasite, gider ve başlangıç nakdi</small>
              </div>
            </li>
            <li>
              <span>3</span>
              <div>
                <strong>Belirsizlikleri tarif et</strong>
                <small>Arıza, devamsızlık, fire ve tedarik gecikmesi</small>
              </div>
            </li>
            <li>
              <span>4</span>
              <div>
                <strong>Karar seçeneklerini çalıştır</strong>
                <small>5.000 gelecek üret, riskleri ve eşikleri karşılaştır</small>
              </div>
            </li>
          </ol>
          <div className="panel-note">
            <span aria-hidden="true">i</span>
            <p>
              Tüm şirketi tek seferde modellemek yerine önce tek, pahalı bir kararı
              seçmek daha güvenilir sonuç verir.
            </p>
          </div>
        </aside>
      </section>

      <section className="section shell" id="nasil-calisir">
        <div className="section-heading">
          <div>
            <p className="kicker">Karmaşıklığı biz taşıyoruz</p>
            <h2>Sen şirketini anlat, sistem modeli kursun.</h2>
          </div>
          <p>
            Ekranda önce iş dilini görürsün. “Weibull”, “dağılım” veya “persentil”
            gibi teknik kavramlar gerektiği yerde kısa bir açıklamayla açılır.
          </p>
        </div>

        <div className="step-grid">
          {steps.map((step) => (
            <article className="step-card" key={step.number}>
              <span className="step-number">{step.number}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section section-contrast" id="ornek">
        <div className="shell example-layout">
          <div className="example-copy">
            <p className="kicker">Örnek karar</p>
            <h2>“Talep artarsa yeni makine almak mantıklı mı?”</h2>
            <p>
              Sistem tek bir satış tahmini yapmaz. Talep, makine arızası,
              devamsızlık, fire, maliyet ve tedarik gecikmesini birlikte değiştirir;
              her stratejiyi aynı olası dünyalarda sınar.
            </p>
            <ul className="check-list">
              <li>İyi, normal ve kötü gelecek aileleri</li>
              <li>Beklenen net sonuç ile kötü durum sonucu</li>
              <li>Nakit sıkışması ve teslimat riski</li>
              <li>Kararı değiştiren en önemli 3 etken</li>
            </ul>
          </div>

          <div className="result-card" aria-label="Örnek simülasyon sonucu">
            <div className="result-card-header">
              <div>
                <span>12 aylık sonuç</span>
                <strong>Strateji karşılaştırması</strong>
              </div>
              <span className="sample-label">Örnek değerler</span>
            </div>
            <div className="result-summary">
              <div>
                <span>En dayanıklı seçenek</span>
                <strong>Esnek dış kaynak tamponu</strong>
              </div>
              <div className="confidence-ring" aria-label="Karar skoru 95 / 100">
                <span>95</span>
                <small>/100</small>
              </div>
            </div>
            <div className="comparison-list">
              {exampleRows.map((row) => (
                <div className="comparison-row" key={row.label}>
                  <div>
                    <span className={`tone-dot ${row.tone}`} />
                    <strong>{row.label}</strong>
                  </div>
                  <span>{row.value}</span>
                  <small>{row.risk}</small>
                </div>
              ))}
            </div>
            <div className="why-box">
              <span className="why-icon" aria-hidden="true">↳</span>
              <div>
                <strong>Neden?</strong>
                <p>
                  Mevcut düzen daha çok kâr üretse de teslimat sınırını sık aşıyor.
                  Yatırım teslimatı koruyor fakat peşin ödeme ve 30 günlük tahsilat vadesi
                  nakdi bozuyor. Esnek tampon iki yönetim sınırını birlikte geçiyor.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section shell" id="guven">
        <div className="truth-card">
          <div className="truth-mark" aria-hidden="true">≠</div>
          <div>
            <p className="kicker">Net sınır</p>
            <h2>Bu sistem geleceği bilmez; kararın dayanıklılığını test eder.</h2>
          </div>
          <p>
            Çıktılar, girdiğiniz veriler ve varsayımlar kadar güvenilirdir. Bu yüzden
            her sonuçta varsayımlar, veri güveni, kullanılan yöntem ve hassasiyet
            düzeyi açıkça gösterilir. Amaç sahte kesinlik değil, bilinçli karar vermektir.
          </p>
        </div>
      </section>

      <footer className="site-footer">
        <div className="shell footer-inner">
          <div className="brand brand-footer">
            <span className="brand-mark" aria-hidden="true"><span /></span>
            <span><strong>Olasılık</strong><small>Simüle</small></span>
          </div>
          <p>Kararları tek tahminle değil, olası geleceklerle sınayın.</p>
        </div>
      </footer>
    </main>
  );
}
