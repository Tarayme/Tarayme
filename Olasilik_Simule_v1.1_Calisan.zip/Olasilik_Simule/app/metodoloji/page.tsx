import Link from "next/link";

import { AppFooter, AppHeader } from "@/components/app-header";

const layers = [
  ["01", "Karar katmanı", "Soru, alternatifler, hedefler, kısıtlar ve zaman ufku."],
  ["02", "İşletme modeli", "Talep, kapasite, çalışan, makine, kalite, tedarik, tahsilat ve nakit ilişkileri."],
  ["03", "Belirsizlik katmanı", "Her risk için tek sayı değil, olay veya dağılım örnekleri."],
  ["04", "Dinamik akış", "Backlog, fazla mesai, yorgunluk ve kalite gibi aydan aya taşınan durumlar."],
  ["05", "Strateji müdahalesi", "Bakım, eğitim veya dış kaynağın maliyet ve mekanizma üzerindeki etkisi."],
  ["06", "Karar motoru", "Net karar sonucu, kötü kuyruk, nakit ve teslimat hedeflerinin birlikte değerlendirilmesi."],
  ["07", "Açıklama", "Yüzde → gelecek ailesi → etken → alt model → girdi zinciri."],
  ["08", "Doğrulama", "Mantık testi, geçmiş dönem replay, kalibrasyon ve karar etkisi."],
];

const algorithmSteps = [
  ["1", "Modeli doğrula", "Birimler, pozitif değerler, olasılık aralıkları ve aşırı kapasite kullanımı kontrol edilir."],
  ["2", "Ortak bir dünya üret", "Her ay için talep, maliyet, devamsızlık, fire, tedarik ve makine arıza çekilişleri oluşturulur; ilişkili riskler ortak stres etkenlerini paylaşır."],
  ["3", "Her stratejiyi aynı dünyada çalıştır", "Dış koşullar sabit kalır; yalnız stratejinin maliyet ve müdahale mekanizması değişir."],
  ["4", "Ayı operasyonel olarak kapat", "Kapasite kayıpları, iyi çıktı, fazla mesai, dış kaynak, backlog ve gecikme hesaplanır."],
  ["5", "Net sonucu ve nakdi ayrı güncelle", "Satıştan operasyon ve strateji harcamaları çıkarılarak net karar sonucu bulunur; satış nakde kullanıcının tahsilat vadesine göre girer."],
  ["6", "Ufku tamamla", "Aydan aya backlog ve yorgunluk taşınır; minimum nakit ve SLA ihlalleri kaydedilir."],
  ["7", "5.000 dünyayı özetle", "P10/P50/P90, CVaR10, ihlal olasılıkları, gelecek aileleri ve duyarlılıklar çıkarılır."],
  ["8", "Kısıtla ve puanla", "Önce nakit ve SLA sınırını geçen planlar ayrılır; sonra net sonuç, likidite, teslimat ve dayanıklılık alt puanları ağırlıklandırılır."],
];

const pseudoCode = [
  "backlog = 0",
  "cash = başlangıç_nakdi",
  "",
  "her ay için:",
  "  talep = trend × mevsim × şok",
  "  kapasite = gözlenen_normal_kapasite",
  "    × devamsızlık_sapması",
  "    × arıza_sapması",
  "    × tedarik_sapması",
  "",
  "  iyi_çıktı = kapasite × kalite_sapması",
  "  tamamlanan = min(talep + backlog,",
  "                    iyi_çıktı + tampon)",
  "  backlog = talep + backlog - tamamlanan",
  "",
  "  net_sonuç += satış - tüm_harcamalar",
  "  nakit += vadeli_tahsilat - tüm_maliyetler",
  "  kısıtları_kaydet()",
  "",
  "sonuçları_özetle()",
].join("\n");

export default function MethodologyPage() {
  return (
    <main className="method-page">
      <AppHeader active="method" />

      <section className="method-hero shell">
        <div>
          <p className="kicker">Model 1.0 · Genel operasyon karar motoru</p>
          <h1>Monte Carlo motorun omurgasıdır; şirketin kendisi değildir.</h1>
          <p>Monte Carlo belirsizliği taşır. Talebin kapasiteye, arızanın backloga, backlogun gecikme maliyetine ve tümünün nakde nasıl geçtiğini ise işletme mekanizması belirler.</p>
          <div className="method-hero-actions"><Link className="button button-primary" href="/model-kur">Bu modelle simülasyon kur →</Link><a className="button button-secondary" href="#algoritma">Algoritmayı incele</a></div>
        </div>
        <aside className="method-principles">
          <span>Değişmez ilkeler</span>
          <ul>
            <li><strong>Dağılım önce</strong><small>Alt modeller tek sayı değil belirsizlik taşır.</small></li>
            <li><strong>Ortak dünyalar</strong><small>Stratejiler aynı rastgele koşullarda sınanır.</small></li>
            <li><strong>Dayanıklılık önce</strong><small>Ortalama kadar kötü kuyruk ve kısıtlar da önemlidir.</small></li>
            <li><strong>Açıklama zinciri</strong><small>Her yüzde etkenine ve girdisine kadar açılır.</small></li>
            <li><strong>Kalibrasyondan önce kesinlik yok</strong><small>İlk sonuç karşılaştırmalı ön analizdir.</small></li>
          </ul>
        </aside>
      </section>

      <section className="method-section method-section-dark">
        <div className="shell">
          <div className="method-section-title"><p className="kicker">Sistem resmi</p><h2>Sekiz katman, tek karar zinciri</h2><p>Karmaşık şirket modeli ekranda sade görünür; fakat her katmanın görevi birbirinden ayrıdır.</p></div>
          <div className="layer-grid">{layers.map(([number, title, text]) => <article key={number}><span>{number}</span><h3>{title}</h3><p>{text}</p></article>)}</div>
        </div>
      </section>

      <section className="method-section shell" id="algoritma">
        <div className="method-section-title"><p className="kicker">Çalıştırma sırası</p><h2>Bir simülasyon koşusunda tam olarak ne oluyor?</h2><p>Aşağıdaki süreç her olası dünya için tekrarlanır. Sonra tüm dünyalar tek raporda birleştirilir.</p></div>
        <div className="algorithm-layout">
          <ol className="algorithm-steps">{algorithmSteps.map(([number, title, text]) => <li key={number}><span>{number}</span><div><h3>{title}</h3><p>{text}</p></div></li>)}</ol>
          <aside className="pseudo-card">
            <div className="pseudo-top"><span>Basitleştirilmiş akış</span><strong>Her dünya × her strateji</strong></div>
            <pre>{pseudoCode}</pre>
            <div className="pseudo-note"><span>i</span><p>Gerçek kod; ortak rastgele sayılar, orta düzey ortak makro/operasyon şokları, lognormal örnekler, makine bazlı arıza olayları, yorgunluk geri beslemesi ve kuyruk metrikleri içerir. Bu bağımlılıklar gerçek şirket verisiyle henüz kalibre edilmemiş başlangıç yapısıdır.</p></div>
          </aside>
        </div>
      </section>

      <section className="method-section method-section-soft">
        <div className="shell">
          <div className="method-section-title"><p className="kicker">Alt modeller</p><h2>Her risk aynı matematikle hesaplanmaz</h2><p>Genel motor basit ama mekanizmaya uygun model ailelerini aynı akışta birleştirir.</p></div>
          <div className="submodel-table">
            <div className="submodel-head"><span>Problem</span><span>Bu sürüm</span><span>Gerçek pilotta gelişmiş yöntem</span><span>Downstream çıktı</span></div>
            {[
              ["Talep", "Trend + mevsim + lognormal şok", "State-space / rejim / causal demand", "Aylık sipariş dağılımı"],
              ["Makine arızası", "Makine-ay Bernoulli + onarım süresi", "Weibull / Cox / survival", "Duruş ve kapasite kaybı"],
              ["Devamsızlık", "Mevsim + ekip şoku + örnekleme hatası", "Hiyerarşik lojistik / count model", "Vardiya kapasitesi"],
              ["Fire / kalite", "Lognormal oran + yorgunluk etkisi", "GLM / Bayes + süreç değişkenleri", "İyi çıktı"],
              ["Tedarik", "Aylık olay + gecikme süresi", "Supplier survival + ortak bölge şoku", "Malzeme kullanılabilirliği"],
              ["Operasyon", "Aylık stok-akış ve backlog", "Discrete-event simulation", "Throughput, kuyruk, SLA"],
              ["Finans", "Net karar sonucu + vadeli tahsilatlı nakit akışı", "Vergi/amortisman, alacak-borç yaşlandırma, finansman", "Likidite / net sonuç dağılımı"],
            ].map((row) => <div className="submodel-row" key={row[0]}>{row.map((cell) => <span key={cell}>{cell}</span>)}</div>)}
          </div>
        </div>
      </section>

      <section className="method-section shell">
        <div className="method-section-title"><p className="kicker">Strateji karşılaştırması</p><h2>Neden ortak rastgele dünyalar kullanıyoruz?</h2></div>
        <div className="common-worlds">
          <div className="world-source"><span>Olası dünya #1842</span><strong>Talep +%18 · maliyet +%7 · 1 arıza · tedarik normal</strong></div>
          <div className="world-branches">
            <article><span>A</span><div><strong>Mevcut düzen</strong><small>Aynı dış şoklar</small></div><em>+₺2,1 Mn</em></article>
            <article><span>B</span><div><strong>Kapasite yatırımı</strong><small>Aynı dış şoklar; devreye alma sonrası kalıcı artış</small></div><em>+₺1,7 Mn</em></article>
            <article><span>C</span><div><strong>Bakım planı</strong><small>Aynı dış şoklar; arıza mekanizması değişir</small></div><em>+₺2,8 Mn</em></article>
            <article><span>D</span><div><strong>İş gücü planı</strong><small>Aynı dış şoklar; kapasite ve fire değişir</small></div><em>+₺2,5 Mn</em></article>
            <article><span>E</span><div><strong>Dış kaynak</strong><small>Aynı dış şoklar; yoğunlukta tampon açılır</small></div><em>+₺3,0 Mn</em></article>
          </div>
          <p>Sonuç farkı farklı talep çekilişinden değil, aynı dünya içinde karar mekanizmasının değişmesinden doğar.</p>
        </div>
      </section>

      <section className="method-section method-section-dark">
        <div className="shell">
          <div className="method-section-title"><p className="kicker">Sonuç matematiği</p><h2>Tek ortalama yerine altı ayrı lens</h2></div>
          <div className="lens-grid">
            {[
              ["Beklenen değer", "Tüm koşuların ortalaması", "Genel finansal yön"],
              ["P10 / P50 / P90", "Dağılımın üç eşiği", "Kötü, ortanca ve iyi dünya aralığı"],
              ["CVaR10", "En kötü %10’un ortalaması", "Kuyruk riskinin şiddeti"],
              ["Kısıt ihlali", "Nakit veya SLA eşiğini aşan koşu oranı", "Yönetim sınırlarının güvenliği"],
              ["Gelecek ailesi", "Benzer dünya örüntülerinin grubu", "Toplam yüzdenin iç yapısı"],
              ["Duyarlılık", "Girdi ile sonuç arasındaki korelasyon payı", "Hangi verinin önce iyileştirileceği"],
            ].map(([title, formula, purpose]) => <article key={title}><span>{title}</span><strong>{formula}</strong><p>{purpose}</p></article>)}
          </div>
          <div className="causal-warning"><span>≠</span><div><h3>Duyarlılık, nedensellik değildir</h3><p>Bu sürümde sürücü önemleri koşular içindeki Pearson korelasyonundan türetilir ve mutlak değere göre normalize edilir. Bir değişkene müdahale edilince sonucun kesin değişeceğini kanıtlamaz.</p></div></div>
        </div>
      </section>

      <section className="method-section shell">
        <div className="method-section-title"><p className="kicker">Test ve model riski</p><h2>Motor bugün neyle sınanıyor?</h2><p>Her sürümde algoritma testleri ile gerçek model doğrulaması ayrı tutulur.</p></div>
        <div className="test-grid">
          <article><span>01</span><h3>Tekrarlanabilirlik</h3><p>Aynı model ve tohumun aynı dağılımı üretmesi.</p><strong>Otomatik test</strong></article>
          <article><span>02</span><h3>Matematiksel invariant</h3><p>Olasılıkların 0-1, aile toplamlarının %100, P10 ≤ P50 ≤ P90 kalması.</p><strong>Otomatik test</strong></article>
          <article><span>03</span><h3>Müdahale yönü</h3><p>Yatırımın kapasiteyi, bakımın arıza sayısını, iş gücü ve tamponun SLA ihlalini beklenen yönde değiştirmesi.</p><strong>Sanity test</strong></article>
          <article><span>04</span><h3>Belirsizlik tepkisi</h3><p>Talep oynaklığı yükseldiğinde sonuç dağılımının genişlemesi.</p><strong>Sensitivity test</strong></article>
          <article><span>05</span><h3>Girdi doğrulama</h3><p>Sıfır talep, negatif maliyet veya aşırı kapasite kullanımının açıkça işaretlenmesi.</p><strong>Guardrail</strong></article>
          <article className="pending"><span>06</span><h3>Gerçek kalibrasyon</h3><p>Şirkete ait geçmiş dönem replay ve olasılık kalibrasyonu.</p><strong>Müşteri verisi gerekir</strong></article>
        </div>
      </section>

      <section className="method-section method-roadmap">
        <div className="shell roadmap-card">
          <div><p className="kicker">Doğru büyüme sırası</p><h2>Genel model → sektör modeli → yaşayan karar ikizi</h2><p>Sonraki sürüm her şeyi aynı anda eklemek değil, yalnız kararı değiştiren alt modeli derinleştirmektir.</p></div>
          <ol><li><span>Şimdi</span><strong>Genel operasyon Monte Carlo</strong><small>Kullanıcı girdisi, beş strateji, açıklanabilir sonuç</small></li><li><span>Sonra</span><strong>Üretim / hizmet dikey motoru</strong><small>Event log, survival, kuyruk, geçmiş replay</small></li><li><span>Daha sonra</span><strong>Decision Twin</strong><small>Canlı veri, incremental recompute, model registry</small></li></ol>
          <Link className="button button-primary" href="/rehber#dogrulama">Doğrulama yolunu gör →</Link>
        </div>
      </section>

      <AppFooter />
    </main>
  );
}
