import Link from "next/link";

import { AppFooter, AppHeader } from "@/components/app-header";

const guideSteps = [
  {
    number: "01",
    title: "Kararı daralt",
    time: "2 dakika",
    text: "‘Şirketim ne olur?’ yerine iki veya daha fazla gerçek eylemi içeren tek bir karar sorusu yaz.",
    good: "Yeni makine mi alalım, yoksa yoğun dönemde dış kaynak mı kullanalım?",
    bad: "Gelecekte başarılı olacak mıyız?",
  },
  {
    number: "02",
    title: "Normal ayı kur",
    time: "3 dakika",
    text: "Son 12-24 aydaki normal talebi ve gerçekten tamamlanan ortalama iyi kapasiteyi; çalışan, kritik kaynak ve başlangıç ayıyla birlikte gir.",
    good: "Son 12 ay ortalaması: 10.000 sipariş, 11.000 tamamlanan iyi kapasite.",
    bad: "Teorik tam kapasite: hiç durmadan 18.000 sipariş.",
  },
  {
    number: "03",
    title: "Parayı bağla",
    time: "3 dakika",
    text: "Tamamlanan işin gelirini ve değişken maliyetini, aylık sabit gideri, tahsilat vadesini ve güvenli nakit tabanını tanımla.",
    good: "Birim gelir 850 TL, değişken maliyet 470 TL, sabit gider 2,4 Mn TL, tahsilat 30 gün.",
    bad: "Sadece yıllık ciro girmek; kapasite ile para arasındaki bağı kaybetmek.",
  },
  {
    number: "04",
    title: "Belirsizlikleri tarif et",
    time: "5 dakika",
    text: "Talep oynaklığı, arıza, devamsızlık, fire, tedarik ve maliyet için yaklaşık oranlarla başla.",
    good: "Aylık talep oynaklığı %16; makine başına aylık arıza olasılığı %7,5.",
    bad: "Bilmiyorum diye riski %0 yazmak.",
  },
  {
    number: "05",
    title: "Müdahaleleri dürüstçe fiyatla",
    time: "4 dakika",
    text: "Bakım, eğitim veya dış kaynağın hem maliyetini hem beklenen etkisini gir. Etkiyi abartma.",
    good: "Bakım: 600 Bin ilk yatırım + 90 Bin/ay; arıza riski -%42 varsayımı.",
    bad: "Planın maliyeti sıfır, etkisi %100.",
  },
  {
    number: "06",
    title: "Sonucu katman katman oku",
    time: "5 dakika",
    text: "Önce kısıt ihlallerine, sonra kötü kuyruğa, ardından ortalamaya ve neden zincirine bak.",
    good: "Nakit riski %8, SLA riski %12, CVaR10 -1,1 Mn, beklenen +4,8 Mn.",
    bad: "Yalnız en yüksek beklenen net sonucu seçmek.",
  },
];

const commonMistakes = [
  ["Tüm şirketi bir anda modellemek", "İlk modelde tek karar koridoru seç: örneğin talep → kapasite → teslimat → nakit."],
  ["Kesin sayı girdiğini sanmak", "Risk alanları birer dağılım varsayımıdır. Sonuçlar da tek sayı değil aralık olarak okunur."],
  ["Aynı şeyi iki kez saymak", "Duruş maliyetini hem kapasite kaybına hem gelir kaybına hem de ayrı dev cezaya yazarken çifte sayımı kontrol et."],
  ["Korelasyonu neden sanmak", "Bir etken sonuçla birlikte hareket edebilir; bu tek başına müdahale edilince sonucu değiştireceğini kanıtlamaz."],
  ["Kötü olasılığı silmek", "Düşük olasılıklı fakat yüksek etkili dünyalar özellikle korunmalıdır."],
  ["Kalibrasyonsuz yüzdeyi gerçek tahmin saymak", "İlk koşu karşılaştırmalı ön analizdir. Gerçek güven için geçmiş dönem replay gerekir."],
];

export default function GuidePage() {
  return (
    <main className="guide-page">
      <AppHeader active="guide" />

      <section className="guide-hero shell">
        <div>
          <p className="kicker">Adım adım kullanım kılavuzu</p>
          <h1>Bir şirketi simüle etmeye nereden başlayacağım?</h1>
          <p>
            Teknik terimleri bilmeden ilk karar modelini kurabilirsin. Aşağıdaki sıra,
            neyi gireceğini, neyi henüz girmemen gerektiğini ve sonucu nasıl okuyacağını gösterir.
          </p>
          <div className="guide-hero-actions">
            <Link className="button button-primary" href="/model-kur">Rehber eşliğinde model kur →</Link>
            <Link className="button button-secondary" href="/ornek-senaryo">Önce tamamlanmış örneği gör</Link>
          </div>
        </div>
        <aside className="guide-map">
          <div className="guide-map-top"><span>İlk model</span><strong>Yaklaşık 20 dakika</strong></div>
          <ol>
            {guideSteps.map((item) => (
              <li key={item.number}><span>{item.number}</span><div><strong>{item.title}</strong><small>{item.time}</small></div></li>
            ))}
          </ol>
        </aside>
      </section>

      <div className="guide-layout shell">
        <aside className="guide-toc">
          <span>Bu sayfada</span>
          <a href="#hizli-baslangic">Hızlı başlangıç</a>
          <a href="#veri-hazirligi">Veriyi hazırlama</a>
          <a href="#sonuc-okuma">Sonucu okuma sırası</a>
          <a href="#dogrulama">Modeli doğrulama</a>
          <a href="#hatalar">Yaygın hatalar</a>
          <a href="#sozluk">Kısa sözlük</a>
          <div><strong>Takıldın mı?</strong><p>Örnek şirket verilerini tek tıkla yükleyip her alanın sonuçtaki yerini görebilirsin.</p><Link href="/ornek-senaryo">Örneği aç →</Link></div>
        </aside>

        <article className="guide-content">
          <section id="hizli-baslangic">
            <div className="guide-section-title"><p className="kicker">Bölüm 1</p><h2>Hızlı başlangıç: altı adım</h2><p>Bu sırayı bozma. Para veya riskten önce karar ve operasyon omurgası kurulmalıdır.</p></div>
            <div className="guide-step-list">
              {guideSteps.map((item) => (
                <article key={item.number}>
                  <div className="guide-step-number"><strong>{item.number}</strong><span>{item.time}</span></div>
                  <div><h3>{item.title}</h3><p>{item.text}</p><div className="good-bad"><div className="good"><span>İyi örnek</span><p>{item.good}</p></div><div className="bad"><span>Zayıf örnek</span><p>{item.bad}</p></div></div></div>
                </article>
              ))}
            </div>
          </section>

          <section id="veri-hazirligi">
            <div className="guide-section-title"><p className="kicker">Bölüm 2</p><h2>Veriyi hazırlarken önce birimleri eşitle</h2><p>Modelde en sık hata, doğru sayının yanlış zaman veya ölçü birimiyle girilmesidir.</p></div>
            <div className="data-table">
              <div className="data-table-head"><span>İstenen alan</span><span>Tercih edilen kaynak</span><span>Hazırlama biçimi</span></div>
              {[
                ["Aylık talep", "Sipariş / satış kayıtları", "Son 12-24 ay; iptal ve iadeleri ayır"],
                ["Gerçek kapasite", "Üretim / hizmet kayıtları", "Teorik değil, iyi tamamlanan aylık ortalama"],
                ["Arıza", "Bakım emirleri / duruş logları", "Makine, tarih, süre ve doğrudan maliyet"],
                ["Devamsızlık", "Vardiya / puantaj", "Kişi adı yerine ekip-gün oranı yeterli"],
                ["Fire / hata", "Kalite kayıtları", "Ürün ailesi veya süreç bazında oran"],
                ["Tedarik gecikmesi", "Satın alma / teslim alma", "Söz verilen ve gerçekleşen tarih farkı"],
                ["Tahsilat", "Fatura / cari hesap", "Satış ile nakde giriş arasındaki ortalama gün"],
                ["Nakit", "Finans / muhasebe", "Kullanılabilir nakit ve yönetim güvenlik eşiği"],
              ].map((row) => <div className="data-table-row" key={row[0]}>{row.map((cell) => <span key={cell}>{cell}</span>)}</div>)}
            </div>
            <div className="guide-callout"><span>!</span><div><strong>Hassas çalışan verisi kullanma</strong><p>İlk modelde kişi bazlı sağlık, medeni durum veya özel nitelikli veri gerekmez. Ekip, vardiya veya rol bazında toplulaştırılmış devamsızlık ve kapasite oranı kullan.</p></div></div>
          </section>

          <section id="sonuc-okuma">
            <div className="guide-section-title"><p className="kicker">Bölüm 3</p><h2>Sonuç ekranını doğru sırayla oku</h2><p>En yüksek puanı görüp çıkmak yerine aşağıdaki beş soruyu sırayla cevapla.</p></div>
            <ol className="reading-order">
              <li><span>1</span><div><h3>Hard constraint bozuluyor mu?</h3><p>Nakit veya teslimat sınırı kabul edilemeyecek sıklıkta aşılıyorsa yüksek ortalama net sonuç yeterli değildir.</p></div><strong>Önce ele</strong></li>
              <li><span>2</span><div><h3>Kötü %10 dünyada ne oluyor?</h3><p>P10 ve CVaR10, ortalamanın sakladığı kötü kuyruğu açar.</p></div><strong>Kuyruğa bak</strong></li>
              <li><span>3</span><div><h3>Ortanca ile ortalama ayrılıyor mu?</h3><p>Büyük fark, birkaç uç dünyanın ortalamayı çektiğini gösterebilir.</p></div><strong>Çarpıklığı gör</strong></li>
              <li><span>4</span><div><h3>Hangi gelecek ailesi riski üretiyor?</h3><p>Nakit, kapasite veya tedarik ailelerinden hangisi toplam riski taşıyor?</p></div><strong>Yüzdeyi aç</strong></li>
              <li><span>5</span><div><h3>Kararı değiştiren etken hangisi?</h3><p>En duyarlı girdiyi gerçek veriyle doğrula; gerekirse o alan için ayrıntılı alt model kur.</p></div><strong>Veri topla</strong></li>
            </ol>
          </section>

          <section id="dogrulama">
            <div className="guide-section-title"><p className="kicker">Bölüm 4</p><h2>İlk koşudan gerçek güvene: doğrulama merdiveni</h2><p>Model ayrıntı ekleyerek değil, geçmiş ve gerçek sonuçlara karşı sınanarak güven kazanır.</p></div>
            <div className="validation-ladder">
              <article><span>L0</span><div><strong>Mantık kontrolü</strong><p>Talep artınca backlog, arıza artınca kapasite kaybı beklenen yönde mi?</p></div><small>İlk gün</small></article>
              <article><span>L1</span><div><strong>Uç koşul testi</strong><p>Arıza %0 veya kapasite çok yüksek olduğunda model mantıklı sınırda mı?</p></div><small>İlk hafta</small></article>
              <article><span>L2</span><div><strong>Historical replay</strong><p>Geçmişteki zor dönemin başlangıç bilgisiyle gerçekleşen sonucu yeniden üretebiliyor mu?</p></div><small>6-24 ay veri</small></article>
              <article><span>L3</span><div><strong>Olasılık kalibrasyonu</strong><p>Modelin %20 dediği olaylar uzun vadede yaklaşık %20 sıklıkla oluyor mu?</p></div><small>Brier / log loss</small></article>
              <article><span>L4</span><div><strong>Karar doğrulaması</strong><p>Önerilen politika kontrollü pilotta gerçekten daha iyi sonuç yarattı mı?</p></div><small>A/B veya aşamalı pilot</small></article>
            </div>
          </section>

          <section id="hatalar">
            <div className="guide-section-title"><p className="kicker">Bölüm 5</p><h2>En sık yapılan altı hata</h2></div>
            <div className="mistake-grid">
              {commonMistakes.map(([title, fix], index) => <article key={title}><span>{String(index + 1).padStart(2, "0")}</span><h3>{title}</h3><p>{fix}</p></article>)}
            </div>
          </section>

          <section id="sozluk">
            <div className="guide-section-title"><p className="kicker">Bölüm 6</p><h2>Kısa sözlük</h2><p>Sonuç ekranında karşılaşacağın teknik kavramların iş dilindeki karşılığı.</p></div>
            <div className="glossary-list">
              {[
                ["Monte Carlo", "Belirsiz girdilerden tekrar tekrar örnek alıp binlerce olası sonuç üretme yöntemi."],
                ["P10", "Dünyaların yalnız %10’unun altında kaldığı kötü durum eşiği."],
                ["CVaR10", "En kötü %10 dünyanın kendi içindeki ortalama sonucu."],
                ["Duyarlılık", "Bir girdi değiştiğinde çıktının ne kadar birlikte değiştiğini gösteren ölçü."],
                ["Gelecek ailesi", "Benzer olay ve sonuç örüntüsüne sahip simülasyon koşularının grubu."],
                ["Karar sınırı", "Bir koşul değiştiğinde tercih edilen stratejinin A’dan B’ye döndüğü eşik."],
                ["Kalibrasyon", "Tahmin edilen olasılıkların gerçek gerçekleşme sıklıklarıyla uyumunu sınama."],
                ["Historical replay", "Modeli geçmiş bir dönemin başlangıcından çalıştırıp gerçek sonuçla karşılaştırma."],
              ].map(([term, definition]) => <details key={term}><summary>{term}<span>+</span></summary><p>{definition}</p></details>)}
            </div>
          </section>

          <section className="guide-cta">
            <div><p className="kicker">Hazırsın</p><h2>İlk karar modelini rehber eşliğinde kur.</h2><p>Her adımda bu sayfadaki açıklamaların kısa hali sağ panelde görünecek.</p></div><Link className="button button-primary" href="/model-kur">Model kurmaya başla →</Link>
          </section>
        </article>
      </div>

      <AppFooter />
    </main>
  );
}
