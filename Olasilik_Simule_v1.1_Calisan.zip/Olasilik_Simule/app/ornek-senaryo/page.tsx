import Link from "next/link";

import { AppFooter, AppHeader } from "@/components/app-header";
import { ExampleRunner } from "@/components/example-runner";

const inputGroups = [
  { title: "Normal operasyon", rows: [["Aylık talep", "10.000 ürün"], ["Gerçek kapasite", "11.000 ürün"], ["Çalışan", "80 kişi"], ["Kritik makine", "6 adet"]] },
  { title: "Para akışı", rows: [["Birim gelir", "850 TL"], ["Değişken maliyet", "470 TL"], ["Sabit gider", "2,4 Mn TL / ay"], ["Başlangıç nakdi", "12 Mn TL"], ["Tahsilat", "30 gün"]] },
  { title: "Ana riskler", rows: [["Talep oynaklığı", "%16 / ay"], ["Arıza olasılığı", "%7,5 / makine-ay"], ["Devamsızlık", "%4,5"], ["Fire", "%3,5"]] },
];

const strategies = [
  ["A", "Mevcut düzen", "Ek yatırım yok", "Bugünkü yapı referans olarak devam eder."],
  ["B", "Kapasite yatırımı", "7 Mn TL + 180 Bin/ay", "3 ay sonra kalıcı %20 kapasite artışı sağlar."],
  ["C", "Bakım odaklı", "600 Bin TL + 90 Bin/ay", "Arıza riski %42, onarım süresi %30 azalır varsayımı."],
  ["D", "İş gücü dayanıklılığı", "500 Bin TL + 110 Bin/ay", "Yedekleme, çapraz eğitim ve %6 kapasite artışı."],
  ["E", "Dış kaynak tamponu", "300 Bin + 50 Bin/ay + kullanım", "İhtiyaçta kapasitenin %18’i; kullanılan birimde %32 prim."],
];

export default function ExampleScenarioPage() {
  return (
    <main className="example-page">
      <AppHeader active="example" />

      <section className="example-hero shell">
        <div>
          <p className="kicker">Uçtan uca çalışılmış örnek</p>
          <h1>MaviHat Ambalaj Fabrikası</h1>
          <p>Bu örnek, “şirketi simüle etmek” sözünü somutlaştırır: önce karar koridoru seçilir, sonra yalnız o kararı etkileyen operasyon ve para zinciri kurulur.</p>
          <div className="decision-question"><span>Karar sorusu</span><strong>Yoğun talep döneminde yeni makine yatırımı yerine hangi operasyon planı daha dayanıklı?</strong></div>
          <ExampleRunner />
          <small className="example-disclaimer">Şirket ve veriler tamamen temsili; gerçek bir işletme tahmini değildir.</small>
        </div>
        <aside className="example-flow" aria-label="Örnek model akışı">
          <div className="flow-entry"><span>Girdi</span><strong>Talep</strong><small>Büyüme · mevsim · şok</small></div>
          <i>↓</i>
          <div className="flow-split"><div><span>Risk</span><strong>Arıza</strong></div><div><span>Risk</span><strong>Devamsızlık</strong></div><div><span>Risk</span><strong>Tedarik</strong></div></div>
          <i>↓</i>
          <div className="flow-entry cyan"><span>Durum</span><strong>Gerçek kapasite + backlog</strong><small>Fazla mesai · fire · tampon</small></div>
          <i>↓</i>
          <div className="flow-split two"><div><span>Sonuç</span><strong>Teslimat</strong></div><div><span>Sonuç</span><strong>Nakit</strong></div></div>
        </aside>
      </section>

      <section className="example-section example-section-soft">
        <div className="shell">
          <div className="example-section-title"><p className="kicker">1. Karar sözleşmesi</p><h2>Tüm fabrikayı değil, tek karar koridorunu modelle.</h2></div>
          <div className="charter-grid">
            <article><span>Karar sahibi</span><strong>Operasyon + Finans</strong><p>COO teslimatı, CFO nakit sınırını birlikte değerlendiriyor.</p></article>
            <article><span>Zaman ufku</span><strong>12 ay</strong><p>Mevsimsellik ve bakım etkisini görecek kadar uzun.</p></article>
            <article><span>Ana hedef</span><strong>Dayanıklı net sonuç</strong><p>Yalnız ortalama değil, kötü kuyruk ve likidite.</p></article>
            <article><span>Hard constraint</span><strong>2,5 Mn TL nakit</strong><p>Nakit bu tabanın altına inerse strateji riskli sayılıyor.</p></article>
          </div>
        </div>
      </section>

      <section className="example-section shell">
        <div className="example-section-title"><p className="kicker">2. Model girdileri</p><h2>Bir ayın normalini ve nasıl bozulabileceğini tarif et.</h2><p>Bu ilk değerler kesin gerçek değil; modelin davranışını ve veri ihtiyacını göstermek için temsili varsayımlardır.</p></div>
        <div className="example-input-grid">
          {inputGroups.map((group) => <article key={group.title}><h3>{group.title}</h3>{group.rows.map(([label, value]) => <div key={label}><span>{label}</span><strong>{value}</strong></div>)}</article>)}
        </div>
        <div className="interaction-story"><span className="story-mark">+</span><div><p className="kicker">Küçük etki, büyük sonuç</p><h3>Arıza tek başına değil; yanlış anda olduğunda pahalı.</h3><p>Talep yüksekken bir makine arızalanır, aynı ay devamsızlık artar ve tedarik gecikirse kapasite eşiği aşılır. Backlog fazla mesaiyi, fazla mesai yorgunluk ve fireyi, fire yeni backlogu artırır. Simülasyon bu birleşimleri tek tek örnekler.</p></div></div>
      </section>

      <section className="example-section example-section-dark">
        <div className="shell">
          <div className="example-section-title"><p className="kicker">3. Karşılaştırılan stratejiler</p><h2>Her plan aynı 5.000 olası dünyadan geçer.</h2></div>
          <div className="example-strategy-list">
            {strategies.map(([letter, title, cost, text]) => <article key={letter}><span>{letter}</span><div><h3>{title}</h3><p>{text}</p></div><strong>{cost}</strong></article>)}
          </div>
        </div>
      </section>

      <section className="example-section shell">
        <div className="example-section-title"><p className="kicker">4. Sonucu nasıl okuyacaksın?</p><h2>Önce risk, sonra ortalama, sonra neden.</h2></div>
        <div className="example-reading-grid">
          <article><span>01</span><h3>Nakit sıkışması</h3><p>Kaç dünyada 2,5 Mn TL tabanı aşılıyor?</p></article>
          <article><span>02</span><h3>Teslimat ihlali</h3><p>Hangi strateji kapasite şokunda SLA’yı koruyor?</p></article>
          <article><span>03</span><h3>Kötü %10</h3><p>Plan yalnız normal dünyada mı iyi, kötü kuyrukta da mı?</p></article>
          <article><span>04</span><h3>Gelecek aileleri</h3><p>Risk nakit, kapasite, maliyet veya tedarikten mi geliyor?</p></article>
          <article><span>05</span><h3>Neden zinciri</h3><p>Sonucu en çok oynatan varsayım hangisi?</p></article>
        </div>
      </section>

      <section className="example-run-section">
        <div className="shell example-run-card"><div><p className="kicker">Şimdi canlı çalıştır</p><h2>Temsili modeli yükle ve bütün sonuç katmanlarını aç.</h2><p>Sonuç ekranında strateji sıralamasını, dağılımı, gelecek ailelerini, duyarlılıkları ve model sınırını tek tek incele.</p></div><ExampleRunner compact /></div>
      </section>

      <section className="example-next shell"><span>Sonraki adım</span><div><h2>Kendi şirketinin verileriyle aynı akışı kur.</h2><p>Hazır örneği anladıktan sonra şablonu kendi talep, kapasite ve maliyetlerinle değiştir.</p></div><Link className="button button-secondary" href="/model-kur">Kendi modelimi kur →</Link></section>

      <AppFooter />
    </main>
  );
}
