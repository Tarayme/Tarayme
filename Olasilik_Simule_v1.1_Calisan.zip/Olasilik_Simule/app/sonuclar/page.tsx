import { AppHeader } from "@/components/app-header";
import { ResultsDashboard } from "@/components/results-dashboard";

export default function ResultsPage() {
  return (
    <main className="app-page results-page">
      <AppHeader />
      <ResultsDashboard />
    </main>
  );
}
