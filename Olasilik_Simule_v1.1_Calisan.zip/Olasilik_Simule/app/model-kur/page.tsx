import { AppHeader } from "@/components/app-header";
import { ModelWizard } from "@/components/model-wizard";

export default function ModelBuilderPage() {
  return (
    <main className="app-page">
      <AppHeader active="builder" />
      <ModelWizard />
    </main>
  );
}
