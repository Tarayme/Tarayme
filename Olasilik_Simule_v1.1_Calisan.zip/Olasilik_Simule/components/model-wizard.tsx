"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

import {
  COMPANY_TEMPLATES,
  STRATEGIES,
  formatCompactTRY,
  getTemplate,
  normalizeModel,
  validateModel,
} from "@/lib/simulation.mjs";

const STORAGE_KEY = "olasilik-simule:model:v1";
const TOUR_KEY = "olasilik-simule:tour-seen:v1";

type CompanySection = {
  name: string;
  type: string;
  unitLabel: string;
  horizonMonths: number;
  startMonth: number;
};

type DecisionSection = { question: string; goal: string };
type NumberSection = Record<string, number>;

type SimulationModel = {
  company: CompanySection;
  decision: DecisionSection;
  operations: NumberSection;
  risks: NumberSection;
  strategySettings: NumberSection;
  priorities: NumberSection;
  constraints: NumberSection;
  selectedStrategies: string[];
  iterations: number;
  seed: number;
};

type EditableSection =
  | "company"
  | "decision"
  | "operations"
  | "risks"
  | "strategySettings"
  | "priorities"
  | "constraints";

type TemplateDefinition = {
  id: string;
  label: string;
  description: string;
  example: string;
};

type StrategyDefinition = {
  id: string;
  label: string;
  shortLabel: string;
  description: string;
};

const templateCatalog = COMPANY_TEMPLATES as Record<string, TemplateDefinition>;
const strategyCatalog = STRATEGIES as StrategyDefinition[];
const monthNames = [
  "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
  "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık",
];

const wizardSteps = [
  {
    label: "Karar",
    title: "Önce şirketi değil, kararı tanımla",
    lead: "İyi bir simülasyon ‘şirkette ne olacak?’ diye başlamaz. Hangi pahalı kararı test etmek istediğini netleştirir.",
    asideTitle: "Bu adım neden önemli?",
    asideText: "Aynı şirket için yatırım, vardiya veya fiyat kararı bambaşka modeller gerektirir. Dar bir karar sorusu, daha az ama daha doğru değişken demektir.",
    example: "Örnek: Önümüzdeki 12 ayda ek makine mi almalıyım, yoksa yoğunlukta dış kaynak mı kullanmalıyım?",
  },
  {
    label: "Operasyon",
    title: "Şirketin normal çalışma düzenini gir",
    lead: "Önce şok olmayan, sıradan bir ayı tarif et. Talep ile kapasite arasındaki fark modelin ana omurgasıdır.",
    asideTitle: "Kapasite ne demek?",
    asideText: "Bir ayda teorik olarak yapabileceğin değil, normal vardiya düzeninde gerçekten tamamlayabildiğin iyi ürün/hizmet miktarıdır.",
    example: "Ayda 10.000 sipariş geliyor; son 12 ayda normal düzende ortalama 11.000 iyi sipariş tamamlanabiliyor.",
  },
  {
    label: "Para",
    title: "Para akışını sade biçimde tarif et",
    lead: "Sistem her olası ayda satış, tahsilat vadesi, değişken maliyet, sabit gider, gecikme cezası ve strateji maliyetlerini ayrı ayrı işler.",
    asideTitle: "Net sonuç ile nakit aynı değil",
    asideText: "Bir strateji dönem sonunda olumlu görünürken yatırım veya geç tahsilat nedeniyle ilk aylarda nakit tabanını aşabilir. Bu yüzden kararın net sonucu ve nakit yolu ayrı hesaplanır.",
    example: "Başlangıç nakdi 6 milyon TL, yönetimin altına inmek istemediği güvenli taban 2,5 milyon TL olabilir.",
  },
  {
    label: "Riskler",
    title: "Tek sayı yerine belirsizlik aralığını tanımla",
    lead: "Burada kesin tahmin vermiyorsun. Talep, arıza, devamsızlık, fire, tedarik ve maliyetin ne kadar oynayabileceğini söylüyorsun.",
    asideTitle: "Bilmiyorsam ne gireceğim?",
    asideText: "Yaklaşık bir değerle başla ve sonuç ekranında hangi varsayımın kararı değiştirdiğine bak. Önemli çıkan alan için daha sonra gerçek veri toplanır.",
    example: "Aylık arıza olasılığı %7 demek, aynı makinenin her ay kesin %7 kayıp yaratması değil; her olası dünyada arıza olayının ayrıca çekilmesidir.",
  },
  {
    label: "Seçenekler",
    title: "Aynı dünyalarda karşılaştırılacak planları seç",
    lead: "Her strateji aynı talep, maliyet ve dış şok örnekleriyle sınanır. Böylece farkın şanstan mı, kararın kendisinden mi geldiği daha net görünür.",
    asideTitle: "Neden aynı olası dünyalar?",
    asideText: "Bir planı iyi talep, diğerini kötü talep altında çalıştırmak adil değildir. Ortak rastgele örnekler strateji farkını daha temiz ölçer.",
    example: "Bakım planı arıza olasılığını azaltır; dış kaynak planı ise yalnız kapasite yetmediğinde daha pahalı ek kapasite açar.",
  },
  {
    label: "Kontrol",
    title: "Modeli çalıştırmadan önce varsayımları kontrol et",
    lead: "Yanlış birimi, eksik sıfırı veya aşırı kapasite kullanımını burada yakala. Sonra 5.000 olası gelecek üret.",
    asideTitle: "Sonuçta ne göreceksin?",
    asideText: "Beklenen sonuç, kötü %10, nakit sıkışması ve teslimat riski; ardından gelecek aileleri ve en etkili nedenler.",
    example: "Sonuç ‘%72 başarılı’ demekle kalmaz; bu oranın hangi talep-arıza-maliyet birleşimlerinden oluştuğunu açar.",
  },
];

const tourSteps = [
  {
    title: "1. Tek bir karar seç",
    text: "Tüm şirketi bir seferde kopyalamaya çalışma. Önce yanlış verilirse pahalı olacak tek bir kararı seç.",
  },
  {
    title: "2. Bildiğin sayıları gir",
    text: "Normal talep, kapasite, fiyat, maliyet ve nakit. Her alanın altında ne istediğimizi düz Türkçeyle açıklıyoruz.",
  },
  {
    title: "3. Bilmediğini aralık olarak yaz",
    text: "Talep ne kadar oynar? Arıza ve devamsızlık ne sıklıkta olur? Kesin olmak zorunda değilsin; duyarlılık ekranı hangi verinin önemli olduğunu gösterecek.",
  },
  {
    title: "4. Planları aynı koşullarda sınat",
    text: "Sistem 5.000 olası gelecek üretir; her planı aynı dış koşullarda çalıştırır ve yalnız ortalamayı değil kötü durumları da karşılaştırır.",
  },
];

function validationErrorStep(message: string) {
  if (/Şirket|Karar sorusu|Karar ufku|Başlangıç ayı/i.test(message)) return 0;
  if (/Aylık talep|Aylık kapasite|Çalışan sayısı|Kritik kaynak|çalışma günü/i.test(message)) return 1;
  if (/Birim|sabit gider|Başlangıç nakdi|Güvenli nakit|Tahsilat|Gecikme maliyeti/i.test(message)) return 2;
  if (/oynaklığı|Mevsimsellik|arıza|onarım|Devamsızlık|Fire|Tedarik|talep büyümesi/i.test(message)) return 3;
  if (/Yatırım|Bakım|İş gücü|Dış kaynak|plan|strateji|ağırlığı|önceliği/i.test(message)) return 4;
  return 5;
}

function NumberField({
  label,
  description,
  value,
  onChange,
  suffix,
  min = 0,
  max,
  step = 1,
  example,
}: {
  label: string;
  description: string;
  value: number;
  onChange: (value: number) => void;
  suffix?: string;
  min?: number;
  max?: number;
  step?: number;
  example?: string;
}) {
  return (
    <label className="form-field">
      <span className="field-label">{label}</span>
      <span className="field-input-wrap">
        <input
          inputMode="decimal"
          max={max}
          min={min}
          onChange={(event) => onChange(Number(event.target.value))}
          step={step}
          type="number"
          value={Number.isFinite(value) ? value : ""}
        />
        {suffix ? <em>{suffix}</em> : null}
      </span>
      <small>{description}</small>
      {example ? <span className="field-example">Örnek: {example}</span> : null}
    </label>
  );
}

function PercentField(props: Omit<Parameters<typeof NumberField>[0], "value" | "onChange" | "suffix"> & {
  value: number;
  onChange: (value: number) => void;
}) {
  return (
    <NumberField
      {...props}
      max={props.max ?? 100}
      onChange={(value) => props.onChange(value / 100)}
      suffix="%"
      value={Number((props.value * 100).toFixed(2))}
    />
  );
}

function TextField({
  label,
  description,
  value,
  onChange,
  placeholder,
  multiline = false,
}: {
  label: string;
  description: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  multiline?: boolean;
}) {
  return (
    <label className="form-field form-field-wide">
      <span className="field-label">{label}</span>
      {multiline ? (
        <textarea
          onChange={(event) => onChange(event.target.value)}
          placeholder={placeholder}
          rows={3}
          value={value}
        />
      ) : (
        <input
          onChange={(event) => onChange(event.target.value)}
          placeholder={placeholder}
          type="text"
          value={value}
        />
      )}
      <small>{description}</small>
    </label>
  );
}

function SelectField({
  label,
  description,
  value,
  options,
  onChange,
}: {
  label: string;
  description: string;
  value: number;
  options: Array<{ value: number; label: string }>;
  onChange: (value: number) => void;
}) {
  return (
    <label className="form-field">
      <span className="field-label">{label}</span>
      <select onChange={(event) => onChange(Number(event.target.value))} value={value}>
        {options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
      </select>
      <small>{description}</small>
    </label>
  );
}

function ReviewItem({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <div className="review-item">
      <span>{label}</span>
      <strong>{value}</strong>
      {note ? <small>{note}</small> : null}
    </div>
  );
}

export function ModelWizard() {
  const router = useRouter();
  const [model, setModel] = useState<SimulationModel>(() => getTemplate("manufacturing") as SimulationModel);
  const [step, setStep] = useState(0);
  const [ready, setReady] = useState(false);
  const [stepError, setStepError] = useState("");
  const [showTour, setShowTour] = useState(false);
  const [tourStep, setTourStep] = useState(0);

  useEffect(() => {
    function loadDraft() {
      try {
        const saved = window.localStorage.getItem(STORAGE_KEY);
        const wantsNewModel = window.location.hash === "#yeni";
        const shouldStartNew = wantsNewModel && (
          !saved || window.confirm("Mevcut taslağın yerine boş bir şirket modeliyle başlamak istiyor musun?")
        );

        if (wantsNewModel) {
          window.history.replaceState(null, "", `${window.location.pathname}${window.location.search}`);
        }
        if (shouldStartNew) {
          window.localStorage.removeItem(STORAGE_KEY);
          const fresh = getTemplate("manufacturing") as SimulationModel;
          fresh.company.startMonth = new Date().getMonth();
          setModel(fresh);
          setStep(0);
          setStepError("");
        } else if (saved) {
          setModel(normalizeModel(JSON.parse(saved)) as SimulationModel);
        } else {
          setModel((previous) => ({
            ...previous,
            company: { ...previous.company, startMonth: new Date().getMonth() },
          }));
        }
      } catch {
        // Local storage is only a convenience; the model still works without it.
      }
    }

    const timer = window.setTimeout(() => {
      loadDraft();
      try {
        if (!window.localStorage.getItem(TOUR_KEY)) setShowTour(true);
      } catch {
        // The walkthrough can still be opened manually.
      }
      setReady(true);
    }, 0);
    window.addEventListener("hashchange", loadDraft);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("hashchange", loadDraft);
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(model));
    } catch {
      // Ignore browser storage limits and keep the in-memory model.
    }
  }, [model, ready]);

  const validation = useMemo(() => validateModel(model), [model]);
  const current = wizardSteps[step];
  const selectedStrategies = new Set(model.selectedStrategies);

  function updateSection(section: EditableSection, key: string, value: string | number) {
    setModel((previous) => {
      const currentSection = previous[section] as Record<string, string | number>;
      return {
        ...previous,
        [section]: { ...currentSection, [key]: value },
      } as SimulationModel;
    });
    setStepError("");
  }

  function selectTemplate(type: string) {
    const next = getTemplate(type) as SimulationModel;
    const previousName = String(model.company.name ?? "");
    if (previousName && !previousName.startsWith("Örnek")) next.company.name = previousName;
    next.company.startMonth = model.company.startMonth;
    setModel(next);
    setStepError("");
  }

  function toggleStrategy(id: string) {
    if (id === "base") return;
    setModel((previous) => {
      const next = new Set(previous.selectedStrategies);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return { ...previous, selectedStrategies: ["base", ...[...next].filter((item) => item !== "base")] };
    });
  }

  function validateCurrentStep() {
    if (step === 0 && (!model.company.name.trim() || !model.decision.question.trim())) {
      return "Şirket adını ve test etmek istediğin karar sorusunu yazmalısın.";
    }
    if (step === 1 && (!(model.operations.monthlyDemand > 0) || !(model.operations.monthlyCapacity > 0))) {
      return "Aylık talep ve kapasite sıfırdan büyük olmalı.";
    }
    if (step === 2 && (!(model.operations.unitPrice > 0) || model.operations.unitVariableCost < 0)) {
      return "Birim gelir sıfırdan büyük, maliyet ise sıfır veya daha büyük olmalı.";
    }
    if (step === 4 && model.selectedStrategies.length < 2) {
      return "Karşılaştırma için mevcut düzene ek olarak en az bir plan seç.";
    }
    return "";
  }

  function nextStep() {
    const error = validateCurrentStep();
    if (error) {
      setStepError(error);
      return;
    }
    setStepError("");
    setStep((value) => Math.min(wizardSteps.length - 1, value + 1));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function previousStep() {
    setStepError("");
    setStep((value) => Math.max(0, value - 1));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function closeTour() {
    setShowTour(false);
    setTourStep(0);
    try {
      window.localStorage.setItem(TOUR_KEY, "1");
    } catch {
      // Tour state does not affect the model.
    }
  }

  function runModel() {
    if (!validation.valid) {
      const firstError = validation.errors[0] ?? "Model girdilerini kontrol et.";
      setStep(validationErrorStep(firstError));
      setStepError(`Simülasyon başlamadı: ${firstError}`);
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(validation.model));
    } catch {
      // The results page can still use the current navigation in supported browsers.
    }
    router.push("/sonuclar");
  }

  return (
    <>
      <section className="wizard-heading shell">
        <div>
          <p className="kicker">Şirket modeli oluştur</p>
          <h1>{current.title}</h1>
          <p>{current.lead}</p>
        </div>
        <button className="tour-button" onClick={() => setShowTour(true)} type="button">
          <span aria-hidden="true">▶</span>
          2 dakikalık kullanım turu
        </button>
      </section>

      <div className="wizard-shell shell">
        <aside className="wizard-progress" aria-label="Model kurma adımları">
          <div className="progress-title">
            <span>İlerleme</span>
            <strong>{step + 1} / {wizardSteps.length}</strong>
          </div>
          <div className="progress-bar"><span style={{ width: `${((step + 1) / wizardSteps.length) * 100}%` }} /></div>
          <ol>
            {wizardSteps.map((item, index) => (
              <li className={index === step ? "active" : index < step ? "done" : ""} key={item.label}>
                <button onClick={() => index <= step && setStep(index)} type="button">
                  <span>{index < step ? "✓" : index + 1}</span>
                  <div><strong>{item.label}</strong><small>{index === step ? "Şu an buradasın" : index < step ? "Tamamlandı" : "Sırada"}</small></div>
                </button>
              </li>
            ))}
          </ol>
          <div className="autosave-note"><span aria-hidden="true">✓</span>Taslağın bu cihazda otomatik saklanır.</div>
        </aside>

        <section className="wizard-card">
          <div className="wizard-card-topline">
            <span>Adım {step + 1}</span>
            <span>Zorunlu alanlar • ile işaretli</span>
          </div>

          {step === 0 ? (
            <div className="wizard-content">
              <div className="form-section">
                <div className="form-section-heading"><span>1</span><div><h2>Şirket türü</h2><p>İşleyişine en yakın şablonu seç. Sayıları sonraki adımlarda değiştireceksin.</p></div></div>
                <div className="template-grid">
                  {Object.values(templateCatalog).map((template) => (
                    <button
                      className={`template-card ${model.company.type === template.id ? "selected" : ""}`}
                      key={template.id}
                      onClick={() => selectTemplate(template.id)}
                      type="button"
                    >
                      <span className="template-radio" />
                      <strong>{template.label}</strong>
                      <p>{template.description}</p>
                      <small>{template.example}</small>
                    </button>
                  ))}
                </div>
              </div>

              <div className="form-section">
                <div className="form-section-heading"><span>2</span><div><h2>Karar sözleşmesi</h2><p>Modelin neyi karşılaştıracağını tek cümlede tanımla.</p></div></div>
                <div className="form-grid">
                  <TextField
                    description="Rapor ve sonuç ekranında görünecek isim."
                    label="Şirket / operasyon adı •"
                    onChange={(value) => updateSection("company", "name", value)}
                    placeholder="Örn. Konya Üretim Tesisi"
                    value={model.company.name}
                  />
                  <TextField
                    description="İki veya daha fazla gerçek seçeneği içeren, cevabı karar doğuran bir soru yaz."
                    label="Test etmek istediğin karar •"
                    multiline
                    onChange={(value) => updateSection("decision", "question", value)}
                    placeholder="Örn. Yeni makine mi almalıyız, yoksa yoğun dönemde dış kaynak mı kullanmalıyız?"
                    value={model.decision.question}
                  />
                </div>
                <div className="choice-label">Karar ufku</div>
                <div className="choice-row">
                  {[6, 12, 18, 24].map((months) => (
                    <button
                      className={model.company.horizonMonths === months ? "selected" : ""}
                      key={months}
                      onClick={() => updateSection("company", "horizonMonths", months)}
                      type="button"
                    >
                      <strong>{months} ay</strong>
                      <small>{months === 12 ? "Önerilen başlangıç" : months < 12 ? "Kısa dönem" : "Uzun dönem"}</small>
                    </button>
                  ))}
                </div>
                <div className="timing-field">
                  <SelectField
                    description="Mevsimsellik ve kış devamsızlığı bu aydan başlayarak takvime yerleştirilir."
                    label="Simülasyonun başlangıç ayı"
                    onChange={(value) => updateSection("company", "startMonth", value)}
                    options={monthNames.map((label, value) => ({ label, value }))}
                    value={model.company.startMonth}
                  />
                </div>
              </div>
            </div>
          ) : null}

          {step === 1 ? (
            <div className="wizard-content">
              <div className="inline-explainer"><span aria-hidden="true">↔</span><div><strong>İlk kontrol: talep / kapasite oranı</strong><p>Şu an normal talep kapasitenin <b>%{Math.round((model.operations.monthlyDemand / Math.max(1, model.operations.monthlyCapacity)) * 100)}</b>’ünü kullanıyor. %85-95 arası genellikle şoklara karşı hassastır.</p></div></div>
              <div className="form-section">
                <div className="form-section-heading"><span>1</span><div><h2>Akış ve kapasite</h2><p>Normal, şoksuz bir ayı baz al.</p></div></div>
                <div className="form-grid form-grid-2">
                  <NumberField label="Aylık normal talep •" description={`Bir ayda gelen ortalama ${model.company.unitLabel} talebi.`} value={model.operations.monthlyDemand} onChange={(value) => updateSection("operations", "monthlyDemand", value)} suffix={model.company.unitLabel} example="10.000" />
                  <NumberField label="Aylık gerçek kapasite •" description={`Son 12-24 ayda normal koşullarda tamamlayabildiğin ortalama iyi ${model.company.unitLabel} miktarı. Arıza, fire ve devamsızlığın normal etkisini yeniden düşmeyiz; yalnız sapmaları örnekleriz.`} value={model.operations.monthlyCapacity} onChange={(value) => updateSection("operations", "monthlyCapacity", value)} suffix={model.company.unitLabel} example="11.000" />
                  <NumberField label="Çalışan sayısı" description="Bu karar koridorunda kapasiteyi etkileyen toplam çalışan." value={model.operations.workers} onChange={(value) => updateSection("operations", "workers", value)} suffix="kişi" />
                  <NumberField label="Kritik makine / sistem sayısı" description="Arızası üretim veya hizmet akışını azaltan kaynak sayısı." value={model.operations.machines} onChange={(value) => updateSection("operations", "machines", value)} suffix="adet" min={1} max={200} />
                  <NumberField label="Ayda çalışma günü" description="Kapasite ve duruş gününü aynı ölçeğe çevirmek için kullanılır." value={model.operations.workingDays} onChange={(value) => updateSection("operations", "workingDays", value)} suffix="gün" min={1} max={31} />
                  <TextField label="Ölçü birimi" description="Sonuçlarda talep, kapasite ve biriken iş bu birimle gösterilir." value={model.company.unitLabel} onChange={(value) => updateSection("company", "unitLabel", value)} placeholder="ürün, sipariş, hizmet" />
                </div>
              </div>
            </div>
          ) : null}

          {step === 2 ? (
            <div className="wizard-content">
              <div className="form-section">
                <div className="form-section-heading"><span>1</span><div><h2>Birim ekonomi</h2><p>Bir adet ürün, sipariş veya hizmet tamamlandığında oluşan gelir ve maliyet.</p></div></div>
                <div className="form-grid form-grid-2">
                  <NumberField label="Birim gelir •" description={`Tamamlanan bir ${model.company.unitLabel} için elde edilen ortalama net satış geliri.`} value={model.operations.unitPrice} onChange={(value) => updateSection("operations", "unitPrice", value)} suffix="TL" example="850" />
                  <NumberField label="Birim değişken maliyet" description="Malzeme, ambalaj, komisyon gibi yalnız iş yapıldıkça oluşan maliyet." value={model.operations.unitVariableCost} onChange={(value) => updateSection("operations", "unitVariableCost", value)} suffix="TL" example="470" />
                </div>
                <div className={`margin-preview ${model.operations.unitPrice - model.operations.unitVariableCost <= 0 ? "negative" : ""}`}>
                  <span>Birim katkı payı</span>
                  <strong>{formatCompactTRY(model.operations.unitPrice - model.operations.unitVariableCost)}</strong>
                  <small>Sabit gider ve risk maliyetlerinden önce kalan tutar</small>
                </div>
              </div>
              <div className="form-section">
                <div className="form-section-heading"><span>2</span><div><h2>Aylık gider ve nakit sınırı</h2><p>Dönem net sonucu ile nakitte güvende kalmayı ayrı ayrı ölç.</p></div></div>
                <div className="form-grid form-grid-2">
                  <NumberField label="Aylık sabit gider" description="Talep olmasa da ödenen kira, maaş, enerji tabanı ve yönetim giderleri." value={model.operations.fixedMonthlyCost} onChange={(value) => updateSection("operations", "fixedMonthlyCost", value)} suffix="TL" example="2.400.000" />
                  <NumberField label="Başlangıç nakdi" description="Simülasyonun ilk gününde kullanılabilir nakit." value={model.operations.startingCash} onChange={(value) => updateSection("operations", "startingCash", value)} suffix="TL" />
                  <NumberField label="Güvenli nakit tabanı" description="Altına inilmesini nakit sıkışması sayacağın yönetim eşiği." value={model.operations.minimumCash} onChange={(value) => updateSection("operations", "minimumCash", value)} suffix="TL" />
                  <NumberField label="Ortalama tahsilat vadesi" description="Satışın faturalanması ile paranın kasaya girmesi arasındaki ortalama süre. Net karar sonucunu değil, aylık nakit yolunu değiştirir." value={model.operations.collectionDelayDays} onChange={(value) => updateSection("operations", "collectionDelayDays", value)} suffix="gün" max={365} />
                  <PercentField label="Biriken iş / gecikme maliyeti" description="Ay sonunda kalan her işin, birim gelire oranla ceza veya müşteri kaybı maliyeti." value={model.operations.latePenaltyRate} onChange={(value) => updateSection("operations", "latePenaltyRate", value)} step={0.5} max={50} />
                </div>
              </div>
            </div>
          ) : null}

          {step === 3 ? (
            <div className="wizard-content risk-sections">
              <div className="form-section">
                <div className="form-section-heading"><span>1</span><div><h2>Talep belirsizliği</h2><p>Talebin yönünü ve aydan aya ne kadar oynadığını ayrı gir.</p></div></div>
                <div className="form-grid form-grid-3">
                  <PercentField label="Yıllık talep büyümesi" description="Ortalama talebin 12 ay sonunda beklenen yönü. Negatif değer küçülmeyi gösterir." value={model.risks.annualDemandGrowth} onChange={(value) => updateSection("risks", "annualDemandGrowth", value)} min={-80} max={200} step={1} />
                  <PercentField label="Aylık talep oynaklığı" description="Talebin normal çevresinde ne kadar dağılabileceği. Veri yoksa %10-20 makul başlangıçtır." value={model.risks.demandVolatility} onChange={(value) => updateSection("risks", "demandVolatility", value)} max={100} step={1} />
                  <PercentField label="Mevsimsellik gücü" description="Yılın yoğun ve sakin ayları arasındaki düzenli fark." value={model.risks.seasonality} onChange={(value) => updateSection("risks", "seasonality", value)} max={60} step={1} />
                </div>
              </div>
              <div className="form-section">
                <div className="form-section-heading"><span>2</span><div><h2>Operasyon riskleri</h2><p>Arıza, çalışan kapasitesi ve kalite kaybı birlikte çalışır.</p></div></div>
                <div className="form-grid form-grid-2">
                  <PercentField label="Makine başına aylık arıza olasılığı" description="Her kritik makine/sistemin bir ay içinde duruş yaratma ihtimali." value={model.risks.monthlyFailureProbability} onChange={(value) => updateSection("risks", "monthlyFailureProbability", value)} max={80} step={0.5} />
                  <NumberField label="Ortalama onarım süresi" description="Arıza olduğunda kaynağın ortalama kaç çalışma günü kapalı kaldığı." value={model.risks.averageRepairDays} onChange={(value) => updateSection("risks", "averageRepairDays", value)} suffix="gün" step={0.1} max={31} />
                  <NumberField label="Arıza başına doğrudan maliyet" description="Parça, servis ve acil müdahale gideri; kaybedilen kapasite ayrıca hesaplanır." value={model.risks.failureRepairCost} onChange={(value) => updateSection("risks", "failureRepairCost", value)} suffix="TL" />
                  <PercentField label="Normal devamsızlık oranı" description="Toplam çalışan-günün gelinmeyen bölümü; kış etkisi modelde ayrıca artar." value={model.risks.absenceRate} onChange={(value) => updateSection("risks", "absenceRate", value)} max={60} step={0.5} />
                  <PercentField label="Fire / hata oranı" description="Tam kapasitenin kalite nedeniyle satışa veya hizmete dönüşmeyen bölümü." value={model.risks.defectRate} onChange={(value) => updateSection("risks", "defectRate", value)} max={60} step={0.5} />
                </div>
              </div>
              <div className="form-section">
                <div className="form-section-heading"><span>3</span><div><h2>Tedarik ve maliyet</h2><p>Dışarıdan gelen şokların kapasite ve kâra geçişi.</p></div></div>
                <div className="form-grid form-grid-3">
                  <PercentField label="Aylık tedarik gecikmesi olasılığı" description="Malzeme veya kritik girdinin geciktiği ay ihtimali." value={model.risks.supplierDelayProbability} onChange={(value) => updateSection("risks", "supplierDelayProbability", value)} max={90} step={0.5} />
                  <NumberField label="Gecikme olduğunda ortalama süre" description="Bir gecikme olayının kapasiteyi etkilediği ortalama çalışma günü." value={model.risks.supplierDelayDays} onChange={(value) => updateSection("risks", "supplierDelayDays", value)} suffix="gün" step={0.1} max={31} />
                  <PercentField label="Değişken maliyet oynaklığı" description="Malzeme, enerji ve komisyonun baz maliyet çevresinde oynama gücü." value={model.risks.variableCostVolatility} onChange={(value) => updateSection("risks", "variableCostVolatility", value)} max={100} step={1} />
                </div>
              </div>
            </div>
          ) : null}

          {step === 4 ? (
            <div className="wizard-content">
              <div className="form-section">
                <div className="form-section-heading"><span>1</span><div><h2>Karşılaştırılacak planlar</h2><p>Mevcut düzen her zaman referanstır. En az bir müdahale planı daha seç.</p></div></div>
                <div className="strategy-select-grid">
                  {strategyCatalog.map((strategy) => {
                    const selected = selectedStrategies.has(strategy.id);
                    return (
                      <button
                        aria-pressed={selected}
                        className={`strategy-select-card ${selected ? "selected" : ""}`}
                        key={strategy.id}
                        onClick={() => toggleStrategy(strategy.id)}
                        type="button"
                      >
                        <span className="strategy-check">{selected ? "✓" : "+"}</span>
                        <div><strong>{strategy.label}</strong><small>{strategy.shortLabel}</small></div>
                        <p>{strategy.description}</p>
                        {strategy.id === "base" ? <em>Referans · kaldırılamaz</em> : null}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="form-section">
                <div className="form-section-heading"><span>2</span><div><h2>Strateji varsayımları</h2><p>Hazır değerlerle başlayabilir veya maliyet ve etki varsayımlarını değiştirebilirsin.</p></div></div>
                <div className="assumption-accordions">
                  {selectedStrategies.has("investment") ? (
                    <details>
                      <summary><div><strong>Kapasite yatırımı</strong><small>Kapasite +%{Math.round(model.strategySettings.investmentCapacityLift * 100)}, {model.strategySettings.investmentLeadMonths} ayda devrede</small></div><span>Düzenle</span></summary>
                      <div className="form-grid form-grid-2 accordion-fields">
                        <NumberField label="İlk yatırım" description="Makine, hat, ekip, yazılım ve kurulum için simülasyon başında ödenen tutar." value={model.strategySettings.investmentUpfrontCost} onChange={(value) => updateSection("strategySettings", "investmentUpfrontCost", value)} suffix="TL" />
                        <NumberField label="Devreye girdikten sonra aylık gider" description="Bakım, enerji, lisans veya kalıcı ekip için ek aylık sabit gider." value={model.strategySettings.investmentMonthlyCost} onChange={(value) => updateSection("strategySettings", "investmentMonthlyCost", value)} suffix="TL" />
                        <PercentField label="Kalıcı kapasite artışı" description="Yatırım devreye girdikten sonra normal gerçek kapasitedeki artış." value={model.strategySettings.investmentCapacityLift} onChange={(value) => updateSection("strategySettings", "investmentCapacityLift", value)} max={100} />
                        <NumberField label="Devreye alma süresi" description="Yatırımın kapasite üretmeye başlamasına kadar geçen tam ay. İlk ödeme başlangıçta yapılır." value={model.strategySettings.investmentLeadMonths} onChange={(value) => updateSection("strategySettings", "investmentLeadMonths", Math.round(value))} suffix="ay" max={36} />
                      </div>
                    </details>
                  ) : null}
                  {selectedStrategies.has("maintenance") ? (
                    <details>
                      <summary><div><strong>Bakım odaklı plan</strong><small>Arıza riski -%{Math.round(model.strategySettings.maintenanceRiskReduction * 100)}, onarım süresi -%{Math.round(model.strategySettings.maintenanceRepairReduction * 100)}</small></div><span>Düzenle</span></summary>
                      <div className="form-grid form-grid-2 accordion-fields">
                        <NumberField label="İlk yatırım" description="Planın başında ödenen ekipman, yedek parça ve kurulum bütçesi." value={model.strategySettings.maintenanceUpfrontCost} onChange={(value) => updateSection("strategySettings", "maintenanceUpfrontCost", value)} suffix="TL" />
                        <NumberField label="Aylık bakım bütçesi" description="Her ay sabit olarak eklenen planlı bakım maliyeti." value={model.strategySettings.maintenanceMonthlyCost} onChange={(value) => updateSection("strategySettings", "maintenanceMonthlyCost", value)} suffix="TL" />
                        <PercentField label="Arıza riskindeki azalma" description="Bakım planının aylık arıza olasılığını ne kadar düşürdüğü varsayımı." value={model.strategySettings.maintenanceRiskReduction} onChange={(value) => updateSection("strategySettings", "maintenanceRiskReduction", value)} max={95} />
                        <PercentField label="Onarım süresindeki azalma" description="Hazır parça ve plan sayesinde duruş süresindeki azalma." value={model.strategySettings.maintenanceRepairReduction} onChange={(value) => updateSection("strategySettings", "maintenanceRepairReduction", value)} max={95} />
                      </div>
                    </details>
                  ) : null}
                  {selectedStrategies.has("workforce") ? (
                    <details>
                      <summary><div><strong>İş gücü dayanıklılığı</strong><small>Kapasite +%{Math.round(model.strategySettings.workforceCapacityLift * 100)}, devamsızlık etkisi -%{Math.round(model.strategySettings.workforceAbsenceReduction * 100)}</small></div><span>Düzenle</span></summary>
                      <div className="form-grid form-grid-2 accordion-fields">
                        <NumberField label="İlk eğitim / kurulum" description="Çapraz eğitim, işe alım ve süreç düzenleme için başlangıç maliyeti." value={model.strategySettings.workforceUpfrontCost} onChange={(value) => updateSection("strategySettings", "workforceUpfrontCost", value)} suffix="TL" />
                        <NumberField label="Aylık ek ekip maliyeti" description="Yedek ekip, prim ve eğitim devam maliyeti." value={model.strategySettings.workforceMonthlyCost} onChange={(value) => updateSection("strategySettings", "workforceMonthlyCost", value)} suffix="TL" />
                        <PercentField label="Devamsızlık etkisindeki azalma" description="Devamsızlık aynı olsa bile yedekleme sayesinde kaybedilmeyen kapasite." value={model.strategySettings.workforceAbsenceReduction} onChange={(value) => updateSection("strategySettings", "workforceAbsenceReduction", value)} max={95} />
                        <PercentField label="Kapasite artışı" description="Eğitim ve görev esnekliğiyle normal kapasitedeki artış." value={model.strategySettings.workforceCapacityLift} onChange={(value) => updateSection("strategySettings", "workforceCapacityLift", value)} max={80} />
                      </div>
                    </details>
                  ) : null}
                  {selectedStrategies.has("flexible") ? (
                    <details>
                      <summary><div><strong>Esnek dış kaynak tamponu</strong><small>Kapasite sınırı +%{Math.round(model.strategySettings.outsourceCapacityLimit * 100)}, birim maliyet primi +%{Math.round(model.strategySettings.outsourceCostPremium * 100)}</small></div><span>Düzenle</span></summary>
                      <div className="form-grid form-grid-2 accordion-fields">
                        <NumberField label="Kurulum / sözleşme maliyeti" description="Tedarikçi seçimi, entegrasyon ve sözleşme başlangıcında bir kez ödenen tutar." value={model.strategySettings.outsourceUpfrontCost} onChange={(value) => updateSection("strategySettings", "outsourceUpfrontCost", value)} suffix="TL" />
                        <NumberField label="Aylık hazır tutma bedeli" description="Kapasite kullanılmasa da tedarikçiyi hazır tutmak için ödenen aylık sabit bedel." value={model.strategySettings.outsourceMonthlyRetainer} onChange={(value) => updateSection("strategySettings", "outsourceMonthlyRetainer", value)} suffix="TL" />
                        <PercentField label="Satın alınabilir ek kapasite" description="Normal aylık kapasitenin en fazla ne kadarı dışarıdan alınabilir?" value={model.strategySettings.outsourceCapacityLimit} onChange={(value) => updateSection("strategySettings", "outsourceCapacityLimit", value)} max={100} />
                        <PercentField label="Dış kaynak maliyet primi" description="İçerideki birim değişken maliyete göre ek fiyat farkı." value={model.strategySettings.outsourceCostPremium} onChange={(value) => updateSection("strategySettings", "outsourceCostPremium", value)} max={300} />
                      </div>
                    </details>
                  ) : null}
                </div>
              </div>

              <div className="form-section">
                <div className="form-section-heading"><span>3</span><div><h2>Karar öncelikleri</h2><p>Sistem strateji skorunu bu ağırlıkları kendi içinde oranlayarak hesaplar.</p></div></div>
                <div className="priority-list">
                  {[
                    ["profit", "Beklenen net sonuç", "Satıştan operasyon ve strateji harcamaları çıkarılınca kalan"],
                    ["liquidity", "Nakit güvenliği", "Güvenli nakit tabanının korunması"],
                    ["delivery", "Teslimat / hizmet", "Hedef hizmet seviyesinin korunması"],
                    ["resilience", "Kötü duruma dayanıklılık", "En kötü %10 dünyadaki sonuç"],
                  ].map(([key, label, description]) => (
                    <label className="priority-row" key={key}>
                      <div><strong>{label}</strong><small>{description}</small></div>
                      <input max="100" min="0" onChange={(event) => updateSection("priorities", key, Number(event.target.value))} type="range" value={model.priorities[key]} />
                      <span>{model.priorities[key]}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          ) : null}

          {step === 5 ? (
            <div className="wizard-content">
              <div className="review-hero">
                <div><span>Hazır model</span><h2>{model.company.name}</h2><p>{model.decision.question}</p></div>
                <div className="run-count"><strong>{Number(model.iterations).toLocaleString("tr-TR")}</strong><span>olası gelecek</span></div>
              </div>
              <div className="review-grid">
                <ReviewItem label="Karar ufku" value={`${model.company.horizonMonths} ay`} note={`${monthNames[model.company.startMonth]} başlangıcı · ${templateCatalog[model.company.type]?.label}`} />
                <ReviewItem label="Talep / kapasite" value={`%${Math.round((model.operations.monthlyDemand / Math.max(1, model.operations.monthlyCapacity)) * 100)}`} note={`${model.operations.monthlyDemand.toLocaleString("tr-TR")} / ${model.operations.monthlyCapacity.toLocaleString("tr-TR")} ${model.company.unitLabel}`} />
                <ReviewItem label="Aylık brüt satış potansiyeli" value={formatCompactTRY(model.operations.monthlyDemand * model.operations.unitPrice)} note="Normal talep karşılanırsa" />
                <ReviewItem label="Nakit / güvenli taban" value={formatCompactTRY(model.operations.startingCash)} note={`Taban ${formatCompactTRY(model.operations.minimumCash)}`} />
                <ReviewItem label="Karşılaştırılan plan" value={`${model.selectedStrategies.length} strateji`} note={model.selectedStrategies.map((id) => strategyCatalog.find((item) => item.id === id)?.shortLabel).join(" · ")} />
                <ReviewItem label="Ana risk aralığı" value={`Talep ±%${Math.round(model.risks.demandVolatility * 100)}`} note={`Arıza %${(model.risks.monthlyFailureProbability * 100).toFixed(1).replace(".", ",")} / ay`} />
              </div>

              {!validation.valid ? (
                <div className="validation-box danger" id="model-errors" role="alert">
                  <span aria-hidden="true">!</span>
                  <div>
                    <strong>Simülasyondan önce {validation.errors.length} alanı düzelt</strong>
                    <p>Düğme artık kilitli değil. Tıkladığında seni ilk hatanın bulunduğu adıma götürür.</p>
                    <ul className="validation-error-list">
                      {validation.errors.map((error: string) => (
                        <li key={error}>
                          <span>{error}</span>
                          <button onClick={() => setStep(validationErrorStep(error))} type="button">Düzelt →</button>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ) : validation.warnings.length ? (
                <div className="validation-box warning"><span aria-hidden="true">!</span><div><strong>Çalıştırılabilir, fakat kontrol et</strong>{validation.warnings.map((warning: string) => <p key={warning}>{warning}</p>)}</div></div>
              ) : (
                <div className="validation-box success"><span aria-hidden="true">✓</span><div><strong>Temel kontroller geçti</strong><p>Girdiler çalıştırılabilir aralıkta. Sonuç ekranında yine de veri ve model sınırlarını göstereceğiz.</p></div></div>
              )}
              <div className="model-boundary-note">
                <strong>Bu ilk sürüm neyi modelleyecek?</strong>
                <p>Talep → kapasite → arıza / devamsızlık / fire / tedarik → tamamlanan iş → net dönem sonucu / vadeli tahsilat → nakit zinciri. Vergi, amortisman, rakip davranışı, kredi faizi ve ayrıntılı süreç kuyrukları bu genel modelin dışında kalır.</p>
              </div>
            </div>
          ) : null}

          {stepError ? <div className="step-error" role="alert"><span>!</span>{stepError}</div> : null}

          <div className="wizard-actions">
            <button className="button button-secondary" disabled={step === 0} onClick={previousStep} type="button">← Geri</button>
            {step < wizardSteps.length - 1 ? (
              <button className="button button-primary" onClick={nextStep} type="button">Kaydet ve devam et <span aria-hidden="true">→</span></button>
            ) : (
              <button aria-describedby={!validation.valid ? "model-errors" : undefined} className={`button button-primary run-button ${validation.valid ? "" : "needs-attention"}`} onClick={runModel} type="button"><span aria-hidden="true">◆</span> Simülasyonu çalıştır</button>
            )}
          </div>
        </section>

        <aside className="wizard-help">
          <span className="help-icon" aria-hidden="true">i</span>
          <p className="kicker">Adım rehberi</p>
          <h2>{current.asideTitle}</h2>
          <p>{current.asideText}</p>
          <div className="help-example"><strong>Somut örnek</strong><p>{current.example}</p></div>
          <a href="/rehber">Ayrıntılı kullanım rehberi <span aria-hidden="true">→</span></a>
        </aside>
      </div>

      {showTour ? (
        <div className="tour-overlay" role="presentation">
          <section aria-label="Kullanım turu" aria-modal="true" className="tour-modal" role="dialog">
            <button aria-label="Turu kapat" className="tour-close" onClick={closeTour} type="button">×</button>
            <div className="tour-visual" aria-hidden="true">
              <div className="tour-orbit"><span /><span /><span /></div>
              <strong>{tourStep + 1}</strong>
            </div>
            <div className="tour-copy">
              <p className="kicker">Hızlı kullanım turu · {tourStep + 1}/{tourSteps.length}</p>
              <h2>{tourSteps[tourStep].title}</h2>
              <p>{tourSteps[tourStep].text}</p>
              <div className="tour-dots">{tourSteps.map((_, index) => <span className={index === tourStep ? "active" : ""} key={index} />)}</div>
              <div className="tour-actions">
                <button className="button button-secondary" disabled={tourStep === 0} onClick={() => setTourStep((value) => Math.max(0, value - 1))} type="button">Geri</button>
                {tourStep < tourSteps.length - 1 ? (
                  <button className="button button-primary" onClick={() => setTourStep((value) => value + 1)} type="button">Devam et →</button>
                ) : (
                  <button className="button button-primary" onClick={closeTour} type="button">Modeli kurmaya başla</button>
                )}
              </div>
            </div>
          </section>
        </div>
      ) : null}
    </>
  );
}
