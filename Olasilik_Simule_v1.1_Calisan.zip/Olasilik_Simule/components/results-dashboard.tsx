"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import type { CSSProperties } from "react";

import {
  formatCompactTRY,
  formatPercent,
  runSimulation,
} from "@/lib/simulation.mjs";

const STORAGE_KEY = "olasilik-simule:model:v1";

type HistogramBin = { from: number; to: number; count: number; percentage: number };
type Driver = {
  key: string;
  label: string;
  explanation: string;
  correlation: number;
  importance: number;
  direction: "positive" | "negative";
};
type FutureFamily = {
  key: string;
  label: string;
  tone: string;
  description: string;
  count: number;
  probability: number;
  averageProfit: number;
  averageServiceLevel: number;
};
type StrategySummary = {
  id: string;
  label: string;
  shortLabel: string;
  description: string;
  expectedProfit: number;
  medianProfit: number;
  p10Profit: number;
  p90Profit: number;
  cvar10: number;
  probabilityProfit: number;
  probabilityCashCrisis: number;
  probabilitySlaFailure: number;
  expectedEndingCash: number;
  expectedEndingReceivables: number;
  expectedServiceLevel: number;
  expectedFulfillmentRate: number;
  expectedMaximumBacklog: number;
  expectedFailures: number;
  histogram: HistogramBin[];
  drivers: Driver[];
  futureFamilies: FutureFamily[];
  probabilityBeatsBase: number;
  expectedDeltaVsBase: number;
  decisionScore: number;
  scoreComponents: Record<string, number>;
  constraintStatus: { cashRisk: boolean; delivery: boolean };
  constraintEligible: boolean;
};
type ModelData = {
  company: { name: string; type: string; unitLabel: string; horizonMonths: number };
  decision: { question: string; goal: string };
  operations: Record<string, number>;
  risks: Record<string, number>;
  constraints: Record<string, number>;
  selectedStrategies: string[];
  iterations: number;
  seed: number;
};
type SimulationResult = {
  model: ModelData;
  iterations: number;
  seed: number;
  warnings: string[];
  strategies: StrategySummary[];
  recommendation: {
    strategyId: string;
    strategyLabel: string;
    decisionScore: number;
    scoreGap: number;
    strength: string;
    note: string;
    hasFeasibleStrategy: boolean;
    selectedByConstraints: boolean;
  };
};

const tabs = [
  { id: "summary", label: "Karar özeti" },
  { id: "distribution", label: "Dağılım" },
  { id: "families", label: "Gelecek aileleri" },
  { id: "drivers", label: "Neden böyle?" },
  { id: "method", label: "Model sınırı" },
];

function MetricCard({
  label,
  value,
  note,
  tone = "neutral",
}: {
  label: string;
  value: string;
  note: string;
  tone?: string;
}) {
  return (
    <article className={`result-metric ${tone}`}>
      <span>{label}</span>
      <strong>{value}</strong>
      <small>{note}</small>
    </article>
  );
}

function Histogram({ strategy }: { strategy: StrategySummary }) {
  const max = Math.max(...strategy.histogram.map((bin) => bin.count), 1);
  return (
    <div className="histogram-wrap">
      <div className="histogram" aria-label={`${strategy.label} net sonuç dağılımı`}>
        {strategy.histogram.map((bin, index) => (
          <div className="histogram-column" key={`${bin.from}-${index}`}>
            <span
              className={bin.to < 0 ? "loss" : "profit"}
              style={{ height: `${Math.max(4, (bin.count / max) * 100)}%` }}
              title={`${formatCompactTRY(bin.from)} – ${formatCompactTRY(bin.to)}: ${formatPercent(bin.percentage, 1)}`}
            />
          </div>
        ))}
      </div>
      <div className="histogram-axis">
        <span>{formatCompactTRY(strategy.histogram[0]?.from ?? 0)}</span>
        <span>Yıllık sonuç</span>
        <span>{formatCompactTRY(strategy.histogram.at(-1)?.to ?? 0)}</span>
      </div>
      <div className="distribution-markers">
        <div><span>Kötü %10</span><strong>{formatCompactTRY(strategy.p10Profit)}</strong></div>
        <div><span>Ortanca</span><strong>{formatCompactTRY(strategy.medianProfit)}</strong></div>
        <div><span>İyi %10 eşiği</span><strong>{formatCompactTRY(strategy.p90Profit)}</strong></div>
      </div>
    </div>
  );
}

function LoadingState() {
  return (
    <section className="results-loading shell" aria-live="polite">
      <div className="loading-orbit"><span /><span /><span /></div>
      <p className="kicker">Simülasyon çalışıyor</p>
      <h1>Olası gelecekler üretiliyor…</h1>
      <p>Talep, arıza, devamsızlık, fire, tedarik ve maliyet şokları her strateji için aynı dünyalarda deneniyor.</p>
      <div className="loading-steps"><span className="done">Girdiler</span><span className="active">Ortak dünyalar</span><span>Karşılaştırma</span><span>Açıklama</span></div>
    </section>
  );
}

export function ResultsDashboard() {
  const [status, setStatus] = useState<"loading" | "ready" | "empty" | "error">("loading");
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [activeTab, setActiveTab] = useState("summary");
  const [focusId, setFocusId] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    const timer = window.setTimeout(() => {
      try {
        const saved = window.localStorage.getItem(STORAGE_KEY);
        if (!saved) {
          setStatus("empty");
          return;
        }
        const model = JSON.parse(saved) as ModelData;
        const simulation = runSimulation(model) as SimulationResult;
        setResult(simulation);
        setFocusId(simulation.recommendation.strategyId);
        setStatus("ready");
      } catch (error) {
        setErrorMessage(error instanceof Error ? error.message : "Simülasyon çalıştırılamadı.");
        setStatus("error");
      }
    }, 80);
    return () => window.clearTimeout(timer);
  }, []);

  const focused = useMemo(
    () => result?.strategies.find((strategy) => strategy.id === focusId) ?? result?.strategies[0],
    [focusId, result],
  );

  function rerun() {
    if (!result) return;
    setStatus("loading");
    window.setTimeout(() => {
      try {
        const nextSeed = (result.seed + 7919) >>> 0;
        const next = runSimulation({ ...result.model, seed: nextSeed }, { seed: nextSeed }) as SimulationResult;
        setResult(next);
        setFocusId(next.recommendation.strategyId);
        setStatus("ready");
      } catch (error) {
        setErrorMessage(error instanceof Error ? error.message : "Yeni koşu üretilemedi.");
        setStatus("error");
      }
    }, 60);
  }

  if (status === "loading") return <LoadingState />;

  if (status === "empty") {
    return (
      <section className="empty-results shell">
        <span aria-hidden="true">◇</span>
        <p className="kicker">Henüz model yok</p>
        <h1>Önce şirket modelini oluştur.</h1>
        <p>Sonuç ekranı; girdiğin şirket verilerini, riskleri ve stratejileri çalıştırdıktan sonra oluşur.</p>
        <div><Link className="button button-primary" href="/model-kur">Model kurmaya başla →</Link><Link className="button button-secondary" href="/ornek-senaryo">Hazır örneği incele</Link></div>
      </section>
    );
  }

  if (status === "error" || !result || !focused) {
    return (
      <section className="empty-results shell error-state">
        <span aria-hidden="true">!</span><p className="kicker">Model çalışmadı</p><h1>Girdilerden biri düzeltilmeli.</h1><p>{errorMessage}</p>
        <Link className="button button-primary" href="/model-kur">Modele dön ve düzelt</Link>
      </section>
    );
  }

  const best = result.strategies.find((strategy) => strategy.id === result.recommendation.strategyId) ?? result.strategies[0];

  return (
    <>
      <section className="results-heading shell">
        <div>
          <div className="results-breadcrumb"><Link href="/model-kur">Model kur</Link><span>›</span><strong>Sonuçlar</strong></div>
          <p className="kicker">{result.model.company.name} · {result.model.company.horizonMonths} ay</p>
          <h1>{result.model.decision.question}</h1>
        </div>
        <div className="results-heading-actions">
          <Link className="button button-secondary" href="/model-kur">Girdileri düzenle</Link>
          <button className="button button-ghost" onClick={rerun} type="button">↻ Yeni dünyalar üret</button>
        </div>
      </section>

      <section className="recommendation-card shell">
        <div className="recommendation-main">
          <div className="recommendation-label"><span className="pulse-dot" />Önceliklerine göre en dengeli seçenek</div>
          <h2>{result.recommendation.strategyLabel}</h2>
          <p>{result.recommendation.note}</p>
          <div className="recommendation-tags">
            <span>{result.iterations.toLocaleString("tr-TR")} ortak dünya</span>
            <span>{result.recommendation.strength === "kısıt" ? "Kısıtlar belirledi" : result.recommendation.strength === "yakın" ? "Yakın sonuç" : `${result.recommendation.strength} fark`}</span>
            <span>Tohum {result.seed}</span>
          </div>
        </div>
        <div className="decision-score">
          <div className="score-ring" style={{ "--score": `${result.recommendation.decisionScore * 3.6}deg` } as CSSProperties}>
            <span>{Math.round(result.recommendation.decisionScore)}</span><small>/100</small>
          </div>
              <div><strong>Karar skoru</strong><small>Olasılık değildir; net sonuç, nakit, teslimat ve kötü kuyruk alt puanlarının bileşimidir.</small></div>
        </div>
        <div className="recommendation-proof">
          <div><span>Beklenen net sonuç</span><strong>{formatCompactTRY(best.expectedProfit)}</strong></div>
          <div><span>Kötü %10 eşiği</span><strong>{formatCompactTRY(best.p10Profit)}</strong></div>
          <div><span>Nakit sıkışması</span><strong>{formatPercent(best.probabilityCashCrisis)}</strong></div>
          <div><span>Teslimat hedefi ihlali</span><strong>{formatPercent(best.probabilitySlaFailure)}</strong></div>
        </div>
      </section>

      {result.warnings.length ? (
        <div className="result-warning shell"><span>!</span><div><strong>Sonucu okurken dikkat</strong><p>{result.warnings.join(" ")}</p></div></div>
      ) : null}

      <div className="results-workspace shell">
        <aside className="strategy-sidebar">
          <span className="sidebar-label">Ayrıntısını incele</span>
          {result.strategies.map((strategy) => (
            <button className={focusId === strategy.id ? "active" : ""} key={strategy.id} onClick={() => setFocusId(strategy.id)} type="button">
              <span className="strategy-rank">{result.strategies.indexOf(strategy) + 1}</span>
              <div><strong>{strategy.label}</strong><small>Skor {Math.round(strategy.decisionScore)} · {formatCompactTRY(strategy.expectedProfit)}{strategy.constraintEligible ? "" : " · Eşik dışı"}</small></div>
            </button>
          ))}
          <div className="sidebar-note"><strong>Nasıl sıralandı?</strong><p>Önce nakit ve teslimat sınırlarını geçen planlar ayrıldı; sonra dört alt puan seçtiğin ağırlıklarla birleştirildi.</p></div>
        </aside>

        <section className="results-main">
          <div className="results-tabs" role="tablist" aria-label="Sonuç bölümleri">
            {tabs.map((tab) => <button aria-selected={activeTab === tab.id} className={activeTab === tab.id ? "active" : ""} key={tab.id} onClick={() => setActiveTab(tab.id)} role="tab" type="button">{tab.label}</button>)}
          </div>

          {activeTab === "summary" ? (
            <div className="result-tab-panel">
              <div className="panel-title"><div><p className="kicker">{focused.label}</p><h2>Tek sayıya değil, dört ayrı sonuca bak.</h2></div><p>Ortalama net sonuç tek başına yanıltabilir. Kötü kuyruk, nakit ve teslimat riski aynı anda değerlendirilir.</p></div>
              <div className="metric-grid">
                <MetricCard label="Beklenen net sonuç" value={formatCompactTRY(focused.expectedProfit)} note="Satış − operasyon ve strateji harcamaları; muhasebe kârı değildir" tone={focused.expectedProfit >= 0 ? "positive" : "danger"} />
                <MetricCard label="En kötü %10 ortalaması" value={formatCompactTRY(focused.cvar10)} note="Kötü kuyrukta ortalama sonuç" tone={focused.cvar10 >= 0 ? "neutral" : "danger"} />
                <MetricCard label="Nakit sıkışması" value={formatPercent(focused.probabilityCashCrisis)} note={`Beklenen son nakit ${formatCompactTRY(focused.expectedEndingCash)} · taban ${formatCompactTRY(result.model.operations.minimumCash)}`} tone={focused.constraintStatus.cashRisk ? "positive" : "danger"} />
                <MetricCard label="Teslimat hedefi ihlali" value={formatPercent(focused.probabilitySlaFailure)} note={`Hedef ${formatPercent(result.model.constraints?.slaTarget ?? 0.94)}`} tone={focused.constraintStatus.delivery ? "positive" : "warning"} />
              </div>
              <div className="summary-split">
                <div className="summary-chart-card"><div className="card-heading"><div><span>Sonuç dağılımı</span><strong>{focused.label}</strong></div><button onClick={() => setActiveTab("distribution")} type="button">Ayrıntı →</button></div><Histogram strategy={focused} /></div>
                <div className="plain-language-card"><span className="plain-icon">Aa</span><p className="kicker">Düz Türkçeyle</p><h3>{focused.id === result.recommendation.strategyId ? "Bu plan neden önde?" : "Bu planın ana dengesi ne?"}</h3><p>{focused.drivers[0]?.direction === "negative" ? `${focused.drivers[0]?.label}, kötü sonuçları en güçlü biçimde aşağı çekiyor.` : `${focused.drivers[0]?.label}, iyi sonuçlarla en güçlü birlikte hareket eden etken.`} {focused.probabilityCashCrisis > 0.2 ? "Nakit güvenliği zayıf." : "Nakit eşiği çoğu dünyada korunuyor."} {focused.probabilitySlaFailure > 0.3 ? "Fakat teslimat hedefi sık bozuluyor." : "Teslimat hedefi büyük ölçüde korunuyor."}</p><button onClick={() => setActiveTab("drivers")} type="button">Neden zincirini aç →</button></div>
              </div>
              <div className="comparison-table-wrap">
                <div className="card-heading"><div><span>Tüm planlar</span><strong>Aynı {result.iterations.toLocaleString("tr-TR")} dünyada karşılaştırma</strong></div></div>
                <div className="comparison-table">
                  <div className="comparison-table-head"><span>Plan</span><span>Skor</span><span>Beklenen</span><span>Kötü %10</span><span>Nakit riski</span><span>SLA riski</span></div>
                  {result.strategies.map((strategy) => (
                    <button className={strategy.id === focused.id ? "selected" : ""} key={strategy.id} onClick={() => setFocusId(strategy.id)} type="button">
                      <span><i className={strategy.id === result.recommendation.strategyId ? "best" : ""} /> <strong>{strategy.label}</strong></span>
                      <span>{Math.round(strategy.decisionScore)}</span><span>{formatCompactTRY(strategy.expectedProfit)}</span><span>{formatCompactTRY(strategy.p10Profit)}</span><span>{formatPercent(strategy.probabilityCashCrisis)}</span><span>{formatPercent(strategy.probabilitySlaFailure)}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : null}

          {activeTab === "distribution" ? (
            <div className="result-tab-panel">
              <div className="panel-title"><div><p className="kicker">Dağılımı oku</p><h2>Ortalama aynı olsa bile risk aynı değildir.</h2></div><p>Her sütun, benzer yıllık sonuca ulaşan olası dünyaların oranını gösterir.</p></div>
              <div className="large-chart-card"><Histogram strategy={focused} /></div>
              <div className="distribution-explain-grid">
                <article><span>P10</span><h3>Kötü durum eşiği</h3><strong>{formatCompactTRY(focused.p10Profit)}</strong><p>Dünyaların %10’u bu değerden daha kötü sonuçlandı.</p></article>
                <article><span>P50</span><h3>Ortanca dünya</h3><strong>{formatCompactTRY(focused.medianProfit)}</strong><p>Dünyaların yarısı bunun altında, yarısı üstünde kaldı.</p></article>
                <article><span>CVaR10</span><h3>Kötü kuyruğun ortalaması</h3><strong>{formatCompactTRY(focused.cvar10)}</strong><p>En kötü %10 dünyanın kendi içindeki ortalama sonucu.</p></article>
                <article><span>P90</span><h3>İyi durum eşiği</h3><strong>{formatCompactTRY(focused.p90Profit)}</strong><p>Dünyaların yalnız %10’u bu değerden daha iyi sonuçlandı.</p></article>
              </div>
            </div>
          ) : null}

          {activeTab === "families" ? (
            <div className="result-tab-panel">
              <div className="panel-title"><div><p className="kicker">Yüzdenin içini aç</p><h2>{result.iterations.toLocaleString("tr-TR")} dünya, 5 anlaşılır aile.</h2></div><p>Benzer olay ve sonuç örüntüleri bir araya getirilir; milyonlarca dal tek tek gösterilmez.</p></div>
              <div className="family-list">
                {focused.futureFamilies.map((family) => (
                  <article className={`family-card ${family.tone}`} key={family.key}>
                    <div className="family-probability"><strong>{formatPercent(family.probability)}</strong><span>{family.count.toLocaleString("tr-TR")} dünya</span></div>
                    <div><h3>{family.label}</h3><p>{family.description}</p><div className="family-bar"><span style={{ width: `${family.probability * 100}%` }} /></div></div>
                    <div className="family-outcome"><span>Ortalama sonuç</span><strong>{formatCompactTRY(family.averageProfit)}</strong><small>Hizmet {formatPercent(family.averageServiceLevel, 1)}</small></div>
                  </article>
                ))}
              </div>
              <div className="family-note"><span>i</span><p>Bu aileler kural tabanlı bir ilk gruplamadır: nakit sıkışması, kapasite baskısı, maliyet/tedarik şoku, güçlü talep ve dengeli operasyon. Gerçek pilotta sektör verisiyle yeniden kalibre edilir.</p></div>
            </div>
          ) : null}

          {activeTab === "drivers" ? (
            <div className="result-tab-panel">
              <div className="panel-title"><div><p className="kicker">Sonuç → etken → model → girdi</p><h2>Bu sonuç en çok neyle değişiyor?</h2></div><p>Buradaki önem, koşular içindeki istatistiksel duyarlılıktır; tek başına nedensellik kanıtı değildir.</p></div>
              <div className="driver-layout">
                <div className="driver-list">
                  {focused.drivers.map((driver, index) => (
                    <article key={driver.key}>
                      <span className="driver-rank">{index + 1}</span>
                      <div><div className="driver-title"><strong>{driver.label}</strong><span className={driver.direction}>{driver.direction === "positive" ? "Sonucu yukarı taşıyor" : "Sonucu aşağı çekiyor"}</span></div><p>{driver.explanation}</p><div className="driver-bar"><span className={driver.direction} style={{ width: `${Math.max(3, driver.importance * 100)}%` }} /></div></div>
                      <strong className="driver-value">{formatPercent(driver.importance)}</strong>
                    </article>
                  ))}
                </div>
                <aside className="trace-card"><p className="kicker">Açıklama zinciri</p><h3>{focused.drivers[0]?.label}</h3><ol><li><span>1</span><div><strong>Sonuç</strong><small>{formatCompactTRY(focused.expectedProfit)} beklenen sonuç</small></div></li><li><span>2</span><div><strong>Etken</strong><small>{formatPercent(focused.drivers[0]?.importance ?? 0)} göreli duyarlılık payı</small></div></li><li><span>3</span><div><strong>Alt model</strong><small>{focused.drivers[0]?.key === "failureDowntime" ? "Arıza olayı + onarım süresi + kapasite" : "Örnekleme + operasyon akışı + nakit"}</small></div></li><li><span>4</span><div><strong>Girdi</strong><small>Kullanıcı varsayımı; henüz geçmiş veriyle kalibre edilmedi</small></div></li></ol><p className="trace-warning">Karar vermeden önce en önemli 1-2 girdiyi gerçek geçmiş veriyle doğrulamak gerekir.</p></aside>
              </div>
            </div>
          ) : null}

          {activeTab === "method" ? (
            <div className="result-tab-panel">
              <div className="panel-title"><div><p className="kicker">Şeffaf model kartı</p><h2>Bu sonuç ne kadar güvenilir?</h2></div><p>Modelin bildiğini, varsaydığını ve henüz kapsamadığını açıkça ayır.</p></div>
              <div className="model-status-grid">
                <article className="warning"><span>Veri durumu</span><strong>Kullanıcı varsayımı</strong><p>Alanlara girilen değerler geçmiş veriyle otomatik doğrulanmadı.</p></article>
                <article className="warning"><span>Kalibrasyon</span><strong>Henüz yapılmadı</strong><p>Olasılıklar ve ortak şok bağımlılıkları geçmiş veriye göre ayarlanmadı.</p></article>
                <article className="positive"><span>Uygun kullanım</span><strong>Karşılaştırmalı ön analiz</strong><p>Hangi stratejinin hangi risk altında kırıldığını keşfetmek.</p></article>
                <article className="danger"><span>Uygun olmayan kullanım</span><strong>Kesin finansal tahmin</strong><p>Bu sonuç tek başına bütçe, kredi veya yatırım kararı değildir.</p></article>
              </div>
              <div className="method-chain"><div><span>1</span><strong>Talep dağılımı</strong><small>Büyüme + oynaklık + mevsim</small></div><i>→</i><div><span>2</span><strong>Kapasite kaybı</strong><small>Arıza + devamsızlık + tedarik</small></div><i>→</i><div><span>3</span><strong>Operasyon</strong><small>Fire + fazla mesai + dış kaynak</small></div><i>→</i><div><span>4</span><strong>Net sonuç / nakit</strong><small>Karar harcaması + vadeli tahsilat</small></div></div>
              <div className="method-limits"><div><h3>Bu sürümün içinde</h3><ul><li>Aylık talep ve kapasite akışı</li><li>Makine bazlı arıza olayları ve onarım süresi</li><li>Mevsimsel devamsızlık ve kalite kaybı</li><li>Tedarik gecikmesi ve değişken maliyet şoku</li><li>Vadeli tahsilat ile net sonuç / nakit ayrımı</li><li>Ortak dünyalarda beş strateji</li></ul></div><div><h3>Bu sürümün dışında</h3><ul><li>Rakip ve müşteri ajan davranışı</li><li>Ürün bazlı ayrıntılı süreç kuyrukları</li><li>Vergi, amortisman, faiz, kredi ve borç sözleşmeleri</li><li>Açılış alacak/borç bakiyeleri</li><li>Gerçek ERP / sensör entegrasyonu</li><li>Otomatik nedensellik keşfi</li></ul></div></div>
              <div className="next-validation"><span>Sonraki güven seviyesi</span><h3>Historical replay</h3><p>Geçmişte zor geçen 6-24 aylık dönemi modelden sakla; yalnız o dönemin başlangıç verisini verip gerçekleşen talep, arıza, backlog ve nakdi ne kadar iyi yeniden ürettiğini ölç.</p><Link href="/rehber#dogrulama">Doğrulama rehberini aç →</Link></div>
            </div>
          ) : null}
        </section>
      </div>
    </>
  );
}
