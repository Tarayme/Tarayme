"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

import { getTemplate } from "@/lib/simulation.mjs";

const STORAGE_KEY = "olasilik-simule:model:v1";

export function buildExampleModel() {
  const model = getTemplate("manufacturing");
  model.company.name = "MaviHat Ambalaj Fabrikası";
  model.company.horizonMonths = 12;
  model.decision.question = "Yoğun talep döneminde yeni makine yatırımı yerine hangi operasyon planı daha dayanıklı?";
  model.operations.monthlyDemand = 10000;
  model.operations.monthlyCapacity = 11000;
  model.operations.unitPrice = 850;
  model.operations.unitVariableCost = 470;
  model.operations.fixedMonthlyCost = 2400000;
  model.operations.startingCash = 12000000;
  model.operations.minimumCash = 2500000;
  model.operations.collectionDelayDays = 30;
  model.operations.workers = 80;
  model.operations.machines = 6;
  model.risks.annualDemandGrowth = 0.08;
  model.risks.demandVolatility = 0.16;
  model.risks.monthlyFailureProbability = 0.075;
  model.risks.averageRepairDays = 2.8;
  model.risks.absenceRate = 0.045;
  model.risks.defectRate = 0.035;
  model.risks.supplierDelayProbability = 0.1;
  model.risks.variableCostVolatility = 0.075;
  model.selectedStrategies = ["base", "investment", "maintenance", "workforce", "flexible"];
  model.iterations = 5000;
  model.seed = 20260817;
  return model;
}

export function ExampleRunner({ compact = false }: { compact?: boolean }) {
  const router = useRouter();
  const [error, setError] = useState("");

  function runExample() {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(buildExampleModel()));
      router.push("/sonuclar");
    } catch {
      setError("Örnek bu tarayıcıda kaydedilemedi. Model kurma sayfasından devam et.");
    }
  }

  return (
    <div className={compact ? "example-runner compact" : "example-runner"}>
      <button className="button button-primary" onClick={runExample} type="button">Hazır örneği 5.000 dünyada çalıştır <span aria-hidden="true">→</span></button>
      {error ? <p role="alert">{error}</p> : null}
    </div>
  );
}
