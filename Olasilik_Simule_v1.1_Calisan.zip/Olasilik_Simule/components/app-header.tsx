import Link from "next/link";

const links = [
  { href: "/", label: "Ana sayfa", id: "home" },
  { href: "/model-kur", label: "Model kur", id: "builder" },
  { href: "/ornek-senaryo", label: "Örnek senaryo", id: "example" },
  { href: "/rehber", label: "Rehber", id: "guide" },
  { href: "/metodoloji", label: "Metodoloji", id: "method" },
];

export function AppHeader({ active = "" }: { active?: string }) {
  return (
    <header className="site-header app-site-header">
      <div className="shell header-inner">
        <Link className="brand" href="/" aria-label="Olasılık Simüle ana sayfa">
          <span className="brand-mark" aria-hidden="true"><span /></span>
          <span><strong>Olasılık</strong><small>Simüle</small></span>
        </Link>
        <nav className="main-nav app-nav" aria-label="Ana menü">
          {links.map((link) => (
            <Link
              className={active === link.id ? "active" : ""}
              href={link.href}
              key={link.id}
            >
              {link.label}
            </Link>
          ))}
        </nav>
        <Link className="button button-small button-primary header-cta" href="/model-kur#yeni">
          Yeni simülasyon
        </Link>
      </div>
    </header>
  );
}

export function AppFooter() {
  return (
    <footer className="site-footer">
      <div className="shell footer-inner">
        <div className="brand brand-footer">
          <span className="brand-mark" aria-hidden="true"><span /></span>
          <span><strong>Olasılık</strong><small>Simüle</small></span>
        </div>
        <p>Kararları tek tahminle değil, olası geleceklerle sınayın.</p>
      </div>
    </footer>
  );
}
