import assert from "node:assert/strict";
import test from "node:test";

const developmentPreviewMeta =
  /<meta(?=[^>]*\bname=["']codex-preview["'])(?=[^>]*\bcontent=["']development["'])[^>]*>/i;

async function loadWorker() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);
  return worker;
}

async function fetchHtml(worker, path) {
  return worker.fetch(
    new Request(`http://localhost${path}`, { headers: { accept: "text/html" } }),
    {
      ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) },
    },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("renders development preview metadata", async () => {
  const worker = await loadWorker();
  const response = await fetchHtml(worker, "/");

  assert.equal(response.status, 200);
  assert.match(
    response.headers.get("content-type") ?? "",
    /^text\/html\b/i,
  );
  assert.match(await response.text(), developmentPreviewMeta);
});

test("all public routes render their primary content", async () => {
  const worker = await loadWorker();
  const routes = [
    ["/", /Karar vermeden önce/],
    ["/model-kur", /Şirket modeli oluştur/],
    ["/sonuclar", /Simülasyon çalışıyor/],
    ["/rehber", /Bir şirketi simüle etmeye nereden başlayacağım/],
    ["/metodoloji", /Monte Carlo motorun omurgasıdır/],
    ["/ornek-senaryo", /MaviHat Ambalaj Fabrikası/],
  ];

  for (const [path, expected] of routes) {
    const response = await fetchHtml(worker, path);
    assert.equal(response.status, 200, `${path} should return 200`);
    assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);
    assert.match(await response.text(), expected, `${path} should contain its main heading`);
  }
});
