import assert from "node:assert/strict";
import test from "node:test";

import {
  getTemplate,
  runSimulation,
  validateModel,
} from "../lib/simulation.mjs";

function byId(result, id) {
  return result.strategies.find((strategy) => strategy.id === id);
}

test("aynı tohum aynı olası dünyaları ve sonuçları üretir", () => {
  const model = getTemplate("manufacturing");
  const first = runSimulation(model, { iterations: 1200, seed: 4312 });
  const second = runSimulation(model, { iterations: 1200, seed: 4312 });

  assert.deepEqual(first.strategies, second.strategies);
  assert.deepEqual(first.recommendation, second.recommendation);
});

test("özet metrikleri, gelecek aileleri ve duyarlılıklar tutarlı kalır", () => {
  const result = runSimulation(getTemplate("manufacturing"), {
    iterations: 1600,
    seed: 9917,
  });

  for (const strategy of result.strategies) {
    assert.ok(Number.isFinite(strategy.expectedProfit));
    assert.ok(strategy.cvar10 <= strategy.p10Profit + 1e-6);
    assert.ok(strategy.p10Profit <= strategy.medianProfit);
    assert.ok(strategy.medianProfit <= strategy.p90Profit);
    assert.ok(strategy.probabilityCashCrisis >= 0 && strategy.probabilityCashCrisis <= 1);
    assert.ok(strategy.probabilitySlaFailure >= 0 && strategy.probabilitySlaFailure <= 1);
    assert.ok(strategy.expectedServiceLevel >= 0 && strategy.expectedServiceLevel <= 1);

    const histogramTotal = strategy.histogram.reduce((sum, bin) => sum + bin.percentage, 0);
    const familyTotal = strategy.futureFamilies.reduce((sum, family) => sum + family.probability, 0);
    const importanceTotal = strategy.drivers.reduce((sum, driver) => sum + driver.importance, 0);
    assert.ok(Math.abs(histogramTotal - 1) < 1e-9);
    assert.ok(Math.abs(familyTotal - 1) < 1e-9);
    assert.ok(Math.abs(importanceTotal - 1) < 1e-9);
  }
});

test("strateji müdahaleleri hedefledikleri operasyon riskini gerçekten azaltır", () => {
  const result = runSimulation(getTemplate("manufacturing"), {
    iterations: 2400,
    seed: 77331,
  });
  const base = byId(result, "base");
  const investment = byId(result, "investment");
  const maintenance = byId(result, "maintenance");
  const workforce = byId(result, "workforce");
  const flexible = byId(result, "flexible");

  assert.ok(maintenance.expectedFailures < base.expectedFailures);
  assert.ok(investment.probabilitySlaFailure <= base.probabilitySlaFailure);
  assert.ok(workforce.expectedServiceLevel >= base.expectedServiceLevel);
  assert.ok(flexible.probabilitySlaFailure <= base.probabilitySlaFailure);
});

test("üretim, hizmet ve lojistik şablonları beş planı sonlu sonuçlarla çalıştırır", () => {
  for (const type of ["manufacturing", "service", "logistics"]) {
    const result = runSimulation(getTemplate(type), { iterations: 900, seed: 7281 });
    assert.equal(result.strategies.length, 5);
    assert.ok(result.recommendation.strategyId);
    for (const strategy of result.strategies) {
      assert.ok(Number.isFinite(strategy.expectedProfit));
      assert.ok(Number.isFinite(strategy.expectedEndingCash));
      assert.ok(Number.isFinite(strategy.expectedEndingReceivables));
      assert.equal(typeof strategy.constraintEligible, "boolean");
    }
  }
});

test("tahsilat vadesi tahakkuk kârını değiştirmeden nakit riskini taşır", () => {
  const immediateModel = getTemplate("manufacturing");
  immediateModel.selectedStrategies = ["base", "flexible"];
  immediateModel.operations.collectionDelayDays = 0;

  const delayedModel = getTemplate("manufacturing");
  delayedModel.selectedStrategies = ["base", "flexible"];
  delayedModel.operations.collectionDelayDays = 60;

  const immediate = byId(runSimulation(immediateModel, { iterations: 1800, seed: 8321 }), "base");
  const delayed = byId(runSimulation(delayedModel, { iterations: 1800, seed: 8321 }), "base");
  assert.ok(Math.abs(immediate.expectedProfit - delayed.expectedProfit) < 1e-6);
  assert.ok(delayed.expectedEndingCash < immediate.expectedEndingCash);
  assert.ok(delayed.probabilityCashCrisis >= immediate.probabilityCashCrisis);
  assert.ok(delayed.expectedEndingReceivables > immediate.expectedEndingReceivables);
});

test("hard constraint geçen bir plan varken eşik dışı plan önerilmez", () => {
  const model = getTemplate("manufacturing");
  model.operations.monthlyCapacity = 10800;
  const result = runSimulation(model, { iterations: 2200, seed: 1489 });
  const eligible = result.strategies.filter((strategy) => strategy.constraintEligible);
  assert.ok(eligible.length > 0);
  assert.equal(result.strategies[0].constraintEligible, true);
  assert.equal(result.recommendation.hasFeasibleStrategy, true);
});

test("daha yüksek talep belirsizliği sonuç aralığını genişletir", () => {
  const lowRisk = getTemplate("manufacturing");
  lowRisk.selectedStrategies = ["base", "investment"];
  lowRisk.risks.demandVolatility = 0.04;

  const highRisk = getTemplate("manufacturing");
  highRisk.selectedStrategies = ["base", "investment"];
  highRisk.risks.demandVolatility = 0.34;

  const low = byId(runSimulation(lowRisk, { iterations: 2600, seed: 5519 }), "base");
  const high = byId(runSimulation(highRisk, { iterations: 2600, seed: 5519 }), "base");
  assert.ok(high.p90Profit - high.p10Profit > low.p90Profit - low.p10Profit);
});

test("hatalı ve aşırı kapasite girdileri açıkça işaretlenir", () => {
  const invalid = getTemplate("service");
  invalid.operations.monthlyDemand = 0;
  const invalidCheck = validateModel(invalid);
  assert.equal(invalidCheck.valid, false);
  assert.ok(invalidCheck.errors.some((message) => message.includes("Aylık talep")));

  const stressed = getTemplate("logistics");
  stressed.operations.monthlyDemand = stressed.operations.monthlyCapacity * 1.3;
  const stressedCheck = validateModel(stressed);
  assert.equal(stressedCheck.valid, true);
  assert.ok(stressedCheck.warnings.some((message) => message.includes("kapasitenin %115")));

  const malformed = getTemplate("manufacturing");
  malformed.company.startMonth = 12;
  malformed.risks.annualDemandGrowth = -1;
  malformed.priorities = { profit: 0, liquidity: 0, delivery: 0, resilience: 0 };
  malformed.selectedStrategies = ["base"];
  const malformedCheck = validateModel(malformed);
  assert.equal(malformedCheck.valid, false);
  assert.ok(malformedCheck.errors.some((message) => message.includes("Başlangıç ayı")));
  assert.ok(malformedCheck.errors.some((message) => message.includes("talep büyümesi")));
  assert.ok(malformedCheck.errors.some((message) => message.includes("karar önceliğinin")));
  assert.ok(malformedCheck.errors.some((message) => message.includes("karşılaştırma planı")));
});

test("seçilmemiş bir plandaki eski hatalı değer çalıştırmayı kilitlemez", () => {
  const model = getTemplate("manufacturing");
  model.selectedStrategies = ["base", "flexible"];
  model.strategySettings.investmentLeadMonths = -9;
  model.strategySettings.maintenanceRiskReduction = 4;
  model.strategySettings.workforceMonthlyCost = -1;

  const validation = validateModel(model);
  assert.equal(validation.valid, true);
  const result = runSimulation(model, { iterations: 700, seed: 441 });
  assert.equal(result.strategies.length, 2);
});
